<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 缓存管理控制器
 *
 * @version $Id$
 */
class ctl_cache
{
    public static $cache_types = array(
        'user' => '用户管理',
        'task' => '任务管理',
    );

    public function __construct()
    {
    }

    public function index()
    {
        tpl::display('cache.index.tpl');
    }

    /**
     * redis_info Redis服务器信息
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2015-12-18 11:28
     */
    public function redis_info()
    {
        $keyword = req::item('keyword', '');
        $list = pub_redis::info();
        if (!empty($keyword)) 
        {
            $list_tmp = array();
            foreach ($list as $k=>$v) 
            {
                if (strpos($k, $keyword) !== false)
                {
                    $k = str_replace($keyword, "<font color='red'>{$keyword}</font>", $k);
                    $list_tmp[$k] = $v;
                }
            }
            $list = $list_tmp;
        }
        tpl::assign('list', $list);
        tpl::display('cache.redis_info.tpl');
    }
    
    /**
     * 根据keys查询
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2015-12-18 11:28
     */
    public function redis_keys()
    {
        $keyword = req::item('keyword');
        $list = array();
        if (!empty($keyword)) 
        {
            $keys = pub_redis::keys($keyword);
            $list = array();
            foreach ($keys as $key) 
            {
                $key  = str_replace(pub_redis::$prefix.":", "", $key);
                $len  = pub_redis::lsize($key);
                $ttl  = pub_redis::ttl($key);
                $type = pub_redis::type($key);
                $list[] = array(
                    'key'  => $key,
                    'len'  => $len,
                    'ttl'  => $ttl,
                    'type' => $type,
                );
            }
            ksort($list);
        }

        tpl::assign( 'list', $list );
        tpl::display( 'cache.redis_cache.tpl' );
    }

    /**
     * 显示缓存内容
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2015-12-18 11:28
     */
    public function show_cache()
    {
        $key  = req::item('key', '');
        $type = pub_redis::type($key);
        // 如果是队列
        if ($type == 'list') 
        {
            $val = pub_redis::rpop($key);
        }
        else 
        {
            $val = pub_redis::get($key);
        }
        if (empty($val)) 
        {
            exit("The value of {$key} does not exist");
        }
        if (util::is_json($val)) 
        {
            $val = pub_redis::decode($val);
        }
        echo '<pre>';print_r($val);echo '</pre>';
    }

    /**
     * 删除Redis对应Key的内容
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2015-12-18 11:28
     */
    public function del()
    {
        $keys = req::item('keys', '');

        foreach ($keys as $key) 
        {
            pub_redis::del($key);
        }

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除Redis缓存 ".implode(",", $keys));

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=cache&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    /**
     * 清除缓存
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2016-09-02 12:05
     */
    public function clear()
    {
        $type = req::item("type", "user");
        $method = 'clear_'.$type;
        mod_cache::$method();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "清除".self::$cache_types[$type]."缓存");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=cache&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "清除".self::$cache_types[$type]."缓存成功", $gourl);
    }
}

