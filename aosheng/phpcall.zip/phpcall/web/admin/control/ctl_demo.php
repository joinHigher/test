<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 测试
 *
 * @version $Id$
 */
class ctl_demo
{
    public function __construct()
    {
    }

    public function index()
    {
        tpl::display('demo.index.tpl');
    }

}
