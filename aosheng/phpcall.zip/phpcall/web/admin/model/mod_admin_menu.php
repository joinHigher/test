<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 管理菜单读取
 *
 * @version $Id$
 */
class mod_admin_menu
{
    public static $menu_key = 'admin_menu';
    public static $apps = array();

    public static function parse_menu()
    {
        config::reload();
        $config = config::get( self::$menu_key );
        $config = cls_menu::replace_app_menu($config);
        $values = cls_menu::xml_to_array($config);
        $values = cls_menu::set_parentid($values);
        return json_encode($values, JSON_UNESCAPED_UNICODE);
    }

    public static function get_purviews($check_purview = false)
    {
        config::reload();
        $config = config::get( self::$menu_key );
        if ( !$check_purview ) 
        {
            // 不进行权限过滤，也不进行 diaplay='none' 过滤
            cls_menu::$is_auth = false;
            cls_menu::$is_hide = false;
        }
        $config = cls_menu::replace_app_menu($config);
        $values = cls_menu::xml_to_array($config);
        $values = cls_menu::set_parentid($values);
        return $values;
    }

    /**
     * 分析菜单，返回特定格式的js，两层菜单
     * @return string
     */
    public static function parse_menu_two()
    {
        config::reload();
        $menu_config = config::get( self::$menu_key );
        self::replace_app_menu( $menu_config );
        //echo $menu_config;
        $menu = '';
        preg_match_all("#<menu([^>]*)>(.*)</menu>#sU", $menu_config, $arr);
        $j = 0;
        foreach($arr[1] as $k=>$v)
        {
            $mi = ++$j;
            $atts     = self::parse_atts($v);
            $m_name   = self::get_att($atts, 'name');
            $m_class  = self::get_att($atts, 'class');
            $m_url    = self::get_att($atts, 'url');
            $m_ct     = self::get_att($atts, 'ct');
            $m_ac     = self::get_att($atts, 'ac');
            $m_reload = self::get_att($atts, 'reload');
            $default  = self::get_att($atts, 'default');
            $display  = self::get_att($atts, 'display');
            if( $m_url == '' && ( $m_ct != '' && $m_ac !='' ) ) 
            {
                $m_url = "?ct={$m_ct}&ac={$m_ac}";
            }
            $m_class = $m_class=='' ? 'default' : $m_class;
            if( $display == 'none' ) continue;
            // ct 和 ac 都不为空，判断一下权限
            if( ( $m_ct != '' && $m_ac !='' ) && !self::has_purview($m_ct, $m_ac) ) continue;
            if( $m_reload==1 ) $m_reload = ',Reload:true';
            if( $default==1 ) $default = ',Default:true';
            if( $m_url != '' ) $m_url = ",Url:'{$m_url}'";
            $topmm = "'{$mi}': {Text:'{$m_name}', Class:'{$m_class}'{$m_url}{$m_reload}{$default}},\n";
            //if( trim($arr[2][$k]) == '') continue;
            // 没有子栏目 或者 没有URL
            if( trim($arr[2][$k]) == '' || $m_url != '' ) 
            {
                $menu .= $topmm;
            }
            else
            {
                preg_match_all("#<item([^>]*)/>#sU", $arr[2][$k], $items);
                $sonmm = '';
                foreach($items[1] as $i=>$i_v)
                {
                    $ii = ++$j;
                    $df = '';
                    $atts      = self::parse_atts($i_v);
                    $i_name    = self::get_att($atts, 'name');
                    $i_class   = self::get_att($atts, 'class');
                    $i_url     = self::get_att($atts, 'url');
                    $i_ct      = self::get_att($atts, 'ct');
                    $i_ac      = self::get_att($atts, 'ac');
                    $i_reload  = self::get_att($atts, 'reload');
                    $default   = self::get_att($atts, 'default');
                    $display   = self::get_att($atts, 'display');
                    $i_class = $i_class=='' ? 'default' : $i_class;
                    if( $display == 'none' ) continue;
                    //var_dump($i_name, $i_url, $i_class, $display);
                    if( !self::has_purview($i_ct, $i_ac) ) continue;
                    if( $i_url == '' ) 
                    {
                        $i_url = "?ct={$i_ct}&ac={$i_ac}";
                    }
                    if( $i_reload==1 ) $i_reload = ',Reload:true';
                    if( $default==1 ) $default = ',Default:true';
                    if( $i_url != '' ) $i_url = ",Url:'{$i_url}'";
                    $sonmm .= "    '{$ii}':{Text:'{$i_name}', Class:'{$i_class}', Parent:'{$mi}'{$i_url}{$i_reload}{$default}},\n";
                }
                if( $sonmm != '' )
                {
                    $menu .= $topmm.$sonmm;
                }
            } 
        }
        //echo $menu;exit;
        return $menu;
    }

    /**
     * 分析菜单，返回特定格式的js，三层菜单
     * @return string
     */
    public static function parse_menu_three()
    {
        //config::reload();
        $menu_config = config::get( self::$menu_key );
        //echo $menu_config;exit;
        self::replace_app_menu( $menu_config );
        $menu = '';
        preg_match_all("#<menu([^>]*)>(.*)</menu>#sU", $menu_config, $arr);
        $j = 0;
        foreach($arr[1] as $k=>$v)
        {
            $mi = ++$j;
            $atts    = self::parse_atts($v);
            $m_name  = self::get_att($atts, 'name');
            $m_class = self::get_att($atts, 'class');
            $display = self::get_att($atts, 'display');
            //var_dump($m_name, $display, $m_class);
            $m_class = $m_class=='' ? 'default' : $m_class;
            if( $display == 'none' ) continue;
            $topmm = "'{$mi}': {Text:'{$m_name}', Class:'{$m_class}'},\n";
            if( trim($arr[2][$k]) == '') continue;
            preg_match_all("#<node([^>]*)>(.*)</node>#sU", $arr[2][$k], $nodes);
            $sonmm = '';
            foreach($nodes[1] as $n=>$n_v)
            {
                $ni = ++$j;
                $df = '';
                $atts      = self::parse_atts($n_v);
                $n_name    = self::get_att($atts, 'name');
                $n_class   = self::get_att($atts, 'class');
                $n_url     = self::get_att($atts, 'url');
                $n_reload  = self::get_att($atts, 'reload');
                $default   = self::get_att($atts, 'default');
                $display   = self::get_att($atts, 'display');
                //var_dump($n_name, $n_class, $display);
                $n_class = $n_class=='' ? 'default' : $n_class;
                if( $display == 'none' ) continue;
                if( $n_reload==1 ) $n_reload = ',Reload:true';
                if( $default == 1 ) $default = ',Default:true';
                if( $n_url != '' ) $n_url = ",Url:'{$n_url}'";
                $sonmm_tmp = "    '{$ni}':{Text:'{$n_name}', Class:'{$n_class}', Parent:'{$mi}'{$n_url}{$n_reload}{$default}},\n";
                // 没有子栏目也没有URL
                //if( trim($nodes[2][$n]) == '' && $n_url == '' ) continue;
                // 没有子栏目 或者 没有URL
                if( trim($nodes[2][$n]) == '' || $n_url != '' ) 
                {
                    $sonmm .= $sonmm_tmp;
                }
                else 
                {
                    preg_match_all("#<item([^>]*)/>#sU", $nodes[2][$n], $items);
                    $sonmm2 = '';
                    foreach($items[1] as $i=>$i_v)
                    {
                        $ii = ++$j;
                        $df = '';
                        $atts      = self::parse_atts($i_v);
                        $i_name    = self::get_att($atts, 'name');
                        $i_class   = self::get_att($atts, 'class');
                        $i_url     = self::get_att($atts, 'url');
                        $i_reload  = self::get_att($atts, 'reload');
                        $i_ct      = self::get_att($atts, 'ct');
                        $i_ac      = self::get_att($atts, 'ac');
                        $default   = self::get_att($atts, 'default');
                        $display   = self::get_att($atts, 'display');
                        $i_class = $i_class=='' ? 'default' : $i_class;
                        if( $display == 'none' ) continue;
                        //var_dump($i_name, $i_url, $i_class, $display);
                        if( !self::has_purview($i_ct, $i_ac) ) continue;
                        if( $i_url == '' ) 
                        {
                            $i_url = "?ct={$i_ct}&ac={$i_ac}";
                        }
                        if( $i_reload==1 ) $i_reload = ',Reload:true';
                        if( $default==1 ) $default = ',Default:true';
                        if( $i_url != '' ) $i_url = ",Url:'{$i_url}'";
                        $sonmm2 .= "        '{$ii}':{Text:'{$i_name}', Class:'{$i_class}', Parent:'{$ni}'{$i_url}{$i_reload}{$default}},\n";
                    }
                    if( $sonmm2 != '' )
                    {
                        $sonmm .= $sonmm_tmp.$sonmm2;
                    }
                }
            }
            if( $sonmm != '' )
            {
                $menu .= $topmm.$sonmm;
            }
        }
        return $menu;
    }

    public static function get_purviews_two($check_purview = false)
    {
        //$menu_file = PATH_CONFIG.'/'.self::$menu_file;
        //$lines = file($menu_file);
        $menu_config = config::get( self::$menu_key );
        self::replace_app_menu( $menu_config );
        $menus = array();
        preg_match_all("#<menu([^>]*)>(.*)</menu>#sU", $menu_config, $arr);

        foreach($arr[1] as $k=>$v)
        {
            $atts = self::parse_atts($v);
            $name = self::get_att($atts, 'name');
            $ct   = self::get_att($atts, 'ct');
            $ac   = self::get_att($atts, 'ac');

            if( $check_purview && ( $ct != '' && $ac !='' ) && !self::has_purview($ct, $ac) ) continue;

            $purview = empty($ct) && empty($ac) ? '' : $ct.'-'.$ac; 
            $menus[$k] = array(
                'name'    => $name,
                'purview' => $purview,
            );

            // 不存在子内容
            if( trim($arr[2][$k]) == '') continue;

            preg_match_all("#<item([^>]*)/>#sU", $arr[2][$k], $items);
            foreach($items[1] as $kk=>$vv)
            {
                $atts = self::parse_atts($vv);
                $name = self::get_att($atts, 'name');
                $ct   = self::get_att($atts, 'ct');
                $ac   = self::get_att($atts, 'ac');

                if( $check_purview && ( $ct != '' && $ac !='' ) && !self::has_purview($ct, $ac) ) continue;

                $purview = empty($ct) && empty($ac) ? '' : $ct.'-'.$ac; 
                $menus[$k]['submenus'][] = array(
                    'name'    => $name,
                    'purview' => $purview,
                );
            }

            if (empty($menus[$k]['submenus'])) 
            {
                unset($menus[$k]);
            }
        }
        return $menus;
    }

    //获取权限列表
    public static function get_purviews_three()
    {
        $menu_config = config::get( self::$menu_key );
        self::replace_app_menu( $menu_config );
        $menu = array ();
        preg_match_all("#<menu([^>]*)>(.*)</menu>#sU", $menu_config, $arr);
        $i = 0;
        foreach($arr[1] as $ak=>$v)
        {
            $mi = $i++;
            $atts    = self::parse_atts($v);
            $m_name  = self::get_att($atts, 'name');
            $m_class = self::get_att($atts, 'class');

            $menu[$mi]['name'] = $m_name;
            $menu[$mi]['layer'] = 1;
            $menu[$mi]['class'] = $m_class;
            $menu[$mi]['child'] = array ();
            if( trim($arr[2][$ak]) == '') continue;

            preg_match_all("#<node([^>]*)>(.*)</node>#sU", $arr[2][$ak], $nodes);
            $j = 0;
            foreach($nodes[1] as $nk=>$n_v)
            {
                $ni = $j++;
                $atts      = self::parse_atts($n_v);
                $n_name    = self::get_att($atts, 'name');
                $n_class   = self::get_att($atts, 'class');

                $menu[$mi]['child'][$ni]['name'] = $n_name;
                $menu[$mi]['child'][$ni]['layer'] = 2;
                $menu[$mi]['child'][$ni]['class'] = $n_class;
                $menu[$mi]['child'][$ni]['child'] = array ();

                preg_match_all("#<item([^>]*)/>#sU", $nodes[2][$nk], $items);
                $k = 0;
                foreach($items[1] as $ik=>$i_v)
                {
                    $ii = $k++;
                    $atts    = self::parse_atts($i_v);
                    $i_name  = self::get_att($atts, 'name');
                    $i_class = self::get_att($atts, 'class');
                    $i_ct    = self::get_att($atts, 'ct');
                    $i_ac    = self::get_att($atts, 'ac');

                    $menu[$mi]['child'][$ni]['child'][$ii]['name'] = $i_name;
                    $menu[$mi]['child'][$ni]['child'][$ii]['layer'] = 3;
                    $menu[$mi]['child'][$ni]['child'][$ii]['class'] = $i_class;
                    $menu[$mi]['child'][$ni]['child'][$ii]['purview'] = $i_ct.'-'.$i_ac;
                }
            }

        }
        return $menu;
    }

    /**
     * 检测用户是否有指定权限
     * @parem string $ct
     * @parem string $ac
     * @return bool
     */
    protected static function has_purview($ct, $ac)
    {
        $rs = call::$auth->check_purview($ct, $ac, 2);
        if( $rs==1 )
        {
            return true;
        } 
        else
        {
            return false;
        }
    }

    /**
     * 分析菜单，返回所有项的名称(用于设置用户权限时显示应用信息)
     * @return string
     */
    public static function parse_apps()
    {
        if( !empty(self::$apps) ) 
        {
            return self::$apps;
        }
        $menu_config = config::get( self::$menu_key );
        $menu = '';
        preg_match_all("#<menu([^>]*)>(.*)</menu>#sU", $menu_config, $arr);
        $j = 0;
        foreach($arr[1] as $k => $v)
        {
            if( trim($arr[2][$k]) == '') 
            {
                continue;
            }
            preg_match_all("#<node([^>]*)>(.*)</node>#sU", $arr[2][$k], $nodes);
            foreach($nodes[1] as $n => $n_v)
            {
                $atts = self::parse_atts($n_v);
                $app       = self::get_att($atts, 'ct');
                $app_name  = self::get_att($atts, 'appname');
                if( $app != '' ) 
                {
                    self::$apps[$app]['app_name'] = $app_name;
                }
                if( $nodes[2][$n]=='' ) 
                {
                    continue;
                }
                preg_match_all("#<item([^>]*)/>#sU", $nodes[2][$n], $items);
                foreach($items[1] as $i => $i_v)
                {
                    $atts = self::parse_atts($i_v);
                    $i_name = self::get_att($atts, 'name');
                    $i_ct = self::get_att($atts, 'ct');
                    $i_ac = self::get_att($atts, 'ac');
                    if( !isset(self::$apps[$i_ct][$i_ac]) ) 
                    {
                        self::$apps[$i_ct][$i_ac] = $i_name;
                    }
                }
            }
        }
        return self::$apps;
    }

    /**
     * 分析属性
     * @parem string $attstr
     * @return array
     */
    protected static function parse_atts($attstr)
    {
        $patts = '';
        preg_match_all("/([0-9a-z_-]*)[\t ]{0,}=[\t ]{0,}[\"']([^>\"']*)[\"']/isU", $attstr, $patts);
        if( !isset($patts[1]) )
        {
            return false;
        }
        $atts = array();
        foreach($patts[1] as $ak=>$attname)
        {
            $atts[trim($attname)] = trim($patts[2][$ak]);
        }
        return $atts;
    }

    /**
     * 从属性数组中读取一个元素
     * @parem $atts
     * @parem $key
     * @parem $df = ''
     * @return string
     */
    protected static function get_att(&$atts, $key, $df='')
    {
        return isset($atts[$key]) ? trim($atts[$key]) : $df;
    }
}

