<?php
defined('PHPCALL') or exit('Request Error!');

class cls_crypt
{
    /**
     * encode
     * 
     * @param mixed $value
     * @param string $key
     * @param string $type phpcall|aes
     * @return void
     */
    public static function encode($value, $key = '', $type = 'phpcall')
    {
        if ( strlen($key) != 32 ) 
        {
            $msg = '加密Key必须满足32位';
            log::error($msg, __method__);
            throw new Exception($msg);
        }

        if ( $type == 'phpcall' && function_exists('phpcall_encrypt') ) 
        {
            $value = phpcall_encrypt($value, $key);
        }
        else 
        {
            cls_aes::instance()->set_key(substr($key, 0, 16));
            cls_aes::instance()->set_iv(substr($key, 16, 16));
            $value = cls_aes::instance()->encrypt($value);
        }

        $value = self::safe_b64encode($value);
        return $value;
    }

    /**
     * decode
     * 
     * @param mixed $value
     * @param string $key
     * @param string $type phpcall|aes
     * @return void
     */
    public static function decode($value, $key = '', $type = 'phpcall')
    {
        if ( strlen($key) != 32 ) 
        {
            $msg = '加密Key必须满足32位';
            log::error($msg, __method__);
            throw new Exception($msg);
        }

        $value = self::safe_b64decode($value);

        if ( $type == 'phpcall' && function_exists('phpcall_encrypt') ) 
        {
            $value = phpcall_decrypt($value, $key);
        }
        else 
        {
            cls_aes::instance()->set_key(substr($key, 0, 16));
            cls_aes::instance()->set_iv(substr($key, 16, 16));
            $value = cls_aes::instance()->decrypt($value);
        }
        return $value;
    }

    /**
	 * generate a URI safe base64 encoded string
	 *
	 * @param	string	$value
	 * @return	string
	 */
	protected static function safe_b64encode($value)
	{
		$data = base64_encode($value);
		$data = str_replace(array('+', '/', '='), array('-', '_', ''), $data);
		return $data;
	}

	/**
	 * decode a URI safe base64 encoded string
	 *
	 * @param	string	$value
	 * @return	string
	 */
	protected static function safe_b64decode($value)
	{
		$data = str_replace(array('-', '_'), array('+', '/'), $value);
		$mod4 = strlen($data) % 4;
		if ($mod4)
		{
			$data .= substr('====', $mod4);
		}
		return base64_decode($data);
	}

	protected static function bin2hex($value)
    {
        return @bin2hex($value);
    }

	protected static function hex2bin($value)
    {
        return @pack('H*', $value);
    }
}
