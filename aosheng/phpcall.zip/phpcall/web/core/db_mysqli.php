<?php
if (!defined('PHPCALL')) exit('Request Error!');
/**
 * 数据库操作类 <<读写分离>>
 *
 * 读 - mysql slave 1
 *    - mysql slave 2
 *    ......
 *
 * 写 - master
 *
 * @author seatle<seatle@foxmail.com>
 * @version $Id$
 */
class db extends db_base
{

    protected static function _init($is_master = false)
    {
        // 获取配置
        $db_config = (self::$link_name == 'default' ? self::_get_default_config() : self::$configs[self::$link_name]);
        // 连接属性及host
        if ($is_master === true)
        {
            $link = 'w';
            $host = $db_config['host']['master'];
        }
        else
        {
            $link = 'r';
            $key = array_rand($db_config['host']['slave']);
            $host = $db_config['host']['slave'][$key];
        }
        // 创建连接
        if (empty(self::$links[self::$link_name][$link]))
        {
            try
            {
                list($host, $port) = explode(':', $host);
                if (empty($port)) $port = 3306;
                self::$links[self::$link_name][$link] = mysqli_connect($host, $db_config['user'], $db_config['pass'], $db_config['name'], $port);
                if ( self::$links[self::$link_name][$link] === false )
                {
                    throw new Exception("Connect MySql Error! ");
                }
                else
                {
                    $charset = str_replace('-', '', strtolower($db_config['charset']));
                    mysqli_query(self::$links[self::$link_name][$link], " SET character_set_connection=" . $charset . ", character_set_results=" . $charset . ", character_set_client=binary, sql_mode='' ");
                }
            }
            catch (Exception $e)
            {
                call::fatal_error('db.php _init()', $e->getMessage() . ' page: ' . util::get_cururl());
            }
        }
        self::$cur_link = self::$links[self::$link_name][$link];
        return self::$links[self::$link_name][$link];
    }

    public static function query_run($sql, $is_master = false)
    {
        if ($sql === '')
        {
            log::error('Invalid query: '.$sql);
            return FALSE;
        }

        // Save the query for debugging
        self::$queries[] = $sql;

        // Start the Query Timer
        $time_start = microtime(TRUE);

        // 对SQL语句进行安全过滤
        if (self::$safe_test == true)
        {
            $sql = self::_filter_sql($sql);
        }

        // 强制使用主数据库
        if ($is_master === true)
        {
            self::$cur_link = self::_init(true);
        }
        else
        {
            if (substr(strtolower($sql), 0, 1) === 's')
            {
                self::$cur_link = self::_init(false);
            }
            else
            {
                self::$cur_link = self::_init(true);
            }
        }

        try
        {
            self::$cur_result = mysqli_query(self::$cur_link, self::get_sql($sql));
            // self::$results[ self::$cur_result ] = self::$cur_result;

            // Stop and aggregate the query time results
            $time_end = microtime(TRUE);
            $querytime = $time_end - $time_start;
            self::$query_times[] = $querytime;

            // 记录慢查询
            if ( self::$log_slow_query && ($querytime > self::$log_slow_time) )
            {
                self::_slow_query_log($sql, $querytime);
            }

            // SQL执行不成功
            if (self::$cur_result === false)
            {
                $err_msg = 'Query error: '.mysqli_error(self::$cur_link).' - Invalid query: '.$sql;
                self::_error_query_log($err_msg);
                throw new Exception($err_msg);
            }
            else
            {
                self::$query_count++;
                return self::$cur_result;
            }
        }
        catch (Exception $e)
        {
            call::fatal_error('db.php query()', $e->getMessage() . ' - Access page:' . util::get_cururl());
        }
    }

    public static function query_over($sql)
    {
        // 执行一个不中断的SQL语句，强制主库执行，别写数据到从库就玩大了
        self::$cur_link = self::_init(true);
        if (self::$safe_test == true)
        {
            $sql = self::_filter_sql($sql);
        }
        $rs = @mysqli_query(self::$cur_link, self::get_sql($sql));
        return $rs;
    }

    public static function insert_id()
    {
        return mysqli_insert_id(self::$cur_link);
    }


    public static function affected_rows()
    {
        return mysqli_affected_rows(self::$cur_link);
    }


    public static function num_rows($rsid = '')
    {
        $rsid = self::_get_rsid($rsid);
        return mysqli_num_rows($rsid);
    }


    public static function fetch_one($rsid = '', $result_type = DB_GET_ASSOC)
    {
        $rsid = self::_get_rsid($rsid);
        $row = mysqli_fetch_array($rsid, $result_type);
        return $row;
    }


    public static function fetch($rsid = '', $result_type = DB_GET_ASSOC)
    {
        return self::fetch_one($rsid, $result_type);
    }


    public static function fetch_all($rsid = '', $result_type = DB_GET_ASSOC)
    {
        $rsid = self::_get_rsid($rsid);
        $row = $rows = array();
        while ($row = mysqli_fetch_array($rsid, $result_type))
        {
            $rows[] = $row;
        }
        mysqli_free_result($rsid);
        return empty($rows) ? false : $rows;
    }


    public static function get_one($sql, $is_master = false)
    {
        if (!preg_match("/limit/i", $sql))
        {
            $sql = preg_replace("/[,;]$/i", '', trim($sql)) . " limit 1 ";
        }
        $rsid = self::query_run($sql, $is_master);
        $row = mysqli_fetch_array($rsid, DB_GET_ASSOC);
        mysqli_free_result($rsid);
        return $row;
    }


    public static function get_all($sql, $is_master = false)
    {
        $rsid = self::query_run($sql, $is_master);
        while ($row = self::fetch_one($rsid, DB_GET_ASSOC))
        {
            $rows[] = $row;
        }
        mysqli_free_result($rsid);
        return empty($rows) ? array() : $rows;
    }


    public static function ping($link = 'w')
    {
        if (self::$links[self::$link_name][$link] != null && !mysqli_ping(self::$links[self::$link_name][$link]))
        {
            mysqli_close(self::$links[self::$link_name][$link]);
            @mysqli_close(self::$cur_link);
            self::$links[self::$link_name][$link] = self::$cur_link = null;
            self::_init(true);
        }
    }


    public static function free($rsid)
    {
        return mysqli_free_result($rsid);
    }


    public static function autocommit($mode = false)
    {
        self::$cur_link = self::_init(true);
        return mysqli_autocommit(self::$cur_link, $mode);
    }


    public static function begin_tran()
    {
        return self::autocommit(false);
    }


    public static function commit()
    {
        return mysqli_commit(self::$cur_link);
    }


    public static function rollback()
    {
        return mysqli_rollback(self::$cur_link);
    }

    public static function errno() 
    {
        return mysqli_errno(self::$cur_link);
    }

    public static function error() 
    {
        return mysqli_error(self::$cur_link);
    }

    public static function expr($string)
    {
        return new db_expression($string);
    }

    public static function query($sql, $type = null) 
    {
        return db_query_builder::instance()->query($sql, $type = null);
    }

    public static function select($select = '*') 
    {
        return db_query_builder::instance()->select($select);
    }

    public static function insert($table = null, array $columns = null)
    {
        return db_query_builder::instance()->insert($table, $columns);
    }

    public static function update($table = null)
    {
        return db_query_builder::instance()->update($table);
    }

    public static function delete($table = null)
    {
        return db_query_builder::instance()->delete($table);
    }
}

/* vim: set expandtab: */

