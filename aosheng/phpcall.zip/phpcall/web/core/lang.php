<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 语言类
 *
 * @version $Id$
 *
 */
class lang
{
	/**
	 * List of translations
	 *
	 * @var	array
	 */
	public static $language  = array();

   	/**
	 * List of loaded language files
	 *
	 * @var	array
	 */
	public static $is_loaded = array();

	public static function init()
    {
        self::$language = array_change_key_case(self::$language);
        //tpl::assign("lang", self::$language);
    }

	/**
	 * Load a language file
	 * 
	 * @param	mixed	$langfile	Language file name
	 * @param	string	$idiom		Language name (english, etc.)
	 * @return void
	 * @author seatle <seatle@foxmail.com> 
	 * @created time :2017-12-07 17:17
	 */
	public static function load($langfile, $idiom = '')
    {
        if (is_array($langfile))
		{
			foreach ($langfile as $value)
			{
                self::load($value, $idiom);
			}

			return;
		}

		$langfile = str_replace('.ini', '', $langfile);
        $langfile = preg_replace('/_lang$/', '', $langfile).'_lang';
		$langfile .= '.ini';

		if (empty($idiom) OR ! preg_match('/^[a-z_-]+$/i', $idiom))
		{
            $idiom = empty($GLOBALS['config']['language']) ? 'zh-cn' : $GLOBALS['config']['language'];
		}

		// Load the base file, so any others found can override it
		$basepath = PATH_CONFIG.'/lang/'.$idiom.'/'.$langfile;
		if (file_exists($basepath))
		{
			//include($basepath);
            $lang = parse_ini_file($basepath);

            self::$is_loaded[$langfile] = $idiom;
            self::$language = array_merge(self::$language, $lang);
            self::init();
            return true;
		}

        return false;
    }

	public static function set($key, $value)
    {
        if ( empty($key) || empty($value) ) 
        {
            return false;
        }

        self::$language[$key] = $value;
        self::init();
    }

    /**
	 * Language get
	 *
	 * Fetches a single line of text from the language array
	 *
	 * @param	string	$line		Language line key
	 * @param	bool	$log_errors	Whether to log an error message if the line is not found
	 * @return	string	Translation
	 */
	public static function get($key, $defaultvalue = null, $log_errors = true)
	{
		$value = isset(self::$language[$key]) ? self::$language[$key] : null;

        // 模版中找不到变量定义
		if ( $value === null )
		{
            if ( empty($defaultvalue) && $log_errors === true ) 
            {
                trigger_error("Could not find the language line {$key}", E_USER_WARNING);
            }
            else 
            {
                $value = $defaultvalue;
            }
		}

		return $value;
	}

    /**
     * 替换数据库中存在的语言模版
     * 
     * @param mixed $array
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2017-12-07 17:17
     */
    public static function tpl_change($str)
    {
        if (empty($str)) 
        {
            return $str;
        }

        if ( strpos($str, '{{lang.') !== false ) 
        {
            if ( preg_match_all('#\{\{lang\.(.*?)\}\}#', $str, $out) )
            {
                $array = array();
                $count = count($out[0]);
                for ($i = 0; $i < $count; $i++) 
                {
                    $array[] = array(
                        'old_str' => $out[0][$i],
                        'key' => $out[1][$i],
                    );
                }
                foreach ($array as $arr) 
                {
                    $old_str = $arr['old_str'];
                    $key = $arr['key'];

                    $new_str = lang::get($key, null, false);
                    if ( !empty($new_str) ) 
                    {
                        $str = str_replace($old_str, $new_str, $str);
                    }
                }
                //var_dump($str);
                //exit;
            }
        }
        return $str;
    }
}

/* vim: set expandtab: */

