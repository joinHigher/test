# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 192.168.0.2 (MySQL 5.7.21-0ubuntu0.16.04.1-log)
# Database: phpcall
# Generation Time: 2018-04-19 03:47:01 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table call_admin
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_admin`;

CREATE TABLE `call_admin` (
  `admin_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理id',
  `pools` varchar(20) DEFAULT NULL COMMENT '权限池',
  `groups` varchar(100) NOT NULL COMMENT '权限组',
  `username` varchar(20) DEFAULT NULL COMMENT '用户名',
  `password` char(32) DEFAULT NULL COMMENT '用户密码',
  `fake_password` char(32) DEFAULT NULL COMMENT '伪造密码',
  `realname` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `potato` varchar(20) DEFAULT NULL COMMENT 'Potato',
  `regtime` int(11) NOT NULL COMMENT '注册时间',
  `regip` varchar(15) NOT NULL COMMENT '注册ip',
  `status` smallint(6) NOT NULL COMMENT '帐号状态 1:正常 0:禁止登陆',
  `logintime` int(10) unsigned NOT NULL COMMENT '最后登录时间',
  `loginip` varchar(15) NOT NULL COMMENT '最后登录IP',
  `key` char(32) DEFAULT NULL,
  `delete_user` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `userid` (`username`),
  KEY `sta` (`status`),
  KEY `pools` (`pools`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户表';

LOCK TABLES `call_admin` WRITE;
/*!40000 ALTER TABLE `call_admin` DISABLE KEYS */;

INSERT INTO `call_admin` (`admin_id`, `pools`, `groups`, `username`, `password`, `fake_password`, `realname`, `email`, `potato`, `regtime`, `regip`, `status`, `logintime`, `loginip`, `key`, `delete_user`, `delete_time`)
VALUES
	(1,'admin','1','admin','5f46e2ed1f3f5edd58dcf40fa357bc2c','f1a83aff289d7edb66388f154ffb3b48','管理员','seatle888@gmail.com','3549903814',1504873451,'10.10.12.25',1,1524109177,'127.0.0.1',NULL,NULL,NULL),
	(2,'admin','3','test','be9caa0d71be99fd5760e3ac02663e64',NULL,'测试用户','test@163.com',NULL,1515395154,'192.168.0.151',1,1523617789,'192.168.0.50',NULL,NULL,NULL);

/*!40000 ALTER TABLE `call_admin` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table call_admin_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_admin_group`;

CREATE TABLE `call_admin_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(20) DEFAULT NULL COMMENT '用户组名称',
  `pools` varchar(20) DEFAULT NULL COMMENT '权限池',
  `purviews` text NOT NULL COMMENT '用户组权限',
  `uptime` int(10) DEFAULT NULL COMMENT '修改时间',
  `addtime` int(10) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组表';

LOCK TABLES `call_admin_group` WRITE;
/*!40000 ALTER TABLE `call_admin_group` DISABLE KEYS */;

INSERT INTO `call_admin_group` (`id`, `name`, `pools`, `purviews`, `uptime`, `addtime`)
VALUES
	(1,'超级管理员','admin','*',1504839424,1504839424),
	(2,'普通管理员','admin','content-index,content-add,content-edit,content-del,category-index,category-add,category-edit,category-del,member-index,member-add,member-edit,member-del,admin-editpwd,admin-editpwd_fake,admin-mypurview,admin_group-index,admin_group-add,admin_group-edit,admin_group-del,admin-index,admin-add,admin-edit,admin-del,system-edit_menu,config-index,config-add,config-edit,config-del,admin-oplog,admin-login_log,cache-index,cache-del,cache-clear,cache-redis_keys,cache-redis_info,filemanage-index,filemanage-add,filemanage-edit,filemanage-del,crond-index,crond-add,crond-edit,crond-del',1523269932,1504839539),
	(3,'测试人员','admin','content-index,content-add,content-edit,content-del,category-index,category-add,category-edit,category-del,member-index,member-add,member-edit,member-del,admin-editpwd,admin-editpwd_fake,admin-mypurview',1523260651,1504842647);

/*!40000 ALTER TABLE `call_admin_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table call_admin_login
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_admin_login`;

CREATE TABLE `call_admin_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) unsigned NOT NULL COMMENT '用户ID',
  `username` varchar(60) NOT NULL DEFAULT '' COMMENT '用户名',
  `loginip` varchar(15) NOT NULL DEFAULT '' COMMENT '登录IP',
  `logintime` int(10) unsigned NOT NULL COMMENT '登录时间',
  `pools` varchar(20) NOT NULL COMMENT '应用池',
  `loginsta` tinyint(2) unsigned NOT NULL COMMENT '登录时状态',
  `cli_hash` varchar(32) NOT NULL COMMENT '用户登录名和ip的hash',
  PRIMARY KEY (`id`),
  KEY `logintime` (`logintime`),
  KEY `cli_hash` (`cli_hash`,`loginsta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户登陆记录表';

LOCK TABLES `call_admin_login` WRITE;
/*!40000 ALTER TABLE `call_admin_login` DISABLE KEYS */;

INSERT INTO `call_admin_login` (`id`, `admin_id`, `username`, `loginip`, `logintime`, `pools`, `loginsta`, `cli_hash`)
VALUES
	(1,1,'admin','192.168.0.119',1513393316,'admin',1,'49500176dbf9fd7e0b794e129c27c24e'),
	(2,1,'admin','192.168.0.119',1513393316,'admin',1,'49500176dbf9fd7e0b794e129c27c24e'),
	(3,1,'admin','192.168.0.149',1513399776,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(4,1,'admin','192.168.0.149',1513399776,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(5,1,'admin','192.168.0.149',1513402624,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(6,1,'admin','192.168.0.149',1513402624,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(7,1,'admin','192.168.0.149',1513402730,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(8,1,'admin','192.168.0.149',1513402730,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(9,1,'admin','192.168.0.149',1513402752,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(10,1,'admin','192.168.0.149',1513402752,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(11,1,'admin','192.168.0.149',1513403452,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(12,1,'admin','192.168.0.149',1513403452,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(13,1,'admin','192.168.0.149',1513403488,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(14,1,'admin','192.168.0.149',1513403488,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(15,1,'admin','192.168.0.149',1513406345,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(16,1,'admin','192.168.0.149',1513406345,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(17,1,'admin','192.168.0.149',1513406376,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(18,1,'admin','192.168.0.149',1513406376,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(19,1,'admin','192.168.0.149',1513406467,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(20,0,'admin','192.168.0.149',1513406733,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(21,0,'admin','192.168.0.149',1513406747,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(22,0,'admin','192.168.0.149',1513406786,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(23,0,'admin','192.168.0.149',1513406813,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(24,1,'admin','192.168.0.149',1513406813,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(25,0,'admin','192.168.0.149',1513406895,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(26,0,'admin','192.168.0.149',1513406938,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(27,1,'admin','192.168.0.149',1513406938,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(28,0,'admin','192.168.0.149',1513406946,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(29,1,'admin','192.168.0.149',1513406946,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(30,0,'admin','192.168.0.149',1513406994,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(31,1,'admin','192.168.0.149',1513406994,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(32,0,'admin','192.168.0.149',1513407741,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(33,0,'admin','192.168.0.149',1513408881,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(34,1,'admin','192.168.0.149',1513408881,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(35,0,'admin','192.168.0.149',1513409234,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(36,1,'admin','192.168.0.149',1513409234,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(37,0,'admin','192.168.0.149',1513409815,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(38,1,'admin','192.168.0.149',1513409815,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(39,0,'admin','192.168.0.149',1513409986,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(40,1,'admin','192.168.0.149',1513409986,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(41,0,'admin','192.168.0.149',1513410244,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(42,1,'admin','192.168.0.149',1513410244,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(43,0,'admin','192.168.0.149',1513410301,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(44,0,'admin','192.168.0.149',1513410315,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(45,1,'admin','192.168.0.149',1513410315,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(46,0,'admin','192.168.0.149',1513411115,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(47,1,'admin','192.168.0.149',1513411115,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(48,0,'admin','192.168.0.149',1513415794,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(49,1,'admin','192.168.0.149',1513415794,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(50,0,'admin','192.168.0.149',1513416025,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(51,1,'admin','192.168.0.149',1513416025,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(52,0,'admin','192.168.0.149',1513416102,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(53,1,'admin','192.168.0.149',1513416102,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(54,0,'admin','192.168.0.149',1513416193,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(55,1,'admin','192.168.0.149',1513416193,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(56,0,'admin','192.168.0.149',1513416292,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(57,1,'admin','192.168.0.149',1513416292,'admin',1,'fa51ec3dd7f73e7764520ca9e24e2be4'),
	(58,0,'admin','192.168.0.122',1513842927,'admin',1,'9e73fbef9bb4d0a29145a08a6453f7c6'),
	(59,1,'admin','192.168.0.122',1513842927,'admin',1,'9e73fbef9bb4d0a29145a08a6453f7c6'),
	(60,0,'admin','192.168.0.118',1514019423,'admin',1,'c4c72880ff077001c8856a6e4f2b503e'),
	(61,1,'admin','192.168.0.118',1514019423,'admin',1,'c4c72880ff077001c8856a6e4f2b503e'),
	(62,0,'admin','127.0.0.1',1514285364,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(63,1,'admin','127.0.0.1',1514285364,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(64,0,'admin','127.0.0.1',1514363407,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(65,1,'admin','127.0.0.1',1514363407,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(66,0,'admin','192.168.0.123',1514891513,'admin',1,'fca6ef8c775842d2332ee72b9fc7300c'),
	(67,1,'admin','192.168.0.123',1514891513,'admin',1,'fca6ef8c775842d2332ee72b9fc7300c'),
	(68,0,'admin','10.211.55.3',1514969001,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(69,0,'admin','10.211.55.3',1514969001,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(70,1,'admin','10.211.55.3',1514969002,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(71,1,'admin','10.211.55.3',1514969002,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(72,0,'admin','10.211.55.3',1515038230,'admin',0,'a1227e7b9eba8846da9fc78c230ba819'),
	(73,0,'admin','10.211.55.3',1515038233,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(74,1,'admin','10.211.55.3',1515038233,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(75,0,'admin','127.0.0.1',1515124988,'admin',0,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(76,0,'admin','127.0.0.1',1515132183,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(77,1,'admin','127.0.0.1',1515132183,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(78,0,'admin','127.0.0.1',1515135425,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(79,1,'admin','127.0.0.1',1515135425,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(80,0,'admin','127.0.0.1',1515136605,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(81,1,'admin','127.0.0.1',1515136605,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(82,0,'admin','10.211.55.3',1515157657,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(83,1,'admin','10.211.55.3',1515157657,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(84,0,'admin','10.211.55.3',1515161289,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(85,1,'admin','10.211.55.3',1515161289,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(86,0,'admin','192.168.0.184',1515225325,'admin',1,'a018b059dbd392ae9cba36f1726b6318'),
	(87,1,'admin','192.168.0.184',1515225325,'admin',1,'a018b059dbd392ae9cba36f1726b6318'),
	(88,0,'admin','127.0.0.1',1515234901,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(89,1,'admin','127.0.0.1',1515234901,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(90,0,'admin','192.168.0.128',1515242614,'admin',1,'1e94be5057955593f4c09e94c729f715'),
	(91,1,'admin','192.168.0.128',1515242614,'admin',1,'1e94be5057955593f4c09e94c729f715'),
	(92,1,'admin','127.0.0.1',1515435163,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(93,1,'admin','127.0.0.1',1515435163,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(94,0,'admin','192.168.0.151',1515386471,'admin',1,'9c9afe28409187819eac4b78c3058704'),
	(95,1,'admin','192.168.0.151',1515386471,'admin',1,'9c9afe28409187819eac4b78c3058704'),
	(96,0,'admin','10.211.55.3',1515383207,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(97,1,'admin','10.211.55.3',1515383207,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(98,0,'test','192.168.0.151',1515395251,'admin',1,'8428824872880457cfc28a23787bfd1f'),
	(99,2,'test','192.168.0.151',1515395251,'admin',1,'8428824872880457cfc28a23787bfd1f'),
	(100,0,'admin','127.0.0.1',1515398325,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(101,1,'admin','127.0.0.1',1515398325,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(102,0,'admin','127.0.0.1',1515554696,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(103,1,'admin','127.0.0.1',1515554696,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(104,0,'admin','192.168.0.155',1515572469,'admin',1,'54062004298007f5faba274b8398df00'),
	(105,1,'admin','192.168.0.155',1515572469,'admin',1,'54062004298007f5faba274b8398df00'),
	(106,0,'admin','192.168.0.116',1515742660,'admin',1,'48b32bd707bab05c914133584ae8fb96'),
	(107,1,'admin','192.168.0.116',1515742660,'admin',1,'48b32bd707bab05c914133584ae8fb96'),
	(108,0,'admin','192.168.0.122',1516004770,'admin',1,'9e73fbef9bb4d0a29145a08a6453f7c6'),
	(109,1,'admin','192.168.0.122',1516004770,'admin',1,'9e73fbef9bb4d0a29145a08a6453f7c6'),
	(110,0,'admin','192.168.0.123',1516093725,'admin',1,'fca6ef8c775842d2332ee72b9fc7300c'),
	(111,1,'admin','192.168.0.123',1516093725,'admin',1,'fca6ef8c775842d2332ee72b9fc7300c'),
	(112,0,'admin','10.211.55.3',1516259703,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(113,1,'admin','10.211.55.3',1516259703,'admin',1,'a1227e7b9eba8846da9fc78c230ba819'),
	(114,0,'admin','127.0.0.1',1516325499,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(115,1,'admin','127.0.0.1',1516325500,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(116,0,'test','192.168.0.177',1516273122,'admin',0,'e40bf9cc24c45ef34bf1ce3add6b955d'),
	(117,0,'test','192.168.0.177',1516273126,'admin',1,'e40bf9cc24c45ef34bf1ce3add6b955d'),
	(118,2,'test','192.168.0.177',1516273126,'admin',1,'e40bf9cc24c45ef34bf1ce3add6b955d'),
	(119,0,'admin','127.0.0.1',1516328791,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(120,1,'admin','127.0.0.1',1516328791,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(121,0,'admin','192.168.0.121',1516356725,'admin',1,'ca103db004308762e239f9cb0a3d9eba'),
	(122,1,'admin','192.168.0.121',1516356725,'admin',1,'ca103db004308762e239f9cb0a3d9eba'),
	(123,0,'admin','127.0.0.1',1516366231,'admin',0,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(124,0,'admin','127.0.0.1',1516366492,'admin',0,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(125,0,'admin','127.0.0.1',1516418061,'admin',0,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(126,0,'test','192.168.0.147',1516438905,'admin',1,'ff08ffb38e90a30e8e808aa488533762'),
	(127,2,'test','192.168.0.147',1516438905,'admin',1,'ff08ffb38e90a30e8e808aa488533762'),
	(128,0,'test','192.168.0.147',1516439578,'admin',1,'ff08ffb38e90a30e8e808aa488533762'),
	(129,2,'test','192.168.0.147',1516439578,'admin',1,'ff08ffb38e90a30e8e808aa488533762'),
	(130,0,'test','127.0.0.1',1516440615,'admin',1,'8e12e8915c88798f4443e9c9b176bf32'),
	(131,2,'test','127.0.0.1',1516440617,'admin',1,'8e12e8915c88798f4443e9c9b176bf32'),
	(132,0,'admin','192.168.0.147',1516450521,'admin',1,'d2cf9367734c1de2708b10c6ea3b4f3e'),
	(133,1,'admin','192.168.0.147',1516450521,'admin',1,'d2cf9367734c1de2708b10c6ea3b4f3e'),
	(134,0,'test','192.168.0.120',1516452270,'admin',1,'e2007d20c2fd38d867e34ab6c1086d7e'),
	(135,2,'test','192.168.0.120',1516452270,'admin',1,'e2007d20c2fd38d867e34ab6c1086d7e'),
	(136,0,'admin','192.168.0.120',1516452286,'admin',1,'848316155d6868af37bbf7a338d398d5'),
	(137,1,'admin','192.168.0.120',1516452286,'admin',1,'848316155d6868af37bbf7a338d398d5'),
	(138,0,'admin','127.0.0.1',1516448744,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(139,1,'admin','127.0.0.1',1516448744,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(140,0,'admin','192.168.0.147',1516453579,'admin',1,'d2cf9367734c1de2708b10c6ea3b4f3e'),
	(141,1,'admin','192.168.0.147',1516453579,'admin',1,'d2cf9367734c1de2708b10c6ea3b4f3e'),
	(142,0,'admin','127.0.0.1',1517043251,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(143,1,'admin','127.0.0.1',1517043251,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(144,0,'admin','127.0.0.1',1517469581,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(145,1,'admin','127.0.0.1',1517469582,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(146,0,'admin','127.0.0.1',1517620471,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(147,1,'admin','127.0.0.1',1517620471,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(148,0,'admin','127.0.0.1',1519934356,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(149,1,'admin','127.0.0.1',1519934356,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(150,0,'admin','127.0.0.1',1520421569,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(151,1,'admin','127.0.0.1',1520421569,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(152,0,'admin','127.0.0.1',1520421820,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(153,1,'admin','127.0.0.1',1520421820,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(154,0,'admin','192.168.0.67',1520425527,'admin',1,'982ad5ea57280dc9d2be551c7de16d5d'),
	(155,1,'admin','192.168.0.67',1520425527,'admin',1,'982ad5ea57280dc9d2be551c7de16d5d'),
	(156,0,'admin','127.0.0.1',1520422833,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(157,1,'admin','127.0.0.1',1520422833,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(158,0,'admin','127.0.0.1',1520536496,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(159,1,'admin','127.0.0.1',1520536496,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(160,0,'test','127.0.0.1',1520488247,'admin',1,'8e12e8915c88798f4443e9c9b176bf32'),
	(161,2,'test','127.0.0.1',1520488247,'admin',1,'8e12e8915c88798f4443e9c9b176bf32'),
	(162,0,'admin','127.0.0.1',1520488292,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(163,1,'admin','127.0.0.1',1520488292,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(164,0,'test','192.168.0.50',1520492307,'admin',1,'f3db732951b5626259176379eca9f063'),
	(165,2,'test','192.168.0.50',1520492307,'admin',1,'f3db732951b5626259176379eca9f063'),
	(166,0,'test','127.0.0.1',1520488853,'admin',1,'8e12e8915c88798f4443e9c9b176bf32'),
	(167,2,'test','127.0.0.1',1520488853,'admin',1,'8e12e8915c88798f4443e9c9b176bf32'),
	(168,0,'admin','192.168.0.62',1520493050,'admin',1,'81bf8fe137f408fa7bb1c70409391ed0'),
	(169,1,'admin','192.168.0.62',1520493050,'admin',1,'81bf8fe137f408fa7bb1c70409391ed0'),
	(170,0,'admin','127.0.0.1',1520496869,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(171,1,'admin','127.0.0.1',1520496869,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(172,0,'admin','192.168.0.51',1520502846,'admin',1,'93d05c024ac4382bbe0ef477fc72d0d7'),
	(173,1,'admin','192.168.0.51',1520502846,'admin',1,'93d05c024ac4382bbe0ef477fc72d0d7'),
	(174,0,'admin','127.0.0.1',1520851006,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(175,1,'admin','127.0.0.1',1520851006,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(176,0,'admin','192.168.0.60',1520928788,'admin',1,'5064f3f043a9d20dc6b0f1f82973554f'),
	(177,1,'admin','192.168.0.60',1520928788,'admin',1,'5064f3f043a9d20dc6b0f1f82973554f'),
	(178,0,'admin','127.0.0.1',1520925285,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(179,1,'admin','127.0.0.1',1520925285,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(180,0,'admin','192.168.0.50',1520929947,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(181,1,'admin','192.168.0.50',1520929947,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(182,0,'admin','192.168.0.50',1521723499,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(183,1,'admin','192.168.0.50',1521723499,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(184,0,'admin','192.168.0.50',1521723507,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(185,1,'admin','192.168.0.50',1521723507,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(186,0,'admin','192.168.0.50',1521723698,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(187,1,'admin','192.168.0.50',1521723698,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(188,0,'admin','192.168.0.50',1521723777,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(189,1,'admin','192.168.0.50',1521723777,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(190,1,'admin','192.168.0.50',1521725576,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(191,1,'admin','192.168.0.50',1521795223,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(192,1,'admin','192.168.0.50',1521795241,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(193,1,'admin','127.0.0.1',1522533047,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(194,1,'admin','192.168.0.50',1522589054,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(195,1,'admin','192.168.0.50',1522589983,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(196,1,'admin','192.168.0.50',1522590098,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(197,1,'admin','192.168.0.50',1522590147,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(198,1,'admin','192.168.0.50',1522590165,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(199,1,'admin','192.168.0.50',1522593063,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(200,1,'admin','192.168.0.50',1523183527,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(201,1,'admin','192.168.0.50',1523183559,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(202,1,'admin','192.168.0.50',1523246268,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(203,1,'admin','127.0.0.1',1523254020,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(204,1,'admin','192.168.0.50',1523257870,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(205,1,'admin','192.168.0.50',1523257870,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(206,1,'admin','192.168.0.50',1523260566,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(207,1,'admin','192.168.0.50',1523260566,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(208,2,'test','192.168.0.50',1523260818,'admin',0,'f3db732951b5626259176379eca9f063'),
	(209,2,'test','192.168.0.50',1523260830,'admin',1,'f3db732951b5626259176379eca9f063'),
	(210,2,'test','192.168.0.50',1523260830,'admin',1,'f3db732951b5626259176379eca9f063'),
	(211,1,'admin','192.168.0.50',1523263848,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(212,1,'admin','192.168.0.50',1523263848,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(213,2,'test','192.168.0.50',1523264814,'admin',1,'f3db732951b5626259176379eca9f063'),
	(214,2,'test','192.168.0.50',1523264814,'admin',1,'f3db732951b5626259176379eca9f063'),
	(215,1,'admin','192.168.0.50',1523264838,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(216,1,'admin','192.168.0.50',1523264838,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(217,1,'admin','192.168.0.50',1523265279,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(218,1,'admin','192.168.0.50',1523265279,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(219,1,'admin','192.168.0.50',1523265552,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(220,1,'admin','192.168.0.50',1523265552,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(221,1,'admin','192.168.1.52',1523455127,'admin',1,'a20afb9635e6fc3366a087dbb21fc78a'),
	(222,1,'admin','192.168.1.69',1523455296,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(223,1,'admin','192.168.1.69',1523458688,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(224,1,'admin','192.168.1.69',1523502076,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(225,1,'admin','192.168.1.69',1523502467,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(226,1,'admin','192.168.1.69',1523509135,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(227,1,'admin','192.168.1.69',1523512651,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(228,1,'admin','192.168.1.69',1523512712,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(229,1,'admin','192.168.1.52',1523521117,'admin',1,'a20afb9635e6fc3366a087dbb21fc78a'),
	(230,1,'admin','192.168.0.50',1523521235,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(231,1,'admin','192.168.1.69',1523521302,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(232,1,'admin','192.168.1.69',1523521356,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(233,1,'admin','127.0.0.1',1523517707,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(234,1,'admin','127.0.0.1',1523523410,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(235,1,'admin','192.168.1.69',1523535417,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(236,1,'admin','192.168.1.69',1523536338,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(237,1,'admin','192.168.1.69',1523587129,'admin',1,'5a9cb1239e0afc1f7a86bfa55272497b'),
	(238,2,'test','192.168.0.50',1523617789,'admin',1,'f3db732951b5626259176379eca9f063'),
	(239,1,'admin','127.0.0.1',1523614233,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(240,1,'admin','192.168.0.50',1523619716,'admin',1,'cd0a59ba6195561f5fd114696f19b7b9'),
	(241,1,'admin','127.0.0.1',1523698059,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d'),
	(242,1,'admin','192.168.0.67',1523703177,'admin',1,'982ad5ea57280dc9d2be551c7de16d5d'),
	(243,1,'admin','192.168.0.67',1523703210,'admin',1,'982ad5ea57280dc9d2be551c7de16d5d'),
	(244,1,'admin','192.168.0.67',1523852630,'admin',1,'982ad5ea57280dc9d2be551c7de16d5d'),
	(245,1,'admin','127.0.0.1',1524109177,'admin',1,'7a0cb45999b8e15ec0dbb6164bf2857d');

/*!40000 ALTER TABLE `call_admin_login` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table call_admin_oplog
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_admin_oplog`;

CREATE TABLE `call_admin_oplog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '项id',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `msg` varchar(250) NOT NULL COMMENT '消息内容',
  `do_time` int(10) unsigned NOT NULL COMMENT '发生时间',
  `do_ip` varchar(15) NOT NULL COMMENT '客户端IP',
  `do_url` varchar(100) NOT NULL COMMENT '操作网址',
  PRIMARY KEY (`id`),
  KEY `user_name` (`username`),
  KEY `do_time` (`do_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户操作日志';

LOCK TABLES `call_admin_oplog` WRITE;
/*!40000 ALTER TABLE `call_admin_oplog` DISABLE KEYS */;

INSERT INTO `call_admin_oplog` (`id`, `username`, `msg`, `do_time`, `do_ip`, `do_url`)
VALUES
	(1,'admin','内容添加 1',1513341911,'192.168.0.151','?ct=content&ac=add&csrf_token_name=c097455ebc54898ad2e250e667eacde4&gourl=?ct=content&ac=index'),
	(2,'admin','内容修改 1',1513342511,'192.168.0.151','?ct=content&ac=edit&id=1&csrf_token_name=39bb74c9416ff3f9591071551835adf8'),
	(3,'admin','内容修改 1',1513342654,'192.168.0.151','?ct=content&ac=edit&id=1&csrf_token_name=cff859dd2c51d6df4ae353bacb0689d7'),
	(4,'admin','内容修改 1',1513342677,'192.168.0.151','?ct=content&ac=edit&id=1&csrf_token_name=477504adfd7e7a5b657699dda94b0ee1'),
	(5,'admin','分类添加 4',1514369243,'192.168.0.126','?ct=category&ac=add&gourl=?ct=category&ac=index&name=1212&create_user=1&create_time=1514369243'),
	(6,'admin','分类添加 5',1515135450,'127.0.0.1','?ct=category&ac=add&gourl=?ct=category&ac=index&name=222&create_user=1&create_time=1515135450'),
	(7,'admin','分类修改 5',1515135467,'127.0.0.1','?ct=category&ac=edit&id=5&gourl=http://phpcall.a.com/web/admin/?ct=category&ac=index&name=bibibli'),
	(8,'admin','用户组修改 2',1515160719,'10.211.55.3','?ct=admin_group&ac=edit&id=2&gourl=http://phpcall.com:8080/?ct=admin_group&ac=index'),
	(9,'admin','清除网址导航缓存',1515164392,'192.168.0.156','?ct=cache&ac=clear&type=guonei'),
	(10,'admin','内容添加 1',1515165416,'192.168.0.156','?ct=content&ac=add&gourl=?ct=content&ac=index&name=23333&catid=1&image_img_upload='),
	(11,'admin','内容修改 1',1515165516,'192.168.0.156','?ct=content&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=content&ac=edit&id=1'),
	(12,'admin','内容修改 1',1515165522,'192.168.0.156','?ct=content&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=23333gggg'),
	(13,'admin','用户添加 2',1515395154,'192.168.0.151','?ct=admin&ac=add&gourl=?ct=admin&ac=index&username=test&realname=测试用户&email=test@163.com'),
	(14,'admin','设置用户独立权限 2',1515395220,'192.168.0.151','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=2'),
	(15,'admin','修改了系统配置的 admin_menu 项目的值',1515391889,'10.211.55.3','?ct=system&ac=edit_menu'),
	(16,'admin','用户修改 2',1515399161,'192.168.0.151','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index'),
	(17,'admin','用户组修改 2',1515399180,'192.168.0.151','?ct=admin_group&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(18,'admin','用户修改 2',1515399319,'192.168.0.151','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index'),
	(19,'admin','用户修改 2',1515399359,'192.168.0.151','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index'),
	(20,'admin','用户修改 2',1515399501,'192.168.0.151','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index'),
	(21,'admin','用户修改 2',1515399512,'192.168.0.151','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index'),
	(22,'admin','设置用户独立权限 2',1515399673,'192.168.0.151','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=2'),
	(23,'admin','设置用户独立权限 2',1515399762,'192.168.0.151','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=2'),
	(24,'admin','设置用户独立权限 2',1515399775,'192.168.0.151','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=2'),
	(25,'admin','清除用户独立权限 2',1515399832,'192.168.0.151','?ct=admin&ac=purview_del&id=2'),
	(26,'admin','用户修改 2',1515399853,'192.168.0.151','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=purview_del&id=2'),
	(27,'admin','清除用户独立权限 2',1515399854,'192.168.0.151','?ct=admin&ac=purview_del&id=2'),
	(28,'admin','清除用户独立权限 2',1515399897,'192.168.0.151','?ct=admin&ac=purview_del&id=2'),
	(29,'admin','分类批量修改 1,3,2,4,5',1515404110,'192.168.0.151','?ct=category&ac=edit_batch&ids=array()&sorts=array()'),
	(30,'admin','分类批量修改 1,3,2,4,5',1515404125,'192.168.0.151','?ct=category&ac=edit_batch&ids=array()&sorts=array()'),
	(31,'admin','内容修改 1',1515404282,'192.168.0.151','?ct=content&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=23333gggg'),
	(32,'admin','内容修改 1',1515404297,'192.168.0.151','?ct=content&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=23333gggg'),
	(33,'admin','修改了系统配置的 admin_menu 项目的值',1515680583,'127.0.0.1','?ct=system&ac=edit_menu'),
	(34,'admin','修改了系统配置的 admin_menu 项目的值',1516278882,'192.168.0.177','?ct=system&ac=edit_menu'),
	(35,'admin','修改了系统配置的 admin_menu 项目的值',1516278911,'192.168.0.177','?ct=system&ac=edit_menu'),
	(36,'admin','分类修改 1',1516347122,'127.0.0.1','?ct=category&ac=edit&id=1&gourl=http://phpcall.cc/?ct=category&ac=index&name=视频&update_user=1'),
	(37,'admin','修改了系统配置的 admin_menu 项目的值',1516363559,'192.168.0.199','?ct=system&ac=edit_menu'),
	(38,'admin','设置用户独立权限 1',1516419748,'127.0.0.1','?ct=admin&ac=purview&id=1&gourl=http://phpcall.cc/?ct=admin&ac=purview&id=1&purviews=array()'),
	(39,'admin','设置用户独立权限 2',1516435043,'192.168.0.147','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=purview&id=2'),
	(40,'admin','设置用户独立权限 2',1516435058,'192.168.0.147','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=purview&id=2'),
	(41,'admin','设置用户独立权限 2',1516435073,'192.168.0.147','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=2'),
	(42,'admin','设置用户独立权限 2',1516435081,'192.168.0.147','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=2'),
	(43,'admin','修改了系统配置的 admin_menu 项目的值',1516450567,'192.168.0.147','?ct=system&ac=edit_menu'),
	(44,'admin','修改了系统配置的 admin_menu 项目的值',1516450584,'192.168.0.147','?ct=system&ac=edit_menu'),
	(45,'admin','修改了系统配置的 admin_menu 项目的值',1517578374,'192.168.0.152','?ct=system&ac=edit_menu'),
	(46,'admin','修改了系统配置的 admin_menu 项目的值',1520854724,'127.0.0.1','?ct=system&ac=edit_menu'),
	(47,'admin','修改了系统配置的 admin_menu 项目的值',1520909150,'127.0.0.1','?ct=system&ac=edit_menu'),
	(48,'admin','配置修改 site_keyword1',1521445745,'192.168.0.50','?ct=config&ac=edit&name=site_keyword1&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(49,'admin','配置修改 site_name',1521465908,'192.168.0.50','?ct=config&ac=edit&name=site_name&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(50,'admin','配置修改 site_tj',1521726288,'192.168.0.50','?ct=config&ac=edit&name=site_tj'),
	(51,'admin','配置修改 site_tj',1521726293,'192.168.0.50','?ct=config&ac=edit&name=site_tj'),
	(52,'admin','配置修改 site_description',1521726410,'192.168.0.50','?ct=config&ac=edit&name=site_description&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(53,'admin','配置修改 site_description',1521726416,'192.168.0.50','?ct=config&ac=edit&name=site_description&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(54,'admin','配置批量修改',1521726572,'192.168.0.50','?ct=config&ac=batch_edit&datas=array()&sorts=array()'),
	(55,'admin','配置批量修改',1521726583,'192.168.0.50','?ct=config&ac=batch_edit&datas=array()&sorts=array()'),
	(56,'admin','配置修改 site_description',1521726749,'192.168.0.50','?ct=config&ac=edit&name=site_description&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(57,'admin','配置修改 site_keyword',1521726771,'192.168.0.50','?ct=config&ac=edit&name=site_keyword&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(58,'admin','配置修改 authorized_time',1521726782,'192.168.0.50','?ct=config&ac=edit&name=authorized_time&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(59,'admin','用户组添加 ',1521778552,'192.168.0.50','?ct=admin_group&ac=add&gourl=?ct=admin_group&ac=index&name=test&purviews=array()'),
	(60,'admin','用户组添加 5',1521778634,'192.168.0.50','?ct=admin_group&ac=add&gourl=?ct=admin_group&ac=index&name=gggg&purviews=array()'),
	(61,'admin','用户组修改 4',1521778948,'192.168.0.50','?ct=admin_group&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=edit&id=4'),
	(62,'admin','用户组修改 4',1521778962,'192.168.0.50','?ct=admin_group&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(63,'admin','用户组修改 4',1521778967,'192.168.0.50','?ct=admin_group&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(64,'admin','用户组删除 4',1521779801,'192.168.0.50','?ct=admin_group&ac=del&id=4'),
	(65,'admin','用户组删除 4',1521779802,'192.168.0.50','?ct=admin_group&ac=del&id=4'),
	(66,'admin','用户组删除 5',1521779808,'192.168.0.50','?ct=admin_group&ac=del&id=5'),
	(67,'admin','用户组添加 6',1521788988,'192.168.0.50','?ct=admin_group&ac=add&gourl=?ct=admin_group&ac=index&name='),
	(68,'admin','用户组删除 6',1521788993,'192.168.0.50','?ct=admin_group&ac=del&id=6'),
	(69,'admin','用户组修改 2',1521792133,'192.168.0.67','?ct=admin_group&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(70,'admin','用户组添加 7',1521792497,'192.168.0.67','?ct=admin_group&ac=add&gourl=?ct=admin_group&ac=index&name='),
	(71,'admin','用户添加 3',1521792498,'192.168.0.50','?ct=admin&ac=add&gourl=?ct=admin&ac=index&username=trset&realname=wa&email=fwa&groups=array()'),
	(72,'admin','用户添加 4',1521792557,'192.168.0.50','?ct=admin&ac=add&gourl=?ct=admin&ac=index&username=fesfes&realname=fes&email=fes&groups=array()'),
	(73,'admin','用户组修改 3',1521789320,'127.0.0.1','?ct=admin_group&ac=edit&id=3&gourl=http://www.phpcall2.cc/?ct=admin_group&ac=index&name='),
	(74,'admin','用户组修改 2',1521789407,'127.0.0.1','?ct=admin_group&ac=edit&id=2&gourl=http://www.phpcall2.cc/?ct=admin_group&ac=index&name=测试2'),
	(75,'admin','用户修改 4',1521793194,'192.168.0.50','?ct=admin&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=ffffff'),
	(76,'admin','用户修改 5',1521793247,'192.168.0.50','?ct=admin&ac=edit&id=5&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=ffffff'),
	(77,'admin','用户修改 4',1521793305,'192.168.0.50','?ct=admin&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=&email='),
	(78,'admin','用户修改 4',1521793314,'192.168.0.50','?ct=admin&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=封锁'),
	(79,'admin','用户修改 4',1521793320,'192.168.0.50','?ct=admin&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=封锁'),
	(80,'admin','用户修改 4',1521793325,'192.168.0.50','?ct=admin&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=封锁'),
	(81,'admin','用户删除 4',1521793655,'192.168.0.50','?ct=admin&ac=del&ids=array()'),
	(82,'admin','用户删除 4',1521793656,'192.168.0.50','?ct=admin&ac=del&ids=array()'),
	(83,'admin','用户删除 4',1521793659,'192.168.0.50','?ct=admin&ac=del&ids=array()'),
	(84,'admin','用户添加 7',1521793670,'192.168.0.50','?ct=admin&ac=add&gourl=?ct=admin&ac=index&username=fes&realname=es&email=fes'),
	(85,'admin','用户删除 7',1521793678,'192.168.0.50','?ct=admin&ac=del&ids=array()'),
	(86,'admin','用户添加 8',1521793700,'192.168.0.50','?ct=admin&ac=add&gourl=?ct=admin&ac=index&username=few&realname=fesz&email=fes&groups=array()'),
	(87,'admin','用户删除 8',1521793704,'192.168.0.50','?ct=admin&ac=del&ids=array()'),
	(88,'admin','用户添加 9',1521793904,'192.168.0.50','?ct=admin&ac=add&gourl=?ct=admin&ac=index&username=fesaf&realname=fes&email=fesfes'),
	(89,'admin','用户修改 1',1521790356,'127.0.0.1','?ct=admin&ac=edit&id=1&gourl=http://www.phpcall2.cc/?ct=admin&ac=edit&id=1&realname=管理员'),
	(90,'admin','设置用户独立权限 9',1521794273,'192.168.0.50','?ct=admin&ac=purview&id=9&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=purview&id=9'),
	(91,'admin','设置用户独立权限 9',1521794283,'192.168.0.50','?ct=admin&ac=purview&id=9&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=9'),
	(92,'admin','设置用户独立权限 9',1521794287,'192.168.0.50','?ct=admin&ac=purview&id=9&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=9'),
	(93,'admin','清除用户独立权限 9',1521794336,'192.168.0.50','?ct=admin&ac=purview_del&id=9'),
	(94,'admin','清除用户独立权限 9',1521794342,'192.168.0.50','?ct=admin&ac=purview_del&id=9'),
	(96,'admin','删除了操作日志 95',1521794506,'192.168.0.50','?ct=admin&ac=oplog_del&ids=array()'),
	(97,'admin','修改密码 1',1521795215,'192.168.0.50','?ct=admin&ac=editpwd&gourl=?ct=admin&ac=index&realname=管理员'),
	(98,'admin','修改密码 1',1521795228,'192.168.0.50','?ct=admin&ac=editpwd&gourl=?ct=admin&ac=index&realname=管理员'),
	(99,'admin','用户组添加 8',1521797701,'192.168.0.50','?ct=admin_group&ac=add&gourl=?ct=admin_group&ac=index&name=fesfes&purviews=array()'),
	(100,'admin','用户组修改 8',1521797706,'192.168.0.50','?ct=admin_group&ac=edit&id=8&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(101,'admin','用户组删除 8',1521797710,'192.168.0.50','?ct=admin_group&ac=del&id=8'),
	(102,'admin','配置批量修改',1521794312,'127.0.0.1','?ct=config&ac=batch_edit&datas=array()&sorts=array()'),
	(103,'admin','计划任务添加 6',1521798017,'192.168.0.50','?ct=crond&ac=add&gourl=?ct=crond&ac=index&name=fes&filename=es&runtime_format=fes&status=1'),
	(104,'admin','计划任务修改 5',1521798274,'192.168.0.50','?ct=crond&ac=edit&id=5&gourl=?ct=crond&ac=index&name=测试&filename=crond_test.php'),
	(105,'admin','计划任务修改 5',1521798279,'192.168.0.50','?ct=crond&ac=edit&id=5&gourl=?ct=crond&ac=index&name=测试ggg&filename=crond_test.php'),
	(106,'admin','计划任务排序',1521798442,'192.168.0.50','?ct=crond&ac=batch_edit&sorts=array()'),
	(107,'admin','计划任务排序',1521798447,'192.168.0.50','?ct=crond&ac=batch_edit&sorts=array()'),
	(108,'admin','计划任务停止 5',1521798451,'192.168.0.50','?ct=crond&ac=status&ids=array()&status=0'),
	(109,'admin','计划任务启动 5',1521798453,'192.168.0.50','?ct=crond&ac=status&ids=array()&status=1'),
	(110,'admin','配置修改 site_name',1521798547,'192.168.0.50','?ct=config&ac=edit&name=site_name&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(111,'admin','用户组修改 2',1521798634,'192.168.0.67','?ct=admin_group&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(112,'admin','分类添加 6',1521798800,'192.168.0.50','?ct=category&ac=add&gourl=?ct=category&ac=index&name=fsfs'),
	(113,'admin','分类修改 6',1521799038,'192.168.0.50','?ct=category&ac=edit&id=6&gourl=http://frame.phpcall.org/admin/?ct=category&ac=edit&id=6'),
	(114,'admin','分类修改 6',1521799050,'192.168.0.50','?ct=category&ac=edit&id=6&gourl=http://frame.phpcall.org/admin/?ct=category&ac=index&name=11111'),
	(115,'admin','分类批量修改 5,6',1521799062,'192.168.0.50','?ct=category&ac=edit_batch&sorts=array()&ids=array()'),
	(116,'admin','分类删除 5',1521799072,'192.168.0.50','?ct=category&ac=del&ids=array()'),
	(117,'admin','用户修改 9',1521799146,'192.168.0.50','?ct=admin&ac=edit&id=9&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=fes'),
	(118,'admin','内容修改 1',1521799947,'192.168.0.50','?ct=content&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=23333gggg'),
	(119,'admin','内容修改 1',1521799953,'192.168.0.50','?ct=content&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=23333gggg'),
	(120,'admin','修改了系统配置的 admin_menu 项目的值',1521801103,'192.168.0.50','?ct=system&ac=edit_menu'),
	(121,'admin','修改了系统配置的 admin_menu 项目的值',1521801179,'192.168.0.50','?ct=system&ac=edit_menu'),
	(122,'admin','配置修改 site_name',1521801240,'192.168.0.50','?ct=config&ac=edit&name=site_name&gourl=http://frame.phpcall.org/admin/?ct=config&ac=index'),
	(123,'admin','修改了系统配置的 admin_menu 项目的值',1521801544,'192.168.0.50','?ct=system&ac=edit_menu'),
	(124,'admin','内容添加 2',1521801703,'192.168.0.50','?ct=content&ac=add&gourl=?ct=content&ac=index&name=fesfes&catid=1&image_img_upload='),
	(125,'admin','内容修改 1',1521801782,'192.168.0.50','?ct=content&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=23333gggg'),
	(126,'admin','内容修改 2',1521801868,'192.168.0.50','?ct=content&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=fesfes'),
	(127,'admin','内容添加 3',1521802013,'192.168.0.50','?ct=content&ac=add&gourl=?ct=content&ac=index&name=fes&catid=3&image_img_upload='),
	(128,'admin','内容添加 4',1521802121,'192.168.0.50','?ct=content&ac=add&gourl=?ct=content&ac=index&name=fesfesg2222&catid=3&image_img_upload='),
	(129,'admin','内容修改 4',1521802159,'192.168.0.50','?ct=content&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=fesfesg2222'),
	(130,'admin','修改了系统配置的 admin_menu 项目的值',1521802367,'192.168.0.50','?ct=system&ac=edit_menu'),
	(131,'admin','修改了系统配置的 admin_menu 项目的值',1521806618,'192.168.0.50','?ct=system&ac=edit_menu'),
	(132,'admin','修改了系统配置的 admin_menu 项目的值',1521807824,'192.168.0.50','?ct=system&ac=edit_menu'),
	(133,'admin','会员添加 1',1521808204,'192.168.0.50','?ct=member&ac=add&gourl=?ct=member&ac=index&name=owner&age=12&email=123@163.com'),
	(134,'admin','会员修改 1',1521808816,'192.168.0.50','?ct=member&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=member&ac=edit&id=1&name=owner888'),
	(135,'admin','会员修改 1',1521808823,'192.168.0.50','?ct=member&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=member&ac=index&name=owner888999'),
	(136,'admin','会员添加 2',1521808868,'192.168.0.50','?ct=member&ac=add&gourl=?ct=member&ac=index&name=test&age=20&email=test@163.com'),
	(137,'admin','会员删除 1',1521809088,'192.168.0.50','?ct=member&ac=del&ids=array()'),
	(138,'admin','会员删除 2',1521809095,'192.168.0.50','?ct=member&ac=del&ids=array()'),
	(139,'admin','内容修改 4',1521809336,'192.168.0.50','?ct=content&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=fesfesg2222'),
	(140,'admin','会员添加 3',1521862699,'192.168.0.50','?ct=member&ac=add&gourl=?ct=member&ac=index&name=test&age=20&email=test@163.com'),
	(141,'admin','会员添加 4',1521862716,'192.168.0.50','?ct=member&ac=add&gourl=?ct=member&ac=index&name=demo&age=21&email=demo@163.com'),
	(142,'admin','会员添加 5',1521868197,'192.168.0.50','?ct=member&ac=add&gourl=?ct=member&ac=index&name=好啦&age=12&email=test@163.com&address=冯绍峰'),
	(143,'admin','会员修改 5',1521868206,'192.168.0.50','?ct=member&ac=edit&id=5&gourl=http://frame.phpcall.org/admin/?ct=member&ac=index&name=好啦&age=12'),
	(144,'admin','会员修改 5',1522385581,'192.168.0.50','?ct=member&ac=edit&id=5&gourl=http://frame.phpcall.org/admin/?ct=member&ac=index&name=好啦&age=12'),
	(145,'admin','用户修改 1',1522589174,'192.168.0.50','?ct=admin&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=1'),
	(146,'admin','用户修改 1',1522589219,'192.168.0.50','?ct=admin&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=管理员'),
	(147,'admin','用户修改 1',1522589223,'192.168.0.50','?ct=admin&ac=edit&id=1&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index&realname=管理员'),
	(148,'admin','用户组修改 3',1523260644,'192.168.0.50','?ct=admin_group&ac=edit&id=3&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(149,'admin','用户组修改 3',1523260651,'192.168.0.50','?ct=admin_group&ac=edit&id=3&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(150,'admin','用户修改 2',1523260702,'192.168.0.50','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index'),
	(151,'admin','设置用户独立权限 2',1523260861,'192.168.0.50','?ct=admin&ac=purview&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=edit&id=2'),
	(152,'admin','修改了系统配置的 admin_menu 项目的值',1523260939,'192.168.0.50','?ct=system&ac=edit_menu'),
	(153,'admin','修改了系统配置的 admin_menu 项目的值',1523261005,'192.168.0.50','?ct=system&ac=edit_menu'),
	(154,'admin','修改了系统配置的 admin_menu 项目的值',1523261271,'192.168.0.50','?ct=system&ac=edit_menu'),
	(155,'admin','修改了系统配置的 admin_menu 项目的值',1523261548,'192.168.0.50','?ct=system&ac=edit_menu'),
	(156,'admin','修改了系统配置的 admin_menu 项目的值',1523261734,'192.168.0.50','?ct=system&ac=edit_menu'),
	(157,'admin','修改了系统配置的 admin_menu 项目的值',1523261819,'192.168.0.50','?ct=system&ac=edit_menu'),
	(158,'admin','修改了系统配置的 admin_menu 项目的值',1523261850,'192.168.0.50','?ct=system&ac=edit_menu'),
	(159,'admin','会员修改 5',1523262060,'192.168.0.50','?ct=member&ac=edit&id=5&gourl=http://frame.phpcall.org/admin/?ct=member&ac=index&name=test&age='),
	(160,'admin','修改了系统配置的 admin_menu 项目的值',1523262130,'192.168.0.50','?ct=system&ac=edit_menu'),
	(161,'admin','修改密码 1',1523262207,'192.168.0.50','?ct=admin&ac=editpwd&gourl=?ct=admin&ac=index&realname=管理员'),
	(162,'admin','伪装密码 1',1523262546,'192.168.0.50','?ct=admin&ac=editpwd_fake'),
	(163,'admin','伪装密码 1',1523262741,'192.168.0.50','?ct=admin&ac=editpwd_fake'),
	(164,'admin','用户组修改 2',1523265576,'192.168.0.50','?ct=admin_group&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(165,'admin','用户组修改 2',1523262393,'127.0.0.1','?ct=admin_group&ac=edit&id=2&gourl=http://www.phpcall.cc:81/?ct=admin_group&ac=index'),
	(166,'admin','用户组修改 2',1523263651,'127.0.0.1','?ct=admin_group&ac=edit&id=2&gourl=http://www.phpcall.cc:81/?ct=admin_group&ac=index'),
	(167,'admin','用户组修改 2',1523263671,'127.0.0.1','?ct=admin_group&ac=edit&id=2&gourl=http://www.phpcall.cc:81/?ct=admin_group&ac=index'),
	(168,'admin','用户组修改 2',1523269920,'192.168.0.50','?ct=admin_group&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(169,'admin','用户组修改 2',1523269932,'192.168.0.50','?ct=admin_group&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin_group&ac=index'),
	(170,'admin','用户修改 2',1523617777,'192.168.0.50','?ct=admin&ac=edit&id=2&gourl=http://frame.phpcall.org/admin/?ct=admin&ac=index'),
	(171,'admin','用户组添加 9',1523619726,'192.168.0.50','?ct=admin_group&ac=add&gourl=?ct=admin_group&ac=index&name=ceshi'),
	(172,'admin','用户组添加 10',1523619748,'192.168.0.50','?ct=admin_group&ac=add&gourl=?ct=admin_group&ac=index&name=ffff'),
	(173,'admin','用户组删除 10',1523619759,'192.168.0.50','?ct=admin_group&ac=del&id=10'),
	(174,'admin','用户组删除 9',1523619763,'192.168.0.50','?ct=admin_group&ac=del&id=9'),
	(175,'admin','内容修改 4',1524020546,'192.168.0.67','?ct=content&ac=edit&id=4&gourl=http://frame.phpcall.org/admin/?ct=content&ac=index&name=fesfesg2222'),
	(176,'admin','修改了系统配置的 admin_menu 项目的值',1524038079,'192.168.0.50','?ct=system&ac=edit_menu');

/*!40000 ALTER TABLE `call_admin_oplog` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table call_admin_purview
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_admin_purview`;

CREATE TABLE `call_admin_purview` (
  `admin_id` int(11) NOT NULL COMMENT '管理员ID',
  `purviews` text NOT NULL COMMENT '配置字符',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户权限表';

LOCK TABLES `call_admin_purview` WRITE;
/*!40000 ALTER TABLE `call_admin_purview` DISABLE KEYS */;

INSERT INTO `call_admin_purview` (`admin_id`, `purviews`)
VALUES
	(2,'');

/*!40000 ALTER TABLE `call_admin_purview` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table call_category
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_category`;

CREATE TABLE `call_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类表',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `sort` int(11) DEFAULT '100' COMMENT '排序',
  `create_user` int(11) DEFAULT NULL COMMENT '创建用户',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_user` int(11) DEFAULT NULL COMMENT '修改用户',
  `update_time` int(10) DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='分类表';

LOCK TABLES `call_category` WRITE;
/*!40000 ALTER TABLE `call_category` DISABLE KEYS */;

INSERT INTO `call_category` (`id`, `name`, `sort`, `create_user`, `create_time`, `update_user`, `update_time`)
VALUES
	(1,'视频',2,1,1511258578,1,1516347122),
	(2,'音乐',2,1,1511258584,NULL,NULL),
	(3,'小说',2,1,1511258589,NULL,NULL),
	(4,'1212',100,1,1514369243,NULL,NULL),
	(6,'11111',9,1,1521798800,1,1521799050);

/*!40000 ALTER TABLE `call_category` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table call_config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_config`;

CREATE TABLE `call_config` (
  `sort` smallint(6) NOT NULL DEFAULT '0' COMMENT '排序id',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '变量名',
  `value` text COMMENT '变量值',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '说明标题',
  `info` varchar(200) NOT NULL COMMENT '备注',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '分组',
  `type` varchar(10) NOT NULL DEFAULT 'string' COMMENT '变量类型',
  PRIMARY KEY (`name`),
  KEY `sort` (`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统配置变量表';

LOCK TABLES `call_config` WRITE;
/*!40000 ALTER TABLE `call_config` DISABLE KEYS */;

INSERT INTO `call_config` (`sort`, `name`, `value`, `title`, `info`, `groupid`, `type`)
VALUES
	(0,'admin_df_purview','<pools:admin name=\"管理员\" auttype=\"session\" login_control=\"?ct=index&ac=login\">\r\n\r\n    <!—— //公开的控制器，不需登录就能访问 ——>\r\n    <ctl:public>index-login,index-logout,index-validate_image,index-send_code</ctl:public>\r\n\r\n    <!—— //保护的控制器，当前池会员登录后都能访问 ——>\r\n    <ctl:protected>index-index,index-adminmsg,admin-mypurview</ctl:protected>\r\n\r\n    <!—— //私有控制器，只有特定组才能访问 ——>\r\n    <ctl:private>\r\n        <admin name=\"管理员\">*</admin>\r\n        <test name=\"测试组\">index-index,system-iplimit,admin-editpwd,system-log,system-login_log</test>\r\n        <boy name=\"帅哥组\">index-index,admin-editpwd</boy>\r\n    </ctl:private>\r\n\r\n</pools:admin>\n\n<pools:default  allowpool=\"default\" name=\"第一平台\" auttype=\"session\" login_control=\"?ct=index&ac=login\">\r\n\r\n    <!—— //公开的控制器，不需登录就能访问 ——>\r\n    <ctl:public>index-login,index-logout,index-validate_image,index-forget_passwd,index-send_code</ctl:public>\r\n\r\n    <!—— //保护的控制器，当前池会员登录后都能访问 ——>\r\n    <ctl:protected>index-index,index-select_company</ctl:protected>\n\n    <!—— //私有控制器，只有特定组才能访问 ——>\r\n    <ctl:private>\r\n    </ctl:private>\r\n\r\n</pools:default>','管理员默认权限','',0,'text'),
	(0,'admin_menu','<xml>\r\n    <!-- //这里的子菜单为隐性项目 -->\r\n    <menu name=\'常用\' class=\'fa fa-th-list\'>\r\n        <menu name=\'内容管理\' class=\'fa fa-file\'>\r\n            <menu name=\'内容列表\' ct=\'content\' ac=\'index\' reload=\'1\' />\r\n            <menu name=\'内容添加\' ct=\'content\' ac=\'add\' display=\'none\' />\r\n            <menu name=\'内容修改\' ct=\'content\' ac=\'edit\' display=\'none\' />\r\n            <menu name=\'内容删除\' ct=\'content\' ac=\'del\' display=\'none\' />\r\n            <menu name=\'{{lang.menu_content_category_manage}}\' ct=\'category\' ac=\'index\' />\r\n            <menu name=\'{{lang.menu_content_category_add}}\'    ct=\'category\' ac=\'add\' display=\'none\' />\r\n            <menu name=\'{{lang.menu_content_category_update}}\' ct=\'category\' ac=\'edit\' display=\'none\' />\r\n            <menu name=\'{{lang.menu_content_category_delete}}\' ct=\'category\' ac=\'del\' display=\'none\'  />\r\n        </menu>\r\n        <menu name=\'会员管理\' class=\'fa fa-users\'>\r\n            <menu name=\'会员列表\' ct=\'member\' ac=\'index\' reload=\'1\'  default=\'1\' />\r\n            <menu name=\'会员添加\' ct=\'member\' ac=\'add\' display=\'none\' />\r\n            <menu name=\'会员修改\' ct=\'member\' ac=\'edit\' display=\'none\' />\r\n            <menu name=\'会员删除\' ct=\'member\' ac=\'del\' display=\'none\' />\r\n        </menu>\r\n    </menu>\r\n    <menu name=\'系统\' class=\'fa fa-gear\'>\r\n        <menu name=\'登陆密码\' ct=\'admin\' ac=\'editpwd\' class=\'fa fa-lock\' />\r\n        <menu name=\'伪装密码\' ct=\'admin\' ac=\'editpwd_fake\' class=\'fa fa-expeditedssl\' />\r\n        <menu name=\'我的权限\' ct=\'admin\' ac=\'mypurview\' class=\'fa fa-user-secret\' />\r\n        <menu name=\'用户管理\' class=\'fa fa-user\'>\r\n            <menu name=\'用户组管理\' ct=\'admin_group\' ac=\'index\'/>\r\n            <menu name=\'用户组添加\' ct=\'admin_group\' ac=\'add\' display=\'none\' />\r\n            <menu name=\'用户组修改\' ct=\'admin_group\' ac=\'edit\' display=\'none\' />\r\n            <menu name=\'用户组删除\' ct=\'admin_group\' ac=\'del\'  display=\'none\' />\r\n\r\n            <menu name=\'用户管理\' ct=\'admin\' ac=\'index\' />\r\n            <menu name=\'用户添加\' ct=\'admin\' ac=\'add\' display=\'none\' />\r\n            <menu name=\'用户修改\' ct=\'admin\' ac=\'edit\' display=\'none\' />\r\n            <menu name=\'用户删除\' ct=\'admin\' ac=\'del\' display=\'none\' />\r\n        </menu>\r\n        <menu name=\'系统管理\' class=\'fa fa-wrench\'>\r\n            <menu name=\'后台菜单配置\' ct=\'system\' ac=\'edit_menu\' />\r\n\r\n            <menu name=\'配置管理\' ct=\'config\' ac=\'index\' />\r\n            <menu name=\'配置添加\' ct=\'config\' ac=\'add\' display=\'none\'  />\r\n            <menu name=\'配置修改\' ct=\'config\' ac=\'edit\' display=\'none\'  />\r\n            <menu name=\'配置删除\' ct=\'config\' ac=\'del\' display=\'none\'  />\r\n\r\n            <menu name=\'操作日志\' ct=\'admin\' ac=\'oplog\' />\r\n            <menu name=\'登录日志\' ct=\'admin\' ac=\'login_log\' />\r\n        </menu>\r\n        <menu name=\'缓存管理\' class=\'fa fa-cloud\'>\r\n            <menu name=\'缓存管理\' ct=\'cache\' ac=\'index\' />\r\n            <menu name=\'缓存删除\' ct=\'cache\' ac=\'del\' display=\'none\' />\r\n            <menu name=\'缓存清理\' ct=\'cache\' ac=\'clear\' display=\'none\' />\r\n            <menu name=\'Redis键值管理\' ct=\'cache\' ac=\'redis_keys\' />\r\n            <menu name=\'Redis服务器信息\' ct=\'cache\' ac=\'redis_info\' />\r\n        </menu>\r\n        <menu name=\'文件管理\' ct=\'filemanage\' ac=\'index\' class=\'fa fa-file\' />\r\n        <menu name=\'文件新增\' ct=\'filemanage\' ac=\'add\' display=\'none\' />\r\n        <menu name=\'文件修改\' ct=\'filemanage\' ac=\'edit\' display=\'none\' />\r\n        <menu name=\'文件删除\' ct=\'filemanage\' ac=\'del\' display=\'none\' />\r\n\r\n        <menu name=\'计划任务管理\' ct=\'crond\' ac=\'index\' class=\'fa fa-tasks\' />\r\n        <menu name=\'计划任务新增\' ct=\'crond\' ac=\'add\' display=\'none\'  />\r\n        <menu name=\'计划任务修改\' ct=\'crond\' ac=\'edit\' display=\'none\'  />\r\n        <menu name=\'计划任务删除\' ct=\'crond\' ac=\'del\' display=\'none\'  />\r\n    </menu>\r\n</xml>','多级管理菜单','',0,'text'),
	(4,'attachment_image','jpg|png|gif|bmp|ico','图片文件类型','',2,'string'),
	(5,'attachment_media','mp3|avi|mpg|mp4|3gp|flv|rm|rmvb|wmv|swf','多媒体文件类型','',2,'string'),
	(7,'attachment_size','16','最大附件大小(Mb)','',2,'number'),
	(6,'attachment_soft','zip|7z|rar|gz|bz2|tar|iso|exe|dll|doc|xls|ppt|docx|xlsx|pptx|wps|pdf|psd','其它文件件类型','',2,'string'),
	(6,'authorized_time','10','登录授权时间','用户登录多长时间会被踢出',1,'number'),
	(2,'doc_auto_des','1','自动提取摘要','',3,'bool'),
	(6,'doc_auto_des_len','150','自动摘要长度','',3,'number'),
	(1,'doc_auto_keywords','1','自动获取关键字','',3,'bool'),
	(3,'doc_auto_thumb','0','自动提取缩略图','',3,'bool'),
	(7,'doc_down_remove','0','抓取远程资源','',3,'bool'),
	(5,'doc_thumb_h','200','缩略图默认高度','',3,'number'),
	(4,'doc_thumb_w','200','缩略图默认宽度','',3,'number'),
	(0,'ip_limit','','后台登录IP限制','',0,'string'),
	(1,'open_upload','1','是否允许上传文件','',2,'bool'),
	(4,'site_description','PHPCALL开发框架','主站摘要信息','',1,'text'),
	(3,'site_keyword','PHPCALL开发框架','主站关键字','',1,'string'),
	(1,'site_name','PHPCALL开发框架','主站名称','',1,'string'),
	(5,'site_tj','','主站统计代码','',1,'text'),
	(2,'site_upload_path','/uploads','附件上传目录','',2,'string'),
	(3,'site_upload_url','http://uploads.phpcall.org','附件目录网址','如果不使用二级域名，此项留空',2,'string'),
	(2,'site_url','http://www.phpcall.org','主站网址','',1,'string');

/*!40000 ALTER TABLE `call_config` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table call_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_content`;

CREATE TABLE `call_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '内容表',
  `catid` smallint(5) DEFAULT NULL COMMENT '分类ID',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `image` char(17) DEFAULT NULL COMMENT '封面图',
  `images` varchar(200) DEFAULT NULL COMMENT '套图',
  `content` text COMMENT '内容',
  `create_user` int(11) DEFAULT NULL COMMENT '创建用户',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_user` int(11) DEFAULT NULL COMMENT '修改用户',
  `update_time` int(10) DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='内容表';



# Dump of table call_crond
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_crond`;

CREATE TABLE `call_crond` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `sort` smallint(5) NOT NULL COMMENT '排序',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '任务名',
  `filename` varchar(248) NOT NULL DEFAULT '' COMMENT '执行脚本',
  `runtime_format` varchar(20) NOT NULL DEFAULT '' COMMENT '执行时间',
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后执行时间',
  `runtime` varchar(30) NOT NULL DEFAULT '0' COMMENT '运行时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态：1=启动 0=停止',
  `uptime` int(10) DEFAULT NULL COMMENT '更新时间',
  `addtime` int(10) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='计划任务表';



# Dump of table call_member
# ------------------------------------------------------------

DROP TABLE IF EXISTS `call_member`;

CREATE TABLE `call_member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` blob,
  `age` blob,
  `email` blob,
  `address` blob,
  `create_user` int(11) DEFAULT NULL,
  `create_time` int(10) DEFAULT NULL,
  `update_user` int(11) DEFAULT NULL,
  `update_time` int(10) DEFAULT NULL,
  `delete_user` int(11) DEFAULT NULL,
  `delete_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(200))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
