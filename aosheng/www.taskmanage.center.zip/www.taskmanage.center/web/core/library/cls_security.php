<?php
class cls_security
{
    /**
	 * Character set
	 *
	 * Will be overridden by the constructor.
	 *
	 * @var	string
	 */
	public static $charset = 'UTF-8';

	/**
	 * XSS Hash
	 *
	 * Random Hash for protecting URLs.
	 *
	 * @var	string
	 */
	private static $_xss_hash;

	/**
	 * CSRF Hash
	 *
	 * Random hash for Cross Site Request Forgery protection cookie
	 *
	 * @var	string
	 */
	private static $_csrf_hash;

	/**
	 * CSRF Expire time
	 *
	 * Expiration time for Cross Site Request Forgery protection cookie.
	 * Defaults to two hours (in seconds).
	 *
	 * @var	int
	 */
	private static $_csrf_expire =	7200;

	/**
	 * CSRF Token name
	 *
	 * Token name for Cross Site Request Forgery protection cookie.
	 *
	 * @var	string
	 */
	private static $_csrf_token_name =	'phpcall_csrf_token';

	/**
	 * CSRF Cookie name
	 *
	 * Cookie name for Cross Site Request Forgery protection cookie.
	 *
	 * @var	string
	 */
	private static $_csrf_cookie_name =	'phpcall_csrf_token';

    public static function init()
    {
        // Is CSRF protection enabled?
		if ($GLOBALS['config']['csrf']['token_on'])
		{
			// CSRF config
			foreach (array('expire', 'token_name', 'cookie_name') as $key)
			{
				if (NULL !== ($val = $GLOBALS['config']['csrf'][$key]))
				{
                    self::${'_csrf_'.$key} = $val;
				}
			}

			// Append application specific cookie prefix
			if ($cookie_prefix = $GLOBALS['config']['cookie']['prefix'])
			{
                self::$_csrf_cookie_name = $cookie_prefix.self::$_csrf_cookie_name;
			}

			// Set the CSRF hash
            self::_csrf_set_hash();
		}

        self::$charset = strtoupper($GLOBALS['config']['charset']);
    }

	public static function xss_clean($str, $is_image = FALSE)
	{
		// Is the string an array?
		if (is_array($str))
		{
			foreach ($str as $key => &$value)
			{
				$str[$key] = self::xss_clean($value);
			}

			return $str;
        }

		$str = util::remove_invisible_characters($str);

        if ($is_image === TRUE)
		{
            $converted_string = $str;
			$str = preg_replace('/<\?(php)/i', '&lt;?\\1', $str);
			return ($str === $converted_string);
		}
		else
		{
			$str = str_replace(array('<?', '?'.'>'), array('&lt;?', '?&gt;'), $str);
		}

        $str = htmlspecialchars($str);

		$str = util::remove_invisible_characters($str);

        return $str;
    }

    // --------------------------------------------------------------------

	/**
	 * CSRF Verify
	 *
	 * @return	CI_Security
	 */
	public static function csrf_verify()
	{
		if (!$GLOBALS['config']['csrf']['token_on'])
        {
            return true;
        }

		// If it's not a POST request we will set the CSRF cookie
        //if (!call::$is_ajax && self::method() === "POST" && $GLOBALS['config']['csrf']['token_on']) 
        if (strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST')
        {
            return self::csrf_set_cookie();
        }

		// Check if URI has been whitelisted from CSRF checks
		if ($exclude_uris = $GLOBALS['config']['csrf']['exclude_uris'])
		{
			foreach ($exclude_uris as $excluded)
			{

                //if (preg_match('#^'.$excluded.'$#iu', util::uri_string()))
				if (preg_match('#^'.$excluded.'#iu', util::uri_string()))
				{
					return true;
				}
			}
		}

		// Check CSRF token validity, but don't error on mismatch just yet - we'll want to regenerate
		$valid = isset(req::$posts[self::$_csrf_token_name], $_COOKIE[self::$_csrf_cookie_name])
			&& hash_equals(req::$posts[self::$_csrf_token_name], $_COOKIE[self::$_csrf_cookie_name]);

		// We kill this since we're done and we don't want to pollute the _POST array
		unset(req::$posts[self::$_csrf_token_name]);

		// Regenerate on every submission?
		if ($GLOBALS['config']['csrf']['token_reset'])
		{
			// Nothing should last forever
			unset($_COOKIE[self::$_csrf_cookie_name]);
            self::$_csrf_hash = NULL;
		}

        self::_csrf_set_hash();
        self::csrf_set_cookie();

		if ($valid !== true)
		{
            self::csrf_show_error();
		}

		//log_message('info', 'CSRF token verified');
        return true;
	}

    // --------------------------------------------------------------------

	/**
	 * CSRF Set Cookie
	 *
	 * @codeCoverageIgnore
	 * @return	CI_Security
	 */
	public static function csrf_set_cookie()
	{
		$expire = time() + self::$_csrf_expire;

        $secure_cookie = (bool) $GLOBALS['config']['cookie']['secure'];

		if ($secure_cookie && ! util::is_https())
		{
			return false;
		}

		setcookie(
			self::$_csrf_cookie_name,
			self::$_csrf_hash,
			$expire,
			$GLOBALS['config']['cookie']['path'],
			$GLOBALS['config']['cookie']['domain'],
			$secure_cookie,
			$GLOBALS['config']['cookie']['httponly']
		);

		return true;
	}

	// --------------------------------------------------------------------

	/**
	 * Show CSRF Error
	 *
	 * @return	void
	 */
	public static function csrf_show_error()
	{
        log::write('csrf_error', util::get_client_ip() . " - " . util::uri_string());
        header('HTTP/1.1 500 Internal Server Error');
        tpl::display("error.500.tpl");
        exit;
    }

    // --------------------------------------------------------------------

	/**
	 * Get CSRF Hash
	 *
	 * @see		CI_Security::$_csrf_hash
	 * @return 	string	CSRF hash
	 */
	public static function get_csrf_hash()
	{
		return self::$_csrf_hash;
	}

	// --------------------------------------------------------------------

	/**
	 * Get CSRF Token Name
	 *
	 * @see		CI_Security::$_csrf_token_name
	 * @return	string	CSRF token name
	 */
	public static function get_csrf_token_name()
	{
		return self::$_csrf_token_name;
	}

	// --------------------------------------------------------------------

    private static function _csrf_set_hash()
    {
        if (self::$_csrf_hash === NULL)
		{
			// If the cookie exists we will use its value.
			// We don't necessarily want to regenerate it with
			// each page load since a page could contain embedded
			// sub-pages causing this feature to fail
			if (isset($_COOKIE[self::$_csrf_cookie_name]) && is_string($_COOKIE[self::$_csrf_cookie_name])
				&& preg_match('#^[0-9a-f]{32}$#iS', $_COOKIE[self::$_csrf_cookie_name]) === 1)
			{
				return self::$_csrf_hash = $_COOKIE[self::$_csrf_cookie_name];
			}

			$rand = self::get_random_bytes(16);
            self::$_csrf_hash = ($rand === false)
				? md5(uniqid(mt_rand(), true))
				: bin2hex($rand);
            //self::$_csrf_hash = md5($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT'] . self::$_csrf_hash);
		}

		return self::$_csrf_hash;
    }

    /**
     * Get random bytes
     *
     * @param	int	$length	Output length
     * @return	string
     */
    public static function get_random_bytes($length)
    {
        if (empty($length) OR ! ctype_digit((string) $length))
        {
            return FALSE;
        }

        if (function_exists('random_bytes'))
        {
            try
            {
                // The cast is required to avoid TypeError
                return random_bytes((int) $length);
            }
            catch (Exception $e)
            {
                // If random_bytes() can't do the job, we can't either ...
                // There's no point in using fallbacks.
                log::error($e->getMessage());
                return FALSE;
            }
        }

        // Unfortunately, none of the following PRNGs is guaranteed to exist ...
        if (defined('MCRYPT_DEV_URANDOM') && ($output = mcrypt_create_iv($length, MCRYPT_DEV_URANDOM)) !== FALSE)
        {
            return $output;
        }


        if (is_readable('/dev/urandom') && ($fp = fopen('/dev/urandom', 'rb')) !== FALSE)
        {
            // Try not to waste entropy ...
            version_compare(PHP_VERSION, '5.4', '>=') && stream_set_chunk_size($fp, $length);
            $output = fread($fp, $length);
            fclose($fp);
            if ($output !== FALSE)
            {
                return $output;
            }
        }

        if (function_exists('openssl_random_pseudo_bytes'))
        {
            return openssl_random_pseudo_bytes($length);
        }

        return FALSE;
    }
}
