<?php

/**
 * 子任务行为
 * Class ctl_sub_tasks
 */
class ctl_sub_tasks
{
    //任务来源
    public static $source = array(
        ''  => '请选择',
        '1' => '客户电话',
        '2' => '官网提交',
        '3' => '网络来源',
    );

    public static $show = array(
        ''  => '请选择',
        '1' => '仅发布者可见',
        '2' => '仅发布者、主要负责人可见',
        '3' => '仅发布者、主要负责人、参与者可见',
        '4' => '所有参与者（包含抄送者）可见',
    );
    //联系方式与紧急联系方式一样
    public static $contact_type = array(
        ''  => '请选择',
        '1' => 'whatsapp',
        '2' => 'Tel',
        '3' => 'Telegram',
        '4' => 'Wechat',
        '5' => 'QQ',
        '6' => 'Potato'
    );

    // currency
    public static $currency_options = array();

    public function __construct()
    {
        $cost_list = db::select('id,name')->from('#PB#_currency')->execute();
        $cost_arr = [];
        $cost_arr[''] = '请选择货币类型';
        foreach($cost_list as $row)
        {
            $id = $row['id'];
            $cost_arr[$id] = $row['name'];
        }
        self::$currency_options = $cost_arr;
        tpl::assign('source', self::$source);
        tpl::assign('show', self::$show);
        tpl::assign('contact_type', self::$contact_type);
    }
    /**
     * 我参与的任务 加入子任务
     */
    public function add_sub_task()
    {
        if (!empty(req::$posts))
        {
            $tip = req::item('tip','','string');
            $data = req::$posts;
            if (!$data['parent_id']) cls_msgbox::show('系统提示', "父级任务不能为空", -1, 3000);
            if (!$data['tasks_title']) cls_msgbox::show('系统提示', "任务标识不能为空", -1, 3000);
            if (!$data['task_kind_id']) cls_msgbox::show('系统提示', "任务类型不能为空", -1, 3000);
            if (!$data['task_level_id']) cls_msgbox::show('系统提示', "紧急程度不能为空", -1, 3000);
            if (!$data['amount']) cls_msgbox::show('系统提示', "任务预不能为空", -1, 3000);
            if (!$data['task_end_datetime']) cls_msgbox::show('系统提示', "任务截止时间不能为空", -1, 3000);
            if (!$data['target']) cls_msgbox::show('系统提示', "任务目标不能为空", -1, 3000);
            if (!$data['task_note']) cls_msgbox::show('系统提示', "任务需求不能为空", -1, 3000);
            if (!$data['demand']) cls_msgbox::show('系统提示', "任务描述不能为空", -1, 3000);
            $parent_data = db::select('level')->from('#PB#_tasks')->where('id', req::item('parent_id', 0, 'int'))->as_row()->execute();

            $member = $data['member']['info'];
            $res    = TRUE;
            unset($data['member']);
            if (empty($member)) cls_msgbox::show('系统提示', "受理范围不能为空", -1, 3000);

            $master_id = $data['parent_id'];
            while (TRUE)
            {
                $find_master_data = db::select('id,parent_id')->from('#PB#_tasks')->where('id', $master_id)->as_row()->execute();
                if (empty($find_master_data))
                {
                    $master_id = -1;
                    break;
                }
                if ($find_master_data['parent_id'] == '0')
                {
                    break;
                }
                else
                {
                    $master_id = $find_master_data['parent_id'];
                }
                unset($find_master_data);
            }

            $fields = array(
                'master_id'         => $master_id,
                'level'             => $parent_data['level'] + 1,
                'task_no'           => mod_tasks::get_task_auto_id(),
                'parent_id'         => req::item('parent_id', '', 'int'),
                'tasks_title'       => req::item('tasks_title', '', 'string'),
                'amount'            => req::item('amount', 0, 'double'),
                'task_kind_id'      => req::item('task_kind_id', 0, 'int'),
                'currency'          => req::item('currency', 0, 'int'),
                'task_level_id'     => req::item('task_level_id', 0, 'int'),
                'accept_status'     => req::item('accept_status', 0, 'int'),
                'task_end_datetime' => strtotime(req::item('task_end_datetime', '')),
                'target'            => req::item('target', '', 'string'),
                'task_note'         => req::item('task_note', '', 'string'),
                'demand'            => req::item('demand', '', 'string'),
                'create_user'       => cls_auth::$user->fields['uid'],
                'post_date'         => time(),
                'create_time'       => time(),
                'update_time'       => time(),
            );
            $gourl  = req::item('gourl', '?ct=tasks&ac=add');
            db::begin_tran();
            $insert_id = mod_tasks::insert_data($fields);
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务ID为{$insert_id}的数据");
            $file_arr = req::item('file_upload');

            if (!empty($file_arr))
            {
                foreach ($file_arr as $key => $value)
                {
                    // $infos  = mod_upload_file::upload($value);
                    $infos = mod_upload_file::upload_files_zip([$key => $value]);
                    // $key_iv = $infos['key_iv'];

                    $fields  = array(
                        'task_id'  => $insert_id,
                        'key_iv'   => $infos['key_iv'],
                        'filename' => $infos['file_name'],
                    );
                    $file_id = mod_tasks_files::insert_data($fields);
                    if ($file_id)
                    {
                        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务附件ID为{$file_id}的数据");
                    }
                    else
                    {
                        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增失败任务附件ID为{$file_id}的数据");
                    }

                }
            }


            //添加任务负责范围
            if ($GLOBALS['config']['global_xss_filtering'])
            {
                $member = json_decode(htmlspecialchars_decode(stripcslashes($member)), TRUE);
            }
            else
            {
                $member = json_decode(stripcslashes($member), TRUE);
            }
            foreach ($member as $key => $value)
            {
                $members[ $key ]['task_id']       = $insert_id;
                $members[ $key ]['relation_id']   = $value['id'];
                $members[ $key ]['relation_type'] = $value['type'] == 'sub_org' ? 1 : ($value['type'] == 'department' ? 2 : ($value['type'] == 'station' ? 3 : 4));
                $members[ $key ]['name']          = $value['name'];
                $members[ $key ]['number']        = isset($value['sn']) ? $value['sn'] : 0;
                $members[ $key ]['create_user']   = cls_auth::$user->fields['admin_id'];
                $members[ $key ]['create_time']   = time();
            }
            $member_arr = array('task_id', 'relation_id', 'relation_type', 'name', 'number', 'create_user', 'create_time');
            $res        = mod_optional_region::bath_insert($member_arr, $members);

            $info            = $data['infos'];
            $info['task_id'] = $insert_id;
            $info['type']    = 2;
            //print_r($info);exit;
            $info['create_user'] = cls_auth::$user->fields['admin_id'];
            $info['create_time'] = time();
            $pid                 = mod_push_unit_info::insert_data($info);
            //print_r($pid);exit;
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了企业信息ID为{$pid}的数据");

           /* $data = array(
                'task_id'     => $insert_id,
                'progress'    => 0,
                'create_user' => cls_auth::$user->fields['admin_id'],
                'create_time' => time(),
                'status'      => 0,
            );

            $progress_table = '#PB#_progress';
            list($insert_id, $rows_affected) = db::insert($progress_table)->set($data)->execute();*/
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务过程ID为{$insert_id}的数据");

            if (!$insert_id || !$pid || !$res)
            {
                db::rollback();
                cls_msgbox::show('系统提示', "添加失败", '?ct='.$tip.'&ac=sub_tasks&id=' . req::item('parent_id', '', 'int'));
            }
            db::commit();
            db::autocommit(true);
            $insert_id_res = db::select('id')->from('#PB#_optional_region')
                ->where('delete_user',0)
                ->and_where('task_id',$insert_id)
                ->order_by('id','DESC')
                ->execute();
            $res_id = !empty($insert_id_res) ? implode(',',array_column($insert_id_res,'id')) : '';
            $data_p["task_id"] = $insert_id;
            $data_p["optional_region"] = $res_id;
            $data_p["progress"] = -1;
            $data_p["create_user"] = cls_auth::$user->fields['admin_id'];
            $data_p["create_time"] = time();
            $data_p["type"]        = 1;
            $data_p["status"]      = 0;
            $res_p = db::insert("#PB#_progress")->set($data_p)->execute();
            cls_msgbox::show('系统提示', "添加成功", '?ct='.$tip.'&ac=sub_tasks&id=' . req::item('parent_id', '', 'int'));

        }
        else
        {
            $tasks_kinds = mod_tasks_kinds::get_all('id,title');
            $tasks_level = mod_tasks_levels::get_all('id,title');

            $parent_id   = req::item('parent_id', 0, 'int');
            $parent_data = db::select('id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')->from('#PB#_tasks')->where('id', $parent_id)->as_row()->execute();
            if (!$parent_data)
            {
                cls_msgbox::show('系统提示', "无法添加子任务", '-1');
            }

            $config_arr = db::select('name,value')->from('#PB#_tasks_configs')->where('name','=','max_post_day')->execute();
            $config = [];
            if (!empty($config_arr)) {
                foreach($config_arr as $row) {
                    if ($row['name'] == 'max_post_day')
                    {
                        $config['max_post_day'] = $row['value'];
                    }
                }
            }
            if (count($config) > 0)
            {
                if ($config['max_post_day'] < 2) {
                    $today   =  date('Y-m-d H:i:s', strtotime('+'.($config['max_post_day'] + 1).' day'));
                } else {
                    $today   =  date('Y-m-d H:i:s', strtotime('+'.($config['max_post_day']).' day'));
                }
            }
            //获取当前用户都信息
            $member = mod_curl_info::get_one_people_info(cls_auth::$user->fields['admin_id']);
            tpl::assign('member', $member);
            tpl::assign('today', $today);
            tpl::assign('parent_data', $parent_data);
            tpl::assign('parent_id', $parent_id);
            tpl::assign('tasks_kinds', $tasks_kinds);
            tpl::assign('tasks_level', $tasks_level);
            tpl::assign('currency_options', self::$currency_options);
            tpl::assign('ac', 'add');
            tpl::assign('ct', req::item('ct','','string'));
            tpl::display('add_sub_task.tpl');
        }


    }

}