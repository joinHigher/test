<?php
if (!defined('PHPCALL')) exit('Request Error!');

class ctl_tasks
{

    public static $url_cust = URL_API_CUST . '?ct=internal_api&ac=get_member_info_by_code&code=';
    private static $running_task = 1;

    public static $show = array(
        '1' => '仅发布者可见',
        '2' => '仅发布者、主要负责人可见',
        '3' => '仅发布者、主要负责人、参与者可见',
        '4' => '所有参与者（包含抄送者）可见',
    );
    //联系方式与紧急联系方式一样
    public static $contact_type = array(
        ''  => '请选择',
        '1' => 'whatsapp',
        '2' => 'Tel',
        '3' => 'Telegram',
        '4' => 'Wechat',
        '5' => 'QQ',
        '6' => 'Potato'
    );

    // currency
    public static $currency_options = array();



    public function __construct()
    {
        $cost_list    = db::select('id,name')->from('#PB#_currency')->execute();
        $cost_arr     = [];
        $cost_arr[''] = '请选择货币类型';
        foreach ($cost_list as $row)
        {
            $id              = $row['id'];
            $cost_arr[ $id ] = $row['name'];
        }
        self::$currency_options = $cost_arr;
        //tpl::assign('source', self::$source);
        tpl::assign('show', self::$show);
        tpl::assign('contact_type', self::$contact_type);
    }

    private $where;

    /**
     * 待我受理列表
     */
    public function index()
    {
        $poster_id = req::item('poster_id', 0, 'int');
        //
        $task_datas = db::select('task_id,relation_id,relation_type')->from('#PB#_optional_region')->where('delete_user', 0)->order_by('task_id')->execute();
        $task_items = [];
        $task_ids   = [];
        if (!empty($task_datas))
        {
            foreach ($task_datas as $row)
            {
                $task_id                  = $row['task_id'];
                $task_items[ $task_id ][] = [
                    'relation_id'   => $row['relation_id'],
                    'relation_type' => $row['relation_type'],
                ];
            }

            foreach ($task_items as $key => $task_item)
            {
                $is_in_place = mod_curl_info::is_allow_case_user($task_item, cls_auth::$user->fields['admin_id']);
                if ($is_in_place)
                {
                    $task_ids[] = $key;
                }
            }
        }

        $my_tasks_id = db::select('id')->from('#PB#_tasks')->where('create_user', cls_auth::$user->fields['admin_id'])->execute();
        if (!empty($my_tasks_id))
        {
            foreach ($my_tasks_id as $row)
            {
                if (!in_array($row['id'], $task_ids))
                {
                    $task_ids[] = $row['id'];
                }
            }

        }
        $task_ids      = array_unique($task_ids);
        $date_from     = req::item('date_from', '');
        $date_end      = req::item('date_end', '');
        $date_type     = req::item('date_type', '');
        $keyword       = req::item('keyword', '');
        $tasks_kind_id = req::item('tasks_kind_id', 0, 'int');
        $page_size     = req::item('page_size', 10);


        if ($tasks_kind_id)
        {
            $this->where[] = ['task_kind_id', '=', $tasks_kind_id];
        }

        if ($date_type == 'post_date')
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['create_time', '>=', strtotime($date_from . ' 00:00:00')];
                $this->where[] = ['create_time', '<=', strtotime($date_end . ' 23:59:59')];
            }
        }
        else if ($date_type == 'stop_date')
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['task_end_datetime', '>=', strtotime($date_from . ' 00:00:00')];
                $this->where[] = ['task_end_datetime', '<=', strtotime($date_end . ' 23:59:59')];
            }
        }

        $this->where[] = ['status', '=', 0];
        if ($poster_id != 0)
        {
            $this->where[] = ['create_user', '=', $poster_id];
        }

        if (count($task_ids) > 0)
        {
            $this->where[] = ['id', 'in', $task_ids];
        }
        else
        {
            $this->where[] = ['id', '=', -1];
        }
        $this->where[] = ['delete_user', '=', 0];
        $result        = db::select('count(*) AS `count`')->from('#PB#_tasks')->as_row();
        $result->where($this->where);
        if (!empty($keyword))
        {
            $result->and_where_open();
            $result->where('tasks_title', 'like', "%{$keyword}%");
            $result->or_where('task_no', 'like', "%{$keyword}%");
            $result->and_where_close();
        }

        $result = $result->execute();
        $count  = $result['count'];
        $pages  = pub_page::make($count, $page_size);
        $query  = db::select('id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')->from('#PB#_tasks');
        $query->where($this->where);
        if (!empty($keyword))
        {
            $query->and_where_open();
            $query->where('tasks_title', 'like', "%{$keyword}%");
            $query->or_where('task_no', 'like', "%{$keyword}%");
            $query->and_where_close();
        }
        $query
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->order_by('create_time', 'desc');
        $list = $query->execute();

        tpl::assign('tasks_kind_id', $tasks_kind_id);
        tpl::assign('poster_id', $poster_id);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list', $list);
        tpl::display('tasks.index.tpl');
    }

    /**
     * 任务详情
     */
    public function detail()
    {
        mod_status::task_is_allow_user();
        $actvie = '';
        $id     = req::item('id', 0, 'int');
        mod_tasks_viewers::saveViewer($id);
        $data = db::select('id,parent_id,task_kind_id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')->from('#PB#_tasks')->where('id', $id)->as_row()->execute();
        if (!$data)
        {
            cls_msgbox::show('系统提示', "无法检视", '-1');
        }

        $is_allow  = FALSE;
        $personnel = db::select('amount')
            ->from('#PB#_personnel')
            ->where('user_id', cls_auth::$user->fields['admin_id'])
            ->where('p_type', 1)
            ->where('task_id', $id)
            ->where('delete_user', 0)
            ->as_row()
            ->execute();
        if (!empty($personnel))
        {
            $is_allow = TRUE;
            $new_cost = $personnel['amount'];
        }
        else
        {
            $new_cost = $data['amount'];
        }
        $files          = db::select()->from('#PB#_tasks_files')->execute();
        $condition      = array(
            'id' => $data['task_kind_id']
        );
        $task_kind_arr  = mod_tasks_kinds::get_one('id,title', $condition);
        $condition      = array(
            'id' => $data['task_level_id']
        );
        $task_level_arr = mod_tasks_levels::get_one('id,title', $condition);

        $task_files_arr = mod_tasks_files::get_files_by_task_id($data['id']);

        $task_kind  = $task_kind_arr['title'];
        $task_level = $task_level_arr['title'];
        tpl::assign('is_allow', $is_allow);
        tpl::assign('new_cost', $new_cost);
        tpl::assign('data', $data);
        tpl::assign('active', $actvie);
        tpl::assign('id', $data['id']);
        tpl::assign('files', $files);
        tpl::assign('task_kind', $task_kind);
        tpl::assign('task_level', $task_level);
        tpl::assign('task_files_arr', $task_files_arr);
        tpl::display('tasks.detail.tpl');
    }

    public function download()
    {
        $task_files = '#PB#_tasks_files';
        $task_id    = req::item('task_id', 0, 'int');
        $filename   = req::item('filename', '', 'string');

        $item = db::select('filename,key_iv')->from($task_files)->where('task_id', $task_id)->and_where('filename', $filename)->as_row()->execute();
        if ($item)
        {
            mod_upload_file::download($item['filename'], $item['key_iv']);
        }
        else
        {
            cls_msgbox::show('系统提示', "无法下载", -1, 3000);
        }

    }

    /**
     * 主项目详情
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            if (!$data['tasks_title']) cls_msgbox::show('系统提示', "任务标识不能为空", -1, 3000);
            if (!$data['task_kind_id']) cls_msgbox::show('系统提示', "任务类型不能为空", -1, 3000);
            if (!$data['task_level_id']) cls_msgbox::show('系统提示', "紧急程度不能为空", -1, 3000);
            if (!$data['amount']) cls_msgbox::show('系统提示', "任务预不能为空", -1, 3000);
            if (!$data['task_end_datetime']) cls_msgbox::show('系统提示', "任务截止时间不能为空", -1, 3000);
            if (!$data['target']) cls_msgbox::show('系统提示', "任务目标不能为空", -1, 3000);
            if (!$data['task_note']) cls_msgbox::show('系统提示', "任务需求不能为空", -1, 3000);
            if (!$data['demand']) cls_msgbox::show('系统提示', "任务描述不能为空", -1, 3000);

            $info2 = $data['infos'];
            unset($data['infos']);
            if (!$info2['source']) cls_msgbox::show('系统提示', "发布单位信息来源不能为空", -1, 3000);
            $member = $data['member']['info'];
            $res    = TRUE;
            unset($data['member']);
            if (empty($member)) cls_msgbox::show('系统提示', "受理范围不能为空", -1, 3000);


            $fields = array(
                'task_no'           => mod_tasks::get_task_auto_id(),
                'tasks_title'       => req::item('tasks_title', '', 'string'),
                'amount'            => req::item('amount', 0, 'double'),
                'task_kind_id'      => req::item('task_kind_id', 0, 'int'),
                'currency'          => req::item('currency', 0, 'int'),
                'task_level_id'     => req::item('task_level_id', 0, 'int'),
                'accept_status'     => req::item('accept_status', 0, 'int'),
                'task_end_datetime' => strtotime(req::item('task_end_datetime', '')),
                'target'            => req::item('target', '', 'string'),
                'task_note'         => req::item('task_note', '', 'string'),
                'demand'            => req::item('demand', '', 'string'),
                // 'poster_id'         => cls_auth::$user->fields['uid'],
                'create_user'       => cls_auth::$user->fields['uid'],
                'post_date'         => time(),
                'create_time'       => time(),
                'update_time'       => time(),
            );
            $gourl  = req::item('gourl', '?ct=tasks&ac=add');
            db::begin_tran();
            $insert_id = mod_tasks::insert_data($fields);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务ID为{$insert_id}的数据");
            $file_arr = req::item('file_upload');

            if (!empty($file_arr))
            {
                foreach ($file_arr as $key => $value)
                {
                    // $infos  = mod_upload_file::upload($value);
                    $infos = mod_upload_file::upload_files_zip([$key => $value]);
                    // $key_iv = $infos['key_iv'];

                    $fields  = array(
                        'task_id'  => $insert_id,
                        'key_iv'   => $infos['key_iv'],
                        'filename' => $infos['file_name'],
                    );
                    $file_id = mod_tasks_files::insert_data($fields);
                    if ($file_id)
                    {
                        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务附件ID为{$file_id}的数据");
                    }
                    else
                    {
                        db::rollback();
                        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增失败任务附件ID为{$file_id}的数据");
                    }

                }
            }

            //添加任务负责范围
            if ($GLOBALS['config']['global_xss_filtering'])
            {
                $member = json_decode(htmlspecialchars_decode(stripcslashes($member)), TRUE);
            }
            else
            {
                $member = json_decode(stripcslashes($member), TRUE);
            }
            foreach ($member as $key => $value)
            {
                $members[ $key ]['task_id']       = $insert_id;
                $members[ $key ]['relation_id']   = $value['id'];
                $members[ $key ]['relation_type'] = $value['type'] == 'sub_org' ? 1 : ($value['type'] == 'department' ? 2 : ($value['type'] == 'station' ? 3 : 4));
                $members[ $key ]['name']          = $value['name'];
                $members[ $key ]['number']        = isset($value['sn']) ? $value['sn'] : 0;
                $members[ $key ]['create_user']   = cls_auth::$user->fields['admin_id'];
                $members[ $key ]['create_time']   = time();
            }
            $member_arr = array('task_id', 'relation_id', 'relation_type', 'name', 'number', 'create_user', 'create_time');
            $res        = mod_optional_region::bath_insert($member_arr, $members);

            // 添加发布单位信息
            if (!empty($info2['img_data']))
            {
                foreach ($info2['img_data'] as $key => $value)
                {
                    $infos = mod_upload_file::upload_files_zip([$key => $value]);
                    if (!$infos['status'])
                    {
                        db::rollback();
                        cls_msgbox::show('系统提示', "发布单位信息文件上传失败", -1, 3000);
                    }

                    $img_data[] = array(
                        'key_iv'   => $infos['key_iv'],
                        'filename' => $infos['file_name'],
                    );
                    unset($infos);
                }
                $info2['img_data'] = json_encode($img_data);
            }

            $info2['task_id'] = $insert_id;
            if (isset($info2['is_m']) && $info2['is_m'])
            {
                if ($info2['is_m'] == 1)
                {
                    unset($data['info2']);
                    $info = $data['info'];
                    if ($info['a_number'])
                    {
                        $res = json_decode(util::http_get(self::$url_cust . $info['a_number']), TRUE);
                        if ($res['code'] != '0')
                        {
                            db::rollback();
                            cls_msgbox::show('系统提示', "发布单位信息户口号有误", -1, 3000);
                        }
                        $info['m_type']   = $res['data']['type'];
                        $info['contacts'] = $res['data']['contacts'];
                        $info['name']     = $res['data']['name'];
                        $info['contact']  = json_encode($res['data']['contact_ways']);
                    }
                }
                elseif($info2['is_m'] == 2)
                {
                    unset($data['info']);
                    $info              = $data['info2'];
                    if (!empty($info['guarantee']))
                    {
                        $guarantee = '';
                        $info['guarantee'] = array_unique($info['guarantee']);
                        foreach ($info['guarantee'] as $key => $value)
                        {
                            if(!$value)
                            {
                                continue;
                            }
                            $res = json_decode(util::http_get(self::$url_cust . $value), TRUE);
                            if ($res['code'] != '0')
                            {
                                db::rollback();
                                cls_msgbox::show('系统提示', "发布单位信息户口号有误", -1, 3000);
                            }
                            $guarantee[] = [
                                'name'   => $res['data']['name'],
                                'number' => $value
                            ];
                        }
                        unset($info['guarantee']);
                        if($guarantee)
                        {
                            $info['guarantee_info'] = json_encode($guarantee);
                        }

                    }

                    if (!empty($info['contact']))
                    {
                        foreach ($info['contact'] as $key => $value)
                        {
                            $contact[] = [
                                'type' => self::$contact_type[ $info['contact_type'][ $key ] ],
                                'num'  => $value
                            ];
                        }
                        $info['contact'] = json_encode($contact);
                    }
                    unset($info['contact_type']);
                }
            }

            $info['create_user'] = cls_auth::$user->fields['admin_id'];
            $info['create_time'] = time();
            $info                = array_merge($info2, $info);
            $p_id                = mod_push_unit_info::insert_data($info);
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了企业信息ID为{$p_id}的数据");
            if (!$insert_id || !$p_id || !$res)
            {
                db::rollback();
                cls_msgbox::show('系统提示', "添加失败", '-1');
            }
            db::commit();
            db::autocommit(true);
            cls_msgbox::show('系统提示', "添加成功", '?ct=tasks&ac=add');
        }
        else
        {
            $tasks_kinds = mod_tasks_kinds::get_all('id,title');
            $tasks_level = mod_tasks_levels::get_all('id,title');
            //获取当前用户都信息
            $member = mod_curl_info::get_one_people_info(cls_auth::$user->fields['admin_id']);

            //任务来源
            $sources = mod_tasks_sources::option_data();

            $config_arr = db::select('name,value')->from('#PB#_tasks_configs')->where('name','=','max_post_day')->execute();
            $config = [];
            if (!empty($config_arr)) {
                foreach($config_arr as $row) {
                    if ($row['name'] == 'max_post_day')
                    {
                        $config['max_post_day'] = $row['value'];
                    }
                }
            }
            if (count($config) > 0)
            {
                if ($config['max_post_day'] < 2) {
                    $today   =  date('Y-m-d H:i:s', strtotime('+'.($config['max_post_day'] + 1).' day'));
                } else {
                    $today   =  date('Y-m-d H:i:s', strtotime('+'.($config['max_post_day']).' day'));
                }

            }
            tpl::assign('today', $today);
            tpl::assign('tasks_kinds', $tasks_kinds);
            tpl::assign('member', $member);
            tpl::assign('sources', $sources);
            tpl::assign('tasks_level', $tasks_level);
            tpl::assign('currency_options', self::$currency_options);
            tpl::assign('ac', 'add');
            tpl::assign('ct', req::item('ct','','string'));
            tpl::display('tasks.add.tpl');
        }

    }

    /**
     * 加入受理任务行为
     */
    public function add_personnel()
    {
        $json['status']  = 'fail';
        $task_id         = req::item('task_id', 0, 'int');
        $amount          = req::item('amount', 0, 'double');
        $reason          = req::item('reason', '', 'string');
        $progress_table  = '#PB#_progress';
        $optional_region = '#PB#_optional_region';
        if (req::is_ajax())
        {
            // get tasks amount
            $task_arr       = db::select('amount,parent_id,create_user')->from('#PB#_tasks')->where('id', $task_id)->as_row()->execute();
            $my_create_user = 0;
            if (isset($task_arr['create_user']))
            {
                $my_create_user = $task_arr['create_user'];
                $task_update_arr = [
                    'update_time'=> time()
                ];
                db::update("#PB#_tasks")->set($task_update_arr)->where("id",$task_id)->execute();
            }
            //check user
            $result = db::select('count(*) AS `count`')
                ->from('#PB#_personnel')
                ->where('task_id', $task_id)
                ->and_where('user_id', cls_auth::$user->fields['admin_id'])
                ->and_where('p_type', 1)
                ->and_where('delete_user', 0)
                ->as_row()->execute();
            $count  = $result['count'];
            if ($count > 0)
            {
                $json['status'] = 'has_one';
                echo json_encode($json);
                exit();
            }
            db::begin_tran();
            // begin 删除personnel的抄写者,跟参与者 因为身分转移的关系
            $login_user_id         = cls_auth::$user->fields['admin_id'];
            $personnel_update_arr  = [
                'delete_user' => $login_user_id,
                'delete_time' => time()];
            $personnel_where_arr[] = ['task_id', '=', $task_id];
            $personnel_where_arr[] = ['delete_user', '=', 0];
            $personnel_where_arr[] = ['user_id', '=', $login_user_id];
            mod_personnel::update_data($personnel_update_arr, $personnel_where_arr);
            // end if
            $task_datas = db::select('task_id,relation_id,relation_type')
                ->from('#PB#_optional_region')
                ->where('task_id', $task_id)
                ->where('delete_user', 0)
                ->order_by('task_id')
                ->execute();
            $task_items = [];
            foreach ($task_datas as $row)
            {
                $task_items[] = [
                    'relation_id'   => $row['relation_id'],
                    'relation_type' => $row['relation_type'],
                ];
            }
            $is_in_place = mod_curl_info::is_allow_case_user($task_items, cls_auth::$user->fields['admin_id']);
            if (!$is_in_place && $my_create_user == 0)
            {
                db::rollback();
                $json['status'] = 'not_in_place';
                echo json_encode($json);
                exit();
            }

            // 0 当前任务 ,1 或者子任务 progress
            // 1 任务 2 子任务 personnel
            $personnel_status = 1;
            $progress_status  = 0;
            if (isset($task_arr['parent_id']))
            {
                if ($task_arr['parent_id'] > 0)
                {
                    $progress_status  = 1;
                    $personnel_status = 2;
                }
            }


            $data_amount = -1;
            if (!empty($task_arr))
            {
                $data_amount = $task_arr['amount'];
            }
            $data                     = db::select('id')
                ->from('#PB#_personnel')
                ->where('task_id', $task_id)
                ->where('p_type', 1)
                ->where('delete_user', 0)->as_row()
                ->execute();
            $field_arr                = array();
            $field_arr['task_id']     = $task_id;
            $field_arr['type']        = $personnel_status;
            $field_arr['create_user'] = cls_auth::$user->fields['admin_id'];
            $field_arr['user_id']     = cls_auth::$user->fields['admin_id'];
            $field_arr['create_time'] = time();
            $field_arr['reason']      = $reason;
            $field_arr['p_type']      = 1;
            $field_arr['update_user'] = 0;
            $field_arr['update_time'] = 0;
            $field_arr['delete_user'] = 0;
            $field_arr['delete_time'] = 0;

            if ((int)$amount == 0)
            {
                $field_arr['amount'] = $data_amount;
            }
            else
            {
                $field_arr['amount'] = $amount;
            }
            if (!empty($data))
            {
                $result = db::select('count(*) AS `count`')
                    ->from('#PB#_tasks')
                    ->where('id', $task_id)
                    ->and_where('amount', $amount)
                    ->and_where('delete_user', 0)
                    ->as_row()
                    ->execute();
                $count  = $result['count'];

                if (($data_amount == $amount or (int)$amount == 0) and $count == 0)
                {
                    $field_arr['status'] = self::$running_task;
                    // change tasks status
                    $tasks_fields_arr = array(
                        'status' => self::$running_task,
                    );
                    db::update('#PB#_tasks')->set($tasks_fields_arr)->where("id", '=', $task_id)->execute();
                    if (db::affected_rows() < 1)
                    {
                        log::error("更新任务失败 task_id:" . $task_id);
                        db::rollback();
                        die(json_encode($json));
                    }
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "更新了任务ID为{$task_id}的数据");

                    $data = array(
                        'task_id'     => $task_id,
                        'progress'    => 0,
                        'type'        => $progress_status,
                        'create_user' => cls_auth::$user->fields['admin_id'],
                        'create_time' => time(),
                        'status'      => self::$running_task,
                    );
                    list($insert_id, $rows_affected) = db::insert($progress_table)->set($data)->execute();
                    if ($insert_id < 1)
                    {
                        log::error("加入任务过程失败 task_id:" . $task_id);
                        db::rollback();
                        die(json_encode($json));
                    }
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务过程ID为{$insert_id}的数据");

                    $data = [
                        'delete_user' => cls_auth::$user->fields['admin_id'],
                        'delete_time' => time()
                    ];

                    db::update($optional_region)->set($data)->where("task_id", '=', $task_id)->execute();
                    if (db::affected_rows() < 1)
                    {
                        log::error("更新任务范围选项失败 task_id:" . $task_id);
                        db::rollback();
                        die(json_encode($json));
                    }
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "更新了任务范围TASK ID为{$task_id}的数据");
                }
                else
                {
                    $field_arr['status'] = 0;
                }
            }
            else
            {
                if ($data_amount == $amount || (int)$amount == 0)
                {
                    $field_arr['status'] = 1;
                    // change tasks status
                    $tasks_fields_arr = array(
                        'status' => 1,
                    );
                    db::update('#PB#_tasks')->set($tasks_fields_arr)->where("id", '=', $task_id)->execute();
                    if (db::affected_rows() < 1)
                    {
                        log::error("更新任务失败 task_id:" . $task_id);
                        db::rollback();
                        die(json_encode($json));
                    }
                    $data = array(
                        'task_id'     => $task_id,
                        'progress'    => 0,
                        'create_user' => cls_auth::$user->fields['admin_id'],
                        'create_time' => time(),
                        'status'      => self::$running_task,
                    );
                    list($insert_id, $rows_affected) = db::insert($progress_table)->set($data)->execute();
                    if ($insert_id < 1)
                    {
                        log::error("新增任务过程失败 task_id:" . $task_id);
                        db::rollback();
                        die(json_encode($json));
                    }
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务过程ID为{$insert_id}的数据");

                    $data = [
                        'delete_user' => cls_auth::$user->fields['admin_id'],
                        'delete_time' => time()
                    ];
                    db::update($optional_region)->set($data)->where("task_id", '=', $task_id)->execute();
                    if (db::affected_rows() < 1)
                    {
                        log::error("更新选项范围失败 task_id:" . $task_id);
                        db::rollback();
                        die(json_encode($json));
                    }
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "更新了任务范围TASK ID为{$task_id}的数据");

                }
                else
                {
                    $field_arr['status'] = 0;
                }

            }
            list($insert_id, $rows_affected) = db::insert('#PB#_personnel')->set($field_arr)->execute();
            if ($data_amount == -1 || !$insert_id)
            {
                db::rollback();
                die(json_encode($json));

            }
            $json['status'] = 'success';
            db::commit();
            db::autocommit(true);
        }
        // 负责人
        $where_arr  = [
            ['create_user', '=', cls_auth::$user->fields['admin_id']],
            ['delete_user', '=', 0],
            ['task_id', '=', $task_id],
            ['p_type', '=', 1],
            ['status', '=', 1],
        ];
        $pm_data    = db::select('count(*) as total')->from('#PB#_personnel')->where($where_arr)->as_row()->execute();
        $json['pm'] = $pm_data['total'];
        echo json_encode($json);
    }

}