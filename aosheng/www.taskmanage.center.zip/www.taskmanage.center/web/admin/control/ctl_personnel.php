<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 任务参与人员
 *
 * @version $Id$
 */
class ctl_personnel
{
    public function __construct()
    {
        $this->table = '#PB#_personnel';
        $this->where = [
            ['delete_user', '=', '0'],
        ];
    }

    /**
    * 列表
     */
    public function index()
    {
        $id = req::item('id', 0, 'int');
        $p_type = req::item('p_type');
        //echo $p_type;
       if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }
        $type = $p_type == 'cc' ? 3 : ($p_type == 'join' ? 2 : 1);
        if($p_type == 'main' || $p_type == '')
        {
            $this->where[] = ['status','=',1];
        }
        $this->where[] = ['p_type','=',$type];
        $this->where[] = ['type','=',1];
        $this->where[] = ['task_id','=',$id];
        $page_size = req::item('page_size', 10);
        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();
        $pages = pub_page::make($row['count'], $page_size);
        $list  = db::select("id,sta_name,task_id")->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('create_time','desc')->execute();
        if(!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $member = mod_curl_info::get_one_people_info(46);
                $list[$key]['org_name']  = $member -> organization;
                $list[$key]['dep_name']  = $member -> department;
                $list[$key]['op_name']   = $member->name;
                $list[$key]['sta_name']  = isset($member->job) ? $member->job : null;
                $list[$key]['number']    = $member->sn;

            }
        }
        //获取当前已存在的用户id
        $where[] = ['delete_user', '=', '0'];
        $where[] = ['task_id','=',$id];
        $ids = db::select('user_id')->from($this->table)->where($where)->distinct(true)->execute();
        $user_ids = implode(',',array_column($ids,'user_id'));
        unset($ids);
        tpl::assign('list', $list);
        tpl::assign('user_ids', $user_ids);
        tpl::assign('id', $id);
        tpl::assign('p_type', $p_type);
        tpl::assign('active', 'personnel');
        tpl::assign('pages', $pages['show']);
        tpl::display('personnel.index.tpl');
    }


    /**
     * @desc 删除
     */
    public function del()
    {
        $id = req::item('id', 0,'int');
        if(!$id)
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');exit;
        }
        $delete_arr = array
        (
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );

        db::update($this->table)
            ->set($delete_arr)
            ->where('id', '=', $id)
            ->execute();
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除人员参与ID为：{$id}的数据");
        cls_msgbox::show('系统提示', "删除成功", $_SERVER['HTTP_REFERER']);
    }


    /**
    * @desc  添加人员
     *
     */
    public function add()
    {
        $task_id = req::item('task_id', 0, 'int');
        $p_type = req::item('p_type', 0, 'int');
        $member = req::item('info');
        if(!$task_id || !$member)
        {
            $data = array(
                'status' => '-1',
                'message' => '数据有误',
                'data' => array(),
            );
            die(json_encode($data));
        }
        foreach ($member as $key => $value)
        {
            $infos[$key]['task_id']   = $task_id;
            $infos[$key]['p_type']    = $p_type;
            $infos[$key]['user_id']   = (int)$value['userid'];
            $infos[$key]['create_user']   = cls_auth::$user->fields['admin_id'];
            $infos[$key]['create_time']   = time();
        }
        $field_arr = array('task_id', 'p_type', 'user_id', 'create_user','create_time');
        $res = mod_personnel::bath_insert($field_arr,$infos);
        if (!$res)
        {
            $data = array(
                'status' => '-1',
                'message' => '失败',
                'data' => array(),
            );
            die(json_encode($data));
        }
        $msg = $p_type == 2 ? "参与人员" : "抄送人员";
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务ID为{$task_id}的{$msg}数据数据");
        $data = array(
            'status' => '0',
            'message' => '成功',
            'data' => $infos,
        );
        die(json_encode($data));

    }


    /**
     *  转移主要负责人
     */
    public function change_poeple()
    {
        $id = req::item('id', 0, 'int');
        if(!$id)
        {
            $data = array(
                'status' => '-1',
                'message' => '数据有误',
                'data' => array(),
            );
            die(json_encode($data));
        }
        $rows = db::select('id,task_id,type,amount')->from($this->table)->where('id',$id)->as_row()->execute();
        if(empty($rows))
        {
            $data = array(
                'status' => '-1',
                'message' => '数据不存在',
                'data' => array(),
            );
            die(json_encode($data));
        }
        $task_id = $rows['task_id'];
        $member = req::item('member');
        if (!empty($member))
        {
            db::begin_tran();
            foreach ($member as $key => $value)
            {
                $infos[$key]['task_id']        = $task_id;
                $infos[$key]['relation_id']    = $value['id'];
                $infos[$key]['relation_type']  = $value['type'] == 'sub_org' ? 1 : ($value['type'] == 'department' ? 2 : ($value['type'] == 'station' ? 3 : 4));
                $infos[$key]['name']           = $value['name'];
                $infos[$key]['number']         = isset($value['sn']) ? $value['sn'] : 0;
                $infos[$key]['create_user']    = cls_auth::$user->fields['admin_id'];
                $infos[$key]['create_time']    = time();
            }
            $field_arr = array('task_id', 'relation_id', 'relation_type', 'name', 'number', 'create_user','create_time');
            $res = mod_optional_region::bath_insert($field_arr,$infos);

            $where[] = ['id','=',$id];
            $where[] = ['p_type','=','1'];
            $where[] = ['delete_user','=','0'];
            $up = [
                'delete_user'=>cls_auth::$user->fields['admin_id'],
                'delete_time'=>time()];
            $res_p = mod_personnel::update_data( $up,$where);

            $update_t = array(
                'status'      => 0,
                'amount'      => $rows['amount'],
                'update_user' => cls_auth::$user->fields['admin_id'],
                'update_time' => time()
            );
            $t_res = mod_tasks::update_data($update_t,array('id ' => $task_id));

            $update_v = array(
                'delete_user'=>cls_auth::$user->fields['admin_id'],
                'delete_time'=>time()
            );
            $data_p_info = db::select('task_id')->from("#PB#_tasks_viewers")->where('task_id',$task_id)->and_where('delete_user','0')->as_row()->execute();
            $v_res =true;
            if(!empty($data_p_info))
            {
                $v_res = db::update("#PB#_tasks_viewers")->set($update_v)->where('task_id',$task_id)->and_where('delete_user','0')->execute();
            }


            if (!$res || !$res_p || !$t_res || !$v_res)
            {
                db::rollback();
                $data = array(
                    'status' => '-1',
                    'message' => '转移失败',
                    'data' => array(),
                );
                die(json_encode($data));
            }
            db::commit();
            db::autocommit(true);
            $insert_id_res = db::select('id')->from('#PB#_optional_region')
                ->where('delete_user',0)
                ->and_where('task_id',$task_id)
                ->order_by('id','DESC')
                ->execute();
            $res_id = !empty($insert_id_res) ? implode(',',array_column($insert_id_res,'id')) : '';
            $data_p["task_id"] = $task_id;
            $data_p["optional_region"] = $res_id;
            $data_p["progress"] = -1;
            $data_p["create_user"] = cls_auth::$user->fields['admin_id'];
            $data_p["create_time"] = time();
            $data_p["type"]        = $rows['type'] == 1 ? 0 : 1;
            $data_p["status"]      = 8;
            $res_p = db::insert("#PB#_progress")->set($data_p)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "转移了任务ID为{$task_id}的主要负责人数据");
            $data = array(
                'status' => '0',
                'message' => '成功',
                'data' => array(),
            );
            die(json_encode($data));

        }
    }

}
