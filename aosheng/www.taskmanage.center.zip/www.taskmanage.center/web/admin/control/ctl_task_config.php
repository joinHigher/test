<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 *
 */
class ctl_task_config
{

    private static $tasks_kinds = '#PB#_tasks_kinds';
    private static $tasks_sources = '#PB#_tasks_sources';

    public function index()
    {

        $expired_days = ["7" => "7", "15" => "15", "30" => "30", "45" => "45", "90" => "90"];
        if (!empty(req::$posts))
        {
            $val = req::item("expired_days");
            mod_tasks_configs::update_data(["value" => $val], ["name" => "max_post_day"]);
            $val = req::item("replay_option");
            mod_tasks_configs::update_data(["value" => $val], ["name" => "comment_mode"]);
            $val = req::item("sub_task_num");
            if ($val == "on")
            {
                mod_tasks_configs::update_data(["value" => "1"], ["name" => "is_allow_max_sub_tasks"]);
            }
            else
            {
                mod_tasks_configs::update_data(["value" => "0"], ["name" => "is_allow_max_sub_tasks"]);
            }
            $val = req::item("sub_task_levne");
            if ($val == "on")
            {
                mod_tasks_configs::update_data(["value" => "1"], ["name" => "is_allow_max_sub_tasks_level"]);
            }
            else
            {
                mod_tasks_configs::update_data(["value" => "0"], ["name" => "is_allow_max_sub_tasks_level"]);
            }
            $val = req::item("sub_task_levne_val");
            mod_tasks_configs::update_data(["value" => $val], ["name" => "max_sub_tasks_level"]);
            $val = req::item("sub_task_num_val");
            mod_tasks_configs::update_data(["value" => $val], ["name" => "max_sub_tasks"]);

            $val = req::item("task_complete_status");
            mod_tasks_configs::update_data(["value" => $val], ["name" => "tasks_finish_mode"]);
            cls_msgbox::show('系统提示', '修改成功', "?ct=task_config&ac=index");
        }
        $tasks_kinds   = mod_tasks_kinds::get_all("id,title");
        $tasks_levels  = mod_tasks_levels::get_all("id,title");
        $tasks_sources = mod_tasks_sources::get_all("id,title");
        $task_configs  = mod_tasks_configs::get_name_val();
        tpl::assign("task_configs", $task_configs);
        tpl::assign('tasks_kinds', $tasks_kinds);
        tpl::assign('tasks_levels', $tasks_levels);
        tpl::assign('tasks_sources', $tasks_sources);
        tpl::assign('expired_days', $expired_days);

        tpl::display("task_set_config.index.tpl");
    }

    public function add_type()
    {
        $info  = array("status" => 1);
        $name  = req::item("name");
        $infos = mod_tasks_kinds::get_one("title,id", ["title" => $name]);
        if (empty($infos))
        {
            $ids = mod_tasks_kinds::insert_data(["title" => $name]);
            if (!empty($ids))
            {
                $info = array("status" => 1, "name" => $name);
            }
        }
        else
        {
            $info = array("status" => 0, "document" => "{$name}已存在");
        }
        echo json_encode($info);
        exit();
    }

    //ajax 添加紧急选项
    public function add_options()
    {
        $name = req::item("name");

        $infos = mod_tasks_levels::get_one("title,id", ["title" => $name]);
        if (empty($infos))
        {
            $ids = mod_tasks_levels::insert_data(["title" => $name]);
            if (!empty($ids))
            {
                $info = array("status" => 1, "id" => 1, "name" => $name);
            }
        }
        else
        {
            $info = array("status" => 0, "document" => "{$name}已存在");
        }
        echo json_encode($info);
        exit();
    }

    public function add_surce()
    {
        $name  = req::item("name");
        $infos = mod_tasks_sources::get_one("title,id", ["title" => $name]);
//        print_r($infos);
        if (empty($infos))
        {
            $ids = mod_tasks_sources::insert_data(["title" => $name]);
            if (!empty($ids))
            {
                $info = array("status" => 1, "name" => $name);
            }
        }
        else
        {
            $info = array("status" => 0, "document" => "{$name}已存在");
        }
        echo json_encode($info);
        exit();
    }

    //删除紧急事项
    public function del_options()
    {
        $id    = req::item("id");
        $infos = mod_tasks_levels::get_one("title,id", ["id" => $id]);
        if (empty($infos))
        {
            cls_msgbox::show('系统提示', '数据不存在', "?ct=task_config&ac=index");
            exit();
        }
        mod_tasks_levels::remove_at($id);
        cls_msgbox::show('系统提示', '删除成功', "?ct=task_config&ac=index");
        exit();

    }

    //修改紧急事项
    public function alter_option()
    {
        $id    = req::item("tasks_levels_id");
        $infos = mod_tasks_levels::get_one("title,id", ["id" => $id]);
        if (empty($infos))
        {
            echo json_encode(["status" => 0, "document" => "数据不存在"]);
            exit();
        }
        $item  = req::item("name");
        $infos = mod_tasks_levels::get_one("title,id", ["title" => $item]);
        if ($infos["id"] != $id && !empty($infos))
        {
            echo json_encode(["status" => 0, "document" => "{$item} 已存在,请修改"]);
            exit();
        }
        mod_tasks_levels::update_data(["title" => $item], $id);
        echo json_encode(["status" => 1, "document" => "修改成功", "id" => $id, 'name' => $item]);

    }

    public function ajax_del_tasks_kinds()
    {
        $id           = req::item('id', 0, 'int');
        $json['code'] = 0;
        if (req::is_ajax())
        {
            $data = [
                'delete_user' => cls_auth::$user->fields['admin_id'],
                'delete_time' => time()
            ];
            db::update(self::$tasks_kinds)->set($data)->where("id", $id)->execute();
            $json['code'] = 1;
        }
        echo json_encode($json);
    }

    public function ajax_del_tasks_sources()
    {
        $id           = req::item('id', 0, 'int');
        $json['code'] = 0;
        if (req::is_ajax())
        {
            $data = [
                'delete_user' => cls_auth::$user->fields['admin_id'],
                'delete_time' => time()
            ];
            db::update(self::$tasks_sources)->set($data)->where("id", $id)->execute();
            $json['code'] = 1;
        }
        echo json_encode($json);
    }


}
















    