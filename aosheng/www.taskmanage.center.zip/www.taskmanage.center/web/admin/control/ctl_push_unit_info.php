<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 发布单位信息
 *
 * @version $Id$
 */
class ctl_push_unit_info
{
    public function __construct()
    {
        $this->table = '#PB#_push_unit_info';
    }

    /**
     * 列表
     */
    public function index()
    {
        $id = req::item('id', 0, 'int');
        $tip = req::item('tip');
        if (empty($id))
         {
             cls_msgbox::show('系统提示', '参数错误！', '-1');
             exit();
        }

        $row  = db::select("#PB#_tasks_sources.title as source_name,#PB#_push_unit_info.id,#PB#_push_unit_info.guarantee_info,#PB#_push_unit_info.source,#PB#_push_unit_info.name,#PB#_push_unit_info.m_type,#PB#_push_unit_info.contacts,#PB#_push_unit_info.type,#PB#_push_unit_info.file_numbers,#PB#_push_unit_info.is_m,#PB#_push_unit_info.a_number,#PB#_push_unit_info.create_time,#PB#_push_unit_info.show,#PB#_push_unit_info.contact,#PB#_push_unit_info.remark,#PB#_push_unit_info.img_data,#PB#_push_unit_info.create_user")
            ->from('#PB#_push_unit_info')
            ->join('#PB#_tasks_sources','LEFT')
            ->on('`#PB#_tasks_sources`.`id`','=','#PB#_push_unit_info.`source` ')
            ->where('#PB#_push_unit_info.task_id','=',$id)
            ->and_where('#PB#_push_unit_info.delete_user','=','0')
            ->as_row()->execute();
        if(empty($row))
        {
            cls_msgbox::show('系统提示', "数据有误", -1, 3000);
        }

        //判断数据来源
        $task_info = db::select('is_member,create_user')->from("#PB#_tasks")->where('delete_user','0')->and_where("id",$id)->as_row()->execute();
        if(!empty($task_info) && $task_info['is_member'] == 1)
        {
            $member = mod_curl_info::get_one_people_info($task_info['create_user'],true);
        }else
        {
            $admin_info = mod_admin::find($task_info['create_user'],"username");
            $member['name'] = $admin_info['username'];
            $member['organization'] = $member['department'] = $member['sn'] ='';
        }

        if(!empty($row['contact']))
        {
            $contact = json_decode($row['contact'],true);
            foreach ($contact as $key => $value)
            {
                $arr[$key]['key'] = $value['type'];
                $arr[$key]['num'] = $value['num'];
            }
            $row['contact'] = $arr;
        }

        if(!empty($row['guarantee_info']))
        {
            $contact = json_decode($row['guarantee_info'],true);
            foreach ($contact as $key => $value)
            {
                $arrs[$key]['number'] = $value['number'];
            }
            $row['guarantee_info'] = $arrs;
        }
        if($task_info['create_user'] == cls_auth::$user->fields['admin_id'])
        {
            $show = true;
        }elseif($tip == "responsible" && ($row['show'] != 1))
        {
            $show = true;
        }elseif($tip == "partake" && ($row['show'] == 4 || $row['show'] == 3))
        {
            $show = true;
        }elseif($tip == "copyer" && $row['show'] == 4)
        {
            $show = true;
        }else
        {
            $show = false;
        }
        if(!empty($row['img_data']))
        {
            $img_data = json_decode($row['img_data'],true);
            foreach ($img_data as $key => $value)
            {
                $img[$key]['key_iv'] = $value['key_iv'];
                $img[$key]['filename'] = $value['filename'];
            }
            $row['img_data'] = $img;
        }
        tpl::assign('row', $row);
        tpl::assign('tip', $tip);
        tpl::assign('member', $member);
        tpl::assign('show', $show);
        tpl::assign('id', $id);
        tpl::assign('active', 'push_unit_info');
        tpl::display('push_unit_info.index.tpl');
    }


    /**
    * @desc 下载
     */
    public function download()
    {
        $id  = req::item('id', 0, 'int');
        $filename = req::item('filename', '', 'string');

        $item = db::select('img_data')->from($this->table)->where('id', $id)->as_row()->execute();
        if(empty($item))
        {
            cls_msgbox::show('系统提示', "数据有误", -1, 3000);
        }
        $img_data = json_decode($item['img_data'],true);
        $new_data = [];
        foreach ($img_data as $key => $value)
        {
            if($value['filename'] == $filename)
            {
                $new_data['filename'] = $value['filename'];
                $new_data['key_iv'] = $value['key_iv'];
            }
        }
        if(empty($new_data))
        {
            cls_msgbox::show('系统提示', "文件不存在", -1, 3000);
        }
        mod_upload_file::download($new_data['filename'], $new_data['key_iv']);
    }




}
