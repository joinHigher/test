<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 权限组管理
 *
 * @version $Id$
 */
class ctl_admin_group
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $lang = util::get_language();
        lang::load("menu", $lang);
    }

    public function index()
    {
        $keyword = req::item('keyword', '');

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = array( 'name', 'like', "%$keyword%" );
        }

        $row = db::select('count(*) AS `count`')
            ->from('#PB#_admin_group')
            ->where($where)
            ->as_row()
            ->execute();

        $pages = pub_page::make($row['count'], 10);

        $list = db::select()
            ->from('#PB#_admin_group')
            ->where($where)
            ->order_by('id', 'asc')
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('admin_group.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $name = req::item('name');
            $row = db::select('count(*) AS `count`')
                ->from('#PB#_config')
                ->where('name', $name)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '用户组名已经存在！', '-1');
                exit();
            }

            $purviews = req::item('purviews');
            $purviews = empty($purviews) ? '' : implode(",", $purviews);
            list($insert_id, $rows_affected) = db::insert('#PB#_admin_group')->set(array(
                'name'     => $name,
                'pools'    => 'admin',
                'purviews' => $purviews,
                'addtime'  => time(),
                'uptime'   => time(),
            ))
            ->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户组添加 {$insert_id}");

            $gourl = req::item('gourl', '?ct=admin_group&ac=index');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else 
        {
            $purviews = mod_admin_menu::get_purviews();
            // 替换语言包
            $purviews = json_encode($purviews, JSON_UNESCAPED_UNICODE);
            $purviews = lang::tpl_change($purviews);

            $gourl = '?ct=admin_group&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::assign('purviews', $purviews);
            tpl::display('admin_group.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
            $name = req::item('name');
            $row = db::select('count(*) AS `count`')->from('#PB#_admin_group')
                ->where('name', $name)
                ->and_where('id', '!=', $id)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '用户组名已经存在！', '-1');
                exit();
            }

            $purviews = req::item('purviews');
            $purviews = empty($purviews) ? '' : implode(",", $purviews);

            db::update('#PB#_admin_group')->set(array(
                'name'     => $name,
                'purviews' => $purviews,
                'uptime'   => time(),
            ))
            ->where('id', $id)
            ->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户组修改 {$id}");

            $gourl = req::item('gourl', '?ct=admin_group&ac=index');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else 
        {
            $info = db::select('name, purviews')
                ->from('#PB#_admin_group')
                ->where('id', $id)
                ->as_row()
                ->execute();

            $purviews = mod_admin_menu::get_purviews();
            // 替换语言包
            $purviews = json_encode($purviews, JSON_UNESCAPED_UNICODE);
            $purviews = lang::tpl_change($purviews);

            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin_group&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::assign('purviews', $purviews);
            tpl::assign('info', $info);
            tpl::display('admin_group.edit.tpl');
        }
    }

    public function del()
    {
        $id = req::item('id', 0);

        $row = db::select('count(*) AS `count`')
            ->from('#PB#_admin')
            ->where('groups','find_in_set', $id)
            ->as_row()
            ->execute();
        if ($row['count']) 
        {
            cls_msgbox::show('系统提示', '用户组下面存在用户，不可删除！', '-1');
            exit();
        }

        db::delete('#PB#_admin_group')->where('id', $id)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户组删除 {$id}");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin_group&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

}
