<?php
if( !defined('PHPCALL') ) exit('Request Error!');


class ctl_task_progress
{
     private $task_status = ["0" => "待受理", "1" => "执行中", "2" => "待验收", "3" => "已完成", "4" => "暂停任务", "5" => "驳回验收", "6" => "已完成","7"=>"执行中","8"=>"转移负责人"];
    private $task_status_text_class = ["0" => "text-primary", "1" => "text-primary", "2" => "text-primary",
                                       "3" => "text-primary", "4" => "text-primary", "5" => "text-primary",
                                       "6" => "text-primary","7"=>"text-primary","8"=>"text-primary"];
    private $relation_types = ["1" => "机构", "2" => "部门", "3" => "岗位", "4" => "人员"];
    private $tip="";
    private $user_id = null;
    public function __construct()
    {
       tpl::assign("task_status",$this->task_status);
       tpl::assign("task_status_text_class",$this->task_status_text_class);
       tpl::assign("relation_types",$this->relation_types);
        $user_id = cls_auth::$user->fields['admin_id'];
        $admin = cls_auth::$user->fields['pools'];
        $this->user_id = cls_auth::$user->fields['admin_id'];
        if($admin == "admin")
        {
             tpl::assign("is_admin",1);     
        }else{
              tpl::assign("is_admin",2);
        }
        tpl::assign("user_login_id",$user_id);
        $task_id = req::item("id");
        $obj  = db::select("task_id,create_user")->from("#PB#_personnel")->where("task_id",$task_id)->where("user_id",$user_id);
        $info  = $obj->as_row()->execute();
        if(!empty($info))
        {   
            tpl::assign("is_master",1);
        }else{
            tpl::assign("is_master",2);
        }
        $this->tip = req::item("tip","responsible");
        tpl::assign("tip",$this->tip);
    }
    
	public function process_list()
    {
        $id        = req::item('id', 0, 'int');
        $fields    = "id,task_no,parent_id,tasks_title,level,task_process,task_kind_id,status,create_user,create_time";
        $task_info = db::select($fields)->from('#PB#_tasks')->where('id', $id)->as_row()->execute();
        if (empty($task_info))
        {
            cls_msgbox::show('系统提示', "无法检视", '-1');
        }
        if($task_info["status"]=="1")
        {
            tpl::assign("show_progess",true);
        }else{
             tpl::assign("show_progess",false);
        }
        $user_id = cls_auth::$user->fields['admin_id'];
        $user_info = db::select("task_id,create_user")->from("#PB#_personnel")->where("task_id",$id)->where("user_id",$user_id)->as_row()->execute();
        if(!empty($user_info)||$task_info["create_user"]==$this->user_id)
        {
            tpl::assign("show_create_progess","true");
        }else{
              tpl::assign("show_create_progess","false");
        }

        if (!empty(req::$posts))
        {
            $type = req::item("type");
            if ($type == "1")  //发布新进展
            {
                $this->save_new_progress($task_info);
            } elseif ($type == "2")     //回复 或评论
            {
                $this->save_discuss();
            }
        }
        $user_ids        = array();
        $sub_tasks_ids[$id] = $id;
        $sub_task_infos  = array();
        $sub_tasks       = db::select($fields)->from('#PB#_tasks')->where('parent_id', $id)->or_where("id",$id)->execute();
        if (!empty($sub_tasks))
        {
            foreach ($sub_tasks as $key => $value)
            {
                $user_ids["member_ids"][]       = $value["create_user"];
                $sub_tasks_ids[$value["id"]]    = $value["id"];
                $sub_task_infos[ $value["id"] ] = $value;
            }
        }
        $progress_infos = db::select("id,task_id,progress,optional_region,remarks,create_user,create_time,status,type,delete_user")
            ->from("#PB#_progress")->where("task_id", "in", $sub_tasks_ids)->or_where("task_id",$id)
            ->where("delete_user","0")->order_by("create_time", "asc")->execute();
        $progress_ids        = array();
        $progress_infos_list = array();
        if($task_info["parent_id"])        //判断当前任务是否为子任务
        {
             unset($progress_infos[0]);
        }
        if (!empty($progress_infos))
        {
            $time              = 0;
            $personne_task_ids = array();
            foreach ($progress_infos as $key => $value)
            {
                if($value["delete_user"]>0)
                {
                    unset($progress_infos[$key]);
                    continue;
                }
                
                $user_ids["member_ids"][] = $value["create_user"];
                $progress_ids[]           = $value["id"];
                if ($key > 0)
                {
                    $date1 = date("Y-m-d", $value["create_time"]);
                    $date2 = date("Y-m-d", $time);
                    $time = $value["create_time"];
                    if ($date1 == $date2)
                    {
                        $progress_infos[ $key ]["create_time"] = "";
                    }
                   
                }
                $progress_infos[ $key ]["create_time1"] = $value["create_time"];
                $discuss = array();
                mod_discuss::get_discuss($value["id"], $value["type"], $discuss, $user_ids);
                if (!empty($discuss))
                {
                    $progress_infos[ $key ]["discuss"] = $discuss;
                }
                $optional_region = explode(",",$value["optional_region"]);
                $obj = db::select("relation_id,relation_type")->from("#PB#_optional_region")->where("task_id",$value["task_id"]);
                $info1                                      = $obj->where("id","in",$optional_region)->execute();
                if (!empty($info1))
                {
                    $progress_infos[ $key ]["personnel"] = $info1;
                    foreach ($info1 as $key => $value)
                    {
                          switch ($value["relation_type"]) {
                          case '1':
                               $user_ids["organization_ids"][] = $value["relation_id"];
                                break;
                         case '2':
                           $user_ids["department_ids"][] = $value["relation_id"];
                            break;
                         case '3':
                            $user_ids["station_ids"][] = $value["relation_id"];
                            break;
                         case '4':
                           $user_ids["member_ids"][] = $value["relation_id"];
                            break;
                        }
                    }
                }
            }
            if (!empty($progress_ids))
            {
                $progress_counts = db::select("count(*) as count,sort_id")
                    ->from("#PB#_discuss")->where("sort_id", "in", $progress_ids)
                    ->where("delete_user", "0")->where("parent_id", "0")
                    ->group_by("sort_id")->execute();
            }

            $count = array();
            if (!empty($progress_counts))
            {
                foreach ($progress_counts as $key => $value)
                {
                    $count[ $value["sort_id"] ] = $value["count"];
                }
            }
            tpl::assign('progress_counts', $count);
        }
        tpl::assign('sub_task_infos', $sub_task_infos);
        tpl::assign('tip', req::item('tip',''));
        tpl::assign('progress_infos', $progress_infos);
        $user_infos = mod_curl_info::get_names_by_ids($user_ids);
    
        tpl::assign('user_infos_organizations', $user_infos["organizations"]);
        tpl::assign('user_infos_departments', $user_infos["departments"]);
        tpl::assign('user_infos_stations', $user_infos["stations"]);
        tpl::assign('user_infos_members', $user_infos["members"]);

        tpl::assign('relation_types', $this->relation_types);
        tpl::assign('task_status', $this->task_status);
        tpl::assign('task_status_text_class', $this->task_status_text_class);
        $task_kind_arr          = mod_tasks_kinds::get_one('id,title', ["id" => $task_info["task_kind_id"]]);
        $task_info["task_kind"] = $task_kind_arr["title"];
        tpl::assign('data', $task_info);
        //当前任务的子任务列表
        tpl::display('responsible.process_list.tpl');
    }
    //保存发布的新进展
    private function save_new_progress($task_info)
    {

        $data["progress"] = req::item("progress");
        $data["task_id"]     = req::item('id', 0, 'int');
        if(!empty($data["progress"]))
        {
            $obj  = db::select("task_id,create_user")->from("#PB#_personnel")->where("task_id",$data["task_id"])->where("user_id",$this->user_id);
            $info  = $obj->where("p_type","1")->as_row()->execute();
            if($task_info["create_user"]!=$this->user_id)
            {
                if(empty($info))
                 cls_msgbox::show('系统提示', "非负责人员和发布者不可以填写进度", '-1');
            }
            if($data["progress"]>100)
            {
                 cls_msgbox::show('系统提示', "任务进度只能小于等于100%", '-1');
            }
            if ($task_info["task_process"] >= $data["progress"])
            {
                cls_msgbox::show('系统提示', "任务进度请输入大于当前当前百分必比数字", '-1');
            }
            if (!is_numeric($data["progress"]))
            {
                cls_msgbox::show('系统提示', "任务进度请输入数字", '-1');
            }
             db::update("#PB#_tasks")->set(["task_process" => $data["progress"]])->where("id", $data["task_id"])->execute();
        }else{
             $data["progress"] = "-1";
        }
        $data["remarks"] = req::item("remarks");
        $str_len         = mb_strlen($data["remarks"]);
        if ($str_len > 300 || $str_len == 0)
        {
            cls_msgbox::show('系统提示', "请输入进度备注", '-1');
        }
        $data["create_user"] = cls_auth::$user->fields['admin_id'];
        $data["create_time"] = time();
        $data["type"]        = "0";
        $data["status"] = $task_info["status"];
        db::insert("#PB#_progress")->set($data)->execute();
        cls_msgbox::show('系统提示', "成功发布新进展", "?ct=task_progress&ac=process_list&id={$data["task_id"]}&tip={$this->tip}");
    }

    private function save_discuss()
    {

        $task_id = req::item("task_id");    //有可能是对子任务的评论，所以需要判断子任务是否存在

        $task_info = db::select("id,create_user")->from('#PB#_tasks')->where("id", $task_id)->as_row()->execute();
        if (empty($task_info))
        {
            cls_msgbox::show('系统提示', "任务不存在", '-1');
        }

        $data["sort_id"] = req::item("progress_id");
        $content         = req::item("content");
        if (mb_strlen($content) > 100)
        {
            cls_msgbox::show('系统提示', "评论内容限定100个内", '-1');
        }
        $data["contents"] = $content;

        $parent_id = req::item("parent_id");
        if (empty($parent_id))
        {
            $progess_info = db::select("create_user")->from("#PB#_progress")->where("id",$data["sort_id"])->as_row()->execute();
            $data["parent_id"]  = "0";
            $data["relay_user"] = $progess_info["create_user"];
        } else
        {
            $info = db::select("id,create_user")->from("#PB#_discuss")->where("id", $parent_id)->as_row()->execute();
            if (empty($info))
            {
                cls_msgbox::show('系统提示', "回复不存在", $_SERVER["HTTP_REFERER"]);
            }
            $data["relay_user"] = $info["create_user"];
            $data["parent_id"]  = $parent_id;
        }

        $data["type"]        = req::item("discuss_type", "0", "int");
        $data["create_user"] = cls_auth::$user->fields['admin_id'];
        $data["create_time"] = time();
        db::insert("#PB#_discuss")->set($data)->execute();
        cls_msgbox::show('系统提示', "回复成功", $_SERVER["HTTP_REFERER"]);
    }

    //删除评论
    public function del_discuss()
    {
        $id      = req::item("id");
        $info    = db::select("id,create_user")->from("#PB#_discuss")->where("id", $id)->as_row()->execute();
        $user_id = cls_auth::$user->fields['admin_id'];
        if (empty($info))
        {
            cls_msgbox::show('系统提示', "数据不存在", "?ct=task_progress&ac=process_list&id={$id}&tip={$this->tip}");
        }
        $data["delete_user"] = $user_id;
        $data["delete_time"] = time();
        db::update("#PB#_discuss")->set($data)->where("id", $id)->execute();
        $task_id = req::item("task_id");
        cls_msgbox::show('系统提示', "删除成功", "?ct=task_progress&ac=process_list&id={$task_id}&tip={$this->tip}");
    }

    //删除新增进展数据
    public function del_progress()
    {
        $task_id = req::item("task_id");
        $id      = req::item("id");
        $info    = db::select("id,create_user,task_id")->from("#PB#_progress")->where("id", $id)->as_row()->execute();
        if (empty($info))
        {
            cls_msgbox::show('系统提示', "数据不存在", "?ct=task_progress&ac=process_list&id={$task_id}");
        }
        $user_id = cls_auth::$user->fields['admin_id'];
        if ($info["create_user"] != $user_id)
        {
            cls_msgbox::show('系统提示', "非本人发布进展,不能删除", "?ct=task_progress&ac=process_list&id={$task_id}&tip={$this->tip}");
        }
        $data["delete_user"] = $user_id;
        $data["delete_time"] = time();
        db::update("#PB#_progress")->set($data)->where("id", $id)->execute();
        $info = db::select("max(progress) progress")->from("#PB#_progress")
            ->where("task_id", $task_id)->where("delete_user", "0")->as_row()->execute();
        if (empty($info))
        {
            $data1["task_process"] = 0;
        }
        $data1["task_process"] = $info["progress"];
        db::update("#PB#_tasks")->set($data1)->where("id", $task_id)->execute();
        cls_msgbox::show('系统提示', "删除成功", "?ct=task_progress&ac=process_list&id={$task_id}&tip={$this->tip}");
    }
}
