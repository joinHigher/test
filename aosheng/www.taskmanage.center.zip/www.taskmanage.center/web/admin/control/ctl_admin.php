<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 用户管理
 *
 * @version $Id$
 */
class ctl_admin
{
    public static $options = array(0 => '所有管理组');

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $lang = util::get_language();
        lang::load("menu", $lang);
        $rows = db::select('id, name')->from('#PB#_admin_group')->execute();
        foreach ($rows as $row) 
        {
            //self::$options['admin_'.$row['id']] = $row['name'];
            self::$options[$row['id']] = $row['name'];
        }
        tpl::assign( 'options', self::$options );
        tpl::assign( 'groupid', 0 );
    }

    /**
     * 管理员帐号管理
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $groupid = req::item('groupid', 0);

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = array( 'username', 'like', "%$keyword%" );
        }
        if (!empty($groupid)) 
        {
            $where[] = array( 'groups', 'find_in_set', $groupid );
        }

        $row = db::select('count(*) AS `count`')
            ->from('#PB#_admin')
            ->where($where)
            ->as_row()
            ->execute();
        
        $pages = pub_page::make($row['count'], 10);

        $list = db::select()->from('#PB#_admin')
            ->where($where)
            ->order_by('admin_id', 'asc')
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();

        foreach ($list as $k=>$v) 
        {
            if (!empty($v['groups'])) 
            {
                $groups = array();
                $groupids = explode(",", $v['groups']);
                foreach ($groupids as $id) 
                {
                    $groups[] = self::$options[$id];
                }
                $list[$k]['groups'] = implode(",", $groups);
            }
        }

        tpl::assign('groupid', $groupid);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('admin.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $username = req::item('username');
            $password = req::item('password');

            if( $username == '' || $password == '' )
            {
                cls_msgbox::show('系统提示', '用户名密码不能为空！', '-1');
                exit();
            }

            $row = db::select('count(*) AS `count`')
                ->from('#PB#_admin')
                ->where('username', $username)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '用户名已经存在！', '-1');
                exit();
            }

            $groups = req::item('groups');
            $groups = empty($groups) ? '' : implode(",", $groups);
            list($insert_id, $rows_affected) = db::insert('#PB#_admin')->set(array(
                'username' => $username,
                'password' => md5($password),
                'realname' => req::item('realname'),
                'email'    => req::item('email'),
                'potato'   => req::item('potato'),
                'pools'    => 'admin',
                'groups'   => $groups,
                'regtime'  => time(),
                'regip'    => util::get_client_ip(),
            ))
            ->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户添加 {$insert_id}");

            $gourl = req::item('gourl', '?ct=admin&ac=index');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else 
        {
            $gourl = '?ct=admin&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('admin.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item('id', 0, 'int');
        if (!empty(req::$posts)) 
        {
            $groups = req::item('groups');
            $groups = empty($groups) ? '' : implode(",", $groups);
            $data = array(
                'realname' => req::item('realname'),
                'email'    => req::item('email'),
                'potato'   => req::item('potato'),
                'groups'   => $groups,
            );
            $password = req::item('password');
            if( $password != '' )
            {
                $data['password'] = md5($password);
            } 
            db::update('#PB#_admin')->set($data)->where('admin_id', $id)->execute();

            $mod_admin_user = new mod_admin_user($id);
            $mod_admin_user->del_cache($id);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户修改 {$id}");

            $gourl = req::item('gourl', '?ct=admin&ac=index');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else 
        {
            $v = db::select()->from('#PB#_admin')->where('admin_id', $id)->as_row()->execute();
            $v['groups'] = empty($v['groups']) ? array() : explode(",", $v['groups']);
            tpl::assign('v', $v);
            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::display('admin.edit.tpl');
        }
    }

    public function del()
    {
        $ids = req::item('ids', array());
        db::delete('#PB#_admin')->where('admin_id', 'in', $ids)->execute();

        foreach ($ids as $id) 
        {
            $mod_admin_user = new mod_admin_user($id);
            $mod_admin_user->del_cache($id);
        }

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户删除 ".implode(",", $ids));

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    /**
     * 对修改用户自己的密码使用单独事件
     */
    public function editpwd()
    {
        $id = cls_auth::$user->fields['uid'];
        if (!empty(req::$posts)) 
        {
            $password = req::item('password', '');
            if( $password == '' )
            {
                cls_msgbox::show('系统提示', "修改失败，密码不能为空", -1);
            } 
            $password = md5($password);

            if (req::item('password') != req::item('passwordok')) 
            {
                cls_msgbox::show('系统提示', "修改失败，两次输入密码不同", -1);
            }

            db::update('#PB#_admin')->set(array(
                'password' => $password,
                'realname' => req::item('realname'),
                'email'    => req::item('email')
            ))->where('admin_id', $id)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改密码 {$id}");

            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=index' : $_SERVER['HTTP_REFERER'];
            cls_msgbox::show('系统提示', "修改成功", $gourl);

        }
        else 
        {
            $v = db::select()->from('#PB#_admin')->where('admin_id', $id)->as_row()->execute();
            $mod_admin_user = new mod_admin_user($id);
            $v['groupname'] = $mod_admin_user->get_groupname();
            tpl::assign('v', $v);
            $gourl = "?ct=admin&ac=index";
            tpl::assign('gourl', $gourl);
            tpl::display('admin.editpwd.tpl');
        }
    }

    public function editpwd_fake()
    {
        $id = cls_auth::$user->fields['uid'];
        if (!empty(req::$posts)) 
        {
            $password = req::item('password', '');
            if( $password == '' )
            {
                cls_msgbox::show('系统提示', "修改失败，密码不能为空", -1);
            } 

            if ( req::item('password') != req::item('passwordok') ) 
            {
                cls_msgbox::show('系统提示', "修改失败，两次输入密码不同", -1);
            }

            $password = md5($password);
            $db_password = db::select('password')->from('#PB#_admin')->as_field()->execute();
            if ( $db_password == $password ) 
            {
                cls_msgbox::show('系统提示', "修改失败，伪装密码不能和登陆密码相同", -1);
            }

            db::update('#PB#_admin')->set(array(
                'fake_password' => $password
            ))->where('admin_id', $id)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "伪装密码 {$id}");

            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=editpwd_fake' : $_SERVER['HTTP_REFERER'];
            cls_msgbox::show('系统提示', "修改成功", $gourl);

        }
        else 
        {
            tpl::display('admin.editpwd_fake.tpl');
        }
    }

    /**
     * 设置具体用户的权限
     */
    public function purview()
    {
        $id = req::item('id', 0, 'int');
        if (!empty(req::$posts)) 
        {
            $mod_admin_user = new mod_admin_user($id);
            $group_purviews = $mod_admin_user->get_group_purviews();
            $purviews = req::item('purviews', array());
            foreach ($purviews as $k=>$v) 
            {
                // 去除在组里已经存在的权限
                if (in_array($v, $group_purviews)) 
                {
                    unset($purviews[$k]);
                }
            }
            $purviews = implode(",", $purviews);

            $mod_admin_user = new mod_admin_user($id);
            $mod_admin_user->del_cache($id);

            $count = db::select('COUNT(*) AS count')
                ->from('#PB#_admin_purview')
                ->where('admin_id', $id)
                ->as_field()
                ->execute();

            if ($count == 0)
            {
                db::insert('#PB#_admin_purview')->set(array(
                    'admin_id' => $id,
                    'purviews' => $purviews
                ))
                ->execute();
            }
            else 
            {
                db::update('#PB#_admin_purview')->set(array(
                    'purviews' => $purviews
                ))
                ->where('admin_id', $id)
                ->execute();
            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "设置用户独立权限 {$id}");

            $gourl = req::item('gourl', '?ct=admin&ac=index');
            cls_msgbox::show('系统提示', "独立权限设置成功", $gourl);
        }
        else 
        {
            $info = db::select('username, realname, groups')
                ->from('#PB#_admin')
                ->where('admin_id', $id)
                ->as_row()
                ->execute();
            $mod_admin_user = new mod_admin_user($id);
            $info['purviews'] = $mod_admin_user->get_purviews();
            $info['groupname'] = $mod_admin_user->get_groupname();

            $purviews = mod_admin_menu::get_purviews();
            $purviews = json_encode($purviews, JSON_UNESCAPED_UNICODE);
            $purviews = lang::tpl_change($purviews);

            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::assign('info', $info);
            tpl::assign('purviews', $purviews);
            tpl::display('admin.purview.tpl');
        }
    }

    /**
     * 清除用户的独立权限
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2016-08-29 22:41
     */
    public function purview_del()
    {
        $id = req::item('id', 0, 'int');
        db::delete('#PB#_admin_purview')->where('admin_id', $id)->execute();

        $mod_admin_user = new mod_admin_user($id);
        $mod_admin_user->del_cache($id);

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "清除用户独立权限 {$id}");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=index' : $_SERVER['HTTP_REFERER']; 
        cls_msgbox::show('系统提示', '成功清除用户的独立权限！', $gourl);
    }

    /**
     * 当前用户登录后列出它的权限
     */
    public function mypurview()
    {
        $info = cls_auth::$user->fields;
        $mod_admin_user = new mod_admin_user($info['uid']);
        $info['purviews'] = $mod_admin_user->get_purviews();
        $info['groupname'] = $mod_admin_user->get_groupname();

        $purviews = mod_admin_menu::get_purviews(true);
        // 替换语言包
        $purviews = json_encode($purviews, JSON_UNESCAPED_UNICODE);
        $purviews = lang::tpl_change($purviews);

        tpl::assign('info', $info);
        tpl::assign('purviews', $purviews);
        tpl::display('admin.mypurview.tpl');
        exit();
    }

    /**
     * 操作日志
     */
    public function oplog()
    {
        $keyword = req::item('keyword', '');
        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = "Concat(`username`, `msg`) Like '%{$keyword}%'";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select Count(*) AS count From `#PB#_admin_oplog` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count']);
        $sql = "Select * From `#PB#_admin_oplog` {$where} Order By `id` Desc Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);

        tpl::assign( 'list', $list );
        tpl::assign( 'pages', $pages['show'] );
        tpl::display( 'admin.oplog.tpl' );
    }

    /**
     * 删除操作日志
     */
    public function oplog_del()
    {
        $ids = req::item('ids', array());
        if (empty($ids)) 
        {
            cls_msgbox::show("用户管理", "删除失败,请选择要删除的日志", -1);
        }

        db::delete('#PB#_admin_oplog')->where('id', 'in', $ids)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除了操作日志 ".implode(',', $ids));

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=log' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "日志删除成功", $gourl);
    }

    /**
     * 登录日志
     */
    public function login_log()
    {
        $keyword = req::item('keyword', '');
        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = "Concat(`accounts`, `loginip`) Like '%{$keyword}%'";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select Count(*) AS count From `#PB#_admin_login` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count']);
        $sql = "Select * From `#PB#_admin_login` {$where} Order By `id` Desc Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);

        tpl::assign( 'list', $list );
        tpl::assign( 'pages', $pages['show'] );
        tpl::display( 'admin.login_log.tpl' );
    }

    /**
     * 删除登录日志
     */
    public function login_log_del()
    {
        $ids = req::item('ids', array());
        if (empty($ids)) 
        {
            cls_msgbox::show("用户管理", "删除失败,请选择要删除的登陆日志", -1);
        }

        db::delete('#PB#_admin_login')->where('id', 'in', $ids)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除了登录日志 ".implode(',', $ids));

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=admin&ac=login_log' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "登陆日志删除成功", $gourl);
    }

    /**
     * 删除三个月前登录日志
     */
    public function del_old_login_log()
    {
        $log_name = 'del_old_login_log';
        $three_mo = time() - (3600 * 24 * 90);
        $rs = db::query_run("Select * From `#PB#_admin_login` where `logintime` < {$three_mo} ");
        $tmp = '';
        $i = $n = 0;
        while( $row = db::fetch_one($rs) )
        {
            $i++;
            $n++;
            // 200条写入一次硬盘
            if( $i > 200 )
            {
                log::write($log_name, $tmp);
                log::save();
                $tmp = '';
                $i = 0;
            } else {
                $tmp .= $row['autoid']."\t".$row['uid']."\t".$row['accounts']."\t".$row['loginip']."\t".date('Y-m-d H:i:s', $row['logintime'])."\t".$row['pools']."\t".$row['loginsta']."\n";
            }
        }
        if( $tmp != '' )
        {
            log::write($log_name, $tmp);
            log::save();
        }

        db::delete('#PB#_admin_login')->where('logintime', '<', $three_mo)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除三个月前登录日志");

        cls_msgbox::show('系统提示', "成功清理 {$n} 条旧登录日志！", '?ct=admin&ac=login_log');
        exit();
    }

    /**
     * 登录IP限制
     */
    public function iplimit()
    {
        $ips = req::item('ips', '');
        if( empty($ips) )
        {
            $ips = cls_access_cfg::get_config( 'ip_limit' );
            tpl::assign('ips', $ips);
            tpl::assign('menu_curr_title', '登录IP限制');
            tpl::display('admin.iplimit.tpl');
        }
        else
        {
            cls_access_cfg::save_config('ip_limit', $ips);
            cls_access::save_log(cls_access::$accctl->fields['username'], self::$menu_root_title." 修改IP限制");
            cls_msgbox::show('系统提示', '成功修改IP限制配置', '?ct=admin&ac=iplimit');
        }
    }

    /**
     * 安全IP
     */
    public function safe_client_ip()
    {
        $ip = req::item('ip', '');
        if( empty($ip) )
        {
            $ip = util::get_client_ip();
            $ips = cls_access_cfg::get_config( 'safe_client_ips' );
            $list = explode(",", $ips);
            $safe_ip = false;
            if (in_array($ip, $list)) 
            {
                $safe_ip = true;
            }
            tpl::assign('ip', $ip);
            tpl::assign('list', $list);
            tpl::assign('safe_ip', $safe_ip);
            tpl::assign('menu_curr_title', '安全IP管理');
            tpl::display('admin.safe_client_ip.tpl');
        }
        else
        {
            $ips = cls_access_cfg::get_config( 'safe_client_ips' );
            $ip_arr = explode(",", $ips);
            $ip_arr[] = $ip;
            $ip_arr = array_filter($ip_arr);
            $ips = implode(",", $ip_arr);
            cls_access_cfg::save_config('safe_client_ips', $ips);
            cls_access::save_log(cls_access::$accctl->fields['username'], self::$menu_root_title." 添加安全IP ".$ip);
            cls_msgbox::show('系统提示', '成功添加安全IP', '?ct=admin&ac=safe_client_ip');
        }
    }

    public function del_safe_client_ip()
    {
        $ips = req::item('ips', '');
        $safe_client_ips = cls_access_cfg::get_config( 'safe_client_ips' );
        $safe_client_ip_arr = explode(",", $safe_client_ips);
        // 取差集就可以删除当前IP了
        $safe_client_ip_arr = array_diff($safe_client_ip_arr, $ips);
        $safe_client_ips = implode(",", $safe_client_ip_arr);

        cls_access_cfg::save_config('safe_client_ips', $safe_client_ips);
        cls_access::save_log(cls_access::$accctl->fields['username'], self::$menu_root_title." 删除安全IP ".implode(",", $ips));
        cls_msgbox::show('系统提示', '成功删除安全IP', '?ct=admin&ac=safe_client_ip');
    }

    /**
     * 全局权限xml配置
     */
    public function purview_xml()
    {
        $purview_xml = req::item('purview_xml', '');
        if( empty($purview_xml) )
        {
            $purview_xml = config::get( 'admin_df_purview' );
            tpl::assign('purview_xml', $purview_xml);
            tpl::display('admin.purview_xml.tpl');
        }
        else
        {
            config::save('admin_df_purview', $purview_xml);
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "全局权限xml配");
            cls_msgbox::show('系统提示', '成功修改权限xml配置', '?ct=admin&ac=purview_xml');
        }
    }

}
