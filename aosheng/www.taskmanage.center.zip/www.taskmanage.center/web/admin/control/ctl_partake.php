<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 参与的任务
 * Class ctl_partake
 */
class ctl_partake
{
    private static $active = 1;
    private static $not_active = 0;
    public static $url_cust = URL_API_CUST . '?ct=internal_api&ac=get_member_info_by_code&code=';
    private static $enabled = 1;
    private static $tasks_configs_table = '#PB#_tasks_configs';
    public static $table_personnel = '#PB#_personnel';

    private $where;


    public function __construct()
    {
        $this->where[] = ['delete_user', '=', 0];
    }

    /**
     * 我参与的任务
     */
    public function index()
    {
        $active    = req::item('active', 0, 'int');
        $poster_id = req::item('poster_id', 0, 'int');
        $tabs      = array(
            array(
                'title' => '执行中的任务',
                'url'   => '?ct=partake&ac=index&active=0'
            ),
            array(
                'title' => '待验收的任务',
                'url'   => '?ct=partake&ac=index&active=1'
            ),
            array(
                'title' => '已完成的任务',
                'url'   => '?ct=partake&ac=index&active=2'
            )
        );

        foreach ($tabs as $key => $tab)
        {
            if ($active == $key)
            {
                $tabs[ $key ]['active'] = self::$active;
            }
            else
            {
                $tabs[ $key ]['active'] = self::$not_active;
            }

        }

        $date_from     = req::item('date_from', '');
        $date_end      = req::item('date_end', '');
        $date_type     = req::item('date_type', '');
        $keyword       = req::item('keyword', '');
        $tasks_kind_id = req::item('tasks_kind_id', 0, 'int');
        $page_size     = req::item('page_size', 10);

        if ($tasks_kind_id)
        {
            $this->where[] = ['task_kind_id', '=', $tasks_kind_id];
        }

        if ($date_type == 'post_date')
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['create_time', '>=', strtotime($date_from . ' 00:00:00')];
                $this->where[] = ['create_time', '<=', strtotime($date_end . ' 23:59:59')];
            }
        }
        else if ($date_type == 'stop_date')
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['task_end_datetime', '>=', strtotime($date_from . ' 00:00:00')];
                $this->where[] = ['task_end_datetime', '<=', strtotime($date_end . ' 23:59:59')];
            }
        }
        switch ($active)
        {
            case 0: //执行中任务
                $this->where[] = ['status', 'in', [1,4]];
                break;
            case 1: //待验收的任务
                $this->where[] = ['status', '=', 2];
                break;
            case 2: //已完成的任务
                $this->where[] = ['status', '=', 3];
                break;
        }


        // 我参与的
        $personnel_data = db::select('task_id')
            ->from('#PB#_personnel')
            ->where('user_id', cls_auth::$user->fields['admin_id'])
            ->where('p_type', '=', '2')
            ->where('delete_user', '0')
            ->distinct(TRUE)
            ->execute();
        $tasks_arr      = [];
        if (!empty($personnel_data))
        {
            foreach ($personnel_data as $row)
            {
                $tasks_arr[] = $row['task_id'];
            }
            $this->where[] = ['id', 'in', $tasks_arr];
        }
        else
        {
            $this->where[] = ['id', '=', -1];
        }

        if ($poster_id != 0)
        {
            $this->where[] = ['create_user', '=', $poster_id];
        }


        $tasks_kind_id = req::item('tasks_kind_id', 0, 'int');

        $result = db::select('count(*) AS `count`')->from('#PB#_tasks')->as_row();
        $result->where($this->where);
        if (!empty($keyword))
        {
            $result->and_where_open();
            $result->where('tasks_title', 'like', "%{$keyword}%");
            $result->or_where('task_no','like',"%{$keyword}%");
            $result->and_where_close();
        }

        $result = $result->execute();
        $count  = $result['count'];
        $pages  = pub_page::make($count, $page_size);
        $query  = db::select('id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')
            ->from('#PB#_tasks')
            ->where($this->where);
        if (!empty($keyword))
        {
            $query->and_where_open();
            $query->where('tasks_title', 'like', "%{$keyword}%");
            $query->or_where('task_no','like',"%{$keyword}%");
            $query->and_where_close();
        }
        $query->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->order_by('create_time', 'desc');
        $list   = $query->execute();
        tpl::assign('tasks_kind_id', $tasks_kind_id);
        tpl::assign('tabs', $tabs);
        tpl::assign('active', $active);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list', $list);
        tpl::assign('poster_id', $poster_id);
        tpl::display('partake.index.tpl');
    }

    /**
     * 我参与的任务 任务详情
     */
    public function detail()
    {
        mod_status::partake_is_allow_user();
        $id   = req::item('id', 0, 'string');
        $data = db::select('id,parent_id,task_kind_id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')->from('#PB#_tasks')->where('id', $id)->as_row()->execute();
        if (!$data)
        {
            cls_msgbox::show('系统提示', "无法检视", '-1');
        }

        $files          = db::select()->from('#PB#_tasks_files')->execute();
        $condition      = array(
            'id' => $data['task_kind_id']
        );
        $task_kind_arr  = mod_tasks_kinds::get_one('id,title', $condition);
        $condition      = array(
            'id' => $data['task_level_id']
        );
        $task_level_arr = mod_tasks_levels::get_one('id,title', $condition);

        $task_files_arr = mod_tasks_files::get_files_by_task_id($data['id']);

        $task_kind  = $task_kind_arr['title'];
        $task_level = $task_level_arr['title'];
        tpl::assign('data', $data);
        tpl::assign('id', $id);
        tpl::assign('files', $files);
        tpl::assign('task_kind', $task_kind);
        tpl::assign('task_level', $task_level);
        tpl::assign('task_files_arr', $task_files_arr);

        tpl::display('partake.detail.tpl');
    }


    /**
     * 我参与的任务 子任务列表
     */
    public function sub_tasks()
    {
        mod_status::partake_is_allow_user();
        // get config setting
        $config_fields = array(
            'is_allow_max_sub_tasks',
            'max_sub_tasks',
        );
        $config        = array();
        $config_array  = db::select('name,value')->from(self::$tasks_configs_table)->where('name', 'in', $config_fields)->execute();
        foreach ($config_array as $row)
        {
            if ($row['name'] == 'is_allow_max_sub_tasks')
            {
                $config['is_allow_max_sub_tasks'] = $row['value'];
            }
            if ($row['name'] == 'max_sub_tasks')
            {
                $config['max_sub_tasks'] = $row['value'];
            }
        }

        $page_size = req::item('page_size', 10);
        $id        = req::item('id', 0, 'int');
        $data      = mod_tasks::get_task_detail($id);
        if (!$data)
        {
            cls_msgbox::show('系统提示', "无法检视", '-1');
        }

        $result = mod_tasks::get_sub_task_size($id);
        $count  = $result['count'];
        $pages  = pub_page::make($count, $page_size);

        $is_show_button = TRUE;
        if ($config['is_allow_max_sub_tasks'] == self::$enabled)
        {
            if ($config['max_sub_tasks'] <= $count)
            {
                $is_show_button = FALSE;
            }
        }

        $condition     = array(
            'id' => $data['task_kind_id']
        );
        $task_kind_arr = mod_tasks_kinds::get_one('id,title', $condition);
        $task_kind     = $task_kind_arr['title'];
        $list          = mod_tasks::get_sub_task_list($id, $pages['page_size'], $pages['offset']);
        if (!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $p_num = db::select('count(id) as p_num')->from(self::$table_personnel)->where([
                    ['delete_user', '=', '0'],
                    ['task_id', '=', $value['id']],
                    ['p_type', '=', 1],
                    ['status', '=', 0],
                ])->as_row()->execute();

                $list[ $key ]['p_num'] = $p_num['p_num'];
            }
        }
        tpl::assign('is_show_button', $is_show_button);
        tpl::assign('task_kind', $task_kind);
        tpl::assign('list', $list);
        tpl::assign('data', $data);
        tpl::assign('id', $data['id']);
        tpl::assign('pages', $pages['show']);

        tpl::display('partake.sub_tasts.tpl');
    }


    /**
     * 我参与的任务 任务参与人员
     */
    public function personnel()
    {
        $id     = req::item('id', 0, 'int');
        $p_type = req::item('p_type');
        //echo $p_type;
        if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }
        $type = $p_type == 'cc' ? 3 : ($p_type == 'join' ? 2 : 1);
        if ($p_type == 'main' || $p_type == '')
        {
            $this->where[] = ['status', '=', 1];
        }
        $this->where[] = ['p_type', '=', $type];
        //$this->where[] = ['type', '=', 1];
        $this->where[] = ['task_id', '=', $id];
        $page_size     = req::item('page_size', 10);
        $row           = db::select('count(*) AS `count`')->from('#PB#_personnel')->where($this->where)->and_where('delete_user','0')->as_row()->execute();
        $pages         = pub_page::make($row['count'], $page_size);
        $list          = db::select("id,task_id,user_id")->from('#PB#_personnel')->where($this->where)->and_where('delete_user','0')->limit($pages['page_size'])->offset($pages['offset'])->order_by('create_time', 'desc')->execute();
        if (!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $member = mod_curl_info::get_one_people_info($value['user_id'], TRUE);
                if ($member)
                {
                    $list[ $key ]['org_name'] = $member['organization'];
                    $list[ $key ]['dep_name'] = $member['department'];
                    $list[ $key ]['op_name']  = $member['name'];
                    $list[ $key ]['sta_name'] = isset($member['job']) ? $member['job'] : null;
                    $list[ $key ]['number']   = $member['sn'];
                }
                else
                {
                    unset($list[ $key ]);
                }

            }
        }
        //获取当前已存在的用户id
        $where[]  = ['delete_user', '=', '0'];
        $where[]  = ['task_id', '=', $id];
        $ids      = db::select('user_id')->from('#PB#_personnel')->where($where)->distinct(TRUE)->execute();
        $user_ids = !empty($ids) ? implode(',', array_column($ids, 'user_id')) : '';
        unset($ids);
        tpl::assign('list', $list);
        tpl::assign('user_ids', $user_ids);
        tpl::assign('id', $id);
        tpl::assign('p_type', $p_type);
        tpl::assign('active', 'personnel');
        tpl::assign('pages', $pages['show']);
        tpl::display('partake.personnel.tpl');
    }


}