<?php
if( !defined('PHPCALL') ) exit('Request Error!');


/**
 * ajax
 *
 * @version $Id$
 */
class ctl_ajax
{

    public static $admin_url_org = URL_API_SYS.'/people.php';
    public static $url_org = URL_API_SYS.'/business_task.php';
    public static $url_cust = URL_API_CUST.'?ct=internal_api&ac=get_member_info_by_code&code=';

    public function __construct()
    {
        if(!req::is_ajax())
        {
            $data = array(
                'status' => '404',
                'message' => '请求方式错误',
                'data' => array(),
            );
            die(json_encode($data));
        }
    }

    /**
    * @dec 获取机构数据
     */
    public function admin_get_org_data()
    {
        $id = req::item('id', 0, 'int');
        $type = req::item('type','organization');
        $post_data = [
            'id' => $id,
            'type' => $type,
            'sign' => md5("AS".date('Ymdh')),
            'action' => 'make_list'
        ];
        //print_r($post_data);exit;
        $util = new util();
        $data = $util->http_post(self::$admin_url_org,$post_data);
        $data = json_decode($data,true);
        if(isset($data['data']['member']) && $data['data']['member'])
        {
            foreach ($data['data']['member'] as $key => $v)
            {
                $data['data']['member'][$key]['name'] = $v['name'] ? $v['name'] : $v['nickname'];
            }
        }
        $data = json_encode($data);
        die($data);
    }


    /**
     * @dec 获取机构数据
     */
    public function get_org_data()
    {
        $user_id = cls_auth::$user->fields['admin_id'];
        if(empty($user_id))
        {
            $data = array(
                'status' => '-1',
                'message' => '请先登录',
                'data' => array(),
            );
            die(json_encode($data));
        }
        $id = req::item('id', 0, 'int');
        $type = req::item('type','organization');
        switch ($type)
        {
            case 'department':
                $type_key = 'department_id';
                break;
            case 'station':
                $type_key = 'station_id';
                break;
            default:
                $type_key = "organization_id";
        }
        $post_data = [
            'user_id' => $user_id,
             $type_key => $id,
            'sign' => md5("AS".date('Ymdh')),
            'action' => 'publish'
        ];
        $util = new util();
        $data = $util->http_post(self::$url_org,$post_data);
        $data = json_decode($data,true);
        //print_r($data);exit;
        if(isset($data['data']['member']) && $data['data']['member'])
        {
            foreach ($data['data']['member'] as $key => $v)
            {
                $data['data']['member'][$key]['name'] = $v['name'] ? $v['name'] : $v['nickname'];
            }
        }

        $data = json_encode($data);
        die($data);
    }






    /**
     * @dec 获取部门数据
     */
   /* public function get_dep_data()
    {
        $dep_id = req::item('dep_id', 0, 'int');
        $data = util::http_get(self::$url_dep.$dep_id);
        die($data);
    }*/

    /**
     * @dec 获取岗位数据
     */
    /*public function get_sta_data()
    {
        $dep_id = req::item('station_id', 0, 'int');
        $data = util::http_get(self::$url_sta.$dep_id);
        die($data);
    }*/




    /**
    * @desc 验证户口号是否正确
     */
    public function check_number()
    {
        $code = (int)request('code');

        if(empty($code))
        {
            $data = array(
                'status' => '-1',
                'message' => '不能为空',
                'data' => array(),
            );
            die(json_encode($data));
        }
        $data = util::http_get(self::$url_cust.$code);
        die($data);
    }
}
