<?php
if (!defined('PHPCALL')) exit('Request Error!');

class ctl_memu_option
{
    private static $menu_option_table = '#PB#_memu_option';

    public function __construct()
    {

    }

    public function index()
    {
        // scan
        
        $type       = req::item("type");
        $controller = req::item("controller");
        tpl::assign("controller",$controller);
        if(!empty($controller))
        {
             $where[] = ["controller", "=", $controller];
        }
        if ($type == 2)
        {
            $where[] = ["name", "=", null];

        } else
        {
            $where[] = ["name", "!=", null];
        }
        $info      = db::select("count(*) as count ")->from("#PB#_memu_option")->where($where)->as_row()->execute();
        $total     = $info["count"];
        $page_size = req::item("page_size", 20);
        $pages     = pub_page::make($total, $page_size);
        tpl::assign('pages', $pages["show"]);
        $memu_list = db::select("id,controller,action,group_id,dispaly,reload,name")
            ->from("#PB#_memu_option")->where($where)->limit($pages["page_size"])->offset($pages["offset"])->execute();
        tpl::assign("type", $type);
        tpl::assign("memu_list", $memu_list);
        $infos = db::select("id, name")->from("#PB#_memu_groups")->execute();
        $menu_groups = array();
        if(!empty($infos))
        {
            foreach ($infos as $key => $value) {
                $menu_groups[$value["id"]] = $value["name"];
            }
        }
        $menu_groups[0] = "顶级";
        tpl::assign("menu_groups",$menu_groups);
        $infos = db::select("id,controller")->from("#PB#_memu_option")->group_by("controller")->execute();
        $controllers = array();
        foreach ($infos as $key => $value) {
            $controllers[$value["controller"]] = $value["controller"];
        }
        tpl::assign("controllers",$controllers);
        tpl::display("memu_option.index.tpl");
    }

    private function _save_ctl_infos()
    {

    }

    public function groups()
    {
        if(!empty(req::$posts))
        {
            $name = req::item("name");
            $id = req::item("group_id");
            $infos = db::select("*")->from("#PB#_memu_groups")->where("name",$name)->where("id","!=",$id)->execute();
            if(!empty($infos))
            {
                 cls_msgbox::show('系统提示', "[$name]已存在",-1);
            }
            $data["name"] = $name;
            $data["parent_id"] = req::item("parent_id");
            $data["display"] = req::item("is_show");
            $data["icon"] = req::item("show_icon");

            db::update("#PB#_memu_groups")->set($data)->where("id",$id)->execute();
            cls_msgbox::show('系统提示', "修改成功",$_SERVER['HTTP_REFERER']);
        }
        $info      = db::select("count(*) as count ")->from("#PB#_memu_groups")->as_row()->execute();
        $total     = $info["count"];
        $page_size = req::item("page_size",20);
        $pages     = pub_page::make($total, $page_size);
        tpl::assign('pages',$pages["show"]);
        $groups_info = db::select("*")->from("#PB#_memu_groups")->execute();
        tpl::assign("groups_info",$groups_info);
        $menu_groups = array();
        if(!empty($groups_info))
        {

            foreach ($groups_info as $key => $value) {
                $menu_groups[$value["id"]] = $value["name"];
            }
        }
        $menu_groups[0] = "顶级";
        
        tpl::assign("menu_groups",$menu_groups);
        tpl::display("memu_option.groups.tpl");
    }

    public function add_group()
    {

        if(!empty(req::$posts))
        {
            $data["name"]        = req::item("name");
            $infos = db::select("id")->from("#PB#_memu_groups")->where("name",$data["name"])->execute();
            if(!empty($infos))
            {
                  cls_msgbox::show('系统提示', "[{$data["name"]}]已存在",-1);
            }
            $data["parent_id"]   = req::item("parent_id");
            $data["display"]     = req::item("is_show");
            $data["icon"]        = req::item("show_icon");
            $data["create_user"] = cls_auth::$user->fields['uid'];
            $data["create_time"] = time();
            db::insert("#PB#_memu_groups")->set($data)->execute();
            cls_msgbox::show('系统提示', '新增成功',"?ct=memu_option&ac=groups");
        }
        $infos = db::select("id, name")->from("#PB#_memu_groups")->execute();
        $menu_groups = array();
        
        if(!empty($infos))
        {
            foreach ($infos as $key => $value) {
                $menu_groups[$value["id"]] = $value["name"];
            }
        }
        $menu_groups["0"] = "顶级";
        tpl::assign("menu_groups",$menu_groups);
        tpl::display("memu_option.add_group.tpl");
    }
    public function import_controller()
    {
        $json['status'] = 'fail';
        if (req::is_ajax())
        {
            $scanned_directory = array_diff(scandir('../admin/control'), array('..', '.', self::class . '.php'));
            $list_item         = [];
            foreach ($scanned_directory as $row)
            {
                include_once $row;
                $list_item[] = $this->parser_class($row);
            }
            $list_item[] = $this->parser_class(self::class);
            foreach ($list_item as $row)
            {
                foreach ($row as $next_row)
                {
                    $data = db::select('count(*) as `total`')
                        ->from(self::$menu_option_table)
                        ->where('controller', $next_row['class'])
                        ->where('action', $next_row['name'])
                        ->as_row()
                        ->execute();
                    if ($data['total'] == 0)
                    {
                        db::insert(self::$menu_option_table)->set([
                            'controller' => $next_row['class'],
                            'action' => $next_row['name'],
                        ])->execute();
                    }
                }
            }

            $json['status'] = 'ok';
        }
        echo json_encode($json);
    }

    private function parser_class($class_name)
    {
        $class_name = str_replace('.php', '', $class_name);
        $class      = new ReflectionClass($class_name);
        $methods    = $class->getMethods(ReflectionMethod::IS_PUBLIC);
        $list       = [];
        foreach ($methods as $row)
        {
            $method = (array)$row;
            if ($method['name'] == '__construct')
            {
                continue;
            }
            $list[] = [
                'class' => $method['class'],
                'name'  => $method['name'],

            ];
        }
        return $list;
    }

    
}



