<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 用户管理
 *
 * @version $Id$
 */
class ctl_test
{
	public function index()
	{

		if(!empty(req::$posts))
		{
	
			$fille_arr = req::item("image1");
			if(!empty($fille_arr))
			{
				foreach ($fille_arr as $key => $value) {
					# code...
				 	$infos  = mod_upload_file::upload($value);
				 	mod_upload_file::download($value,$infos["key_iv"]);
				}	
			}
		}
		tpl::display('test.index.tpl');
	}

}