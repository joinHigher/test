<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 审核管理
 *
 * @version $Id$
 */
class ctl_audit_management
{
    public static $table = '#PB#_tasks';
    public static $table_push_unit_info = '#PB#_push_unit_info';
    public static $table_optional_region = '#PB#_optional_region';
    public static $table_personnel = '#PB#_personnel';

    public function __construct()
    {
        $this->op_user_id = cls_auth::$user->fields['uid'];
        $this->where = [
            ['delete_user', '=', '0'],
        ];
    }


    /**
     * @desc 我审核的
     */
    public function index()
    {
        $task_kind_id = req::item('task_kind_id', 0 , 'int');
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 10);
        $date_type = req::item('date_type', '');
        $date_from = req::item('date_from', '');
        $date_end = req::item('date_end', '');

        $this->where[]   = ['create_user','=',$this->op_user_id];
        $this->where[]   = ['status','=','0'];
        $or_where1 = $or_where2 = [];
        if(!empty($keyword))
        {
            $or_where1[] = array('tasks_title', 'like', "%{$keyword}%");
            $or_where2[] = array('task_no', 'like', "%{$keyword}%");
        }
        if($task_kind_id)
        {
            $this->where[]   = ['task_kind_id','=',$task_kind_id];
        }

        if($date_type == 1 )
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['create_time', '>=', strtotime($date_from.' 00:00:00')];
                $this->where[] = ['create_time', '<=', strtotime($date_end.' 23:59:59')];
            }
        }else
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['task_end_datetime', '>=', strtotime($date_from.' 00:00:00')];
                $this->where[] = ['task_end_datetime', '<=', strtotime($date_end.' 23:59:59')];
            }
        }

        $sql_count      = db::select('count(*) AS `count`')->from(self::$table)->where($this->where);
        if($keyword)
        {
            $sql_count = $sql_count->and_where_open()
                ->where($or_where1)
                ->or_where($or_where2)
                ->and_where_close();
        }
        $row   = $sql_count->as_row()->execute();

        $pages = pub_page::make($row['count'], $page_size);
        $sql   = db::select('id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')
            ->from(self::$table)
            ->where($this->where);
        if($keyword)
        {
            $sql = $sql->and_where_open()
                ->where($or_where1)
                ->or_where($or_where2)
                ->and_where_close();
        }

        $list = $sql->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->order_by('create_time', 'desc')
            ->execute();
        if(!empty($list))
        {
            foreach ($list as $key => $value)
            {
                /*$data = db::select("relation_id,relation_type,count(id) as num,name")
                    ->from(self::$table_optional_region)
                    ->where([['delete_user', '=', '0'],['task_id','=',$value['id']]])
                    ->group_by('task_id')
                    ->as_row()
                    ->execute();
                $list[$key]['region_num'] = $list[$key]['region'] = [];
                if(!empty($data))
                {
                    $ids[] = $data['relation_id'];
                    $ids_type = $data['relation_type'] == 1 ? 'organization_ids' : ($data['relation_type'] == 2 ? 'department_ids' : ($data['relation_type'] == 3 ? 'station_ids' : 'member_ids'));
                    $keys = $ids_type == 'organization_ids' ? 'organizations' : ($ids_type == 'department_ids' ? 'departments' : ($ids_type == 'station_ids' ? 'stations' : 'members'));

                    $arr = [
                        $ids_type => $ids
                    ];
                    $curl_data = mod_curl_info::get_names_by_ids($arr);
                    unset($ids);
                    $list[$key]['region_num'] = $data['num'];
                    $list[$key]['region']     = isset($curl_data[$keys][$data['relation_id']]['name']) ? $curl_data[$keys][$data['relation_id']]['name'] : null;

                }*/
                $obj = db::select("relation_id,relation_type")->from("#PB#_optional_region")->where("task_id",$value["id"]);
                $info1  = $obj->where('delete_user', '0')->execute();
                if (!empty($info1))
                {
                    foreach ($info1 as $keys => $values)
                    {
                        switch ($values["relation_type"]) {
                            case '1':
                                $user_ids["organization_ids"][] = $values["relation_id"];
                                break;
                            case '2':
                                $user_ids["department_ids"][] = $values["relation_id"];
                                break;
                            case '3':
                                $user_ids["station_ids"][] = $values["relation_id"];
                                break;
                            case '4':
                                $user_ids["member_ids"][] = $values["relation_id"];
                                break;
                        }
                    }
                    $list[$key]['region_num'] = $list[$key]['region'] = [];
                    $curl_data = mod_curl_info::get_names_by_ids($user_ids);
                    unset($user_ids);
                    $list[$key]['region_num'] = count($curl_data['organizations']) + count($curl_data['departments']) + count($curl_data['stations']) + count($curl_data['members']);
                    if(!empty($curl_data['organizations']))
                    {
                        $list[$key]['region']     = array_values($curl_data['organizations'])[0]['name'];

                    }elseif(!empty($curl_data['departments']))
                    {
                        $list[$key]['region']     = array_values($curl_data['departments'])[0]['name'];
                    }elseif(!empty($curl_data['stations']))
                    {
                        $list[$key]['region']     = array_values($curl_data['stations'])[0]['name'];
                    }elseif(!empty($curl_data['members']))
                    {
                        $list[$key]['region']     = array_values($curl_data['members'])[0]['name'];
                    }else{
                        $list[$key]['region']     = [];
                    }
                }


                //查询 是否有报价
                $p_num = db::select('count(id) as p_num')->from(self::$table_personnel)->where([
                    ['delete_user', '=', '0'],
                    ['task_id','=',$value['id']],
                    ['p_type','=',1],
                    ['status','=',0],
                ])->as_row()->execute();
                $list[$key]['p_num'] = $p_num['p_num'];
                unset($curl_data);
            }
        }
        $data = db::select('id,title')->from("#PB#_tasks_kinds")->where("delete_user",'0')->execute();
        if(!empty($data))
        {
            $tasks_kinds_options = array_column($data,'title','id');
        }
        tpl::assign('task_kind_id', $task_kind_id);
        tpl::assign('date_from', $date_from);
        tpl::assign('date_end', $date_end);
        tpl::assign('tasks_kinds_options', $tasks_kinds_options);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list', $list);

        tpl::display('audit_management.index.tpl');
    }

    /**
     * @desc 任务详情
     */
    public function detail()
    {
        $id     = req::item('id', 0, 'int');
        $action_home = req::item('action_home','audit_management');
        //echo $action_home;
        $page_size = req::item('page_size',20);
        $row = db::select('id,task_no,tasks_title,amount,currency')->from(self::$table)->where('id', $id)->and_where('delete_user','0')->as_row()->execute();
        if (!$row)
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }

        $rows = db::select('Count(*) AS count')->from(self::$table_personnel)->where($this->where)->and_where('task_id',$id)->as_row()->execute();
        $pages = pub_page::make($rows['count'], $page_size);
        $list = db::select('id,task_id,amount,reason,user_id')->from(self::$table_personnel)->where([
            ['delete_user','=','0'],
            ['task_id','=',$id],
            ['status','=','0'],
            ['p_type','=','1'],
        ])
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();
        if(!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $member = mod_curl_info::get_one_people_info($value['user_id'],true);
                if($member)
                {
                    $list[$key]['org_name']  = $member['organization'];
                    $list[$key]['dep_name']  = $member['department'];
                    $list[$key]['op_name']   = $member['name'];
                    $list[$key]['sta_name']  = isset($member['job']) ? $member['job'] : null;
                    $list[$key]['number']    = $member['sn'];
                }else
                {
                        unset($list[$key]);
                }
            }
        }
        tpl::assign('row', $row);
        tpl::assign('action_home', $action_home);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('audit_management.detail.tpl');
    }


    /**
     * @desc  准负责人详情
     * */
    public function detail_pesonnel()
    {
        $id     = req::item('id', 0, 'int');
        $action_home     = req::item('action_home', 'audit_management');
        $show     = req::item('show');
        if (!$id)
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }
        $row = db::select('id,task_id,reason,amount,user_id')
            ->from(self::$table_personnel)
            ->where('delete_user','0')
            ->and_where('id',$id)
            ->as_row()->execute();
        $member  = [];
        if(!empty($row))
        {
            $data = db::select('currency,amount')->from(self::$table)->where('id',$row['task_id'])->as_row()->execute();
            $row['currency'] = $data['currency'];
            $row['amount_b'] = $data['amount'];
            $member   = mod_curl_info::get_one_people_info($row['user_id'],true);
        }
        tpl::assign('row', $row);
        tpl::assign('show', $show);
        tpl::assign('action_home', $action_home);
        tpl::assign('member', $member);
        tpl::display('audit_management.detail_pesonnel.tpl');
    }

    public function agree()
    {
        $id     = req::item('id', 0, 'int');
        $action_home     = req::item('action_home', 'audit_management');
        if (!$id)
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }
        $row = db::select('id,task_id')
            ->from(self::$table_personnel)
            ->where('delete_user','0')
            ->and_where('id',$id)
            ->as_row()->execute();
        if(empty($row))
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }

        db::begin_tran();

        $update_data = array(
            'status'      => 1,
            'update_user' => cls_auth::$user->fields['admin_id'],
            'update_time' => time()
        );
        $p_res = mod_personnel::update_data($update_data, array('id ' => $id));


        $rows = db::select('id,task_id')
            ->from(self::$table_personnel)
            ->where('delete_user','0')
            ->and_where('task_id',$row['task_id'])
            ->and_where('id','!=',$id)
            ->as_row()->execute();
        $p_d_res = true;
        if(!empty($rows))
        {
            $update_data_d = array(
                'delete_user' => cls_auth::$user->fields['admin_id'],
                'delete_time' => time()
            );
            $p_d_res = mod_personnel::update_data($update_data_d,array('task_id'=>$row['task_id'],'status'=>'0'));
        }

        $update_t = array(
            'status'      => 1,
            'update_user' => cls_auth::$user->fields['admin_id'],
            'update_time' => time()
        );
        $t_res = mod_tasks::update_data($update_t,array('id ' => $row['task_id']));

        $update_o  = array(
            'delete_user' => cls_auth::$user->fields['admin_id'],
            'delete_time' => time()
        );
        $o_res = mod_optional_region::update_data($update_o,array('task_id ' => $row['task_id']));

        if(!$p_res || !$p_d_res || !$t_res || !$o_res)
        {
            db::rollback();
            cls_msgbox::show('系统提示', "预算核审已失败", '-1');
        }
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "编辑了准主要负责人为{$id}的数据，为主要负责人");

        db::commit();
        db::autocommit(true);
        cls_msgbox::show('系统提示', "预算核审已通过", "?ct={$action_home}&ac=index");
    }


    /**
     *
     * @desc  待审核的
     * */
    public function wait()
    {
        $task_kind_id = req::item('task_kind_id', 0 , 'int');
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 10);
        $date_type = req::item('date_type', '');
        $date_from = req::item('date_from', '');
        $date_end = req::item('date_end', '');

        $or_where1 = $or_where2 = [];
        if(!empty($keyword))
        {
            $or_where1[] = array('tasks_title', 'like', "%{$keyword}%");
            $or_where2[] = array('task_no', 'like', "%{$keyword}%");
        }
        if($task_kind_id)
        {
            $this->where[]   = ['task_kind_id','=',$task_kind_id];
        }

        if($date_type == 1 )
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['create_time', '>=', strtotime($date_from.' 00:00:00')];
                $this->where[] = ['create_time', '<=', strtotime($date_end.' 23:59:59')];
            }
        }else
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['task_end_datetime', '>=', strtotime($date_from.' 00:00:00')];
                $this->where[] = ['task_end_datetime', '<=', strtotime($date_end.' 23:59:59')];
            }
        }

        //查询
        $ids = db::select('task_id')->from(self::$table_personnel)
            ->where('user_id',$this->op_user_id)
            ->and_where('delete_user', '0')
            ->and_where('p_type','1')
            ->and_where('status','0')
            ->execute();
        $list = $pages = [];
        $pages['show'] = '';
        if(!empty($ids))
        {
            $ids = array_column($ids,'task_id');
            $row       = db::select('count(*) AS `count`')->from(self::$table)->where('id','in',$ids)->and_where($this->where)->as_row()->execute();
            $pages     = pub_page::make($row['count'], $page_size);
            $sql      = db::select('id,task_no,tasks_title,create_user,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')
                ->from(self::$table)
                ->where('id','in',$ids)
                ->and_where($this->where);
            if($keyword)
            {
                $sql = $sql->and_where_open()
                    ->where($or_where1)
                    ->or_where($or_where2)
                    ->and_where_close();
            }
            $list =  $sql->limit($pages['page_size'])
                ->offset($pages['offset'])
                ->order_by('create_time', 'desc')
                ->execute();
        }

        if(!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $member = mod_curl_info::get_one_people_info($value['create_user'],true);
                $list[$key]['dep_name'] = $list[$key]['op_name'] = null;
                if($member)
                {
                    $list[$key]['dep_name'] = $member['department'];
                    $list[$key]['op_name']  = $member['name'];
                }

            }
        }
        $data = db::select('id,title')->from("#PB#_tasks_kinds")->where("delete_user",'0')->execute();
        if(!empty($data))
        {
            $tasks_kinds_options = array_column($data,'title','id');
        }
        tpl::assign('task_kind_id', $task_kind_id);
        tpl::assign('date_from', $date_from);
        tpl::assign('date_end', $date_end);
        tpl::assign('tasks_kinds_options', $tasks_kinds_options);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list', $list);

        tpl::display('audit_management.wait.tpl');
    }


    public function detail_wait()
    {
        $id     = req::item('id', 0, 'int');
        $row = db::select('id,task_no,tasks_title,amount,currency')->from(self::$table)->where('id', $id)->and_where('delete_user','0')->as_row()->execute();
        if (!$row)
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }


        $list = db::select('id,task_id,amount,reason,user_id')->from(self::$table_personnel)->where([
            ['delete_user','=','0'],
            ['task_id','=',$id],
            ['status','=','0'],
            ['user_id','=',$this->op_user_id],
        ])
            ->as_row()
            ->execute();
        $member = mod_curl_info::get_one_people_info(cls_auth::$user->fields['admin_id'],true);
        tpl::assign('row', $row);
        tpl::assign('list', $list);
        tpl::assign('member', $member);
        tpl::display('audit_management.detail_wait.tpl');
    }

}
