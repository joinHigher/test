<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 我发布的任务
 * Class ctl_poster
 */
class ctl_poster
{
    private static $active = 1;
    private static $no_active = 0;
    private static $finish_task = 3;
    private static $running_task = 1;
    private static $waiting_checking_task = 2;
    private static $pause_task = 4;
    private static $reject_task = 5;
    private static $enabled = 1;
    private static $tasks_configs_table = '#PB#_tasks_configs';
    public static $url_cust = URL_API_CUST . '?ct=internal_api&ac=get_member_info_by_code&code=';
    public static $table_personnel = '#PB#_personnel';

    public function __construct()
    {
        $this->where = [
            ['delete_user', '=', '0'],
        ];
    }

    /**
     * 列表
     */
    public function index()
    {
        $task_table = '#PB#_tasks';
        $poster_id  = req::item('poster_id', 0, 'int');
        $active     = req::item('active', 0, 'int');
        $tabs       = array(
            array(
                'title' => '待受理的任务',
                'url'   => '?ct=poster&ac=index&active=0'
            ),
            array(
                'title' => '执行中的任务',
                'url'   => '?ct=poster&ac=index&active=1'
            ),
            array(
                'title' => '待验收的任务',
                'url'   => '?ct=poster&ac=index&active=2'
            ),
            array(
                'title' => '已完成的任务',
                'url'   => '?ct=poster&ac=index&active=3'
            )
        );

        foreach ($tabs as $key => $tab)
        {
            if ($active == $key)
            {
                $tabs[ $key ]['active'] = self::$active;
            }
            else
            {
                $tabs[ $key ]['active'] = self::$no_active;
            }

        }


        $date_from     = req::item('date_from', '');
        $date_end      = req::item('date_end', '');
        $date_type     = req::item('date_type', '');
        $keyword       = req::item('keyword', '');
        $tasks_kind_id = req::item('tasks_kind_id', 0, 'int');
        $page_size     = req::item('page_size', 10);

        if ($tasks_kind_id)
        {
            $this->where[] = ['task_kind_id', '=', $tasks_kind_id];
        }

        if ($date_type == 'post_date')
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['create_time', '>=', strtotime($date_from . ' 00:00:00')];
                $this->where[] = ['create_time', '<=', strtotime($date_end . ' 23:59:59')];
            }
        }
        else if ($date_type == 'stop_date')
        {
            if (!empty($date_from) && !empty($date_end))
            {
                $this->where[] = ['task_end_datetime', '>=', strtotime($date_from . ' 00:00:00')];
                $this->where[] = ['task_end_datetime', '<=', strtotime($date_end . ' 23:59:59')];
            }
        }
        switch ($active)
        {
            case 0: //待受理
                $this->where[] = ['status', '=', 0];
                break;
            case 1: //执行中任务
                $this->where[] = ['status', 'in', [1, 4]];
                break;
            case 2: //待验收的任务
                $this->where[] = ['status', '=', 2];
                break;
            case 3: //已完成的任务
                $this->where[] = ['status', '=', 3];
                break;
        }
        $this->where[] = ['create_user', '=', cls_auth::$user->fields['admin_id']];
        if ($poster_id != 0)
        {
            $task_id_arr  = db::select('task_id')
                ->from('#PB#_personnel')
                ->where('user_id', $poster_id)
                ->where('delete_user', 0)
                ->execute();
            $task_id_list = [];
            foreach ($task_id_arr as $row)
            {
                $task_id_list[] = $row['task_id'];
            }
            $this->where[] = ['id', 'in', $task_id_list];
        }
        $result = db::select('count(*) AS `count`')->from('#PB#_tasks')->as_row();
        $result->where($this->where);
        if (!empty($keyword))
        {
            $result->and_where_open();
            $result->where('tasks_title', 'like', "%{$keyword}%");
            $result->or_where('task_no','like',"%{$keyword}%");
            $result->and_where_close();
        }

        $result = $result->execute();
        $count  = $result['count'];
        $pages  = pub_page::make($count, $page_size);
        $query  = db::select('id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')
            ->from($task_table)
            ->where($this->where);
        if (!empty($keyword))
        {
            $query->and_where_open();
            $query->where('tasks_title', 'like', "%{$keyword}%");
            $query->or_where('task_no','like',"%{$keyword}%");
            $query->and_where_close();
        }
        $query->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->order_by('create_time', 'desc');
        $list   = $query->execute();
        if (!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $p_num = db::select('count(id) as p_num')->from(self::$table_personnel)->where([
                    ['delete_user', '=', '0'],
                    ['task_id', '=', $value['id']],
                    ['p_type', '=', 1],
                    ['status', '=', 0],
                ])->as_row()->execute();

                $list[ $key ]['p_num'] = $p_num['p_num'];
            }
        }

        tpl::assign('tasks_kind_id', $tasks_kind_id);
        tpl::assign('tabs', $tabs);
        tpl::assign('active', $active);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list', $list);
        tpl::assign('poster_id', $poster_id);
        tpl::display('poster.index.tpl');
    }

    /**
     * 我发布的任务详情
     */
    public function detail()
    {
        mod_status::poster_is_allow_user();
        $id   = req::item('id', 0, 'int');
        $data = db::select('id,parent_id,task_kind_id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')->from('#PB#_tasks')->where('id', $id)->as_row()->execute();
        if (!$data)
        {
            cls_msgbox::show('系统提示', "无法检视", '-1');
        }

        $files          = db::select()->from('#PB#_tasks_files')->execute();
        $condition      = array(
            'id' => $data['task_kind_id']
        );
        $task_kind_arr  = mod_tasks_kinds::get_one('id,title', $condition);
        $condition      = array(
            'id' => $data['task_level_id']
        );
        $task_level_arr = mod_tasks_levels::get_one('id,title', $condition);

        $task_files_arr = mod_tasks_files::get_files_by_task_id($data['id']);

        $task_kind  = $task_kind_arr['title'];
        $task_level = $task_level_arr['title'];
        tpl::assign('data', $data);
        tpl::assign('id', $id);
        tpl::assign('files', $files);
        tpl::assign('task_kind', $task_kind);
        tpl::assign('task_level', $task_level);
        tpl::assign('task_files_arr', $task_files_arr);

        tpl::display('poster.detail.tpl');
    }

    /**
     * 子任务列表
     */
    public function sub_tasks()
    {
        // get config setting
        $config_fields = array(
            'is_allow_max_sub_tasks',
            'max_sub_tasks',
        );
        $config        = array();
        $config_array  = db::select('name,value')->from(self::$tasks_configs_table)->where('name', 'in', $config_fields)->execute();
        foreach ($config_array as $row)
        {
            if ($row['name'] == 'is_allow_max_sub_tasks')
            {
                $config['is_allow_max_sub_tasks'] = $row['value'];
            }
            if ($row['name'] == 'max_sub_tasks')
            {
                $config['max_sub_tasks'] = $row['value'];
            }
        }

        $page_size = req::item('page_size', 10);
        $id        = req::item('id', 0, 'int');
        $data      = mod_tasks::get_task_detail($id);
        if (!$data)
        {
            cls_msgbox::show('系统提示', "无法检视", '-1');
        }

        $result = mod_tasks::get_sub_task_size($id);
        $count  = $result['count'];
        $pages  = pub_page::make($count, $page_size);

        $is_show_button = TRUE;
        if ($config['is_allow_max_sub_tasks'] == self::$enabled)
        {
            if ($config['max_sub_tasks'] <= $count)
            {
                $is_show_button = FALSE;
            }
        }
        $condition     = array(
            'id' => $data['task_kind_id']
        );
        $task_kind_arr = mod_tasks_kinds::get_one('id,title', $condition);
        $task_kind     = $task_kind_arr['title'];
        $list          = mod_tasks::get_sub_task_list($id, $pages['page_size'], $pages['offset']);
        if (!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $p_num = db::select('count(id) as p_num')->from(self::$table_personnel)->where([
                    ['delete_user', '=', '0'],
                    ['task_id', '=', $value['id']],
                    ['p_type', '=', 1],
                    ['status', '=', 0],
                ])->as_row()->execute();

                $list[ $key ]['p_num'] = $p_num['p_num'];
            }
        }
        tpl::assign('is_show_button', $is_show_button);
        tpl::assign('task_kind', $task_kind);
        tpl::assign('list', $list);
        tpl::assign('data', $data);
        tpl::assign('id', $data['id']);
        tpl::assign('pages', $pages['show']);

        tpl::display('poster.sub_tasks.tpl');
    }

    /**
     * 我发布的任务 任务参与人员
     */
    public function personnel()
    {
        $id     = req::item('id', 0, 'int');
        $p_type = req::item('p_type');
        //echo $p_type;
        if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }
        $type = $p_type == 'cc' ? 3 : ($p_type == 'join' ? 2 : 1);
        if ($p_type == 'main' || $p_type == '')
        {
            $this->where[] = ['status', '=', 1];
        }
        $this->where[] = ['p_type', '=', $type];
        //$this->where[] = ['type', '=', 1];
        $this->where[] = ['task_id', '=', $id];
        $page_size     = req::item('page_size', 10);
        $row           = db::select('count(*) AS `count`')->from('#PB#_personnel')->where($this->where)->as_row()->execute();
        $pages         = pub_page::make($row['count'], $page_size);
        $list          = db::select("id,task_id,user_id")->from('#PB#_personnel')->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('create_time', 'desc')->execute();
        if (!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $member = mod_curl_info::get_one_people_info($value['user_id'], TRUE);
                if ($member)
                {
                    $list[ $key ]['org_name'] = $member['organization'];
                    $list[ $key ]['dep_name'] = $member['department'];
                    $list[ $key ]['op_name']  = $member['name'];
                    $list[ $key ]['sta_name'] = isset($member['job']) ? $member['job'] : null;
                    $list[ $key ]['number']   = $member['sn'];
                }
                else
                {
                    unset($list[ $key ]);
                }

            }
        }
        //查询当前任务状态
        $task_info = db::select('status,task_end_datetime,is_member,create_user')->from("#PB#_tasks")->where('delete_user', '0')->and_where("id", $id)->as_row()->execute();
        if (empty($task_info))
        {
            cls_msgbox::show('系统提示', '数据有误！', '-1');
            exit();
        }

        //获取当前已存在的用户id
        $where[]  = ['delete_user', '=', '0'];
        $where[]  = ['task_id', '=', $id];
        $ids      = db::select('user_id')->from('#PB#_personnel')->where($where)->distinct(TRUE)->execute();
        $user_ids = '';

        $user_ids .= !empty($ids) ? implode(',', array_column($ids, 'user_id')) : '';
        if($task_info['is_member'] == 1 && !empty($ids))
        {
            if(!in_array($task_info['create_user'],array_column($ids, 'user_id')))
            {
                $user_ids .= ','.$task_info['create_user'];
            }
        }else
        {
            $user_ids .= $task_info['create_user'];
        }
        $user_ids = trim($user_ids,',');
        unset($ids);
        $show = TRUE;
        if ($task_info['status'] == 3)
        {
            $show = FALSE;
        }
        tpl::assign('list', $list);
        tpl::assign('user_ids', $user_ids);
        tpl::assign('id', $id);
        tpl::assign('show', $show);
        tpl::assign('p_type', $p_type);
        tpl::assign('active', 'personnel');
        tpl::assign('pages', $pages['show']);
        tpl::display('poster.personnel.tpl');
    }

    /**
     * 通过验收行为
     */
    public function add_pass_task()
    {
        $task_id        = req::item('task_id', 0, 'int');
        $task_table     = '#PB#_tasks';
        $progress_table = '#PB#_progress';
        $json['status'] = 'fail';
        if (req::is_ajax())
        {
            $data = db::select('status,task_process')->from($task_table)->where('id', $task_id)->as_row()->execute();
            if (!empty($data))
            {
                $process = $data['task_process'];
                if ($data['status'] == self::$waiting_checking_task)
                {
                    $task_field_arr           = array();
                    $task_field_arr['status'] = self::$finish_task;
                    db::update($task_table)->set($task_field_arr)->where("id", '=', $task_id)->execute();
                    if (db::affected_rows() < 1)
                    {
                        log::error(cls_auth::$user->fields['username'] . '更新任务失败 task id:' . $task_id);
                        die(json_encode($json));
                    }

                    $data = array(
                        'task_id'     => $task_id,
                        'progress'    => $process,
                        'type'        => 0,
                        'create_user' => cls_auth::$user->fields['admin_id'],
                        'create_time' => time(),
                        'status'      => 6,
                    );
                    db::insert($progress_table)->set($data)->execute();
                    $progress_id = db::insert_id();
                    if ($progress_id < 1)
                    {
                        log::error(cls_auth::$user->fields['username'] . '新增过程失败 task id:' . $task_id);
                        die(json_encode($json));
                    }
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务过程ID为{$progress_id}的数据");
                    $json['status'] = 'success';
                }
            }
        }
        echo json_encode($json);
    }

    /**
     * 驳回验收行为
     */
    public function add_reject_task()
    {
        $task_id        = req::item('task_id', 0, 'int');
        $reason         = req::item('reason', 0, 'string');
        $task_table     = '#PB#_tasks';
        $reason_table   = '#PB#_tasks_reject_reasons';
        $progress_table = '#PB#_progress';
        $json['status'] = 'fail';
        if (req::is_ajax())
        {
            $data = db::select('status,task_process')->from($task_table)->where('id', $task_id)->as_row()->execute();
            if (!empty($data))
            {
                $process = $data['task_process'];
                if ($data['status'] == self::$waiting_checking_task)
                {
                    $task_field_arr           = array();
                    $task_field_arr['status'] = self::$running_task;
                    db::update($task_table)->set($task_field_arr)->where("id", '=', $task_id)->execute();
                    if (db::affected_rows() < 1)
                    {
                        log::error(cls_auth::$user->fields['username'] . '更新任务资讯 id:' . $task_id . '失败');
                        die(json_encode($json));
                    }
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "更新了任务ID为{$task_id}的数据");
                    $data = [
                        'task_id'     => $task_id,
                        'reason'      => $reason,
                        'create_user' => cls_auth::$user->fields['admin_id'],
                        'create_time' => time(),
                    ];
                    db::insert($reason_table)->set($data)->execute();
                    $reason_id = db::insert_id();
                    if ($reason_id < 1)
                    {
                        log::error(cls_auth::$user->fields['username'] . '新增理由资讯失败');
                        die(json_encode($json));
                    }

                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务驳回理由ID为{$reason_id}的数据");
                    $data = array(
                        'task_id'     => $task_id,
                        'progress'    => $process,
                        'remarks'     => $reason,
                        'type'        => 0,
                        'create_user' => cls_auth::$user->fields['admin_id'],
                        'create_time' => time(),
                        'status'      => self::$reject_task,
                    );
                    db::insert($progress_table)->set($data)->execute();
                    $progress_id = db::insert_id();
                    if ($progress_id < 1)
                    {
                        log::error(cls_auth::$user->fields['username'] . '新增过程资讯失败');
                        die(json_encode($json));
                    }
                    $json['status'] = 'success';
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增了任务过程ID为{$progress_id}的数据");
                }
            }
        }
        echo json_encode($json);
    }

}