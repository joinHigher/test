<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 汇率管理
 *
 * @version $Id$
 */
class ctl_currency
{

    public function index()
    {
        $keyword = req::item("keyword");
        $where_str = [];
        if(!empty($keyword))
        {
            $where_str[] = ["name","like","%{$keyword}%"];
        }

        $total 		   = mod_currency::get_total($where_str);
        $page_size     = req::item("page_size",10);
        $pages         = pub_page::make($total, $page_size);
        // $page_str      = "{$pages["offset"]},{$pages["page_size"]}";
        $currency_list = mod_currency::get_all($where_str,$pages);
        $admin_users   = mod_admin::get_names();
        tpl::assign('admin_users',$admin_users);
        tpl::assign('pages',$pages["show"]);
        tpl::assign('currency_list',$currency_list);
        tpl::display("currency.index.tpl");
    }

    public function add()
    {
        if (!empty(req::$posts))
        {
            $form_data = $this->_ver_from();
            $form_data["create_user"] = cls_auth::$user->fields['uid'];
            $form_data["create_time"] = time();
            $status = mod_currency::save($form_data);
            if($status)
            {
                cls_msgbox::show('系统提示',"添加成功","?ct=currency&ac=add");
            }else{
                cls_msgbox::show('系统提示',"添加失败,稍后再试..",-1);
            }

        }
        tpl::display("currency.add.tpl");
    }

    public function edit()
    {
        $cid = req::item("id");
        if(empty($cid))
        {
            cls_msgbox::show('系统提示',"不存在改货币信息",-1);
        }

        $info = mod_currency::get_one(["id"=>$cid]);
        if(empty($info))
        {
            cls_msgbox::show('系统提示',"不存在改货币信息",-1);
        }
        if (!empty(req::$posts))
        {
            $form_data = $this->_ver_from();
            $status = mod_currency::save($form_data,["id"=>$cid]);
            if($status)
            {
                cls_msgbox::show('系统提示',"编辑成功","?ct=currency&ac=index");
            }else{
                cls_msgbox::show('系统提示',"编辑失败,稍后再试..",-1);
            }
        }
        tpl::assign('currency_info',$info);
        tpl::display("currency.edit.tpl");
    }

    
    private function _ver_from()
    {

        $form_data["name"] 	 = req::item("name");
        $form_data["symbol"] 	 = req::item("symbol");
        $form_data["delete_user"] = 0;
        if(empty($form_data["name"])||mb_strlen($form_data["name"])>10)
        {
            cls_msgbox::show('系统提示',"请输入10个字内的货币名称",-1);
        }

        if(empty($form_data["symbol"])||mb_strlen($form_data["symbol"])>10)
        {
            cls_msgbox::show('系统提示',"请输入10个字内的货币符号",-1);
        }

        $cid = req::item("id");
        if(empty($cid))
        {
            $info = mod_currency::get_one(["name"=>$form_data["name"]]);
        }else{
            $info = mod_currency::get_one(["name"=>$form_data["name"],["id","!=",$cid]]);
        }
        if(!empty($info))
        {
            $name = req::item("name");
            cls_msgbox::show('系统提示',"[{$name}]已存在",-1);
        }
        $form_data["calculator"] = req::item("calculator");
        if(!is_numeric($form_data["calculator"]))
        {
            cls_msgbox::show('系统提示',"请正确输入与美元的汇率",-1);
        }
        $form_data["update_user"] = cls_auth::$user->fields['uid'];
        $form_data["update_time"] = time();
        return $form_data;
    }

}

