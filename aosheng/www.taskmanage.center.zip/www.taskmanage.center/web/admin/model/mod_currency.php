<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/*
	获取货币信息
*/
class mod_currency{

    private static $table_name = "tm_currency";
    private static $field = "id, name, calculator,symbol, create_user, create_time, update_user, update_time, delete_user";

    private static $data_arr;
    //各货币的美元汇率
    private static $dollar_calculator;

    //获取货币信息
    public static function get_list($status = false)
    {
        $variable = self::get_all();

        if($status)
        {
            self::$data_arr["0"] ="请选择货币类型";
        }else{
            self::$data_arr["0"] ="";
        }

        if(!empty($variable))
        {
            foreach ($variable as $key => $value) {
                self::$data_arr[$value["id"]] = $value["name"];
                self::$dollar_calculator[$value["id"]] =$value["calculator"];
            }
        }


        return self::$data_arr;
    }

    //获取货币名称
    public static function get_name($id)
    {
        if(empty(self::$data_arr))
        {
            self::get_list();
        }
        if(empty(self::$data_arr[$id]))
        {
            return "--";
        }
        return self::$data_arr[$id];
    }
    public static function get_calculators(){
        return self::$dollar_calculator;
    }

    /**
     * 汇率计算 换算为美元
     * @param $outType 需要换算的货币类型
     * @param $number 需要换算的金额
     * @return float|int 美元
     */
    public static function exchange_calculator($id, $number)
    {
        if(empty($dollar_calculator))
        {
            self::get_list();
        }
        if(!$id){
            return false;
        }
        return number_format($number * self::$dollar_calculator[$id],2);
    }
    /**
     * 计算金额，换算为输入的货币类型的金额
     * @param $id 输入货币类型
     * @param $number 输入货币金额
     * @return mixed
     */
    public static function get_amount($id,$number)
    {

        if(empty($dollar_calculator))
        {
            self::get_list();
        }
        if(!$id){
            return false;
        }
        //金额 除以 汇率
        return number_format($number / self::$dollar_calculator[$id],2);
    }

    public static function save($data,array $where=array())
    {
        $table = self::$table_name;
        if(empty($where))
        {
            // return  db::insert($table,$data);
            return db::insert(self::$table_name)->set($data)->execute();
        }else{
            return db::update(self::$table_name)->set($data)->where($where)->execute();
        }
    }

    public static function get_one(array $where=[])
    {
        // $table = self::$table_name;
        // return db::get_one("select *from {$table} where {$where}");
        return db::select(self::$field)->from(self::$table_name)->where($where)->as_row()->execute();
    }
    public static function get_total(array $where=[])
    {
        //     $table  = self::$table_name;
        //     $sql    = "select count(*) count from {$table} where {$where}";
        //     $info   =  db::get_one($sql);
        $info = db::select("count(*) count")->from(self::$table_name)->where($where)->as_row()->execute();
        return $info["count"];
    }
    public static function get_all(array $where=array(),array $pages=[])
    {
        // $table = self::$table_name;
        $obj = db::select(self::$field)->from(self::$table_name)->where($where);
        if(!empty($page))
        {
            // $page = "limit {$page}";
            $obj->limit($pages["page_size"])->offset($pages["offset"]);
        }
        // $sql = "select * from {$table} where {$where} {$page}";
        // $variable = db::get_all($sql);
        $variable = $obj->execute();
        if(!empty($variable))
        {
            foreach ($variable as $key => $value) {
                # code...
                $variable[$key]["name"] = $value["name"];
            }
        }

        return $variable;

    }

}









