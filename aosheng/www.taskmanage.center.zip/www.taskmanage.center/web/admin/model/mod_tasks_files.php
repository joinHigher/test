<?php
/**
 * Created by PhpStorm.
 * User: kosbox
 * Date: 2018/4/2
 * Time: 下午5:21
 */

class mod_tasks_files
{
    public static $table = '#PB#_tasks_files';

    public static function insert_data($data)
    {
        list($insert_id, $rows_affected) = db::insert(self::$table)->set($data)->execute();
        return $insert_id;
    }

    /**
     * 取出所有任务紧急等级数据
     *
     * @return object
     */
    public static function get_files_by_task_id(int $task_id)
    {
        return db::select('task_id,filename')->from(self::$table)->where('task_id', $task_id)->execute();
    }

}