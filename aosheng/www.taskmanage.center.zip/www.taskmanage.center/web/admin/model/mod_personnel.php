<?php
if( !defined('PHPCALL') ) exit('Request Error!');

/**
 * 任务人员选择范围
 *
 */
class mod_personnel
{
    protected static $table = '#PB#_personnel'; //表名

    protected  static $where = [
        ['delete_user', '=', '0']
    ];


    /**
     *  查询单条数据
     * @param  array $data
     */
    public static function get_one_data($filed,$where=[])
    {
        if(!empty($where))
        {
            self::$where[] = $where;
        }
        $data = db::select($filed)
            ->from(self::$table)
            ->where(self::$where)
            ->as_row()
            ->execute();
        return $data;
    }

    /**
     *  查询列表数据
     * @param  array $data
     * @param  array $where
     */
    public static function getlist($filed,$where = [])
    {
        if(!empty($where))
        {
            self::$where[] = $where;
        }
        $data = db::select($filed)
            ->from(self::$table)
            ->where(self::$where)
            ->execute();
        return $data;
    }


    /**
     *  新增数据.
     * @param  array $data
     */
    public static function insert_data($data)
    {
        db::insert(self::$table)->set($data)->execute();
        $insert_id = db::insert_id();
        return $insert_id;
    }

    /**
     * 批量插入数据
     * @param array $fields_arr
     * @param  array $data
     */
    public static function bath_insert($fields_arr, $data)
    {
        return db::insert(self::$table)->columns($fields_arr)->values($data)->execute();
    }

    /**
     * 更新数据.
     * @param array $data
     * @param array $where
     */
    public static function update_data($data, $where)
    {
        return db::update(self::$table)->set($data)->where($where)->execute();

    }

}