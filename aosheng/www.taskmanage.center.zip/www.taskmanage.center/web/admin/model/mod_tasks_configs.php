<?php

/**
 * 验收方式
 *
 * Class mod_tasks_levels
 */
class mod_tasks_configs
{
    public static $table = '#PB#_tasks_configs';

    /**
     * 取出所有验收方式数据
     *
     * @return object
     */
    public static function get_all(string $filed)
    {
        return db::select($filed)->from(self::$table)->execute();
    }

    /**
     * 插入资料到 数据表 tasks_level
     *
     * @param array $data 栏位
     *
     * @return mixed
     */
    public static function insert_data($data)
    {
        list($insert_id, $rows_affected) = db::insert(self::$table)->set($data)->execute();
        return $insert_id;
    }

    /**
     *  根据条件取出一条数据
     * @param filed:需取出的字段，必填，不能为*
     * @param where:查询条件，数组，可为空 
    */
    public static function get_one(string $filed,array $where=null)
    {
        return db::select($filed)->from(self::$table)->where($where)->as_row()->execute();
    }
    /**
     * 更新 数据表 tasks_level
     *
     * @param array $data 栏位
     * @param int   $id   流水编号
     *
     * @return mixed
     */
    public static function update_data($data, array $where=null)
    {
        return db::update(self::$table)->set($data)->where($where)->execute();
    }
     /**
     * 获取name = val 的数组
     *
     */
    public static function get_name_val()
    {
        $variable = self::get_all("name,value");
        $infos = array();
        foreach ($variable as $key => $value) {
            # code...
            $infos[$value["name"]] = $value["value"];
        }
        return $infos;
    }

}









