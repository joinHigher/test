<?php

class mod_tasks_viewers
{
    private static $table = '#PB#_tasks_viewers';

    public static function saveViewer($task_id)
    {

        $ip        = util::get_client_ip();
        $view_time = time();
        $wheres    = [
            ['task_id', '=', $task_id],
            ['viewer_id', '=', cls_auth::$user->fields['admin_id']],
            ['delete_user', '=', 0]
        ];
        $row       = db::select('viewer_id')
            ->from(self::$table)
            ->where($wheres)
            ->as_row()->execute();
        if (empty($row))
        {
            db::insert('#PB#_tasks_viewers')->set(array(
                'viewer_id'     => cls_auth::$user->fields['admin_id'],
                'task_id'       => $task_id,
                'view_datetime' => $view_time,
                'viewer_ip'     => $ip,
            ))->execute();
        }
    }
}