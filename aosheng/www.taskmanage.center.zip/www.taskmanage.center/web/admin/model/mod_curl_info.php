<?php
if (!defined('PHPCALL')) exit('Request Error!');

class mod_curl_info
{

    //根据ids 获取id=>name 数组
    public static function get_names_by_ids(array $ids)
    {
        if (empty($ids)) return FALSE;
        $ids['organization_ids'] = isset($ids['organization_ids']) ? array_unique($ids['organization_ids']) : null;
        $ids['department_ids']   = isset($ids['department_ids']) ? array_unique($ids['department_ids']) : null;
        $ids['station_ids']      = isset($ids['station_ids']) ? array_unique($ids['station_ids']) : null;
        $ids['member_ids']       = isset($ids['member_ids']) ? array_unique($ids['member_ids']) : null;
        $post_data               = [
            'organization_ids' => $ids['organization_ids'],
            'department_ids'   => $ids['department_ids'],
            'station_ids'      => $ids['station_ids'],
            'member_ids'       => $ids['member_ids'],
            'sign'             => md5("AS" . date('Ymdh')),
            'action'           => 'mixing'
        ];
        $util                    = new util();
        $data                    = $util->http_post(URL_API_SYS . '/organ.php', http_build_query($post_data));
        $info                    = json_decode($data, TRUE);
        $res                     = $info['data'];
        $res                     = self::format_name($res);
        //print_r($res);exit;
        return $res;
    }


    /**
     * @desc  获取单个员工信息
     *
     * @param 用户ID
     * */
    public static function get_one_people_info($user_id, $smrty = FALSE)
    {
        if (!$user_id)
        {
            return FALSE;
        }
        $post_data = [
            'id'     => $user_id,
            'sign'   => md5("AS" . date('Ymdh')),
            'action' => 'get_one'
        ];
        $util      = new util();
        $data      = $util->http_post(URL_API_SYS . '/people.php', $post_data);
        $info      = json_decode($data, TRUE);
        if ($info['status'] != 0 || empty($info['data']))
        {
            if ($smrty)
            {
                return FALSE;
            }
            cls_msgbox::show('系统提示', "当前账号有误", '-1');
        }
        $res         = $info['data'];
        $res['name'] = isset($res['name']) && $res['name'] ? $res['name'] : $res['nickname'];
        return $res;
    }

    /**
     * 取得机构 部门 岗位 user id
     *
     * @param      $type 型态 1:机构 2:部门 3:岗位 4:人员id relation_type
     * @param      $id   relation_id
     * @param bool $smrty
     *
     * @return array|bool
     */
    public static function get_peoples_user_id($type, $id, $smrty = FALSE)
    {
        $type_name = '';
        switch ($type)
        {
            case 1: //机构
                $type_name = 'organization';
                break;
            case 2: //部门
                $type_name = 'department';
                break;
            case 3: //岗位
                $type_name = 'station';
                break;
            case 4:
                $type_name = 'member';
                break;
        }
        if (!$id)
        {
            return FALSE;
        }
        if ($type_name == 'member')
        {
            return [
                $id
            ];
        }
        $post_data = [
            'id'     => $id,
            'sign'   => md5("AS" . date('Ymdh')),
            'type'   => $type_name,
            'action' => 'get_peoples'
        ];
        $util      = new util();
        $data      = $util->http_post(URL_API_SYS . '/people.php', $post_data);
        $info      = json_decode($data, TRUE);
        if ($info['status'] != 0 || empty($info['data']))
        {
            if ($smrty)
            {
                return FALSE;
            }
            cls_msgbox::show('系统提示', "当前账号有误", '-1');
        }
        return $info['data'];

    }


    /**
     * 取得任务范围内,所有人员id
     *
     * @param array $id_arr 任务范围数组
     *
     * @return array|bool
     */
    public static function get_range_user_id(array $id_arr)
    {

        $organization_ids = [];
        $department_ids   = [];
        $station_ids      = [];
        $member_ids       = [];
        if ($id_arr < 1)
        {
            return FALSE;
        }
        foreach ($id_arr as $row)
        {
            switch ($row['relation_type'])
            {
                case 1:
                    $organization_ids[] = $row['relation_id'];
                    break;
                case 2:
                    $department_ids[] = $row['relation_id'];
                    break;
                case 3:
                    $station_ids[] = $row['relation_id'];
                    break;
                case 4:
                    $member_ids[] = $row['relation_id'];
                    break;
            }
        }
        $post_data = [
            'organization_ids' => $organization_ids,
            'department_ids'   => $department_ids,
            'station_ids'      => $station_ids,
            'sign'             => md5("AS" . date('Ymdh')),
            'action'           => 'get_peoples_by_mix'
        ];

        $util  = new util();
        $data  = $util->http_post(URL_API_SYS . '/people.php', http_build_query($post_data));
        $info  = json_decode($data, TRUE);
        $items = [];
        if ($info['status'] != 0 || empty($info['data']))
        {
            $items = $info['data'];
        }
        return array_merge($items, $member_ids);

    }


    public static function format_name($data)
    {

        if (isset($data['members']) && $data['members'])
        {
            foreach ($data['members'] as $key => $v)
            {
                $data['members'][ $key ]['name'] = $v['name'] ? $v['name'] : $v['nickname'];
            }

        }
        return $data;
    }

    /**
     * 允许任务范围的人,如果再任务范围的人的话,会显示 true ,否则为 false
     *
     * @param array $id_arr  组织 id,单位 id,岗位 id, 人员 id
     * @param       $user_id 当前登入的人
     *
     * @return bool true/false
     */
    public static function is_allow_case_user(array $id_arr, $user_id)
    {
        $organization_ids = [];
        $department_ids   = [];
        $station_ids      = [];
        $member_ids       = [];
        if ($id_arr < 1)
        {
            return FALSE;
        }
        foreach ($id_arr as $row)
        {
            switch ($row['relation_type'])
            {
                case 1:
                    $organization_ids[] = $row['relation_id'];
                    break;
                case 2:
                    $department_ids[] = $row['relation_id'];
                    break;
                case 3:
                    $station_ids[] = $row['relation_id'];
                    break;
                case 4:
                    $member_ids[] = $row['relation_id'];
                    break;
            }
        }
        $post_data = [
            'organization_ids' => $organization_ids,
            'department_ids'   => $department_ids,
            'station_ids'      => $station_ids,
            'id'               => $user_id,
            'sign'             => md5("AS" . date('Ymdh')),
            'action'           => 'is_people_in'
        ];
        $util = new util();
        $data = $util->http_post(URL_API_SYS . '/people.php', http_build_query($post_data));
        $info = json_decode($data, TRUE);
        $is_in_company = false;
        if ($info['status'] == 0 )
        {
            $is_in_company = true;
        }
        $is_in_member = false;
        if (in_array($user_id,$member_ids)) {
            $is_in_member = true;
        }
        $is_in_place = false;
        $in_place_index = 0;
        if ($is_in_company)
        {
            $in_place_index++;
        }
        if ($is_in_member)
        {
            $in_place_index++;
        }
        if ($in_place_index > 0)
        {
            $is_in_place = true;
        }
        return $is_in_place;
    }
}