<?php
if( !defined('PHPCALL') ) exit('Request Error!');

/**
* 
*/
class mod_upload_file
{
	
	/**
	 *@param: 上传的文件名
	 *@return array: 
	 	成功status返回true，key_iv:加密key_iv
	 	失败：status 返回false,document:失败原因
	 	
	*/
	public static function upload(string $filename)
	{

		if(!file_exists(PATH_UPLOADS_TEMP."/{$filename}"))
		{
			return array("status"=>FALSE,"document"=>"上传文件不存在");
		}
        // 压缩文件
		$key = util::random('unique');
		// 加密
		$value = file_get_contents(PATH_UPLOADS_TEMP."/{$filename}");
		$value = cls_crypt::encode($value, $key);
		file_put_contents(PATH_UPLOADS_FILE."/{$filename}", $value);
		unlink(PATH_UPLOADS_TEMP."/{$filename}");

		return array("status"=>true,"key_iv"=>$key);
	}
	/**
	*多个文件上传后压缩成一个文件
	 *@param files = array("file1.xx","file2.xx")
	 *@return 成功返回数组 array(status=>true,key_iv=>"xxx","file_name"=>"xxx")
	 		失败：array(status=>false,document=>"失败原因")
	*/
	public static function upload_files_zip(array $files)
	{

		 $zipname = uniqid().".zip";
		 foreach ($files as $key => $value) {
		 	# code...
		 	$file_info = pathinfo($value,PATHINFO_EXTENSION);
			if($file_info == "php")
			{
				return array("status"=>FALSE,"document"=>"文件异常");
			}
		 	if(!file_exists(PATH_UPLOADS_TEMP."/{$value}"))
			{
			    return array("status"=>FALSE,"document"=>"某个上传文件不存在");
			}
		 	pub_zip::add(PATH_UPLOADS_TEMP."/{$value}");
		 }
		 pub_zip::zip(PATH_UPLOADS_TEMP."/{$zipname}");
		 pub_zip::close();
		 $infos = self::upload($zipname);
		 if($infos["status"])
		 {
		 	$infos["file_name"] = $zipname;

		 }
		 foreach ($files as $key => $value) {
		 	unlink(PATH_UPLOADS_TEMP."/{$value}");
		 }
		 return $infos;
	}
	public static function download(string $file_name,string $key)
	{
		if(!file_exists(PATH_UPLOADS_FILE."/{$file_name}"))
		{
			cls_msgbox::show('系统提示', '文件不存在',-1);
		}
		
    	$value = file_get_contents(PATH_UPLOADS_FILE."/{$file_name}");
		$plaintext = cls_crypt::decode($value, $key);
		$file_size = strlen($plaintext);
		header("Content-Type: application/octet-stream");
		header("Accept-Ranges: bytes");
		header("Accept-Length: ".$file_size);
		header("Content-Disposition: attachment; filename={$file_name}");
		echo $plaintext;
		exit();
	}

}








