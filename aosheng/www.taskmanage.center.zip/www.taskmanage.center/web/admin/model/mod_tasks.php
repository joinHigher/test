<?php
/**
 * Created by PhpStorm.
 * User: kosbox
 * Date: 2018/4/2
 * Time: 下午5:19
 */

class mod_tasks
{
    public static $table = '#PB#_tasks';

    public static function insert_data($data)
    {
        list($insert_id, $rows_affected) = db::insert(self::$table)->set($data)->execute();
        return $insert_id;
    }

    public static function get_task_auto_id()
    {
        $time        = time();
        $time_length = strlen($time);
        return substr($time, $time_length - 5, $time_length);
    }


    /**
     * 更新数据.
     * @param array $data
     * @param array $where
     */
    public static function update_data($data, $where)
    {
        return db::update(self::$table)->set($data)->where($where)->execute();

    }

    public static function get_task_detail($task_id)
    {
        $data = db::select('id,parent_id,task_kind_id,task_no,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')
            ->from(self::$table)
            ->where('id', $task_id)
            ->as_row()
            ->execute();
        return $data;
    }

    public static function get_sub_task_list($parent_id,$page_size,$offset)
    {
        return db::select('id,task_no,parent_id,tasks_title,amount,currency,task_level_id,accept_status,task_end_datetime,target,task_note,demand,task_process,`status`,reason,post_date')
            ->from(self::$table)
            ->where('parent_id', $parent_id)
            ->where('delete_user', 0)
            ->limit($page_size)
            ->offset($offset)
            ->order_by('create_time', 'desc')->execute();
    }

    public static function get_sub_task_size($parent_id)
    {
        return db::select('count(*) AS `count`')
            ->from(self::$table)
            ->where('parent_id', $parent_id)
            ->where('delete_user', 0)
            ->as_row()
            ->execute();
    }
}