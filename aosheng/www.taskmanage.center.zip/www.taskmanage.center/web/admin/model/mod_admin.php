<?php
if( !defined('PHPCALL') ) exit('Request Error!');

class mod_admin
{
    protected static $table = '#PB#_admin';
    protected static $names_arr=array();

    public static function make()
    {
        return new static();
    }

    public static function find($id, $field = '*')
    {
        return db::select($field)->from(self::$table)->where('admin_id',$id)->as_row()->execute();
    }

    public static function get_name($id)
    {
        if(empty(self::$names_arr[$id]))
        {
            self::$names_arr=self::get_names();
            return self::$names_arr[$id];
        }
        return self::$names_arr[$id];
    }

    public static function get_names()
    {
        $infos = db::select('admin_id,username')->from(self::$table)->execute();
        $rows=array();
        foreach ($infos as $key => $value)
        {
            # code...
            $rows[$value["admin_id"]]=$value["username"];
        }
        return $rows;
    }
}
