<?php

class mod_status
{

    /**
     * 新发布的案件 是否在范围内
     */
    public static function task_is_allow_user()
    {
        $id         = req::item('id', '0', 'int');
        $task_datas = db::select('task_id,relation_id,relation_type')
            ->from('#PB#_optional_region')
            ->where('task_id', $id)
            ->where('delete_user', 0)
            ->order_by('task_id')
            ->execute();
        $task_items = [];
        if (empty($task_datas))
        {
            cls_msgbox::show('系统提示', "任务主要负责人已经被指派，请刷新后再查阅", '?ct=tasks&ac=index', 3000);
        }
        foreach ($task_datas as $row)
        {
            $task_items[] = [
                'relation_id'   => $row['relation_id'],
                'relation_type' => $row['relation_type'],
            ];
        }
        $is_in_place = mod_curl_info::is_allow_case_user($task_items, cls_auth::$user->fields['admin_id']);
        $task_arr    = db::select('create_user')
            ->from('#PB#_tasks')
            ->where('id', $id)
            ->where('create_user', cls_auth::$user->fields['admin_id'])
            ->as_row()
            ->execute();

        if (!$is_in_place && empty($task_arr))
        {
            cls_msgbox::show('系统提示', "任务主要负责人已经被指派，请刷新后再查阅", '?ct=tasks&ac=index', 3000);
        }
    }

    /**
     * 我负责的任务 是否在范围内
     */
    public static function responsible_is_allow_user()
    {
        $id         = req::item('id', 0, 'int');
        $tasks_data = db::select('parent_id,master_id')->from('#PB#_tasks')->where('id', $id)->as_row()->execute();
        if (empty($tasks_data))
        {
            cls_msgbox::show('系统提示', "任务主要负责人已经被指派，请刷新后再查阅", '?ct=responsible&ac=index', 3000);
        }
        $tasks_arr = [];
        // 我负责的
        $personnel_data = db::select('task_id')
            ->from('#PB#_personnel')
            ->where('user_id', cls_auth::$user->fields['admin_id'])
            ->where('status', 1)
            ->where('delete_user', '0')
            ->distinct(TRUE)
            ->execute();

        if (!empty($personnel_data))
        {
            foreach ($personnel_data as $row)
            {
                $tasks_arr[] = $row['task_id'];
            }
        }
        else
        {
            cls_msgbox::show('系统提示', "任务主要负责人已经被指派，请刷新后再查阅", '?ct=responsible&ac=index', 3000);
        }
        // 主任务验证方式
        if ($tasks_data['parent_id'] == 0)
        {
            if (!in_array($id, $tasks_arr))
            {
                cls_msgbox::show('系统提示', "任务主要负责人已经被指派，请刷新后再查阅", '?ct=responsible&ac=index', 3000);
            }
        }

    }

    /**
     * 我发布的任务 是否在范围内
     */
    public static function poster_is_allow_user()
    {
        $id   = req::item('id', 0, 'int');
        $data = db::select("count(*) as total ")
            ->from('#PB#_tasks')
            ->where('id', $id)
            ->and_where('create_user', cls_auth::$user->fields['admin_id'])
            ->as_row()
            ->execute();
        if ($data['total'] == 0)
        {
            cls_msgbox::show('系统提示', "任务不存在列表里面", '?ct=poster&ac=index', 3000);
        }
    }

    public static function partake_is_allow_user()
    {
        $id         = req::item('id', 0, 'int');
        $tasks_data = db::select('parent_id,master_id')->from('#PB#_tasks')->where('id', $id)->as_row()->execute();
        if (empty($tasks_data))
        {
            cls_msgbox::show('系统提示', "任务参与人员已经被指派，请刷新后再查阅", '?ct=partake&ac=index', 3000);
        }

        // 我参与的
        $personnel_data = db::select('task_id')
            ->from('#PB#_personnel')
            ->where('user_id', cls_auth::$user->fields['admin_id'])
            ->where('p_type', '=', '2')
            ->where('delete_user', '0')
            ->distinct(TRUE)
            ->execute();
        $tasks_arr      = [];
        if (!empty($personnel_data))
        {
            foreach ($personnel_data as $row)
            {
                $tasks_arr[] = $row['task_id'];
            }
        }
        else
        {
            cls_msgbox::show('系统提示', "任务参与人员已经被指派，请刷新后再查阅", '?ct=partake&ac=index', 3000);
        }

        if ($tasks_data['parent_id'] == 0)
        {
            if (!in_array($id, $tasks_arr))
            {
                cls_msgbox::show('系统提示', "任务参与人员已经被指派，请刷新后再查阅", '?ct=partake&ac=index', 3000);
            }
        }

    }

    public static function copyer_is_allow_user()
    {
        $id         = req::item('id', '0', 'int');
        $tasks_data = db::select('parent_id,master_id')->from('#PB#_tasks')->where('id', $id)->as_row()->execute();
        if (empty($tasks_data))
        {
            cls_msgbox::show('系统提示', "任务抄送人员已经被指派，请刷新后再查阅", '?ct=copyer&ac=index', 3000);
        }
        // 抄送者
        $personnel_data = db::select('task_id')
            ->from('#PB#_personnel')
            ->where('user_id', cls_auth::$user->fields['admin_id'])
            ->where('delete_user', '0')
            ->where('p_type', '3')
            ->distinct(TRUE)
            ->execute();

        $tasks_arr = [];
        if (!empty($personnel_data))
        {
            foreach ($personnel_data as $row)
            {
                $tasks_arr[] = $row['task_id'];
            }
        }
        else
        {
            cls_msgbox::show('系统提示', "任务抄送人员已经被指派，请刷新后再查阅", '?ct=copyer&ac=index', 3000);
        }
        if ($tasks_data['parent_id'] == 0)
        {
            if (!in_array($id, $tasks_arr))
            {
                cls_msgbox::show('系统提示', "任务抄送人员已经被指派，请刷新后再查阅", '?ct=copyer&ac=index', 3000);
            }
        }
    }

}