<?php
if( !defined('PHPCALL') ) exit('Request Error!');



class mod_discuss
{
	private static $table_name = "#PB#_discuss";

	/**
	  * @function: 获取评论信息
	 * @param $sort 0:进展的评论 1:子任务的评论
	 *@param $sort_id :如果sort=0 ，则为进展的id,sort=1,则为子任务的id	
	*/
	public static function get_discuss(int $sort_id,int $sort,array &$discuss=null,array &$user_ids=null,int $parent_id=0)
	{
		$where[] = ["parent_id","=",$parent_id];
		$where[] = ["sort_id","=",$sort_id];
		// $where[] = ["sort","=",$sort];

		$infos = db::select("id,sort_id,parent_id,contents,create_user,create_time,type,relay_user")
				->from(self::$table_name)->where($where)->where("delete_user","0")->execute();

		if(empty($infos))
		{
			return true;
		}
		$discuss[]=$infos;
		if(!empty($user_ids))
		{
			foreach ($infos as $key => $value) 
			{
				$user_ids["member_ids"][] = $value["create_user"];
				$user_ids["member_ids"][] = $value["relay_user"];
				self::get_discuss($sort_id,$sort,$discuss,$user_ids,$value["id"]);
			}
		}else{
			foreach ($infos as $key => $value) 
			{
				self::get_discuss($sort_id,$sort,$discuss,$user_ids,$value["id"]);
			}
		}
	}
}