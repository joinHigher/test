<?php

/**
 * 任务类型
 *
 * Class mod_tasks_kinds
 */
class mod_tasks_kinds
{
    public static $table = '#PB#_tasks_kinds';
    public static $pk = 'id';

    /**
     * 取出所有任务紧急等级数据
     *
     * @return object
     */
    public static function get_all(string $filed)
    {
        return db::select($filed)->from(self::$table)->where('delete_user',0)->execute();
    }

    /**
     * 插入资料到 数据表 tasks_level
     *
     * @param array $data 栏位
     *
     * @return mixed
     */
    public static function insert_data($data)
    {
        list($insert_id, $rows_affected) = db::insert(self::$table)->set($data)->execute();
        return $insert_id;
    }

    /**
     *  根据条件取出一条数据
     * @param filed:需取出的字段，必填，不能为*
     * @param where:查询条件，数组，可为空 
    */
    public static function get_one(string $filed,array $where=null)
    {
        return db::select($filed)->from(self::$table)->where($where)->as_row()->execute();
    }

    /**
     * 更新 数据表 tasks_level
     *
     * @param array $data 栏位
     * @param int   $id   流水编号
     *
     * @return mixed
     */
    public static function update_data($data, $id)
    {
        return db::update(self::$table)->set($data)->where('id', $id)->execute();
    }

    /**
     * 删除 数据表 tasks_level
     *
     * @param int $id 编号
     *
     * @return mixed
     */
    public static function remove_at($id)
    {
        $data = [
            'delete_user' => cls_auth::$user->fields['admin_id'],
            'delete_time' => time()
        ];
        return db::update(self::$table)->set($data)->where('id', $id)->execute();
    }
}