/**
 * 弹窗插件
 */
;(function(){
    function _Popup(target,option){
        this.el = target;

        this.$uid = 0;
        this.$map = {};

        //记录状态
        this.status = {
            hasInit:false,
            hasFirstLoad:false
        }
        //配置项目
        this.$opt = {
            title:"弹窗",
            content: $(".popup-select-wrap")
        }

        //结果保存集合
        this.selectArr = [];
        $.extend(this.$opt,option);

        this.bind();
    }

    _Popup.prototype.getUid = function(){
        return this.$uid++;
    }
    _Popup.prototype.add = function(item){
        var uid = this.getUid();
        this.set(uid,item);
        return uid;
    }
    _Popup.prototype.set = function(id,item){
        item.uid = id;
        this.$map[id] = item;
    }

    _Popup.prototype.get = function(id){
        return this.$map[id];
    }

    _Popup.prototype.bind = function(){
        var self = this;
        var $origin = $(this.$opt.content).find('.origin');
        var $selected = $(this.$opt.content).find('.selected');
        //绑定触发元素
        $(this.el).on("click",function(){
            layer.open({
                type: 1,
                title: self.$opt.title,
                shade: 0.3,
                maxmin: true,
                shadeClose: false,
                area: ['780px','600px'],
                content: self.$opt.content,
                btn: ['保存', '关闭'],
                btnAlign: 'c',
                yes:function(index, layero){
                    //成功回调
                    typeof self.$opt.callback == 'function' && self.$opt.callback(self.selectArr);
                    //这里不需要修改，直接返回后清空
                    self.selectArr = [];
                    layer.close(index);
                },
                success: function () {
                    typeof self.$opt.load == 'function' && self.$opt.load({first:true},function(data){
                        var html = '';
                        //模拟数据
                        $.each(data,function(i,item){
                            var uid = self.add(item);
                            html += '<li >'+
                                '<a href="javascript:;" class="has-child" data-uid="'+uid+'" data-id="'+item.id+'" data-key="'+item.id+'" data-name="'+item.name+'"><i class="fa fa-plus-square-o"></i>'+item.name+'</a>'+
                                '<ul>';
                            var upper = {
                                organization: {
                                    id:item.id,
                                    name:item.name
                                }
                            }
                            upper = JSON.stringify(upper);
                            // if(item.child.length > 0){
                            //     var childStr = '';
                            //     $.each(item.child,function(i,sitem){
                            //         var suid = self.add(sitem);
                            //         var hasChild = sitem.is_sub == '0' ? 'load-empty' : '';
                            //         childStr += '<li class="item">'+
                            //             '<a href="javascript:;" data-upper=\''+upper+'\' class="has-child  ' + hasChild + '" data-id="'+sitem.id+'" data-type="'+sitem.type+'" data-key="' +item.id +','+ sitem.id+'" data-name="'+item.name+','+sitem.name+'"><i class="fa fa-plus-square-o"></i>'+sitem.name+'</a>'+
                            //             '<ul></ul></li>'
                            //     })
                            //     html += childStr;
                            // }
                            html +='</ul></li>'
                        });
                        $origin.html(html);
                        if(!self.status.hasInit){
                            //初始化操作
                            typeof self.$opt.init== 'function' && self.$opt.init(self.selectArr),leftCreate('',self.selectArr);
                            self.status.hasInit = true;
                        }
                    });
                   
                }
            });
        });

        //单选
        $origin.on("change",".check",function(){
            var _this = $(this),
                id = _this.val(),
                name= _this.closest('label').text().trim(),
                key = _this.data('key'),
                keyName = _this.data('name');
            var p =_this.closest("ul").children(".checkall").find("input");
            var pid = p.val();

            var siblings = _this.closest('li').siblings('.child');

            var upper = _this.data('upper');
            var sn = _this.data('sn')

            if(this.checked){
                objToArr(self.selectArr,name,id,key,keyName,upper,sn);
                var flag = true;
                siblings.each(function(){
                    if(!$(this).find('>label>input').is(':checked')){
                        flag = false;
                    }
                });
                p.prop('checked',flag);
            }else{
                arrRemove(self.selectArr,key);
                p.prop('checked',false);
            }
            leftCreate(this,self.selectArr);
        });

        //展开下级
        $origin.on("click",".has-child",open);

        //全选操作
        $origin.on('change',".checkall input",function(){
            
            var checkboxs = $(this).closest('li').siblings(".child").find('>label>.check');
            if(this.checked){
                checkboxs.each(function(i){
                    if($(this).attr('disabled')) return true;
                    if(!this.checked){
                        $(this).prop('checked',true).trigger('change');
                    }
                })
            }else{
                checkboxs.each(function(i){
                    if($(this).attr('disabled')) return true;
                    if(this.checked){
                        $(this).prop('checked',false).trigger('change');
                    }
                })
            }
            // leftCreate(this,self.selectArr);
        });

        //左侧删除
        $selected.on("click",".fa-close",function(){
            var _this = $(this);
            _this.parents("li").remove();
            var key = _this.closest('li').data('key');
            arrRemove(self.selectArr,key);
            $origin.find("input[data-key='"+key+"']").prop('checked',false).trigger('change');
        });

        function open(){
            var _this = $(this),_parent = _this.closest("li");
            var id = _this.data("id"),
                allName = _this.data('name'),
                key = _this.data('key');
                level=_this.data("level"),
                type=_this.data('type'),
                name = function(){
                    if(_this[0].tagName.toUpperCase == 'A'){
                        return $.trim(_this.text())
                    }else{
                        return $.trim(_this.parent().text());
                    }
                }()


            if(_parent.hasClass("open")){
                _parent.removeClass("open");
            }else{
                _parent.siblings("li").removeClass("open");
                _parent.addClass("open");

            }
            if(_this.hasClass('load-empty')){
                layer.msg('没有下级数据');
            }else if(!_this.hasClass('load-done')){
                typeof self.$opt.load == 'function' && self.$opt.load($(this).data(),function(data){
                    if(!data.length){
                        _this.addClass('load-empty');
                        layer.msg('没有下级数据');
                        return false;
                    }
                    var prevStr = '';
                    var html  = '';

                    var upper = _this.data('upper') || ''; 
                    if(upper){
                        switch(type){
                            case 'top':
                            case 'organization':
                                upper.organization = {
                                    id:id,
                                    name:name
                                }
                                break;
                            case 'department':
                                upper.department = {
                                    id:id,
                                    name:name
                                }
                                break;
                            case 'station':
                                upper.station = {
                                    id:id,
                                    name:name
                                }
                                break;
                        }

                        upper = JSON.stringify(upper);
                    }
                    
                    $.each(data,function(i,item){
                        var datatype = !!type ? ('data-'+ type +'="'+ id+":"+type+'"') : '';
                        if(item.type !== 'member'){
                            var hasChild = item.is_sub == '0' ? 'load-empty' : '';
                            html += '<li class="item">'+
                            '<a href="javascript:;" data-upper=\''+upper+'\' class="has-child ' + hasChild + '" data-type="'+item.type+'"  data-id="'+item.id+'" data-key="'+ key + ',' + item.id + '" data-name="'+ allName +',' + item.name + '"><i class="fa fa-plus-square-o"></i>'+item.name+'</a>'+
                            '<ul></ul></li>';
                        }else{
                            if(!prevStr) prevStr ='<li class="checkall"><label ><input type="checkbox">全选</label></li>'
                            html += '<li class="child"><label '+(item.disabled ? 'class="disabled"' : '') +'><input type="checkbox" ' + (item.disabled ? 'disabled="disabled" ' : '' ) + 'data-sn="'+item.sn+'" data-upper=\''+upper+'\'  data-id ="'+item.id+'" value="'+item.id+'" class="check"  data-key="'+ key + ',' + item.id + '" data-name="'+ allName +',' + item.name + '" >'+item.name+'</label></li>'
                        }
                    })
                    if(html){
                        _this.siblings("ul").html(prevStr + '' + html);

                        _this.addClass('load-done');
                        checkCheck(_this,allName);
                    }
                })
            }else{
                checkCheck(_this,allName);
            }
        }
        
        //判断是否以加入数组中
        function checkCheck(_this,allName){
            if(JSON.stringify(self.selectArr).indexOf(allName)!=-1){
                var checkboxs = _this.siblings("ul").find('[type=checkbox]');
                checkboxs.each(function(i){
                    if(!this.checked){
                        $(this).prop('checked',true);
                    }
                })
            }
        }
         //del
        function arrRemove(arr,key){
            //不能用id删除，有可能id相同
            var index = -1;
            arr.forEach(function(item,i){
                if(item.key == key) index = i;
            });
            if(index!=-1)
                arr.splice(index, 1)

        }
        //push
        function objToArr(arr,name,id,key,keyName,upper,sn){
            var obj = {};
            obj.id = id;
            obj.name = name;
            obj.key = key;
            obj.keyName = keyName;
            obj.upper = upper;
            obj.sn = sn;
            if(JSON.stringify(arr).indexOf(name)==-1) arr.push(obj);
        }
        //左侧
        function leftCreate(e,arr){
            var _this = $(e);
            var leftstr = "";
            $.each(arr,function(i,item){
                leftstr += '<li class="left-item" data-name="'+item.name+'" data-key="'+item.key+'" data-id="'+item.id+'"><span >'+item.name+'</span> <i class="fa fa-close"></i></li>'
            })

            $selected.find("ul").html(leftstr);
        }
    
    }

    $.fn.perPopup = function(option){
        return new _Popup(this,option);
    }

   
})();

function per_parseData(data,filterArr,cb){
    var arr = [];
    if(data.status == 0){
        var rs = data.data;
        
        //添加子机构
        rs.organization && rs.organization.forEach(function(item){
            item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'organization',
            },item))
        });

        //添加部门
        rs.department && rs.department.forEach(function(item){
            item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'department',
            },item))
        });

        //添加岗位
        rs.station && rs.station.forEach(function(item){
            item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'station',
            },item))
        });

        //添加人员
        rs.member && rs.member.forEach(function(item){
            if(filterArr.indexOf(item.id) !== -1){
                item.disabled = true;
            }
            item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'member',
            },item))
        });
        if(rs.top && !isNaN(rs.top.id)){
            var top = $.extend({
                    type:'top',
                    name : rs.top.short_name,
                    // child:[]
                },rs.top);
            !!top.short_name ? top.name = top.short_name : top.short_name = top.name;
                // top.child = arr;
                cb([top]);
        }else{
            cb(arr);
        }

    }else{
        layer.alert(data.message);
    }
}