var regFn = function(){
    $(".form-horizontal").Validform({
        tiptype:function(msg,o,cssctl){
            if(o.type==3){
                $(o.obj).addClass().parent("div").addClass("has-error");
                var str = '<span class="Validform_checktip Validform_wrong"><i class="fa fa-times-circle"></i> '+ msg+'</span>';
                $(o.obj).closest("div").children(".Validform_checktip").remove();
                $(o.obj).closest("div").append(str);
                $(o.obj).parents("div.form-group").find(".control-label").css("color","#ed5565");
            }else{
                $(o.obj).parents("div.form-group").find(".control-label").css("color","#1ab394");
                $(o.obj).closest("div").removeClass("has-error").addClass("has-success");
                if($(o.obj).attr("sucmsg")){
                    $(o.obj).closest("div").children(".Validform_checktip").addClass("Validform_right").html('<i class="fa fa-check-circle-o"></i> '+$(o.obj).attr("sucmsg"));
                }else{
                    $(o.obj).closest("div").children(".Validform_checktip").remove();
                }
            }
        },
        showAllError:true,
        datatype:{    //自定义方法
           
        }
    });
}