/**
 * 弹窗插件
 */
;(function(){
    function _Popup(target,option){
        this.el = target;

        this.$uid = 0;
        this.$map = {};

        //记录状态
        this.status = {
            hasInit:false,
            hasFirstLoad:false
        }
        //配置项目
        this.$opt = {
            title:"弹窗",
            content: $(".popup-select-wrap")
        }

        //结果保存集合
        window.selected = this.selectArr = [];
        $.extend(this.$opt,option);

        this.bind();
    }

    _Popup.prototype.getUid = function(){
        return this.$uid++;
    }
    _Popup.prototype.add = function(item){
        var uid = this.getUid();
        this.set(uid,item);
        return uid;
    }
    _Popup.prototype.set = function(id,item){
        item.uid = id;
        this.$map[id] = item;
    }

    _Popup.prototype.get = function(id){
        return this.$map[id];
    }

    _Popup.prototype.bind = function(){
        var self = this;
        var $origin = $(this.$opt.content).find('.origin');
        var $selected = $(this.$opt.content).find('.selected');
        //绑定触发元素
        $(this.el).on("click",function(){
            layer.open({
                type: 1,
                title: self.$opt.title,
                shade: 0.3,
                maxmin: true,
                shadeClose: false,
                area: ['780px','600px'],
                content: self.$opt.content,
                btn: ['保存', '关闭'],
                btnAlign: 'c',
                yes:function(index, layero){
                    //成功回调
                    var rs = [];
                    $.each(self.selectArr,function(i,id){
                        var item = self.get(id);
                        if(item) rs.push(item);
                    })
                    typeof self.$opt.callback == 'function' && self.$opt.callback(self,rs);
                    layer.close(index);
                },
                success: function () {
                    if(!self.status.hasInit){
                        //初始化操作
                        self.status.hasInit = true;
                        typeof self.$opt.init== 'function' && self.$opt.init(function(rs){
                            // var leftstr = '';
                            $.each(rs,function(i,item){
                                // leftstr += '<li class="left-item" data-match="'+ item.type + '_'+ item.match+'"><span>'+item.name+'</span> <i class="fa fa-close"></i></li>'
                                self.selectArr.push(self.add(item));
                            })
                            leftCreate();
                            // $selected.find("ul").html(leftstr);
                        
                        });
                        typeof self.$opt.load == 'function' && self.$opt.load({first:true},function(data){
                            var html = '';
                            // if(data && data.length){
                            //     html += '<li class="checkall"><label ><input type="checkbox">全选</label></li>'
                            // }
                            $.each(data,function(i,item){

                                var uid = self.add(item);
                                item.match = '' + item.id;

                                html += '<li class="item child" data-uid="'+uid+'">'+
                                '<label ><input type="hidden"  data-match="'+item.type + '_'+ item.match+'" class="check" value="'+item.id+'">'+item.name+'</label> ' +
                                '<a href="javascript:;" class="has-child2 '+(item.child ? "load-done" : "") +'">下级</a>'+
                                '<ul>';
                                
                                if(item.child && item.child.length > 0){
                                    var childStr = '<li class="checkall"><label ><input type="checkbox">全选</label></li>';
                                    $.each(item.child,function(i,sitem){

                                        var pitem = self.get(uid);
                                        sitem.match = pitem.match + '_' + sitem.id;
                                        sitem.parent = pitem;

                                        var cuid = self.add(sitem);
                                        childStr += '<li class="child" data-uid="'+cuid+'">'+
                                                    '<label ><input type="checkbox"  data-match="'+sitem.type + '_'+ sitem.match+'" class="check" value="'+sitem.id+'">'+sitem.name+'</label> '

                                        if(sitem.is_sub == '1'){
                                            childStr  += '<a href="javascript:;" class="has-child2">下级</a><ul></ul>';
                                        }
                                        childStr += '</li>';
                                    })
                                    html += childStr;
                                }
                                html +='</ul></li>'
                            });
                            $origin.html(html);
                            checkCheck($origin);
                            
                        });
                    }
                }
            });
        });

        //单选
        $origin.on("change",".check",function(e,ignoreCheckAll,ignoreRender){
            var _this = $(this),
                id = _this.val(),
                uid = _this.closest('li').data('uid');

            var p =_this.closest("ul").children(".checkall").find("input");
            var pid = p.val();

            var siblings = _this.closest('li').siblings('.child');

            if(this.checked){
                objToArr(uid);
                if(!ignoreCheckAll){
                    var flag = true;
                    siblings.each(function(){
                        if(!$(this).find('>label>input').is(':checked')){
                            flag = false;
                        }
                    });
                    p.prop('checked',flag);
                }
                
            }else{
                arrRemove(uid);
                p.prop('checked',false);
            }
            !ignoreRender && leftCreate();
        });

        //展开下级
        $origin.on("click",".has-child2",open);

        //全选操作
        $origin.on('change',".checkall input",function(){
            var checkboxs = $(this).closest('li').siblings(".child").find('>label>.check');
            if(this.checked){
                checkboxs.each(function(i){
                    if(!this.checked){
                        $(this).prop('checked',true).trigger('change',true);
                    }
                })
            }else{
                checkboxs.each(function(i){
                    if(this.checked){
                        $(this).prop('checked',false).trigger('change',true);
                    }
                })
            }
        });

        //左侧删除
        $selected.on("click",".fa-close",function(){
            var _this = $(this);
            _this.parents("li").remove();
            var uid = _this.closest('li').data('uid');
            var match = _this.closest('li').data('match');
            arrRemove(uid);
            $origin.find("[data-match='"+match+"']").prop('checked',false).trigger('change');
        });

        function open(){
            var _this = $(this),
                _parent = _this.closest("li"),
                uid = _parent.data('uid');
               

            if(_parent.hasClass("open")){
                _parent.removeClass("open");
            }else{
                _parent.siblings("li").removeClass("open");
                _parent.addClass("open");

            }
            if(_this.hasClass('load-empty')){
                layer.msg('没有下级数据');
            }else if(!_this.hasClass('load-done')){

                var uitem = self.get(uid);
                if(!uitem) return false;

                typeof self.$opt.load == 'function' && self.$opt.load(uitem,function(data){
                    if(!data.length){
                        _this.addClass('load-empty');
                        layer.msg('没有下级数据');
                        return false;
                    }
                    var prevStr = '';
                    var html  = '';
                    
                    $.each(data,function(i,item){
                        if(!prevStr) prevStr ='<li class="checkall"><label ><input type="checkbox">全选</label></li>'
                        item.parent = uitem;
                        item.match = uitem.match + '_' + item.id;
                        var cuid = self.add(item);
                        html += '<li class="child" data-uid="'+cuid+'">'+
                        '<label><input type="'+(item.type == 'organization' ? 'hidden' : 'checkbox')+'" class="check" value="'+item.id+'" data-match="'+item.type + '_'+ item.match+'">'+item.name+'</label> ';
                        if(item.type !== 'member' && item.is_sub == '1'){
                             html += '<a href="javascript:;" class="has-child2" >下级</a><ul></ul>';
                        }
                        html += '</li>';
                    })
                    if(html){
                        _this.siblings("ul").html(prevStr + '' + html);
                        _this.addClass('load-done');
                        checkCheck(_this.siblings('ul'));
                    }
                })
            }else{
                checkCheck(_this.siblings('ul'));
            }
        }
        
        //判断是否以加入数组中
        function checkCheck(_this){
            var li = $selected.find('ul>li');
            li.each(function(){
                var ck = _this.find('[type=checkbox][data-match="'+$(this).data('match')+'"]');
                if(ck.size()>0){
                    var uid = ck.closest('li').data('uid');
                    var ouid = $(this).data('uid');
                    $(this).attr('data-uid',uid);
                    arrRemove(ouid);
                    objToArr(uid);
                    ck.prop('checked',true).trigger('change',[false,true]);
                }
            })
        }
    
         //del
        function arrRemove(uid){
            //不能用id删除，有可能id相同
            var index = self.selectArr.indexOf(uid);
            if(index!=-1)
            self.selectArr.splice(index, 1)

        }
        //push
        function objToArr(uid){
            var item = self.get(uid);
            if(item.type == 'organization') return;
            var index = self.selectArr.indexOf(uid);
            if(index == -1 ) self.selectArr.push(uid);
        }
        //左侧
        function leftCreate(){
            var leftstr = "";
            $.each(self.selectArr,function(i,id){
                var item = self.get(id);
                leftstr += '<li class="left-item" data-uid="'+item.uid+'" data-match="'+ item.type + '_'+ item.match+'"><span>'+item.name+'</span> <i class="fa fa-close"></i></li>'
            })
            $selected.find("ul").html(leftstr);
        }
    }

    $.fn.taskPopup = function(option){
        return new _Popup(this,option);
    }
})();

function task_parseData(data,cb){
    var arr = [];
    if(data.status == 0){
        var rs = data.data;
        //添加子机构
        rs.organization && rs.organization.forEach(function(item){
            !!item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'organization',
            },item))
        });

        //添加部门
        rs.department && rs.department.forEach(function(item){
            !!item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'department',
            },item))
        });

        //添加岗位
        rs.station && rs.station.forEach(function(item){
            !!item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'station',
            },item))
        });

        //添加人员
        rs.member && rs.member.forEach(function(item){
            !!item.short_name ? item.name = item.short_name : item.short_name = item.name;
            arr.push($.extend({
                type:'member',
            },item))
        });
        if(rs.top && !isNaN(rs.top.id)){
            var top = $.extend({
                type:'top',
                // child:[]
            },rs.top);
            !!top.short_name ? top.name = top.short_name : top.short_name = top.name;
                // top.child = arr;
                cb([top]);
        }else{
            cb(arr);
        }

    }else{
        layer.alert(data.message);
    }
}