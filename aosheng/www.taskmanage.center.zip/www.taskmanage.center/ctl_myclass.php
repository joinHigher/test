<?php
/**
 * Created by PhpStorm.
 * User: kosbox
 * Date: 2018/5/2
 * Time: 下午4:05
 */

class ctl_myclass
{

}