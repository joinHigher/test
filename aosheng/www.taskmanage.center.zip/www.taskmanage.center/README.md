### 项目名
任务管理系统

### 测试环境

- 域名 

[www1.taskmanage.center](http://www1.taskmanage.center) 


- 自动部署

基于 gitlab-ci 实现，配置文件位于项目根目录：[.gitlab_ci.yml](http://www1.gitlab.center/ultron/www.taskmanage.center/blob/master/.gitlab-ci.yml) ，
目前规则是：提交到 master 分支则自动更新代码

- 查看 [执行日志](http://www1.gitlab.center/ultron/www.taskmanage.center/pipelines)


- 部署目录及配置

```
# 机器
ssh -p 25680 www@192.168.0.46 #密码www，可以sudo

# nginx配置
/etc/nginx/sites-enabled/www1.taskmanage.center.conf

# 代码目录
/data/web/www1.taskmanage.center/

```


