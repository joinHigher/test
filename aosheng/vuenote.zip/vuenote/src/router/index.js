import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

import index from '@/components/index'
import login from '@/components/login'
import register from '@/components/register'
import changePwd from '@/components/changePwd'

let router =  new VueRouter({
  routes: [
    {
      path: '/',
      name: 'index',
      component: index
    },
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/register',
      name: 'register',
      component: register
    },
    {
      path: '/changePwd',
      name: 'changePwd',
      component: changePwd
    }
  ]
});
export default router
