<template>
  <div class="container">
      <section class="part1" v-if="part3.currentWindowId === 3">
          <header class="center">
              <el-button-group>
                  <el-button type="primary" :class="{ active: part1.tab === 'Notebooks' }" @click="tabToggle('Notebooks')">Notebooks</el-button>
                  <el-button type="primary" :class="{ active: part1.tab === 'Tags' }" @click="tabToggle('Tags')">Tags</el-button>
              </el-button-group>
          </header>
          <article>
              <el-menu v-if="part1.tab==='Notebooks'" @open="handleOpen"
                       @close="handleClose" @select="selectMenu" :default-openeds="part1.defaultOpeneds">
                  <template v-for="(row, index) in notebooks">
                      <el-submenu :index="String(row.id)" class="submenu-style">
                          <template slot="title">
                              <span>{{ row.name }}</span>
                          </template>
                          <template v-for="(item, _index) in row.list">
                              <el-menu-item :index="String(item.id)" class="menu-item-style"
                                            :class="{active: item.id === part1.currentIndex}">
                                  <div class="left"
                                       v-if="item.id === 2 || item.id === 3 || item.id === 4 || item.id === 5 || item.id === 6">
                                      <i class="el-icon-fa-inbox" v-if="item.id ===2"></i>
                                      <i class="el-icon-fa-star-o" v-if="item.id ===3"></i>
                                      <i class="el-icon-fa-clock-o" v-if="item.id ===4"></i>
                                      <i class="el-icon-fa-trash-o" v-if="item.id ===5"></i>
                                      <i class="el-icon-fa-hdd-o" v-if="item.id ===6"></i>
                                      {{ item.name }}
                                      <input v-model="item.name" class="edit-name-input" v-if="item.isEdit">
                                  </div>
                                  <div class="left" v-else>
                                      <span v-if="!item.isEdit">{{ item.name }}</span>
                                      <input v-model="item.name" class="edit-name-input" v-if="item.isEdit" autofocus="true"
                                             v-on:keyup.13="saveMenuName(item)"
                                             v-on:blur="saveMenuName(item)">
                                  </div>
                                  <div class="right">
                                      <i class="el-icon-fa-trash-o" @click.stop="deleteMenuItem(index1, _index)"
                                         v-if="item.id !== 2 && item.id !== 3 && item.id !== 4 && item.id !== 5 && item.id !== 6"></i>
                                      <i class="el-icon-fa-pencil"  @click.stop="editMenuItem(item)"
                                         v-if="item.id !== 2 && item.id !== 3 && item.id !== 4 && item.id !== 5 && item.id !== 6"></i>
                                      {{ item.count }}
                                  </div>
                              </el-menu-item>
                          </template>
                      </el-submenu>
                  </template>
              </el-menu>

              <el-menu v-if="part1.tab==='Tags'" default-active="1001" v-bind:default-openeds="['1000']"
                       @open="handleOpen1" @close="handleClose1" @select="selectMenuTags">
                  <template v-for="(row, index) in tags">
                      <el-submenu :index="String(row.id)" class="submenu-style">
                          <template slot="title">
                              <span>{{ row.name }}</span>
                          </template>
                          <template v-for="(item, _index) in row.list">
                              <el-menu-item :index="String(item.id)" class="menu-item-style">
                                  <div class="left">
                                      {{ item.name }}
                                  </div>
                                  <div class="right">
                                      {{ item.count }}
                                  </div>
                              </el-menu-item>
                          </template>
                      </el-submenu>
                  </template>
              </el-menu>
          </article>
          <footer>
              <el-popover
                      ref="popover1"
                      placement="top"
                      width="80"
                      v-model="part1.newMenuVisible"
                      popper-class="pop-common-style">
                  <ul>
                      <li v-for="item in notebooks" v-if="item.id !== 1">
                          <a href="javascript:;" @click="newMenu(item)">{{ item.name }}</a>
                      </li>
                  </ul>
              </el-popover>
              <i class="el-icon-fa-plus" v-popover:popover1 v-if="part1.tab === 'Notebooks'"></i>
          </footer>
      </section>
      <section class="part2" v-if="part3.currentWindowId === 2 || part3.currentWindowId === 3">
          <header class="center">
              <i class="el-icon-fa-plus"></i>
              <span>
                  <el-popover
                          ref="popover3"
                          placement="bottom"
                          width="300"
                          v-model="part2.selectMenuVisible"
                          popper-class="pop-common-style select-menu-pop-style">
                      <div class="menu-list">
                          <menu-temp ref="menuRef"></menu-temp>
                      </div>
                      </el-popover>
                  <el-button type="text" v-popover:popover3>{{ part2.currentMenuName }}</el-button>
                  <i class="el-icon-fa-angle-down"></i>
              </span>
          </header>
          <article>
              <div class="sort">
                  <span>
                      <el-popover
                              ref="popover2"
                              placement="bottom"
                              width="100"
                              v-model="part2.sortVisible"
                              popper-class="pop-common-style">
                          <ul>
                              <li v-for="item in part2.sort.condition1" @click="selectCond(1,item)">
                                  <a href="javascript:;">
                                      <i class="el-icon-fa-check" v-if="item.id === part2.sortCon1"></i>
                                      <span>{{ item.name }}</span>
                                  </a>
                              </li>
                              <li class="line"></li>
                              <li v-for="item in part2.sort.condition2" @click="selectCond(2,item)">
                                  <a href="javascript:;">
                                      <i class="el-icon-fa-check" v-if="item.id === part2.sortCon2"></i>
                                      <span>{{ item.name }}</span>
                                  </a>
                              </li>
                          </ul>
                      </el-popover>
                      <el-button type="text" v-popover:popover2>Sort by Updated</el-button>
                      <i class="el-icon-fa-arrow-down"></i>
                      <i class="el-icon-fa-angle-down"></i>
                  </span>
              </div>
              <table width="100%" class="article-list">
                  <tbody>
                      <tr v-for="row in article" :class="{active: row.id === part2.currentIndex}"
                          @click="selectedArticle(row)">
                          <td>
                              <p>{{ row.title }}</p>
                              <p>
                                  <span>{{ row.time }}</span>
                                  <span v-show="row.tips" class="el-icon-fa-tag"></span>
                                  <span>{{ row.tips }}</span>
                              </p>
                          </td>
                      </tr>
                  </tbody>
              </table>
          </article>
          <footer>
              <el-input class="search-input" placeholder="Find by keyword,title or #tag" icon="search"
                      v-model="part2.searchKey"
                      :on-icon-click="handleIconClick">
              </el-input>
          </footer>
      </section>
      <section class="part3">
          <header>
              <div>
                  <el-popover
                          ref="popover4"
                          placement="bottom"
                          width="100"
                          v-model="part3.windowShow"
                          popper-class="pop-common-style">
                      <ul>
                          <li v-for="item in part3.windowType" @click="getCurrentWindowId(item)">
                              <a href="javascript:;">
                                  <i class="el-icon-fa-check" v-if="part3.currentWindowId == item.id"></i>
                                  <span>{{ item.name }}</span>
                              </a>
                          </li>
                      </ul>
                  </el-popover>
                  <el-button type="text" v-popover:popover4>
                      <i class="el-icon-fa-navicon"></i>
                      <i class="el-icon-fa-angle-down"></i>
                  </el-button>
              </div>
              <div>
                  <el-button-group>
                      <el-button type="primary" class="active">
                          <i class="el-icon-fa-pencil"></i>
                      </el-button>
                      <el-button type="primary">
                          <i class="el-icon-fa-eye"></i>
                      </el-button>
                      <el-button type="primary">
                          <i class="el-icon-fa-columns"></i>
                      </el-button>
                  </el-button-group>
              </div>
              <div>
                  <el-popover
                          ref="popover5"
                          placement="bottom"
                          width="100"
                          v-model="part3.langShow"
                          popper-class="pop-common-style">
                      <ul>
                          <li v-for="item in part3.langs" @click="getCurrentLang(item)">
                              <a href="javascript:;">
                                  <i class="el-icon-fa-check" v-if="part3.currentLang == item.id"></i>
                                  <span>{{ item.name }}</span>
                              </a>
                          </li>
                      </ul>
                  </el-popover>
                  <i class="el-icon-fa-language" v-popover:popover5></i>
                  <i class="el-icon-fa-search"></i>
                  <i class="el-icon-fa-user"></i>
                  <i class="el-icon-fa-power-off"></i>
              </div>
          </header>
          <article>
              <article>
                  <div class="set-tags-row">
                      <div>
                       <span class="sort" @click="openMoveBook">
                           <i class="el-icon-fa-book"></i>
                           inbox123
                           <i class="el-icon-fa-angle-down"></i>
                       </span>
                          <span class="el-icon-fa-tag"></span>
                          <input-tag :tags.sync="tagsArray"></input-tag>
                      </div>
                      <div class="time-set" :class="{active : part3.reminderTime !==''}">   <!--提醒时间-->
                          <el-popover
                                  ref="popover7"
                                  placement="bottom"
                                  width="270"
                                  v-model="part3.timeVisible"
                                  popper-class="pop-common-style">
                          <div class="reminder-box">
                              <reminder-temp ref="reminderRef" :params="part3.reminderTime"></reminder-temp>
                          </div>
                          </el-popover>
                          <span>{{ part3.reminderTime }}</span>
                          <span class="el-icon-fa-clock-o" v-popover:popover7 @click="openReminderSet"></span>
                      </div>
                  </div>
                  <div class="created-time">
                      <span>Created: 2014-9-12</span>
                      <span>Updated: 2015-9-12</span>
                  </div>
              </article>

          </article>
          <footer>
              <div>
                  <i class="el-icon-fa-angle-left" :class="{ active: part3.currentArrow === 0 }" @click="arrowClick(0)"></i>
                  <i class="el-icon-fa-angle-right" :class="{ active: part3.currentArrow === 1 }" @click="arrowClick(1)"></i>
              </div>
              <div>
                  <i class="el-icon-fa-star-o" v-if="!part3.showStar" @click="starClick(0)"></i>
                  <i class="el-icon-fa-star" v-if="part3.showStar" @click="starClick(1)"></i>
                  <i class="el-icon-fa-tv"></i>

                  <el-popover
                          ref="popover6"
                          placement="top"
                          width="160"
                          v-model="part3.moreListVisible"
                          popper-class="pop-common-style more-list-style">
                      <ul>
                          <li v-for="item in part3.moreList" @click="clickMoreItem(item)">
                              <a href="javascript:;">
                                  <span>{{ item.name }}</span>
                                  <span class="el-icon-fa-angle-right" v-if="item.id === 6 || item.id === 7 || item.id === 8"></span>
                              </a>
                          </li>
                      </ul>
                  </el-popover>
                  <i class="el-icon-fa-list" v-popover:popover6></i>
              </div>
          </footer>
      </section>

      <moveNotebook-temp ref="moveNotebookRef"></moveNotebook-temp>
  </div>
</template>

<script>
    import InputTag from 'vue-input-tag'
    import menuTemp from './tpl/menuTemp';
    import reminderTemp from './tpl/reminderTemp';
    import moveNotebookTemp from './tpl/moveNotebookTemp'

export default {
    components: {
        menuTemp,
        reminderTemp,
        InputTag,
        moveNotebookTemp,
    },

  data () {
  return {
      self: this,
      notebooks: "",
      tags: "",
      part1: {
          tab: "Notebooks",
          currentIndex: 2,
          newMenuVisible: false,
          defaultOpeneds: ['1'],
      },
      article: "",
      part2: {
          currentMenuName: "inbox",
          currentIndex: 1,
          searchKey: "",
          searchMenuId: "",
          sortVisible: false,
          sort: {
              condition1: [
                  {id: 0, name: 'title'},
                  {id: 1, name: 'date created'},
                  {id: 2, name: 'date updated'},
                  {id: 3, name: 'manually'},
              ],
              condition2: [
                  {id: 4, name: 'ascending'},
                  {id: 5, name: 'descending'}
              ]
          },
          sortCon1: 1,
          sortCon2: 4,
          selectMenuVisible: false,
      },
      part3: {
          windowShow: false,
          windowType: [
              {id: 1, name: 'Singe Pane'},
              {id: 2, name: 'Two Panes'},
              {id: 3, name: 'Three Panes'},
          ],
          currentWindowId: 3,
          langShow: false,
          langs: [
              {id: 1, name: "English"},
              {id: 2, name: "Chinese"},
          ],
          currentLang: 1,
          moreListVisible: false,
          moreList: [
              {id: 1, name: 'Open in the Window'},
              {id: 2, name: 'Show in Finder'},
              {id: 3, name: 'copy note link'},
              {id: 4, name: 'move to notebook...'},
              {id: 5, name: 'delete note'},
              {id: 6, name: 'copy note'},
              {id: 7, name: 'email note'},
              {id: 8, name: 'export note'},
              {id: 9, name: 'print note'}
          ],
          showStar: false,
          currentArrow: 1, // 0 - left,  1 - right
          reminderTime: '',
          timeVisible: false,
      },
      tagsArray: ['111', '333'],
  }
},
    created () {
        this.$eventHub.$on('selectMenuById', this.selectMenuById); 
        this.$eventHub.$on('selectReminderTime', this.selectReminderTime);
        this.$eventHub.$on('markedAsDone', this.markedAsDone);
        this.getMenu();
        this.getArticle();
    },

    // beforeDestroy () {
    //     this.$eventHub.off('selectMenuById', this.selectMenuById);
    // },

  methods: {
      tabToggle (tab) {
          this.part1.tab = tab;
      },

      getMenu () {
          this.$http.get('./static/menu.json').then( res => {
              if (res.body.code !== 0) {
                  alert("error");
                  return false;
              }
              this.notebooks = res.body.data.notebooks;
              this.tags = res.body.data.tags;
          });
      },

      getArticle () {
          this.$http.get('./static/article.json').then( res => {
              if (res.body.code !== 0) {
                  alert("error");
                  return false;
              }
              this.article = res.body.data;
              console.log(this.article);
          });
      },

      setDefaultOpensAndCurrentMenu (key) {
          //设置notebook菜单栏的默认打开项
          this.part1.defaultOpeneds.length = 0;
          this.part1.defaultOpeneds.push(String(key));

          //notebook菜单栏的打开后，将该菜单栏下的第一个元素设置为当前项，呈现灰色背景选中状态
          let list = this.notebooks;
          let currentId = '';
          for (let i=0; i<list.length; i++) {
              if ( Number(list[i].id) === Number(key) ) {
                  currentId = i;
                  console.log(i);
                  break;
              }
          }
          if ( list[currentId].list[0] ) {
              this.part1.currentIndex = list[currentId].list[0].id;
          }
          console.log(this.part1.currentIndex);
      },

      //notebooks项
      handleOpen (key, keyPath) {
          this.setDefaultOpensAndCurrentMenu(key);
      },
      handleClose (key, keyPath) {
          this.setDefaultOpensAndCurrentMenu(key);
      },

      selectMenu (key, keyPath) {
          this.part1.currentIndex = keyPath[0];
          this.part1.defaultOpeneds.length = 0;
          this.part1.defaultOpeneds.push(String(keyPath[0]));

          let list = this.notebooks;
          for (let i=0; i< list.length; i++) {
              let subList = list[i].list;
              for (let j=0; j< subList.length; j++) {
                  if ( Number(subList[j].id) === Number(keyPath[1]) ) {
                      this.part2.currentMenuName = subList[j].name;
                      break;
                  }
              }
          }

      },

      deleteMenuItem (index, _index) {
          console.log(this.notebooks[index1].list);
          this.notebooks[index1].list.splice(_index, 1);

      },

      editMenuItem (item) {
          item.isEdit = true;
      },

      saveMenuName (item) {
          item.isEdit = false;
      },

      // 新建菜单
      newMenu (item) {
          let list = item.list;
          let tempList = [];
          list.forEach(item => {
              tempList.push(item.id);
          });
          let maxId = Math.max(...tempList);
          let obj = {
              "name": "",
              "id": maxId + 1,
              "count": 0,
              "isEdit": true
          };
          this.part1.defaultOpeneds.length = 0;
          this.part1.defaultOpeneds.push(String(item.id));
          item.list.push(obj);
          this.part1.newMenuVisible = false;
      },


      // tags 项
      handleOpen1 (key, keyPath) {
          console.log("2  "+key);
      },
      handleClose1 (key, keyPath) {
          console.log("2  "+key);
      },

      selectMenuTags (key, keyPath) {
          console.log("2  "+key);
      },

      //part2
      selectedArticle (row) {
          this.part2.currentIndex = row.id;
      },

      handleIconClick (ev) {
          console.log(ev);
      },

      // 排序条件选择
      selectCond(type, item) {
          type === 1 ? this.part2.sortCon1 = item.id : this.part2.sortCon2 = item.id;
          this.part2.sortVisible = false;
      },
      //通过弹窗选择，获得需要查询菜单的id，在通过id调接口对文章进行搜索，res是菜单id
      selectMenuById (res) {
          this.part2.searchMenuId = res;
          this.part2.selectMenuVisible = false;
      },

      //part3
      getCurrentWindowId (item) {
          this.part3.currentWindowId = item.id;
          this.part3.windowShow = false;
      },

      getCurrentLang (item) {
          this.part3.currentLang = item.id;
          this.part3.langShow = false;
      },

      clickMoreItem (item) {
          console.log(item);
          if (item.id === 4) {
              this.$refs.moveNotebookRef.initPage();
          }
          this.part3.moreListVisible = false;
      },

      starClick (type) {
          console.log(type);
          type ? this.part3.showStar = false : this.part3.showStar = true;
      },
      arrowClick (type) {
          console.log(type);
          this.part3.currentArrow = type;
      },

      openReminderSet () {
          this.$refs.reminderRef.initPage();
      },

      selectReminderTime (res) {
          console.log("获得设置的时间"+ res);
          this.part3.reminderTime = res;
          this.part3.timeVisible = false;
      },

      markedAsDone () {
          this.part3.timeVisible = false;
      },

      openMoveBook () {
          this.$refs.moveNotebookRef.initPage();
      },

  }
}
</script>

<style lang="less">
    @import '../assets/css/index';

    //弹窗菜单选择样式
    .select-menu-pop-style {
        padding: 20px 0 0 0 !important;
        background: @colorf4;
        .search-input {
            margin-bottom: 20px;
        }
        .el-menu {
            background: @colorf4;
        }
        .submenu-style {
            padding: 0;
        };
        .el-submenu__title, .menu-item-style, .menu-item-style:hover {
            background: @colorf4;
            height: 32px !important;
            line-height: 30px !important;
            padding: 0 !important;
        }
        .menu-item-style {
            position: relative !important;
            span {
                margin-left: 40px;
            }
            i {
                position: absolute !important;
                top: 10px !important;
                left: 240px !important;
            }
            &:active, &:focus, &.is-active {
                background: #d4d4d4;
                color: @color6;
            }
        }
        & > .menu-list > div > .el-menu {
            height: 300px !important;
            overflow-y: auto !important;
        }
    }


</style>
