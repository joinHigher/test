<template>
    <div class="content center">
        <div class="add-reminder" v-if="addShow">
            <p class="title">Add reminder</p>
            <el-button size="lg" class="btn1" icon="date" @click="addReminder">Date added</el-button>
        </div>
        <div class="set-reminder" v-if="setShow">
            <p class="title">Remind me...</p>
            <el-button size="lg" class="btn1" @click="getTomorrow">Tomorrow</el-button>
            <el-button size="lg" class="btn1" @click="getAfterAWeek">After a week</el-button>
            <span class="current-time"> {{ currentTime }} </span>
            <calendar :value="calendar1.value"
                      :begin="calendar1.begin" :weeks="calendar1.weeks"
                      :months="calendar1.months" @select="calendar1.select"></calendar>
        </div>
        <div class="handel-reminder" v-if="handleShow">
            <el-button size="lg" class="btn1" @click="markedAsDone">Marked as done</el-button>
            <el-button size="lg" class="btn1" @click="clearReminder">Clear reminder</el-button>
            <el-button size="lg" class="btn1" @click="changeTime">Change time</el-button>
        </div>

    </div>
</template>

<script>
    import calendar from './calendar.vue';
    export default {
        components: {
            calendar
        },
        props: ["params"],
        data () {
            let that = this;
            return {
                self: this,
                addShow: true,
                setShow: false,
                handleShow: false,
                currentTime: '', // 当前时间
                tomorrow: '', // 明天
                afterAWeek: '', // 一周后
                calendar1: {
                    value: "", //默认日期
                    weeks: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                    begin: "",// 开始时间
                    months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
                             'September', 'October', 'November', 'December'],
                    select (value) {
                        let y = value[0];
                        let m = value[1] < 10 ? "0" + value[1] : value[1];
                        let d = value[2] < 10 ? "0" + value[2] : value[2];
                        let selectedTime = y + "-" + m + "-" + d;
                        let day = new Date(Date.parse(selectedTime.replace(/-/g, '/')));
                        let weekList = ["Sun", "Mon", "Tues", "Wed", "Thur", "Fri", "Sat"];
                        let week = weekList[day.getDay()];
                        let res = selectedTime + ' ' + week;
                        that.$eventHub.$emit("selectReminderTime", res);
                    }
                },

            }
        },
        created () {

        },

        methods: {
            initPage () {
                if (this.params) {
                    this.handleShow = true;
                    this.addShow = false;
                    this.setShow = false;
                } else {
                    this.addShow = true;
                    this.setShow = false;
                    this.handleShow = false;
                }
            },

            addReminder () {
                this.addShow = false;
                this.setShow = true;
                let res = this.getCurrentTime();
                this.currentTime = res.format1;
                this.calendar1.value = res.format2;
                this.calendar1.begin = res.format2;
            },

            getCurrentTime () {
                let current = new Date();
                let year = current.getFullYear();
                let month = current.getMonth() + 1;
                let day = current.getDate();
                let h = current.getHours();
                let m = current.getMinutes();
                let s = current.getSeconds();
                let format1 = "";
                let format2 = [];
                if (month < 10) {
                    month = "0" + month;
                }
                if (day < 10) {
                    day = "0"  + day;
                }
                if (h < 10) {
                    h = "0"  + h;
                }
                if (m < 10) {
                    m = "0"  + m;
                }
                if (s < 10) {
                    s = "0"  + s;
                }
                format1 = year + "-" + month + "-" + day  + " " + h + ":" + m + ":" + s;
                format2 = [year, month, day];
                let res = {
                    format1: format1,
                    format2: format2
                };
                return res;
            },

            //时间计算方法
            countTime (t) {
                let current = Math.round(new Date().getTime()/1000);
                let target = current + t ;
                let timeTemp = new Date(target * 1000);
                let year = timeTemp.getFullYear();
                let month = timeTemp.getMonth() + 1;
                let day = timeTemp.getDate();
                let w = timeTemp.getDay();
                if (month < 10) {
                    month = "0" + month;
                }
                if (day < 10) {
                    day = "0" + day;
                }
                let selectedTime = year + "-" + month + "-" + day;
                let weekList = ["Sun", "Mon", "Tues", "Wed", "Thur", "Fri", "Sat"];
                let week = weekList[w];
                let res = selectedTime + ' ' + week;
                return res;
            },

            getTomorrow () {
                this.tomorrow = this.countTime(86400);
                this.$eventHub.$emit('selectReminderTime', this.tomorrow);
            },

            getAfterAWeek () {
                this.afterAWeek = this.countTime(86400 * 7);
                this.$eventHub.$emit('selectReminderTime', this.afterAWeek);
            },

            markedAsDone () {
                console.log("标记为已读");
                this.$eventHub.$emit('markedAsDone');
            },

            clearReminder () {
                this.$eventHub.$emit('selectReminderTime', '');
            },

            changeTime () {
                this.addShow = false;
                this.setShow = true;
                this.handleShow = false;
            },
        }
    }
</script>

<style lang="less" scoped>
    @import '../../assets/css/index';
    // 重写btn1样式
    .btn1 {
        width: 226px;
        height: 30px;
        margin-bottom: 15px;
        font-size: 12px;
        background: @colorf;
        color: @colorm;
        &:hover {
            background: @colorf;
            color: @colorm;
        }
        &:active, &:focus {
            background: @colorm;
            color: @colorf;
        }
    }

    .title {
        margin-bottom: 20px;
        color: @color9;
        font-size: 14px;
    }

    .content {
        padding: 20px 10px 0 10px;
    }

    .set-reminder {
        button {
            margin: 0 0 15px !important;
        }
        .current-time {
            display: inline-block;
            margin-bottom: 15px;
            width: 226px;
            height: 30px;
            line-height: 30px;
            background: #f0f0f0;
            color: #000;
        }
    }
</style>