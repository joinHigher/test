<template>
    <div>
        <el-input class="search-input" placeholder="Find by keyword,title or #tag" icon="search"
                  v-model="searchKey"
                  :on-icon-click="handleIconClick">
        </el-input>
        <el-menu @open="handleOpen" @close="handleClose" @select="selectMenu">
            <template v-for="(row, index) in menu">
                <el-submenu :index="String(row.id)" class="submenu-style">
                    <template slot="title">
                        <span>{{ row.name }}</span>
                    </template>
                    <template v-for="(item, _index) in row.list">
                        <el-menu-item :index="String(item.id)" class="menu-item-style">
                            <span class="menu-name">{{ item.name }}</span>
                            <i class="el-icon-fa-check" v-if="Number(item.id) === Number(selectedMenu)"></i>
                        </el-menu-item>
                    </template>
                </el-submenu>
            </template>
        </el-menu>
    </div>
</template>

<script>
    export default {
        data () {
            return {
                self: this,
                menu: this.notebooks,
                searchKey: '',
                selectedMenu: '',
            }
        },
        created () {
            this.getMenu();

        },
        methods: {
            getMenu () {
                this.$http.get('../../static/menu.json').then( res => {
                    if (res.body.code !== 0) {
                        alert("error");
                        return false;
                    }
                    this.menu = res.body.data.notebooks;
                    console.log(this.menu);
                });
            },

            handleOpen (key, keyPath) {

            },

            handleClose (key, keyPath) {

            },

            selectMenu (key, keyPath) {
                console.log(key);
                this.selectedMenu = key;
                this.$eventHub.$emit('selectMenuById', this.selectedMenu);
            },
            handleIconClick () {

            },

        }
    }
</script>

<style lang="less">

</style>