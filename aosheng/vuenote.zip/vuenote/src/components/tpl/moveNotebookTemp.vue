<template>
    <div class="move-to-notebook pop-common-style select-menu-pop-style" :class="{ showComponent : isShow }">
        <h4>Move to Notebook</h4>
        <el-input class="search-input" placeholder="Find by keyword,title or #tag" icon="search"
                  v-model="searchKey"
                  :on-icon-click="handleIconClick">
        </el-input>
        <el-menu @open="handleOpen" @close="handleClose" @select="selectMenu">
            <template v-for="(row, index) in menu">
                <el-submenu :index="String(row.id)" class="submenu-style">
                    <template slot="title">
                        <span>{{ row.name }}</span>
                    </template>
                    <template v-for="(item, _index) in row.list">
                        <el-menu-item :index="String(item.id)" class="menu-item-style">
                            <span class="menu-name">{{ item.name }}</span>
                            <i class="el-icon-fa-check" v-if="Number(item.id) === Number(selectedMenu)"></i>
                        </el-menu-item>
                    </template>
                </el-submenu>
            </template>
        </el-menu>
        <div class="footer">
            <el-button size="small" type="danger" @click="popClose">Cancel</el-button>
            <el-button size="small" type="success" @click="move">Move</el-button>
        </div>
    </div>
</template>

<script>
    export default {
        data () {
            return {
                self: this,
                isShow: false,
                menu: this.notebooks,
                searchKey: '',
                selectedMenu: '',
            }
        },
        created () {
            this.getMenu();

        },
        computed: {

        },
        methods: {
            initPage () {
                this.isShow = true;
            },

            popClose () {
                this.isShow = false;
            },

            move () {
                console.log("move");
                this.isShow = false;
            },

            getMenu () {
                this.$http.get('../../static/menu.json').then( res => {
                    if (res.body.code !== 0) {
                        alert("error");
                        return false;
                    }
                    this.menu = res.body.data.notebooks;
                    console.log(this.menu);
                });
            },

            handleOpen (key, keyPath) {

            },

            handleClose (key, keyPath) {

            },

            selectMenu (key, keyPath) {
                console.log(key);
                this.selectedMenu = key;
                this.$eventHub.$emit('selectMenuById', this.selectedMenu);
            },
            handleIconClick () {

            },

        },
    }
</script>


<style lang="less" scoped>
    .move-to-notebook {
        position: absolute;
        top: -600px;
        left: 40%;
        width: 300px;
        transition: top .3s ease-out;
        background: #f4f5f9;
        box-shadow: 0 0 6px rgba(0,0,0,.3);
        border-radius: 5px;
        h4 {
            font-size: 14px;
            color: #333;
            text-align: center;
            margin-bottom: 10px;
        }
        & > .el-menu {
              height: 300px !important;
              overflow-y: auto !important;
          }
        .footer {
            text-align: right;
            padding: 10px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            .el-button--danger {
                color: #333;
                background-color: #fff;
                border-color: #adadad;
                &:hover, &:active, &:focus {
                    background: #e6e6e6;
                }
            }
            .el-button--success {
                color: #fff;
                background-color: #337ab7;
                border-color: #2e6da4;
                &:hover, &:active, &:focus {
                    background: #286090;
                }
            }
        }
    }

    .showComponent {
        top: 10px;
    }
</style>