<template>
    <div>
        <el-button type="success">hello</el-button>
    </div>
</template>

<script>
    export default {
        data () {
            return {

            }
        },
        created () {

        },
        methods () {


        },

    }
</script>