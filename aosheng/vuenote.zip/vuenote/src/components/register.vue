<template>
    <div class="form">
        <header class="header mb100"></header>
        <h4 class="mb40">Create an account</h4>
        <el-form ref="form" :model="form" label-width="120px">
            <el-form-item label="Name:" class="mb30">
                <el-input v-model="form.name" placeholder="Your full name"></el-input>
            </el-form-item>
            <el-form-item label="Email address:" class="mb30">
                <el-input v-model="form.email" placeholder="name@company.com"></el-input>
            </el-form-item>
            <el-form-item label="Password:" class="mb30">
                <el-input type="password" v-model="form.password" placeholder="Password (at least 6 characters)"></el-input>
            </el-form-item>
            <el-form-item label=" " class="mb30">
                <el-button size="lg" class="btn1" @click="createAccount">Create your account</el-button>
            </el-form-item>
            <el-form-item label=" ">
                <div>
                    <el-button type="text" class="left btn2">Already have an account?</el-button>
                    <el-button type="text" class="left btn2" @click="toSignIn">sign in</el-button>
                </div>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>

    export default {

        data () {
            return {
                self: this,
                form: {
                    name: '',
                    email: '',
                    password: '',
                }
            }
        },
        methods: {

            createAccount () {
                alert("createAccount");

            },

            toSignIn () {
                this.$router.push({ name: "login" });
            }
        }
    }
</script>

<style lang="less" scoped>
    @import "../assets/css/form.less";

</style>
