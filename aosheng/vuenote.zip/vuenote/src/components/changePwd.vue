<template>
    <div class="form">
        <header class="header mb100"></header>
        <h4 class="mb40">Change Password</h4>
        <el-form ref="form" :model="form" label-width="135px">
            <el-form-item label="Old password:" class="mb30">
                <el-input type="password" v-model="form.password" placeholder=""></el-input>
            </el-form-item>
            <el-form-item label="New password:" class="mb30">
                <el-input type="password" v-model="form.newPassword" placeholder=""></el-input>
            </el-form-item>
            <el-form-item label="Confirm password:" class="mb30">
                <el-input type="password" v-model="form.chkPassword" placeholder=""></el-input>
            </el-form-item>
            <el-form-item label=" " class="mb30">
                <el-button size="lg" class="btn1" @click="submit">submit</el-button>
            </el-form-item>
            <el-form-item label=" ">
                <div>
                    <el-button type="text" class="left btn2" @click="toHome">Return to home page</el-button>
                </div>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>

    export default {

        data () {
            return {
                self: this,
                form: {
                    password: '',
                    newPassword: '',
                    chkPassword: '',
                }
            }
        },
        methods: {

            submit () {
                alert("change pwd submit");

            },

            toHome () {
                this.$router.push({ name: "index" });
            }
        }
    }
</script>

<style lang="less" scoped>
    @import "../assets/css/form.less";

</style>
