exports.install = function(Vue, options) {
    Vue.prototype.getSomeData = function(){
        return "11111111"
    };

}
