import Vue from 'vue'
import App from './App'
import router from './router'
import VueResource from 'vue-resource'

import Element from 'element-ui'
import Less from 'less'
import 'element-ui/lib/theme-default/index.css'
import './assets/css/common.less'
//import 'less/lib/less/index'

Vue.use(VueResource);
Vue.use(Element);
Vue.use(Less);

// 添加eventBus
Vue.prototype.$eventHub = Vue.prototype.$eventHub ||  new Vue();

Vue.config.productionTip = false;

Vue.prototype.GLOBAL= {
  //host: 'http://192.168.31.100:8080'
  //host: 'http://test.woaieat.com:8080'
}


// vue-resource options
Vue.http.options.emulateJSON = true;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
})
