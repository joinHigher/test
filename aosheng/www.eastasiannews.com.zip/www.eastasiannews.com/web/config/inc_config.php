<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 全局配置文件
 * 本文件为初始化时固定的配置，相关参数不可在后台直接调整
 *
 */

// 在线项目配置
if( file_exists(dirname(__FILE__).'/inc_config.online.php') )
{
    include dirname(__FILE__).'/inc_config.online.php';
    return;
}

if( file_exists(dirname(__FILE__).'/inc_config.dev.php') )
{
    include dirname(__FILE__).'/inc_config.dev.php';
    return;
}

// debug配置

//-------------------------------------------------------------
// 基本常量
//-------------------------------------------------------------
define('PATH_MODEL',    './model');
define('PATH_CONTROL',  './control');
define('PATH_ROOT',     PHPCALL);
define('PATH_LIBRARY',  PHPCALL . '/core/library');
define('PATH_CONFIG',   PHPCALL . '/config');
define('PATH_SHARE',    PHPCALL . '/share');
define('PATH_TEMPLATE', PHPCALL . '/templates');
define('PATH_UPLOADS',  PHPCALL . '/uploads');
define('PATH_DATA',     PHPCALL . '/data');
define('PATH_CACHE',    PATH_DATA . '/cache');

// 主应用URL
define('URL', 'http://www1.eastasiannews.com');
define('URL_UPLOADS', 'http://www1.eastasiannews.com/uploads');
define('URL_UPLOADS_CDN', 'http://uploads.bcdn.phpcall.org');
define('URL_API', 'http://www1.eastasiannews.com/api');
define('URL_H5', 'http://www1.eastasiannews.com/h5');
define('URL_WEBSOCKET', 'wss://wss.phpcall.org:9528');
define('WEBSOCKET_ADDR', '127.0.0.1');
define('WEBSOCKET_PORT', '9527');

// 开启调试模式
define('DEBUG_MODE', true);

// 全局禁用cache( cache::get 强制返回 false)
define('NO_CACHE', true);

//------------------------------------------------------------------------------------------
// 配置变量，或系统定义的全局性变量，建议都用 config 开头，在路由器中默认拦截这种变量名
//------------------------------------------------------------------------------------------

// 指定某些IP允许开启调试，数组格式为 array('ip1', 'ip2'...)
$GLOBALS['config']['safe_client_ip'] = array(
    '127.0.0.1',
    '101.1.18.36'
);

// 程序分析
$GLOBALS['config']['profiler'] = array(
    'benchmarks'         => true,
    'config'             => true,
    'controller_info'    => true,
    'http_headers'       => true,
    'uri_string'         => true,
    'get'                => true,
    'post'               => true,
    'cookie_data'        => true,
    'session_data'       => true,
    'memory_usage'       => true,
    'queries'            => true,
    'query_toggle_count' => 25,
);

//MySql配置
//slave数据库从库可以使用多个
$GLOBALS['config']['db'] = array(
    'enable'  => true,
    'user'    => 'ultron',
    'pass'    => 'c83854b',
    'name'    => 'asianews',
    'charset' => 'utf-8',
    'prefix'  => 'an',
    'host' => array(
        'master' => '192.168.0.45:25686',
        'slave'  => array('192.168.0.45:25686')
    ),
    'crypt_key' => '',
    'crypt_fields' => array(
        'an_member' => array(),
    ),
);


// cache配置(df_prifix建议按网站名分开,如mc_phpcall_ / mc_tuan_ 等)
// cache_type一般是memcache、redis，如无可用则用file，如有条件，用memcached
$GLOBALS['config']['cache'] = array(
    'enable'     => true,
    'prefix'     => 'mc_df_',
    'cache_type' => 'file',
    'cache_time' => 7200,
    'cache_name' => PATH_CACHE.'/cfc_data',
    'memcache' => array(
        'timeout' => 1,
        'servers' => array(
            array( 'host' => '127.0.0.1', 'port' => 11211, 'weight' => 1 ),
        )
    )
);

// Redis 配置 (这个在腾讯云的安全策略里面限制了外网不能访问了)
$GLOBALS['config']['redis'] = array(
    'prefix'  => 'mc_df_',
    'timeout' => 30,
    'host'    => '127.0.0.1',
    'port'    => 6379,
    'pass'    => 'foobared',
);

// 网站日志配置
// ERROR => 1, DEBUG => 2, WARNING => 3, INFO => 4
$GLOBALS['config']['log'] = array(
    'file_path' => PATH_DATA.'/log',
    'log_type'  => 'file',
    'log_threshold' => array(1, 2, 3, 4),
    'log_date_format' => 'Y-m-d H:i:s',
);

// session
$GLOBALS['config']['session'] = array(
    'session_type'   => 'file',  // session类型 default || file || mysql || memcache || redis
    'session_expire' => 86400,   // session 回收时间
);

// cookie
$GLOBALS['config']['cookie'] = array(
    'prefix'   => 'phpcall_',       // cookie前缀
    'pwd'      => 'VKghmkBjpipoX',  // cookie加密码，密码前缀
    'expire'   => 7200,             // cookie超时时间
    'path'     => '/',              // cookie路径
    'domain'   => '',               // 正式环境中如果要考虑二级域名问题的应该用 .xxx.com
    'secure'   => FALSE, 
    'httponly' => FALSE,
);

// 表单令牌,防止CSRF跨站请求伪造，防止表单重复提交
$GLOBALS['config']['csrf'] = array(
    'token_on'     => false,               // 是否开启令牌验证
    'token_name'   => 'csrf_token_name',  // 令牌验证的表单隐藏字段名称
    'token_reset'  => true,               // 令牌验证出错后是否重置令牌 默认为true
    'cookie_name'  => 'csrf_cookie_name', // 令牌存放的cookie名称
    'expire'       => 7200,               // 令牌过期时间
    'exclude_uris' => array(              // 不检查的url，通常是ajax的url
        'ct=oauth&ac=authorize'
        //'ct=index&ac=login'
    ),            
);

$GLOBALS['config']['validate'] = array(
    'image_code'  => true,
    'potato_code' => false,
);

// 发送Potato消息
$GLOBALS['config']['potato'] = array(
    'bot_token'  => '10000170:Krd0i9cCAevijCCPZ0BNJgEU',
    'text_tpl'   => array(
        'login' => '【系统】登陆验证码: {{code}} 验证码5分钟内有效。为了保障您的账号安全，请勿向他人泄漏验证码信息。',
    )
);

// 发送邮箱
$GLOBALS['config']['send_email'] = array(
    'host' => 'smtp.sina.cn',
    'user' => 'smtptester2@sina.cn',
    'pass' => 'test123456',
    'name' => '鼎盛互动',
    'html' => "
<p>亲爱的鼎盛互动用户{{username}}，您好！</p>
<p>您的验证码是: {{code}} <br/>
此验证码将用于验证身份，修改密码密保等。请勿将验证码透露给其他人。</p>
<p>本邮件由系统自动发送，请勿直接回复！<br/>
感谢您的访问，祝您使用愉快</p>
");

// 默认时区
$GLOBALS['config']['timezone_set'] = 'Asia/Shanghai';

// 默认编码
$GLOBALS['config']['charset'] = 'UTF-8';

// 全局xss过滤
$GLOBALS['config']['global_xss_filtering'] = true;

// 需处理的网址必须使用<{rewrite}><{/rewriet}>括起来
// 此项需要修改 PATH_DATA/rewrite.ini
$GLOBALS['config']['use_rewrite'] = false;

// 框架版本标识
$GLOBALS['config']['frame_name'] = 'phpcall';
$GLOBALS['config']['frame_ui']   = '2';
$GLOBALS['config']['frame_ver']  = '2.3';
