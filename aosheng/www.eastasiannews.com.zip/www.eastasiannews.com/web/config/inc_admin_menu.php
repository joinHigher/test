<xml>
    <!-- //这里的子菜单为隐性项目 -->
    <menu name='常用' class='fa fa-th-list'>
        <menu name='频道管理' ct='channel' ac='index' default='1' />
        <menu name='频道添加' ct='channel' ac='add' display='none' />
        <menu name='频道编辑' ct='channel' ac='edit' display='none' />
        <menu name='频道删除' ct='channel' ac='del' display='none'  />

        <menu name='新闻管理' class='fa fa-th-list'>
            <menu name='全部新闻' ct='news' ac='index' />
            <menu name='专题新闻' ct='news_special' ac='index' />
            <menu name='新闻排序' ct='news' ac='edit_batch' />
        </menu>

        <menu name='会员管理' class='fa fa-th-list'>
            <menu name='会员全部列表' ct='member' ac='index' />
            <menu name='会员正常列表' ct='member' ac='able_list' display='none' />
            <menu name='会员已禁用列表' ct='member' ac='disable_list' display='none' />
            <menu name='会员编辑' ct='member' ac='edit' display='none' />

            <menu name='等级管理' ct='member_level' ac='index' />
            <menu name='等级添加' ct='member_level' ac='add' display='none' />
            <menu name='等级编辑' ct='member_level' ac='edit' display='none' />
            <menu name='等级删除' ct='member_level' ac='del' display='none'  />
        </menu>

        <menu name='投诉反馈' class='fa fa-th-list'>
            <menu name='投诉管理' ct='member_complaint' ac='index' />
            <menu name='投诉待处理列表' ct='member_complaint' ac='pending_list' display='none' />
            <menu name='投诉已处理列表' ct='member_complaint' ac='pended_list' display='none' />

            <menu name='反馈管理' ct='member_feedback' ac='index' />
            <menu name='反馈待处理列表' ct='member_feedback' ac='pending_list' display='none' />
            <menu name='反馈已处理列表' ct='member_feedback' ac='pended_list' display='none' />
        </menu>
        <menu name='设置' class='fa fa-th-list'>
            <menu name='国家设置' ct='area' ac='index' />
            <menu name='新闻采集设置' ct='member_complaint' ac='pending_list' display='none' />

        </menu>
    </menu>
    <menu name='系统' class='fa fa-gear'>
        <menu name='用户管理' class='fa fa-user'>
            <menu name='用户组管理' ct='admin_group' ac='index' />
            <menu name='用户组添加' ct='admin_group' ac='add' display='none' />
            <menu name='用户组修改' ct='admin_group' ac='edit' display='none' />
            <menu name='用户组删除' ct='admin_group' ac='del'  display='none' />

            <menu name='用户管理' ct='admin' ac='index' />
            <menu name='用户添加' ct='admin' ac='add' display='none' />
            <menu name='用户修改' ct='admin' ac='edit' display='none' />
            <menu name='用户删除' ct='admin' ac='del' display='none' />

            <menu name='修改密码' ct='admin' ac='editpwd' />
            <menu name='我的权限' ct='admin' ac='mypurview' />
        </menu>
        <menu name='系统管理' class='fa fa-wrench'>
            <menu name='后台菜单配置' ct='system' ac='edit_menu' />

            <menu name='配置管理' ct='config' ac='index' />
            <menu name='配置添加' ct='config' ac='add' display='none'  />
            <menu name='配置修改' ct='config' ac='edit' display='none'  />
            <menu name='配置删除' ct='config' ac='del' display='none'  />

            <menu name='操作日志' ct='admin' ac='oplog' />
            <menu name='登录日志' ct='admin' ac='login_log' />
        </menu>
        <menu name='缓存管理' class='fa fa-cloud'>
            <menu name='缓存管理' ct='cache' ac='index' />
            <menu name='缓存删除' ct='cache' ac='del' display='none' />
            <menu name='缓存清理' ct='cache' ac='clear' display='none' />
            <menu name='Redis键值管理' ct='cache' ac='redis_keys' />
            <menu name='Redis服务器信息' ct='cache' ac='redis_info' />
        </menu>
        <menu name='文件管理' ct='filemanage' ac='index' class='fa fa-file' />
        <menu name='文件新增' ct='filemanage' ac='add' display='none' />
        <menu name='文件修改' ct='filemanage' ac='edit' display='none' />
        <menu name='文件删除' ct='filemanage' ac='del' display='none' />

        <menu name='计划任务管理' ct='crond' ac='index' class='fa fa-tasks' />
        <menu name='计划任务新增' ct='crond' ac='add' display='none'  />
        <menu name='计划任务修改' ct='crond' ac='edit' display='none'  />
        <menu name='计划任务删除' ct='crond' ac='del' display='none'  />
    </menu>
</xml>
