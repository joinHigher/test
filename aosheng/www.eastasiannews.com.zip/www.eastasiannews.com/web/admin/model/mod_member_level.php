<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员等级模块
 *
 * @version $Id$
 */
class mod_member_level
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_member_level';

    //表字段
    public static $field = array (
		'id',
		'name',
		'level',
		'status',
		'create_time',
		'create_user',
		'update_time',
		'update_user',
		'delete_time',
		'delete_user',
	);

    //状态
	public static $status_list = array(
		0 => '禁用',
		1 => '启用',
	);

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	public static function get_field($field = '', $is_contrary_field = false)
	{
		if(!is_array($field))
		{
			$field = explode(',', $field);
		}

		if(!empty($field) && $is_contrary_field === true)
		{
			return array_diff(self::$field, $field);
		}

		return empty($field) ? self::$field : $field;
	}

}
