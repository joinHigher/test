<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 新闻模块
 *
 * @version $Id$
 */
class mod_news
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_news';

    //表字段
    public static $field = array (
		'id',
		'country_ids',
		'channel_ids',
		'title',
		'describe',
		'cover_img',
		'video',
		'atlas',
		'level_id',
		'is_top',
		'is_hot',
		'is_main',
		'is_issue',
		'type',
		'label',
		'browse_total',
		'content',
		'publisher',
		'top_time',
		'recom_time',
		'issue_time',
		'create_time',
		'create_user',
		'update_time',
		'update_user',
		'delete_time',
		'delete_user',
	);

	//新闻类型
	public static $type_list = array(
		1 => '图文',
		2 => '视频',
		3 => '专题',
		4 => '图集',
	);

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	public static function get_field($field = '', $is_contrary_field = false)
	{
		if(!is_array($field))
		{
			$field = explode(',', $field);
		}

		if(!empty($field) && $is_contrary_field === true)
		{
			return array_diff(self::$field, $field);
		}

		return empty($field) ? self::$field : $field;
	}

	//判断新闻状态
	public static function new_status($is_issue, $delete_user)
	{
		$news_status = '';
		if($is_issue === 0)
		{
			$news_status = '草稿';
		}
		else
		{
			$news_status = '已发表';
		}
		if($delete_user != 0)
		{
			$news_status = '<span style="color: red;">已删除</span>';
		}

		return $news_status;
	}

}
