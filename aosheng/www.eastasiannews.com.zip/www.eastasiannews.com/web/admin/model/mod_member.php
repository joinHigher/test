<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员模块
 *
 * @version $Id$
 */
class mod_member
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_member';

    //表字段
    public static $field = array (
		'id',
		'level_id',
		'sex',
		'name',
		'nickname',
		'account',
		'password',
		'email',
		'status',
		'head_img',
		'reg_ip',
		'device',
		'profession',
		'interest',
		'login_time',
		'create_time',
		'create_user',
		'update_time',
		'update_user',
		'delete_time',
		'delete_user',
	);

    //状态
	public static $status_list = array(
		0 => '禁用',
		1 => '启用',
	);

	//性别
	public static $sex_list = array(
		0 => '未知',
		1 => '男',
		2 => '女',
	);

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	public static function get_field($field = '', $is_contrary_field = false)
	{
		if(!is_array($field))
		{
			$field = explode(',', $field);
		}

		if(!empty($field) && $is_contrary_field === true)
		{
			return array_diff(self::$field, $field);
		}

		return empty($field) ? self::$field : $field;
	}

}
