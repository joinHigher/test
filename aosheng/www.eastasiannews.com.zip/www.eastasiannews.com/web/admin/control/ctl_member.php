<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员管理
 *
 * @version $Id$
 */
class ctl_member
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
    }

	//全部列表
	public function index()
	{
		$this->_list(0);
	}

	//正常列表
	public function able_list()
	{
		$this->_list(1);
	}

	//禁用列表
	public function disable_list()
	{
		$this->_list(2);
	}

	//编辑用户
	public function edit()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$go_url = '?ct=member&ac=show&id='.$id.'&list_type='.req::item('list_type', 0, 'int');

		if (!empty(req::$posts))
		{
			$password = req::item('password');
			$level_id = req::item('level_id');
			$nickname = req::item('nickname');
			$sex = req::item('sex');
			$status = req::item('status');
			$interest = req::item('interest');
			$profession = req::item('profession');
			$email = req::item('email');

			if(!empty($nickname))
			{
				$row = db::select('count(*) AS `count`')->from(mod_member::$table_name)
					->where('nickname', $nickname)
					->where('id', '!=', $id)
					->as_row()
					->execute();

				if( $row['count'] )
				{
					cls_msgbox::show('系统提示', '该呢称已经存在！', '-1');
				}
			}

			if(!empty($email))
			{
				$row = db::select('count(*) AS `count`')->from(mod_member::$table_name)
					->where('email', $email)
					->where('id', '!=', $id)
					->as_row()
					->execute();

				if( $row['count'] )
				{
					cls_msgbox::show('系统提示', '该邮箱已经存在！', '-1');
				}
			}

			$update_data = array ();
			if(!empty($password)) $update_data['password'] = pub_mod_member::get_password($password);
			if(!empty($email)) $update_data['email'] = $email;
			$update_data['level_id'] = $level_id;
			$update_data['nickname'] = $nickname;
			$update_data['sex'] = $sex;
			$update_data['status'] = $status;
			$update_data['interest'] = $interest;
			$update_data['profession'] = $profession;
			$update_data['update_user'] = cls_auth::$user->fields['uid'];
			$update_data['update_time'] = time();

			db::update(mod_member::$table_name)->set($update_data)
				->where('id', $id)
				->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "会员修改 {$id}");

			cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $go_url);

		}
		else
		{
			$info = db::select(mod_member::get_field())->from(mod_member::$table_name)
				->where('id', '=', $id)
				->as_row()
				->execute();

			tpl::assign('info', $info);
			tpl::assign('sex_list', mod_member::$sex_list);
			tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
			tpl::assign('list_type', req::item('list_type', 0, 'int'));
			tpl::assign('go_url', $go_url);
			tpl::display('member.edit.tpl');
		}
	}

	//查看
	public function show()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$info = db::select(mod_member::get_field())->from(mod_member::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		$info['level_name'] = db::select('name')->from(mod_member_level::$table_name)
			->where('id', '=', $info['level_id'])
			->as_field()
			->execute();

		tpl::assign('id', $id);
		tpl::assign('info', $info);
		tpl::assign('sex_list', mod_member::$sex_list);
		tpl::assign('list_type', req::item('list_type', 0, 'int'));
		tpl::assign('go_url', $this->_go_url());
		tpl::display('member.show.tpl');
	}

	//禁止登录
	public function disable_login()
	{
		$id = req::item('id', '0', 'int');
		$remark = req::item('remark');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$count = db::select('count(*) AS `count`')->from(mod_member::$table_name)
			->where('id', '=', $id)
			->as_field()
			->execute();
		if( $count == 0 )
		{
			cls_msgbox::show('系统提示', '会员不存在！', '-1');
		}

		$update_data = array ();
		$update_data['status'] = 0;
		$update_data['update_user'] = cls_auth::$user->fields['uid'];
		$update_data['update_time'] = time();

		db::update(mod_member::$table_name)->set($update_data)
			->where('id', $id)
			->execute();

		//添加惩罚记录
		$add_data = array ();
		$add_data['member_id'] = $id;
		$add_data['op_name'] = '禁止登录';
		$add_data['admin_name'] = cls_auth::$user->fields['username'];
		$add_data['remark'] = $remark;
		$add_data['update_time'] = $add_data['create_time'] = time();
		$add_data['create_user'] = cls_auth::$user->fields['uid'];

		list($insert_id, $rows_affected) = db::insert(mod_member_punish_log::$table_name)->set($add_data)->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "禁止用户登录 {$id}");

		$go_url = '?ct=member&ac=show&id='.$id.'&list_type='.req::item('list_type', 0, 'int');
		cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '禁止成功'), $go_url);

	}

	//恢复登录
	public function able_login()
	{
		$id = req::item('id', '0', 'int');
		$remark = req::item('remark');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$count = db::select('count(*) AS `count`')->from(mod_member::$table_name)
			->where('id', '=', $id)
			->as_field()
			->execute();
		if( $count == 0 )
		{
			cls_msgbox::show('系统提示', '会员不存在！', '-1');
		}

		$update_data = array ();
		$update_data['status'] = 1;
		$update_data['update_user'] = cls_auth::$user->fields['uid'];
		$update_data['update_time'] = time();

		db::update(mod_member::$table_name)->set($update_data)
			->where('id', $id)
			->execute();

		//添加惩罚记录
		$add_data = array ();
		$add_data['member_id'] = $id;
		$add_data['op_name'] = '恢复登录';
		$add_data['admin_name'] = cls_auth::$user->fields['username'];
		$add_data['remark'] = $remark;
		$add_data['update_time'] = $add_data['create_time'] = time();
		$add_data['create_user'] = cls_auth::$user->fields['uid'];

		list($insert_id, $rows_affected) = db::insert(mod_member_punish_log::$table_name)->set($add_data)->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "禁止用户登录 {$id}");

		$go_url = '?ct=member&ac=show&id='.$id.'&list_type='.req::item('list_type', 0, 'int');
		cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '恢复成功'), $go_url);

	}

	//阅读记录
	public function read_log()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$field = array (
			mod_member_read_log::$table_name.'.member_id member_id',
			mod_member_read_log::$table_name.'.news_id news_id',
			mod_member_read_log::$table_name.'.read_start_time read_start_time',
			mod_member_read_log::$table_name.'.read_end_time read_end_time',
			mod_member_read_log::$table_name.'.create_time create_time',
			mod_news::$table_name.'.id id',
			mod_news::$table_name.'.title title',
			mod_news::$table_name.'.browse_total browse_total',
			mod_news::$table_name.'.type news_type',
		);

		$where = array ();
		$where[] = array (mod_member_read_log::$table_name.'.member_id', '=', $id);

		$count = db::select('COUNT(*) AS `count`')
			->from(mod_member_read_log::$table_name)
			->where($where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, req::item('page_size', 10));

		$list = db::select($field)
			->from(mod_member_read_log::$table_name)
			->join(mod_news::$table_name, 'LEFT')
			->on(mod_member_read_log::$table_name.'.news_id', '=', mod_news::$table_name.'.id')
			->where($where)
			->order_by(mod_member_read_log::$pk, 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		tpl::assign('id', $id);
		tpl::assign('pages', $pages['show']);
		tpl::assign('list', $list);
		tpl::assign('type_list', mod_news::$type_list);
		tpl::assign('list_type', req::item('list_type', 0, 'int'));
		tpl::assign('go_url', $this->_go_url());
		tpl::display('member.read_log.tpl');
	}

	//登录记录
	public function login_log()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$where = array ();
		$where[] = array ('member_id', '=', $id);

		$count = db::select('COUNT(*) AS `count`')
			->from(mod_member_login_log::$table_name)
			->where($where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, req::item('page_size', 10));

		$list = db::select(mod_member_login_log::get_field())
			->from(mod_member_login_log::$table_name)
			->where($where)
			->order_by(mod_member_login_log::$pk, 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		tpl::assign('id', $id);
		tpl::assign('pages', $pages['show']);
		tpl::assign('list', $list);
		tpl::assign('list_type', req::item('list_type', 0, 'int'));
		tpl::assign('go_url', $this->_go_url());
		tpl::display('member.login_log.tpl');
	}

	//惩罚记录
	public function punish_log()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择会员！', '-1');
		}

		$where = array ();
		$where[] = array ('member_id', '=', $id);

		$count = db::select('COUNT(*) AS `count`')
			->from(mod_member_punish_log::$table_name)
			->where($where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, req::item('page_size', 10));

		$list = db::select(mod_member_punish_log::get_field())
			->from(mod_member_punish_log::$table_name)
			->where($where)
			->order_by(mod_member_punish_log::$pk, 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		tpl::assign('id', $id);
		tpl::assign('pages', $pages['show']);
		tpl::assign('list', $list);
		tpl::assign('list_type', req::item('list_type', 0, 'int'));
		tpl::assign('go_url', $this->_go_url());
		tpl::display('member.punish_log.tpl');
	}

	//获取列表
    private function _list($list_type = 0)
    {

        $level_id = req::item('level_id');
        $status = req::item('status');
        $start_time = req::item('start_time');
        $end_time = req::item('end_time');
        $keyword = req::item('keyword', '');

        $where = array();

        if(is_numeric($level_id))
		{
			$where[] = array( 'level_id', '=', $level_id);
			$level_id = intval($level_id);
		}

		if(!empty($start_time))
		{
			$where[] = array( 'create_time', '>=', strtotime($start_time.' 00:00:00'));
		}

		if(!empty($end_time))
		{
			$where[] = array( 'create_time', '<=', strtotime($end_time.' 23:59:59'));
		}

		switch ($list_type)
		{
			//正常
			case 1:
				$where[] = array( 'status', '=', 1);
				break;
			//禁用
			case 2:
				$where[] = array( 'status', '=', 0);
				break;
			//全部
			default:
				if(is_numeric($status))
				{
					$where[] = array( 'status', '=', $status);
					$status = intval($status);
				}
				break;
		}

        if (!empty($keyword)) 
        {
            $where[] = array( 'name', 'like', "%$keyword%" );
        }

		$where[] = array( 'delete_user', '=', 0);

        $row = db::select('COUNT(*) AS `count`')
            ->from(mod_member::$table_name)
            ->where($where)
            ->as_row()
            ->execute();

        $pages = pub_page::make($row['count'], req::item('page_size', 10));

        $list = db::select(mod_member::get_field())
            ->from(mod_member::$table_name)
            ->where($where)
            ->order_by(mod_member::$pk, 'desc')
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();

        if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$list[$k]['head_img'] = empty($v['head_img']) ? '' : URL_UPLOADS . '/image/' . $v['head_img'];
			}
		}

		tpl::assign('level_id', $level_id);
		tpl::assign('status', $status);
		tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
		tpl::assign('status_list', mod_member::$status_list);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list_type', $list_type);
        tpl::display('member.index.tpl');
    }

	//返回url
	private function _go_url()
	{
		$list_type = req::item('list_type', 0, 'int');

		switch ($list_type)
		{
			//正常
			case 1:
				$go_url = '?ct=member&ac=able_list';
				break;
			//禁用
			case 2:
				$go_url = '?ct=member&ac=disable_list';
				break;
			//全部
			default:
				$go_url = '?ct=member&ac=index';
				break;
		}

		return $go_url;
	}
}
