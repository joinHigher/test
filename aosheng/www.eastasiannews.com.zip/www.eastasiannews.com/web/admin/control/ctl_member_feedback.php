<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员反馈管理
 *
 * @version $Id$
 */
class ctl_member_feedback
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
    }

	//全部列表
	public function index()
	{
		$this->_list(0);
	}

	//待处理列表
	public function pending_list()
	{
		$this->_list(1);
	}

	//已处理列表
	public function pended_list()
	{
		$this->_list(2);
	}

	//查看
	public function show()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择反馈！', '-1');
		}

		$info = db::select(mod_member_feedback::get_field())->from(mod_member_feedback::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		if(empty($info))
		{
			cls_msgbox::show('系统提示', '反馈消息不存在！', '-1');
		}

		if(!empty(req::$posts))
		{
			$reply = req::item('reply');

			if(empty($reply))
			{
				cls_msgbox::show('系统提示', '回复内容不能为空！', '-1');
			}

			$update_data = array ();
			$update_data['reply'] = $reply;
			$update_data['status'] = 1;
			$update_data['update_user'] = cls_auth::$user->fields['uid'];
			$update_data['update_time'] = time();

			db::update(mod_member_feedback::$table_name)->set($update_data)
				->where('id', $id)
				->execute();

			//添加反馈消息通知
			$add_data = array ();
			$add_data['member_id'] = $info['member_id'];
			$add_data['type'] = 2;
			$add_data['is_read'] = 0;
			$add_data['foreign_id'] = $id;
			$add_data['title'] = '帮助反馈';
			$add_data['describe'] = $info['content'];
			$add_data['remark'] = '';
			$add_data['create_time'] = cls_auth::$user->fields['uid'];
			$add_data['create_user'] = time();

			db::insert('#PB#_message')->set($add_data)->execute();


			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "反馈回复 {$id}");

			$gourl = '?ct=member_feedback&ac=show&id='.$id.'list_type='.req::item('list_type', 0, 'int');
			cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '回复成功'), $gourl);

		}
		else
		{

			//处理图片
			$img_list = array ();
			if(!empty($info['img']))
			{
				$img_list = explode(',', $info['img']);
				foreach ($img_list as $k => $v)
				{
					$img_list[$k] = URL_UPLOADS. '/image/' . $v;
				}
			}

			$info['img_list'] = $img_list;

			tpl::assign('id', $id);
			tpl::assign('info', $info);
			tpl::assign('list_type', req::item('list_type', 0, 'int'));
			tpl::assign('go_url', $this->_go_url());
			tpl::display('member_feedback.show.tpl');

		}
	}

	//查看图片
	public function show_img()
	{

		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择反馈！', '-1');
		}

		$img = db::select('img')->from(mod_member_feedback::$table_name)
			->where('id', '=', $id)
			->as_field()
			->execute();

		//处理图片
		$pics = array ();
		if(!empty($img))
		{
			$img_list = explode(',', $img);
			foreach ($img_list as $k => $v)
			{
				$pics[$k] = URL_UPLOADS. '/image/' . $v;
			}
		}

		tpl::assign('pics', $pics);
		tpl::display('modal.pics.view.tpl');
	}

	//获取列表
    private function _list($list_type = 0)
    {

        $status = req::item('status');
        $keyword = req::item('keyword', '');
		$start_time = req::item('start_time');
		$end_time = req::item('end_time');

        $where = array();

		switch ($list_type)
		{
			//待处理
			case 1:
				$where[] = array( 'status', '=', 0);
				break;
			//已处理
			case 2:
				$where[] = array( 'status', '=', 1);
				break;
			//全部
			default:
				if(is_numeric($status))
				{
					$where[] = array( 'status', '=', $status);
					$status = intval($status);
				}
				break;
		}

        if (!empty($keyword)) 
        {
            $where[] = array( 'member_name', 'like', "%$keyword%" );
        }

		if(!empty($start_time))
		{
			$where[] = array( 'create_time', '>=', strtotime($start_time.' 00:00:00'));
		}

		if(!empty($end_time))
		{
			$where[] = array( 'create_time', '<=', strtotime($end_time.' 23:59:59'));
		}

		$where[] = array( 'delete_user', '=', 0);

        $row = db::select('COUNT(*) AS `count`')
            ->from(mod_member_feedback::$table_name)
            ->where($where)
            ->as_row()
            ->execute();

        $pages = pub_page::make($row['count'], req::item('page_size', 10));

        $list = db::select(mod_member_feedback::get_field())
            ->from(mod_member_feedback::$table_name)
            ->where($where)
            ->order_by(mod_member_feedback::$pk, 'desc')
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();

		tpl::assign('status', $status);
		tpl::assign('status_list', mod_member_feedback::$status_list);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list_type', $list_type);
        tpl::display('member_feedback.index.tpl');
    }

	//返回url
	private function _go_url()
	{
		$list_type = req::item('list_type', 0, 'int');

		switch ($list_type)
		{
			//待处理列表
			case 1:
				$go_url = '?ct=member_feedback&ac=pending_list';
				break;
			//已处理列表
			case 2:
				$go_url = '?ct=member_feedback&ac=pended_list';
				break;
			//全部
			default:
				$go_url = '?ct=member_feedback&ac=index';
				break;
		}

		return $go_url;
	}
}
