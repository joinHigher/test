<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 用户等级管理
 *
 * @version $Id$
 */
class ctl_member_level
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {

    }

	//列表
    public function index()
    {
		$keyword = req::item('keyword', '');

		$where = array();

		$where[] = array('delete_user', '=', 0);
		if (!empty($keyword))
		{
			$where[] = array( 'name', 'like', "%$keyword%" );
		}

		$row = db::select('count(*) AS `count`')
			->from(mod_member_level::$table_name)
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], 10);

		$list = db::select(mod_member_level::get_field())->from(mod_member_level::$table_name)
			->where($where)
			->order_by(mod_member_level::$pk, 'asc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				switch ($v['status'])
				{
					case 1:
						$list[$k]['status_name'] = '<span style="color: red;">';
						break;

					case 0:
						$list[$k]['status_name'] = '<span style="color: green;">';
						break;
				}

				$list[$k]['status_name'] .= mod_member_level::$status_list[$v['status']];
			}
		}

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('member_level.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $id = req::item('id', '0', 'int');
            $name = req::item('name');

            if(empty($name))
			{
				cls_msgbox::show('系统提示', '等级名称不能为空！', '-1');
			}

            $row = db::select('count(*) AS `count`')
                ->from(mod_member_level::$table_name)
                ->or_where('id', $id)
                ->or_where('name', $name)
                ->as_row()
                ->execute();

            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '等级或者等级名称已经存在！', '-1');
            }

			$add_data = array ();
			$add_data['id'] = $id;
			$add_data['name'] = $name;
			$add_data['status'] = req::item('status', 0, 'int');
			$add_data['update_time'] = $add_data['create_time'] = time();
			$add_data['create_user'] = cls_auth::$user->fields['uid'];

            list($insert_id, $rows_affected) = db::insert(mod_member_level::$table_name)->set($add_data)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "会员等级添加 {$insert_id}");

            $gourl = '?ct=member_level&ac=index';
            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_add', '添加成功'), $gourl);
        }
        else 
        {
            tpl::display('member_level.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
            $name = req::item('name');

			if(empty($name))
			{
				cls_msgbox::show('系统提示', '等级名称不能为空！', '-1');
			}

            $row = db::select('count(*) AS `count`')->from(mod_member_level::$table_name)
                ->where('name', $name)
                ->where('id', '!=', $id)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '等级或者等级名称已经存在！', '-1');
            }

			$update_data = array ();
			$update_data['id'] = $id;
			$update_data['name'] = $name;
			$update_data['status'] = req::item('status', 0, 'int');
			$update_data['update_user'] = cls_auth::$user->fields['uid'];
			$update_data['update_time'] = time();

            db::update(mod_member_level::$table_name)->set($update_data)
            ->where('id', $id)
            ->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "会员等级修改 {$id}");

            $gourl = '?ct=member_level&ac=index';
            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $gourl);
        }
        else 
        {
            $info = db::select(mod_member_level::get_field())->from(mod_member_level::$table_name)->where('id', $id)->as_row()->execute();

            tpl::assign('info', $info);
            tpl::display('member_level.edit.tpl');
        }
    }

	//查看
	public function show()
	{
		$id = req::item("id", 0);

		$info = db::select(mod_member_level::get_field())->from(mod_member_level::$table_name)->where('id', $id)->as_row()->execute();

		if(empty($info))
		{
			cls_msgbox::show('系统提示', '请选择会员等级！', '-1');
		}

		//统计禁用会员
		$disable_total = db::select('count(*) AS `count`')
			->from(mod_member::$table_name)
			->where('level_id', '=', $info['id'])
			->where('status', '=', 0)
			->where('delete_user', '=', 0)
			->as_field()
			->execute();

		//统计启用会员
		$able_total = db::select('count(*) AS `count`')
			->from(mod_member::$table_name)
			->where('level_id', '=', $info['id'])
			->where('status', '=', 1)
			->where('delete_user', '=', 0)
			->as_field()
			->execute();

		tpl::assign('disable_total', $disable_total);
		tpl::assign('able_total', $able_total);
		tpl::assign('info', $info);
		tpl::display('member_level.show.tpl');
	}
}
