<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 演示控制器
 *
 * @version $Id$
 */
class ctl_demo
{
    /**
     * 主入口
     */
    public function index()
    {
		tpl::display('demo.index.tpl');
    }
}
