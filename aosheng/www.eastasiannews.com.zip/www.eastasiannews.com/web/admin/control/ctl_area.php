<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 地区设置管理
 *
 * @version $Id$
 */
class ctl_area
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {

    }

	//获取列表
	public function index()
	{
		$keyword = req::item('keyword', '');

		$where = array();

		$where[] = array('delete_user', '=', 0);
		if (!empty($keyword))
		{
			$where[] = array( 'name', 'like', "%$keyword%" );
		}

		$row = db::select('count(*) AS `count`')
			->from(mod_area::$table_name)
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], req::item('page_size', 10));

		$list = db::select(mod_area::get_field())->from(mod_area::$table_name)
			->where($where)
			->order_by('status', 'DESC')
			->order_by('sort', 'ASC')
            ->order_by(mod_area::$pk, 'asc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$list[$k]['news_total'] = db::select('COUNT(*) count')->from(mod_news::$table_name)
					->where('countrys', 'FIND_IN_SET', $v['id'])
					->where('delete_user', '=', 0)
					->as_field()
					->execute();

				$color = $v['status'] == 0 ? 'red' : 'green';
				$list[$k]['status_name'] = '<font color="'.$color.'">'. mod_area::$status_list[$v['status']] .'</span>';
				$color = $v['is_fix'] == 0 ? 'red' : 'green';
				$list[$k]['fix_name'] = '<font color="'.$color.'">'. mod_area::$bool_status[$v['is_fix']] .'</span>';
				$color = $v['is_default'] == 0 ? 'red' : 'green';
				$list[$k]['default_name'] = '<font color="'.$color.'">'. mod_area::$bool_status[$v['is_default']] .'</span>';
			}
		}

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('area.index.tpl');
	}

    public function add()
    {
        if (!empty(req::$posts)) 
        {
        	//验证表单
			$this->_validate();

            $name = req::item('name');

            $row = db::select('count(*) AS `count`')
                ->from(mod_area::$table_name)
                ->where('name', $name)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '国家名称已经存在！', '-1');
            }

            list($insert_id, $rows_affected) = db::insert(mod_area::$table_name)
                ->set(array(
                    'name'          => req::item('name'),
                    'en_name'       => req::item('en_name'),
                    'en_short_name' => req::item('en_short_name'),
                    'is_default'    => req::item('is_default', 0, 'int'),
                    'is_fix'        => req::item('is_fix', 0, 'int'),
                    'mobile_prefix' => req::item('mobile_prefix'),
                    'status'        => req::item('status', 0, 'int'),
                    'sort'          => req::item('sort', 0, 'int'),
                    'update_user'   => cls_auth::$user->fields['uid'],
                    'update_time'   => time()
                ))
                ->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "国家添加 {$insert_id}");

            $gourl = '?ct=area&ac=index';
            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_add', '添加成功'), $gourl);
        }
        else 
        {
            tpl::display('area.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
			//验证表单
			$this->_validate();

            $name = req::item("name", '');
            $row = db::select('count(*) AS `count`')->from(mod_area::$table_name)
                ->where('name', $name)
                ->where('id', '!=', $id)
                ->as_row()
                ->execute();

            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '国家已经存在！', '-1');
            }

            db::update(mod_area::$table_name)
                ->set(array(
                    'name'          => req::item('name'),
                    'en_name'       => req::item('en_name'),
                    'en_short_name' => req::item('en_short_name'),
                    'is_default'    => req::item('is_default', 0, 'int'),
                    'is_fix'        => req::item('is_fix', 0, 'int'),
                    'mobile_prefix' => req::item('mobile_prefix'),
                    'status'        => req::item('status', 0, 'int'),
                    'sort'          => req::item('sort', 0, 'int'),
                    'update_user'   => cls_auth::$user->fields['uid'],
                    'update_time'   => time()
                ))
                ->where('id', $id)
                ->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "国家修改 {$id}");

            $gourl = '?ct=area&ac=index';
            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $gourl);
        }
        else 
        {
            $info = db::select(mod_area::get_field())->from(mod_area::$table_name)->where('id', $id)->as_row()->execute();

            tpl::assign('info', $info);
            tpl::display('area.edit.tpl');
        }
    }

    public function del()
    {
        $id = req::item('id', 0, 'int');
        if (empty($id))
        {
            cls_msgbox::show('系统提示', "请选择要删除的国家", -1);
        }

		$del_data = array ();
		$del_data['delete_user'] = cls_auth::$user->fields['uid'];
		$del_data['delete_time'] = time();

		db::update(mod_area::$table_name)->set($del_data)
			->where('id', $id)
			->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "国家删除 ".$id);

        cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_delete', '删除成功'), $this->_go_url());
    }

	//表单验证
	private function _validate()
	{
		$config = array(
			array(
				'field' => 'name',
				'rules' => 'required',
				'errors' => array(
					'required' => '国家名称不能为空',
				),
			),
			/*
			array(
				'field' => 'en_name',
				'rules' => 'required',
				'errors' => array(
					'required' => '英文名称不能为空',
				),
			),
			*/
			array(
				'field' => 'en_short_name',
				'rules' => 'required',
				'errors' => array(
					'required' => '英文缩写不能为空',
				),
			),
			/*
			array(
				'field' => 'mobile_prefix',
				'rules' => 'required',
				'errors' => array(
					'required' => '电话前缀不能为空',
				),
			),
			*/
		);

		$instance = cls_validation::instance();
		$instance->set_rules($config);

		if ($instance->run() === FALSE)
		{
			$error = $instance->error();
			cls_msgbox::show('系统提示', $error, '-1');
		}

	}

}
