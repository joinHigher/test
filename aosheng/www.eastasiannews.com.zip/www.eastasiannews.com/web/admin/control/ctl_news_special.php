<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 专题新闻管理
 *
 * @version $Id$
 */
class ctl_news_special
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {

    }

	//全部列表
    public function index()
    {
		$this->_list(0);
    }

	//已发表列表
	public function publish_list()
	{
		$this->_list(1);
	}

	//草稿列表
	public function draft_list()
	{
		$this->_list(2);
	}

	//已删除列表
	public function del_list()
	{
		$this->_list(3);
	}

	//获取列表
	private function _list($list_type = 0)
	{
		$keyword = req::item('keyword', '');
		$level_id = req::item('level_id');
		$channel_id = req::item('channel_id');
		$start_time = req::item('start_time');
		$end_time = req::item('end_time');

		$where = array();
		$where[] = array('type', '=', 3);

		if(!empty($channel_id))
		{
			$where[] = array('channel_id', '=', $channel_id);
		}

		if(is_numeric($level_id))
		{
			$where[] = array('level_id', '=', $level_id);
			$level_id = intval($level_id);
		}

		if(!empty($start_time))
		{
			$where[] = array('issue_time', '>=', strtotime($start_time. ' 00:00:00'));
		}

		if(!empty($end_time))
		{
			$where[] = array('issue_time', '<=', strtotime($end_time. ' 23:59:59'));
		}

		switch ($list_type)
		{
			//全部
			case 0:

				break;
			//已发表
			case 1:
				$where[] = array('is_issue', '=', 1);
				$where[] = array('delete_user', '=', 0);
				break;
			//草稿
			case 2:
				$where[] = array('is_issue', '=', 0);
				$where[] = array('delete_user', '=', 0);
				break;
			//已删除
			case 3:
				$where[] = array('delete_user', '!=', 0);
				break;
		}

		if (!empty($keyword))
		{
			$where[] = array( 'title', 'like', "%$keyword%" );
		}

		$row = db::select('count(*) AS `count`')
			->from(mod_news::$table_name)
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], req::item('page_size', 10));

		$list = db::select(mod_news::get_field())->from(mod_news::$table_name)
			->where($where)
			->order_by('sort', 'desc')
			->order_by('issue_time', 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				//获取频道
				$channel_list = array ();
				if(!empty($v['channel_ids']))
				{
					$channel_list = db::select('id,name')->from(mod_channel::$table_name)
						->where('id', 'in', explode(',', $v['channel_ids']))
						->where('delete_user', '=', 0)
						->execute();
				}

				$list[$k]['channel_list'] = $channel_list;
				$list[$k]['cover_img'] = pub_mod_news::handle_img($v['cover_img']);

				//获取文章总数
				$new_total = db::select('SUM(news_total) as sum')
					->from(mod_special_section::$table_name)
					->where('special_id', '=', $v['id'])
					->where('delete_user', '=', 0)
					->as_field()
					->execute();
				$list[$k]['new_total'] = empty($new_total) ? 0 : $new_total;

				//新闻状态
				$list[$k]['news_status'] = mod_news::new_status($v['is_issue'], $v['delete_user']);
			}
		}

		tpl::assign('level_id', $level_id);
		tpl::assign('channel_id', $channel_id);
		tpl::assign('list_type', $list_type);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
		tpl::assign('channel_list', pub_mod_channel::get_all_list());
		tpl::display('news_special.index.tpl');
	}

	//添加
    public function add()
    {
        if (!empty(req::$posts)) 
        {
        	//验证
        	$this->_validate();

            $title = req::item('title', '');
			$publisher = req::item('publisher', '');
			$describe = req::item('describe', '');
			$cover_img = req::item('cover_img', array ());
			$channel_ids = req::item('channel_ids', array ());
			$is_top = req::item('is_top', '0', 'int');
			$level_id = req::item('level_id', '0', 'int');
            $country_ids = req::item('countrys', array ());
            $is_issue = req::item('is_issue', '0', 'int');
			$section_title = req::item('section_title');
			$section_news_ids = req::item('section_news_ids');

            $row = db::select('count(*) AS `count`')
                ->from(mod_news::$table_name)
                ->where('title','=' , $title)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '新闻标题已经存在！', '-1');
            }

			$add_data = array ();

			if(!empty($country_ids)) $add_data['countrys'] = implode(',', $country_ids);
			$add_data['channel_ids'] = implode(',', $channel_ids);
			$add_data['title'] = $title;
			$add_data['describe'] = $describe;
			$add_data['cover_img'] = implode(',', $cover_img);
			$add_data['level_id'] = $level_id;
			$add_data['is_top'] = $is_top;
			$add_data['is_issue'] = $is_issue;
			if($is_issue == 1) $add_data['issue_time'] = time();
			$add_data['type'] = 3;
			$add_data['browse_total'] = 0;
			$add_data['publisher'] = $publisher;
			$add_data['update_time'] = $add_data['create_time'] = time();
			$add_data['create_user'] = cls_auth::$user->fields['uid'];

            list($insert_id, $rows_affected) = db::insert(mod_news::$table_name)->set($add_data)->execute();

			if(!empty($insert_id))
			{
				//设置排序
				$update_data = array ();
				$update_data['sort'] = $insert_id;
				db::update(mod_news::$table_name)->set($update_data)
					->where('id', '=', $insert_id)
					->execute();

				//如果是添加新闻时，添加专题
				if(!empty($section_title))
				{
					foreach ($section_title as $k => $v)
					{
						$add_data = array ();
						$news_ids = isset($section_news_ids[$k]) ? array_unique(explode(',', $section_news_ids[$k])) : array ();
						$add_data['special_id'] = $insert_id;
						$add_data['title'] = $section_title[$k];
						$add_data['news_total'] = count($news_ids);
						$add_data['news_ids'] = empty($news_ids) ? 0 : implode(',', $news_ids);
						$add_data['update_time'] = $add_data['create_time'] = time();
						$add_data['create_user'] = cls_auth::$user->fields['uid'];

						db::insert(mod_special_section::$table_name)->set($add_data)->execute();
					}
				}
			}

			//转移图片文件
			pub_mod_news::move_file($cover_img);

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "专题新闻添加 {$insert_id}");

            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_add', '添加成功'), $this->_go_url());
        }
        else
        {
			tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
			tpl::assign('channel_list', pub_mod_channel::get_all_list());
			tpl::assign('area_list', pub_mod_area::get_all_list());
            tpl::assign('gourl', $this->_go_url());
            tpl::display('news_special.add.tpl');
        }
    }

	//编辑
    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts))
        {

			//验证
			$this->_validate();

			$title = req::item('title', '');
			$publisher = req::item('publisher', '');
			$describe = req::item('describe', '');
			$cover_img = req::item('cover_img', array ());
			$channel_ids = req::item('channel_ids', array ());
			$is_top = req::item('is_top', '0', 'int');
			$level_id = req::item('level_id', '0', 'int');
			$country_ids = req::item('countrys', array ());
			$is_issue = req::item('is_issue', '0', 'int');
			$section_title = req::item('section_title');
			$section_news_ids = req::item('section_news_ids');
			$section_id = req::item('section_id');

			$row = db::select('count(*) AS `count`')
				->from(mod_news::$table_name)
				->where('id','!=' , $id)
				->where('title','=' , $title)
				->as_row()
				->execute();
			if( $row['count'] )
			{
				cls_msgbox::show('系统提示', '新闻标题已经存在！', '-1');
			}

			$update_data = array ();
			if(!empty($country_ids)) $update_data['countrys'] = implode(',', $country_ids);
			$update_data['channel_ids'] = implode(',', $channel_ids);
			$update_data['title'] = $title;
			$update_data['describe'] = $describe;
			$update_data['cover_img'] = implode(',', $cover_img);
			$update_data['level_id'] = $level_id;
			$update_data['is_top'] = $is_top;
			$update_data['is_issue'] = $is_issue;
			if($is_issue == 1) $update_data['issue_time'] = time();
			$update_data['type'] = 3;
			$update_data['browse_total'] = 0;
			$update_data['publisher'] = $publisher;
			$update_data['update_user'] = cls_auth::$user->fields['uid'];
			$update_data['update_time'] = time();

            $result = db::update(mod_news::$table_name)->set($update_data)
            ->where('id', $id)
            ->execute();

			if(!empty($result))
			{
				//修改专题
				if(!empty($section_title))
				{
					//获取所有的专题ID
					$edit_section_ids = array ();
					$old_section_ids = array ();
					$old_section_list = db::select('id')->from(mod_special_section::$table_name)
						->where('special_id', '=', $id)
						->where('delete_user', '=', 0)
						->execute();
					if(!empty($old_section_list))
					{
						foreach ($old_section_list as $k => $v)
						{
							$old_section_ids[$k] = $v['id'];
						}
					}

					foreach ($section_title as $k => $v)
					{
						if(in_array($section_id[$k], $old_section_ids))
						{
							//修改章节
							$update_data = array ();
							$news_ids = isset($section_news_ids[$k]) ? array_unique(explode(',', $section_news_ids[$k])) : array ();
							$update_data['title'] = $section_title[$k];
							$update_data['news_total'] = count($news_ids);
							$update_data['news_ids'] = empty($news_ids) ? 0 : implode(',', $news_ids);
							$update_data['update_user'] = cls_auth::$user->fields['uid'];
							$update_data['update_time'] = time();

							$special_where = array ();
							$special_where[] = array ('id', '=', $section_id[$k]);
							db::update(mod_special_section::$table_name)->set($update_data)
								->where($special_where)
								->execute();

							//修改的章节ID
							$edit_section_ids[] = $section_id[$k];
						}
						else
						{
							//添加章节
							$add_data = array ();
							$news_ids = isset($section_news_ids[$k]) ? array_unique(explode(',', $section_news_ids[$k])) : array ();
							$add_data['special_id'] = $id;
							$add_data['title'] = $section_title[$k];
							$add_data['news_total'] = count($news_ids);
							$add_data['news_ids'] = empty($news_ids) ? 0 : implode(',', $news_ids);
							$add_data['update_time'] = $add_data['create_time'] = time();
							$add_data['create_user'] = cls_auth::$user->fields['uid'];

							db::insert(mod_special_section::$table_name)->set($add_data)
								->where($special_where)
								->execute();
						}
					}

					//删除多余的章节
					if(!empty($old_section_ids))
					{
						$del_data = array ();
						$del_data['delete_user'] = cls_auth::$user->fields['uid'];
						$del_data['delete_time'] = time();

						db::update(mod_special_section::$table_name)->set($del_data)
							->where('id','in', array_diff($old_section_ids, $edit_section_ids))
							->execute();
					}

				}
			}

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "专题新闻修改 {$id}");

            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $this->_go_url);
        }
        else
        {
            $info = db::select(mod_news::get_field())->from(mod_news::$table_name)->where('id', $id)->as_row()->execute();
			$info['img_url'] = pub_mod_news::handle_img($info['cover_img']);

            tpl::assign('info', $info);
			tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
			tpl::assign('channel_list', pub_mod_channel::get_all_list());
			tpl::assign('area_list', pub_mod_area::get_all_list());
			tpl::assign('gourl', $this->_go_url());
            tpl::display('news_special.edit.tpl');
        }
    }

	//删除
    public function del()
    {
        $ids = req::item('ids', array ());
        if (empty($ids))
        {
            cls_msgbox::show('系统提示', "请选择要删除的新闻", -1);
        }

		$del_data = array ();
		$del_data['delete_user'] = cls_auth::$user->fields['uid'];
		$del_data['delete_time'] = time();

		db::update(mod_news::$table_name)->set($del_data)
			->where('id','in', $ids)
			->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "专题新闻删除 ". implode(',', $ids));

        cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_delete', '删除成功'), $this->_go_url());
    }

	//恢复
	public function recover()
	{
		$ids = req::item('ids', array ());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "请选择要恢复的新闻", -1);
		}

		$del_data = array ();
		$del_data['update_user'] = cls_auth::$user->fields['uid'];
		$del_data['delete_user'] = 0;
		$del_data['update_time'] = time();

		db::update(mod_news::$table_name)->set($del_data)
			->where('id','in', $ids)
			->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "专题新闻恢复 ". implode(',', $ids));

		cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_delete', '恢复成功'), $this->_go_url());
	}

	//新闻发布
	public function issue()
	{
		$ids = req::item('ids', array ());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "请选择要发布的新闻", -1);
		}

		$issue_data = array ();
		$issue_data['is_issue'] = 1;
		$issue_data['update_user'] = cls_auth::$user->fields['uid'];
		$issue_data['issue_time'] = time();

		db::update(mod_news::$table_name)->set($issue_data)
			->where('id','in', $ids)
			->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新闻发布 ". implode(',', $ids));

		$this->_ajax_return(array (), 1, 'success');
	}

	//获取专题章节json数据
	public function ajax_section_list()
	{
		$id = req::item('id', 0, 'int');

		if($id <= 0)
		{
			$this->_ajax_return(array (), 0, '专题ID不能为空');
		}

		$list = db::select('id,title,news_ids')->from(mod_special_section::$table_name)
			->where('special_id', '=', $id)
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$list[$k]['children'] = db::select('id,title')->from(mod_news::$table_name)
					->where('id', 'in', explode(',', $v['news_ids']))
					->execute();
				unset($list[$k]['news_ids']);
			}
		}

		$this->_ajax_return($list, 1, 'success');
	}

	//获取频道json数据
	public function ajax_channel_list()
	{
		$list = (array)db::select('id,name')->from(mod_channel::$table_name)
			->where('status', '=', 1)
			->where('delete_user', '=', 0)
			->execute();

		$this->_ajax_return($list, 1, 'success');
	}

	//获取频道json数据
	public function ajax_news_list()
	{

		$channel_id = req::item('channel_id', '0', 'int');

		$where = array ();
		if($channel_id > 0)
		{
			$where[] = array ('channel_ids', 'FIND_IN_SET', $channel_id);
		}

		$where[] = array ('is_issue', '=', 1);
		$where[] = array ('delete_user', '=', 0);

		$count = db::select('count(*) AS `count`')
			->from(mod_news::$table_name)
			->where($where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, 5);

		$list = (array)db::select('id,title,cover_img,publisher')->from(mod_news::$table_name)
			->where($where)
			->order_by('issue_time', 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				if(!empty($v['cover_img']))
				{
					$cover_img_list = explode(',', $v['cover_img']);
					$list[$k]['cover_img'] = pub_mod_news::handle_img($cover_img_list['0']);
				}
			}
		}

		$data_list = array (
			'news_total' => $count,
			'list' => $list,
		);
		$this->_ajax_return($data_list, 1, 'success');
	}

	//表单验证
	private function _validate()
	{
		$type = req::item('type', '3', 'int');

		$config = array(
			array(
				'field' => 'title',
				'rules' => 'required',
				'errors' => array(
					'required' => '标题不能为空',
				),
			),
			array(
				'field' => 'describe',
				'rules' => 'required',
				'errors' => array(
					'required' => '描述不能为空',
				),
			),
			array(
				'field' => 'cover_img[]',
				'rules' => 'required',
				'errors' => array(
					'required' => '请上传封面图',
				),
			),
			array(
				'field' => 'level_id',
				'rules' => 'required',
				'errors' => array(
					'required' => '请选择等级',
				),
			),
			array(
				'field' => 'publisher',
				'rules' => 'required',
				'errors' => array(
					'required' => '来源不能为空',
				),
			),
			array(
				'field' => 'channel_ids[]',
				'rules' => 'required',
				'errors' => array(
					'required' => '请选择频道',
				),
			),
			array(
				'field' => 'countrys[]',
				'rules' => 'required',
				'errors' => array(
					'required' => '请选择区域',
				),
			),
		);

		$instance = cls_validation::instance();
		$instance->set_rules($config);

		if ($instance->run() === FALSE)
		{
			$error = $instance->error();
			cls_msgbox::show('系统提示', $error, '-1');
		}

	}

	//返回json数据
	private function _ajax_return($array, $status = 1, $msg = 'success')
	{
		$return_data = array(
			'status' => $status,
			'msg' => $msg,
			'data' => $array,
		);

		//header('Content-type: application/json');
		exit(json_encode($return_data, JSON_UNESCAPED_UNICODE));
	}

	//跳转URL
	private function _go_url()
	{
		$list_type = req::item('list_type', '0', 'int');

		switch ($list_type)
		{
			//已发表
			case 1:
				$gourl = '?ct=news_special&ac=publish_list';
				break;
			//草稿
			case 2:
				$gourl = '?ct=news_special&ac=draft_list';
				break;
			//已删除
			case 3:
				$gourl = '?ct=news_special&ac=del_list';
				break;
			//全部
			default:
				$gourl = '?ct=news_special&ac=index';
				break;
		}

		return $gourl;
	}

}
