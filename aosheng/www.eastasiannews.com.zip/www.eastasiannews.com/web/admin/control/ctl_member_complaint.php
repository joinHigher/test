<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员投诉管理
 *
 * @version $Id$
 */
class ctl_member_complaint
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
    }

	//全部列表
	public function index()
	{
		$this->_list(0);
	}

	//待处理列表
	public function pending_list()
	{
		$this->_list(1);
	}

	//已处理列表
	public function pended_list()
	{
		$this->_list(2);
	}

	//查看
	public function show()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择反馈！', '-1');
		}

		$info = db::select(mod_member_complaint::get_field())->from(mod_member_complaint::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		if(empty($info))
		{
			cls_msgbox::show('系统提示', '投诉信息不存在！', '-1');
		}

		//获取新闻信息
		$news_info = db::select(mod_news::get_field())->from(mod_news::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		if(empty($news_info))
		{
			cls_msgbox::show('系统提示', '新闻不存在！', '-1');
		}

		if(!empty(req::$posts))
		{
			$reply_type = req::item('reply_type');
			$reply = req::item('reply');

			if(empty($reply_type))
			{
				cls_msgbox::show('系统提示', '请选择投诉类型！', '-1');
			}

			if(empty($reply))
			{
				cls_msgbox::show('系统提示', '回复内容不能为空！', '-1');
			}

			$update_data = array ();
			$update_data['reply'] = $reply;
			$update_data['status'] = 1;
			$update_data['news_type'] = $news_info['news_type'];
			$update_data['news_title'] = $news_info['title'];
			$update_data['reply_type'] = $reply_type;
			$update_data['update_user'] = cls_auth::$user->fields['uid'];
			$update_data['update_time'] = time();

			db::update(mod_member_complaint::$table_name)->set($update_data)
				->where('id', $id)
				->execute();

			//添加反馈消息通知
			$add_data = array ();
			$add_data['member_id'] = $info['member_id'];
			$add_data['type'] = 3;
			$add_data['is_read'] = 0;
			$add_data['foreign_id'] = $id;
			$add_data['title'] = '投诉理由';
			$add_data['describe'] = $news_info['title'];
			$add_data['remark'] = $info['content'];
			$add_data['create_time'] = cls_auth::$user->fields['uid'];
			$add_data['create_user'] = time();

			db::insert('#PB#_message')->set($add_data)->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "投诉回复 {$id}");

			$gourl = '?ct=member_complaint&ac=show&id='.$id;
			cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '回复成功'), $gourl);

		}
		else
		{
			//处理图片
			$news_info['img'] = '';
			if(!empty($news_info['cover_img']))
			{
				$img_list = explode(',', $news_info['cover_img']);
				$news_info['img'] = pub_mod_news::handle_img($img_list[0]);
			}

			$news_info['new_status'] = mod_news::new_status($news_info['is_issue'], $news_info['delete_user']);

			//投诉统计
			$news_info['complaint_total'] = db::select('COUNT(*) count')->from(mod_member_complaint::$table_name)
				->where('news_id', '=', $info['news_id'])
				->as_field()
				->execute();

			//获取频道
			$channel_list = array ();
			if(!empty($news_info['channel_ids']))
			{
				$channel_list = db::select('id,name')->from(mod_channel::$table_name)
					->where('id', 'in', explode(',', $news_info['channel_ids']))
					->where('delete_user', '=', 0)
					->execute();
			}

			$news_info['channel_list'] = $channel_list;



			tpl::assign('id', $id);
			tpl::assign('info', $info);
			tpl::assign('news_info', $news_info);
			tpl::assign('statistics', $this->_statistics_reply_type($info, 1));
			tpl::assign('list_type', req::item('list_type', 0, 'int'));
			tpl::assign('go_url', $this->_go_url());
			tpl::display('member_complaint.show.tpl');

		}
	}

	//投诉人信息
	public function complaint_people()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择反馈！', '-1');
		}

		$info = db::select(mod_member_complaint::get_field())->from(mod_member_complaint::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		if(empty($info))
		{
			cls_msgbox::show('系统提示', '投诉信息不存在！', '-1');
		}

		//获取投诉人信息
		$member_info = db::select(mod_member::get_field())->from(mod_member::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		$member_info['sex_name'] = mod_member::$sex_list[$member_info['sex']];
		$member_info['interest'] = empty($member_info['interest']) ? '未填写' : $member_info['interest'];
		$member_info['profession'] = empty($member_info['profession']) ? '未填写' : $member_info['profession'];
		$member_info['level_name'] = db::select('name')->from(mod_member_level::$table_name)
									->where('id', '=', $member_info['level_id'])
									->as_field()
									->execute();

		$demo_img = 'http://img1.gtimg.com/ninja/2/2018/05/ninja152747528512873.jpg';
		$member_info['head_img'] = empty($member_info['head_img']) ? $demo_img : URL_UPLOADS.'/image/'.$member_info['head_img'];


		//获取用户投诉的记录
		$where = array();
		$where[] = array( 'member_id', '=', $info['member_id']);
		$where[] = array( 'delete_user', '=', 0);

		$row = db::select('COUNT(*) AS `count`')
			->from(mod_member_complaint::$table_name)
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], req::item('page_size', 10));

		$list = db::select(mod_member_complaint::get_field())
			->from(mod_member_complaint::$table_name)
			->where($where)
			->order_by(mod_member_complaint::$pk, 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$color = 'green';
				if($v['status'] == 1)
				{
					switch ($v['reply_type'])
					{
						case 1:
							$color = 'black';
							break;
						case 2:
							$color = 'red';
							break;
						case 3:
							$color = 'black';
							break;
					}
				}

				$list[$k]['status_name'] = '<span style="color:'.$color.';">'.mod_member_complaint::$reply_type_list[$v['reply_type']].'</span>';

			}
		}

		tpl::assign('id', $id);
		tpl::assign('info', $info);
		tpl::assign('member_info', $member_info);
		tpl::assign('list_type', req::item('list_type', 0, 'int'));
		tpl::assign('status_list', mod_member_complaint::$status_list);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::assign('statistics', $this->_statistics_reply_type($info, 2));
		tpl::assign('go_url', $this->_go_url());
		tpl::display('member_complaint.complaint_people.tpl');
	}

	//投诉记录,本条新闻的投诉记录
	public function news_log()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择反馈！', '-1');
		}

		$info = db::select(mod_member_complaint::get_field())->from(mod_member_complaint::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		if(empty($info))
		{
			cls_msgbox::show('系统提示', '投诉信息不存在！', '-1');
		}

		//获取新闻信息
		$news_info = db::select(mod_news::get_field())->from(mod_news::$table_name)
			->where('id', '=', $id)
			->as_row()
			->execute();

		//处理图片
		$news_info['img'] = '';
		if(!empty($news_info['cover_img']))
		{
			$img_list = explode(',', $news_info['cover_img']);
			$news_info['img'] = pub_mod_news::handle_img($img_list[0]);
		}

		$news_info['new_status'] = mod_news::new_status($news_info['is_issue'], $news_info['delete_user']);

		//获取频道
		$channel_list = array ();
		if(!empty($news_info['channel_ids']))
		{
			$channel_list = db::select('id,name')->from(mod_channel::$table_name)
				->where('id', 'in', explode(',', $news_info['channel_ids']))
				->where('delete_user', '=', 0)
				->execute();
		}

		$news_info['channel_list'] = $channel_list;

		//投诉统计
		$news_info['complaint_total'] = db::select('COUNT(*) count')->from(mod_member_complaint::$table_name)
			->where('news_id', '=', $info['news_id'])
			->as_field()
			->execute();

		//获取该新闻相关的记录
		$where = array();
		$where[] = array( 'news_id', '=', $info['news_id']);
		$where[] = array( 'delete_user', '=', 0);

		$row = db::select('COUNT(*) AS `count`')
			->from(mod_member_complaint::$table_name)
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], req::item('page_size', 10));

		$list = db::select(mod_member_complaint::get_field())
			->from(mod_member_complaint::$table_name)
			->where($where)
			->order_by(mod_member_complaint::$pk, 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$color = 'green';
				if($v['status'] == 1)
				{
					switch ($v['reply_type'])
					{
						case 1:
							$color = 'black';
							break;
						case 2:
							$color = 'red';
							break;
						case 3:
							$color = 'black';
							break;
					}
				}

				$list[$k]['status_name'] = '<span style="color:'.$color.';">'.mod_member_complaint::$reply_type_list[$v['reply_type']].'</span>';

			}
		}

		tpl::assign('id', $id);
		tpl::assign('info', $info);
		tpl::assign('news_info', $news_info);
		tpl::assign('list_type', req::item('list_type', 0, 'int'));
		tpl::assign('status_list', mod_member_complaint::$status_list);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::assign('statistics', $this->_statistics_reply_type($info, 3));
		tpl::assign('go_url', $this->_go_url());
		tpl::display('member_complaint.news_log.tpl');
	}

	//查看图片
	public function show_img()
	{

		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			cls_msgbox::show('系统提示', '请选择反馈！', '-1');
		}

		$img = db::select('img')->from(mod_member_complaint::$table_name)
			->where('id', '=', $id)
			->as_field()
			->execute();

		//处理图片
		$pics = array ();
		if(!empty($img))
		{
			$img_list = explode(',', $img);
			foreach ($img_list as $k => $v)
			{
				$pics[$k] = URL_UPLOADS. '/image/' . $v;
			}
		}

		tpl::assign('pics', $pics);
		tpl::display('modal.pics.view.tpl');
	}

	//获取列表
    private function _list($list_type = 0)
    {

        $status = req::item('status');
        $keyword = req::item('keyword', '');
		$start_time = req::item('start_time');
		$end_time = req::item('end_time');

        $where = array();

		switch ($list_type)
		{
			//待处理
			case 1:
				$where[] = array( 'status', '=', 0);
				break;
			//已处理
			case 2:
				$where[] = array( 'status', '=', 1);
				break;
			//全部
			default:
				if(is_numeric($status))
				{
					$where[] = array( 'status', '=', $status);
					$status = intval($status);
				}
				break;
		}

        if (!empty($keyword)) 
        {
            $where[] = array( 'member_name', 'like', "%$keyword%" );
        }

		if(!empty($start_time))
		{
			$where[] = array( 'create_time', '>=', strtotime($start_time.' 00:00:00'));
		}

		if(!empty($end_time))
		{
			$where[] = array( 'create_time', '<=', strtotime($end_time.' 23:59:59'));
		}

		$where[] = array( 'delete_user', '=', 0);

        $row = db::select('COUNT(*) AS `count`')
            ->from(mod_member_complaint::$table_name)
            ->where($where)
            ->as_row()
            ->execute();

        $pages = pub_page::make($row['count'], req::item('page_size', 10));

        $list = db::select(mod_member_complaint::get_field())
            ->from(mod_member_complaint::$table_name)
            ->where($where)
            ->order_by(mod_member_complaint::$pk, 'desc')
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();

		tpl::assign('status', $status);
		tpl::assign('status_list', mod_member_complaint::$status_list);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::assign('list_type', $list_type);
        tpl::display('member_complaint.index.tpl');
    }

	//统计投诉回复的类型
	private function _statistics_reply_type($info, $type = 1)
	{
		$where = array ();

		switch ($type)
		{
			//投诉详情
			case 1:
				//$where[] = array ('news_id', '=', $info['news_id']);
				break;
			//投诉人信息
			case 2:
				$where[] = array ('member_id', '=', $info['member_id']);
				break;
			//投诉记录
			case 3:
				$where[] = array ('news_id', '=', $info['news_id']);
				break;
		}
		$list = db::select('COUNT(*) count, reply_type')->from(mod_member_complaint::$table_name)
			->where($where)
			->group_by('reply_type')
			->execute();

		$new_list = array (
			1 => 0,
			2 => 0,
			3 => 0,
		);

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$new_list[$v['reply_type']] = $v['count'];
			}
		}

		return $new_list;
	}

	//返回url
	private function _go_url()
	{
		$list_type = req::item('list_type', 0, 'int');

		switch ($list_type)
		{
			//待处理列表
			case 1:
				$go_url = '?ct=member_complaint&ac=pending_list';
				break;
			//已处理列表
			case 2:
				$go_url = '?ct=member_complaint&ac=pended_list';
				break;
			//全部
			default:
				$go_url = '?ct=member_complaint&ac=index';
				break;
		}

		return $go_url;
	}
}
