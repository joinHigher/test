<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 频道管理
 *
 * @version $Id$
 */
class ctl_channel
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {

    }

	//全部
    public function index()
    {
		$this->_list();
    }

	//禁用列表
	public function disable_list()
	{
		$this->_list(2);
	}

	//启用列表
	public function able_list()
	{
		$this->_list(1);
	}

	//获取列表
	private function _list($list_type = 0)
	{
		$keyword = req::item('keyword', '');

		$where = array();

		switch ($list_type)
		{
			//使用中
			case 1:
				$where[] = array('status', '=', 1);
				break;
			//已禁用
			case 2:
				$where[] = array('status', '=', 0);
				break;
		}

		$where[] = array('delete_user', '=', 0);
		if (!empty($keyword))
		{
			$where[] = array( 'name', 'like', "%$keyword%" );
		}

		$row = db::select('count(*) AS `count`')
			->from(mod_channel::$table_name)
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], req::item('page_size', 10));

		$list = db::select(mod_channel::get_field())->from(mod_channel::$table_name)
			->where($where)
			//->order_by(mod_channel::$pk, 'asc')
			->order_by('status', 'DESC')
			->order_by('sort', 'ASC')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$list[$k]['level_name'] = db::select('name')
					->from(mod_member_level::$table_name)
					->where('id', '=', $v['level_id'])
					->where('delete_user', '=', 0)
					->as_field()
					->execute();

                $color = $v['status'] == 0 ? 'red' : 'green';
                $list[$k]['status_name'] = '<font color="'.$color.'">'. mod_area::$status_list[$v['status']] .'</span>';
                $color = $v['is_fix'] == 0 ? 'red' : 'green';
                $list[$k]['fix_name'] = '<font color="'.$color.'">'. mod_area::$bool_status[$v['is_fix']] .'</span>';
                $color = $v['is_default'] == 0 ? 'red' : 'green';
                $list[$k]['default_name'] = '<font color="'.$color.'">'. mod_area::$bool_status[$v['is_default']] .'</span>';

				//switch ($v['status'])
				//{
					//case 1:
						//$list[$k]['status_name'] = '<span style="color: green;">';
						//break;

					//case 0:
						//$list[$k]['status_name'] = '<span style="color: red;">';
						//break;
				//}

				//$list[$k]['status_name'] .= mod_channel::$status_list[$v['status']];
				//$list[$k]['fix_name'] = mod_channel::$is_fix_list[$v['is_fix']];
				//$list[$k]['default_name'] = mod_channel::$is_fix_list[$v['is_default']];

				$list[$k]['news_total'] = db::select('COUNT(*) count')->from(mod_news::$table_name)
					->where('channel_ids', 'FIND_IN_SET', $v['id'])
					->where('delete_user', '=', 0)
					->as_field()
					->execute();
			}
		}

		tpl::assign('list_type', $list_type);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('channel.index.tpl');
	}

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $name = req::item('name');

            if(empty($name))
			{
				cls_msgbox::show('系统提示', '频道名称不能为空！', '-1');
			}

            $row = db::select('count(*) AS `count`')
                ->from(mod_channel::$table_name)
                ->where('name', $name)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '频道名称已经存在！', '-1');
            }

			$add_data = array ();
			$add_data['name'] = $name;
			$add_data['level_id'] = req::item('level_id', 0, 'int');
			$add_data['type'] = req::item('type', 1, 'int');
			$add_data['is_default'] = req::item('is_fix', 0, 'int');
			$add_data['is_fix'] = req::item('is_fix', 0, 'int');
			$add_data['status'] = req::item('status', 0, 'int');
			$add_data['sort'] = 0;
			//$add_data['new_total'] = 0;
			$add_data['update_time'] = $add_data['create_time'] = time();
			$add_data['create_user'] = cls_auth::$user->fields['uid'];

            list($insert_id, $rows_affected) = db::insert(mod_channel::$table_name)->set($add_data)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "频道添加 {$insert_id}");

            $gourl = '?ct=channel&ac=index';
            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_add', '添加成功'), $gourl);
        }
        else 
        {
			tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
            tpl::assign('gourl', $this->_go_url());
            tpl::display('channel.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
            $name = req::item('name');

			if(empty($name))
			{
				cls_msgbox::show('系统提示', '频道名称不能为空！', '-1');
			}

            $row = db::select('count(*) AS `count`')->from(mod_channel::$table_name)
                ->where('name', $name)
                ->where('id', '!=', $id)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '标题已经存在！', '-1');
            }

			$update_data = array ();
			$update_data['name'] = $name;
			$update_data['type'] = req::item('type', 1, 'int');
			$update_data['is_default'] = req::item('is_default', 0, 'int');
			$update_data['is_fix'] = req::item('is_fix', 0, 'int');
			$update_data['status'] = req::item('status', 0, 'int');
			$update_data['level_id'] = req::item('level_id', 0, 'int');
			$update_data['update_user'] = cls_auth::$user->fields['uid'];
			$update_data['update_time'] = time();

            db::update(mod_channel::$table_name)->set($update_data)
            ->where('id', $id)
            ->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "频道修改 {$id}");

            $gourl = '?ct=channel&ac=index';
            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $gourl);
        }
        else 
        {
            $info = db::select(mod_channel::get_field())->from(mod_channel::$table_name)->where('id', $id)->as_row()->execute();

			tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
            tpl::assign('gourl', $this->_go_url());
            tpl::assign('info', $info);
            tpl::display('channel.edit.tpl');
        }
    }
    
    public function edit_batch()
    {
        $ids = req::item('ids', array());
        $sorts = req::item('sorts', array());
        if (empty($ids)) 
        {
            cls_msgbox::show('系统提示', "未选中任何数据", -1);
        }
        foreach ($ids as $id) 
        {
            $sort = $sorts[$id];
            db::update(mod_channel::$table_name)
                ->set(array(
                    'sort' => $sort
                ))
                ->where('id', $id)->execute();
        }

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "频道批量修改 ".implode(",", $ids));

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=category&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', '修改成功', $gourl);
    }

    public function del()
    {
        $id = req::item('id', 0, 'int');
        if (empty($id))
        {
            cls_msgbox::show('系统提示', "删除失败，请选择要删除的频道", -1);
        }

		$row = db::select('count(*) AS `count`')->from(mod_news::$table_name)
			->where('channel_ids', 'FIND_IN_SET', $id)
			->where('delete_user', '=', 0)
			->as_row()
			->execute();

		if( $row['count'] )
		{
			cls_msgbox::show('系统提示', '该频道有新闻不能删除！', '-1');
		}
		
		$del_data = array ();
		$del_data['delete_user'] = cls_auth::$user->fields['uid'];
		$del_data['delete_time'] = time();

		db::update(mod_channel::$table_name)->set($del_data)
			->where('id', $id)
			->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "频道删除 ".$id);

        cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_delete', '删除成功'), $this->_go_url());
    }

	//跳转URL
	private function _go_url()
	{
		$list_type = req::item('list_type', '0', 'int');

		switch ($list_type)
		{
			//使用中
			case 1:
				$gourl = '?ct=channel&ac=able_list';
				break;
			//已禁用
			case 2:
				$gourl = '?ct=channel&ac=disable_list';
				break;
			default:
				$gourl = '?ct=channel&ac=index';
				break;
		}

		return $gourl;
	}
}
