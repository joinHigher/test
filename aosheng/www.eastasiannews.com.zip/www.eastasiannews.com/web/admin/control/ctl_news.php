<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 新闻管理
 *
 * @version $Id$
 */
class ctl_news
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {

    }

	//全部列表
    public function index()
    {
		$this->_list(0);
    }

	//已发表列表
	public function publish_list()
	{
		$this->_list(1);
	}

	//草稿列表
	public function draft_list()
	{
		$this->_list(2);
	}

	//已删除列表
	public function del_list()
	{
		$this->_list(3);
	}

	//获取列表
	private function _list($list_type = 0)
	{
		$keyword = req::item('keyword', '');
		$type = req::item('type');
		$level_id = req::item('level_id');
		$channel_id = req::item('channel_id');
		$start_time = req::item('start_time');
		$end_time = req::item('end_time');

		$where = array();
		$where[] = array('type', '!=', 3);

		if(!empty($channel_id))
		{
			$where[] = array('channel_ids', 'FIND_IN_SET', $channel_id);
		}

		if(is_numeric($level_id))
		{
			$where[] = array('level_id', '=', $level_id);
			$level_id = intval($level_id);
		}

		if(!empty($type))
		{
			$where[] = array('type', '=', $type);
		}

		if(!empty($start_time))
		{
			$where[] = array('issue_time', '>=', strtotime($start_time. ' 00:00:00'));
		}

		if(!empty($end_time))
		{
			$where[] = array('issue_time', '<=', strtotime($end_time. ' 23:59:59'));
		}

		switch ($list_type)
		{
			//全部
			case 0:

				break;
			//已发表
			case 1:
				$where[] = array('is_issue', '=', 1);
				$where[] = array('delete_user', '=', 0);
				break;
			//草稿
			case 2:
				$where[] = array('is_issue', '=', 0);
				$where[] = array('delete_user', '=', 0);
				break;
			//已删除
			case 3:
				$where[] = array('delete_user', '!=', 0);
				break;
		}

		if (!empty($keyword))
		{
			$where[] = array( 'title', 'like', "%$keyword%" );
		}

		$row = db::select('count(*) AS `count`')
			->from(mod_news::$table_name)
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], req::item('page_size', 10));

		$list = db::select(mod_news::get_field())->from(mod_news::$table_name)
			->where($where)
			->order_by(mod_news::$pk, 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				//获取频道
				$channel_list = array ();
				if(!empty($v['channel_ids']))
				{
					$channel_list = db::select('id,name')->from(mod_channel::$table_name)
						->where('id', 'in', explode(',', $v['channel_ids']))
						->where('delete_user', '=', 0)
						->execute();
				}

				$list[$k]['channel_list'] = $channel_list;

				//获取归属专题
				$list[$k]['special_list'] = array ();
				$special_ids = db::select('special_id')->from(mod_special_section::$table_name)
					->where('news_ids', 'FIND_IN_SET', $v['id'])
					->execute();
				if(!empty($special_ids))
				{
					foreach ($special_ids as $sk => $sv)
					{
						$list[$k]['special_list'][$sk] = db::select('id,title')
							->from(mod_news::$table_name)
							->where('id', '=', $sv['special_id'])
							->as_row()
							->execute();
					}
				}

				//新闻状态
				$list[$k]['news_status'] = mod_news::new_status($v['is_issue'], $v['delete_user']);

				$list[$k]['type_name'] = mod_news::$type_list[$v['type']];

				if($v['cover_img'])
				{
					$cover_imgs = explode(',', $v['cover_img']);
					$list[$k]['cover_img'] = pub_mod_news::handle_img($cover_imgs[0]);
				}
				
			}
		}

		$type_list = mod_news::$type_list;
		unset($type_list[3]);

		tpl::assign('type', $type);
		tpl::assign('level_id', $level_id);
		tpl::assign('channel_id', $channel_id);
		tpl::assign('list_type', $list_type);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::assign('type_list', $type_list);
		tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
		tpl::assign('channel_list', pub_mod_channel::get_all_list());
		tpl::display('news.index.tpl');
	}

	//添加
    public function add()
    {
        if (!empty(req::$posts)) 
        {
        	//验证
        	$this->_validate();

            $title = req::item('title', '');
            $country_ids = req::item('countrys', array ());
            $channel_ids = req::item('channel_ids', array ());
            $cover_img = req::item('cover_img', array ());
            $video = req::item('video', array ());
            $level_id = req::item('level_id', '0', 'int');
            $is_top = req::item('is_top', '0', 'int');
            $is_hot = req::item('is_hot', '0', 'int');
            $is_main = req::item('is_main', '0', 'int');
            $is_issue = req::item('is_issue', '0', 'int');
            $type = req::item('type', '1', 'int');
            $label = req::item('label');
            $publisher = req::item('publisher', '东亚新闻');
            $content = req::item('content', '');
            $special_ids = req::item('special_ids');
            $section_ids = req::item('section_ids');
            $atlas_img = req::item('atlas_img');
            $atlas_desc = req::item('atlas_desc');

            $row = db::select('count(*) AS `count`')
                ->from(mod_news::$table_name)
                ->where('title','=' , $title)
                ->as_row()
                ->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '新闻标题已经存在！', '-1');
            }

			//如果是图集新闻，处理内容
			$atlas = '';
			if($type == 4)
			{
				$content_list = array ();
				$content_list['imgs'] = $atlas_img;
				$content_list['descs'] = $atlas_desc;

				$atlas = serialize($content_list);

				if(!empty($atlas_img))
				{
					$atlas_img_list = explode(',', $atlas_img);
					$cover_img[] = $atlas_img_list[0];
				}
			}

			$add_data = array ();

            $add_data['id'] = util::random('web');
			if(!empty($country_ids)) $add_data['countrys'] = implode(',', $country_ids);
			$add_data['channel_ids'] = implode(',', $channel_ids);
			$add_data['title'] = $title;
			if(!empty($video)) $add_data['video'] = implode(',', $video);
			$add_data['cover_img'] = implode(',', $cover_img);
			$add_data['level_id'] = $level_id;
			$add_data['is_top'] = $is_top;
			$add_data['is_hot'] = $is_hot;
			$add_data['is_main'] = $is_main;
			$add_data['is_issue'] = $is_issue;
			if($is_issue == 1) $add_data['issue_time'] = time();
			$add_data['issue_time'] = time();
			$add_data['type'] = $type;
			$add_data['label'] = $label;
			$add_data['browse_total'] = 0;
			$add_data['publisher'] = $publisher;
			$add_data['content'] = $content;
			$add_data['atlas'] = $atlas;
			$add_data['update_time'] = $add_data['create_time'] = time();
			$add_data['create_user'] = cls_auth::$user->fields['uid'];

            list($insert_id, $rows_affected) = db::insert(mod_news::$table_name)->set($add_data)->execute();

            if(!empty($insert_id))
			{
				//设置排序
				$update_data = array ();
				$update_data['sort'] = $insert_id;
				db::update(mod_news::$table_name)->set($update_data)
					->where('id', '=', $insert_id)
					->execute();

				//如果是添加新闻时，添加专题
				if(!empty($special_ids) && !empty($section_ids))
				{
					foreach ($special_ids as $k => $v)
					{
						$special_where = array ();
						$special_where[] = array ('special_id', '=', $v);
						$special_where[] = array ('id', '=', $section_ids[$k]);
						$news_ids = db::select('news_ids')->from(mod_special_section::$table_name)
							->where($special_where)
							->as_field()
							->execute();

						if(!empty($news_ids))
						{
							$news_ids = explode(',', $news_ids);
							$news_ids[] = $insert_id;

							$update_data = array ();
							$news_ids = array_unique($news_ids);
							$update_data['news_total'] = count($news_ids);
							$update_data['news_ids'] = implode(',', $news_ids);
							db::update(mod_special_section::$table_name)->set($update_data)
								->where($special_where)
								->execute();
						}
					}
				}
			}

			//转移图片文件
			pub_mod_news::move_file($cover_img);

            if(!empty($atlas_img))
			{
				pub_mod_news::move_file(explode(',', $atlas_img));
			}

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新闻添加 {$insert_id}");

            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_add', '添加成功'), $this->_go_url());
        }
        else 
        {
        	//获取全部的专题
			$special_list = db::select('id,title')->from(mod_news::$table_name)
				->where('type', '=', 3)
				->where('is_issue', '=', 1)
				->where('delete_user', '=', 0)
				->execute();

			tpl::assign('special_list', $special_list);
			tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
			tpl::assign('channel_list', pub_mod_channel::get_all_list());
			tpl::assign('area_list', pub_mod_area::get_all_list());
            tpl::assign('gourl', $this->_go_url());
            tpl::display('news.add.tpl');
        }
    }

	//编辑
    public function edit()
    {
        $id = req::item("id", 0);

		$info = db::select(mod_channel::get_field())->from(mod_news::$table_name)->where('id', $id)->as_row()->execute();

		if( empty($info) )
		{
			cls_msgbox::show('系统提示', '请选择新闻！', '-1');
		}

		//获取新闻已选择的专题章节
		$special_section_list = db::select('id,special_id')->from(mod_special_section::$table_name)
			->where('news_ids', 'FIND_IN_SET', $info['id'])
			->where('delete_user', '=', 0)
			->execute();

		if (!empty(req::$posts))
        {
			//验证
			$this->_validate();

			$title = req::item('title', '');
			$country_ids = req::item('countrys', array ());
			$channel_ids = req::item('channel_ids', array ());
			$cover_img = req::item('cover_img', array ());
			$video = req::item('video', array ());
			$level_id = req::item('level_id', '0', 'int');
			$is_top = req::item('is_top', '0', 'int');
			$is_hot = req::item('is_hot', '0', 'int');
			$is_main = req::item('is_main', '0', 'int');
			$is_issue = req::item('is_issue', '0', 'int');
			$type = req::item('type', '1', 'int');
			$label = req::item('label');
			$publisher = req::item('publisher', '东亚新闻');
			$content = req::item('content', '');
			$special_ids = req::item('special_ids');
			$section_ids = req::item('section_ids');
			$atlas_img = req::item('atlas_img');
			$atlas_desc = req::item('atlas_desc');

			$row = db::select('count(*) AS `count`')
				->from(mod_news::$table_name)
				->where('id','!=' , $id)
				->where('title','=' , $title)
				->as_row()
				->execute();

			if( $row['count'] )
			{
				cls_msgbox::show('系统提示', '新闻标题已经存在！', '-1');
			}

			//如果是图集新闻，处理内容
			$atlas = '';
			if($type == 4)
			{
				$content_list = array ();
				$content_list['imgs'] = $atlas_img;
				$content_list['descs'] = $atlas_desc;

				$atlas = serialize($content_list);

				if(!empty($atlas_img))
				{
					$atlas_img_list = explode(',', $atlas_img);
					$cover_img[] = $atlas_img_list[0];
				}
			}

			$update_data = array ();
			if(!empty($country_ids)) $update_data['countrys'] = implode(',', $country_ids);
			$update_data['channel_ids'] = implode(',', $channel_ids);
			$update_data['title'] = $title;
			if(!empty($video)) $update_data['video'] = implode(',', $video);
			$update_data['cover_img'] = implode(',', $cover_img);
			$update_data['level_id'] = $level_id;
			$update_data['is_top'] = $is_top;
			$update_data['is_hot'] = $is_hot;
			$update_data['is_main'] = $is_main;
			$update_data['is_issue'] = $is_issue;
			if($is_issue == 1) $update_data['issue_time'] = time();
			$update_data['type'] = $type;
			$update_data['label'] = $label;
			$update_data['browse_total'] = 0;
			$update_data['publisher'] = $publisher;
			$update_data['atlas'] = $atlas;
			$update_data['content'] = $content;
			$update_data['update_user'] = cls_auth::$user->fields['uid'];
			$update_data['update_time'] = time();

            $result = db::update(mod_news::$table_name)->set($update_data)
				->where('id', $id)
				->execute();

			if(!empty($result))
			{
				//获取全部的旧章节
				$old_section_ids = array ();
				if(!empty($special_section_list))
				{
					foreach ($special_section_list as $k => $v)
					{
						$old_section_ids[] = $v['id'];
					}
				}

				//如果是添加新闻时，添加专题
				if(!empty($special_ids) && !empty($section_ids))
				{
					foreach ($special_ids as $k => $v)
					{
						//如果已经存在则跳过
						if(in_array($section_ids[$k], $old_section_ids))
						{
							$old_section_ids = array_diff($old_section_ids, array ($section_ids[$k]));
							continue;
						}

						$special_where = array ();
						$special_where[] = array ('id', '=', $section_ids[$k]);
						$special_where[] = array ('special_id', '=', $v);
						$news_ids = db::select('news_ids')->from(mod_special_section::$table_name)
							->where($special_where)
							->as_field()
							->execute();

						if(!empty($news_ids))
						{
							$news_ids = explode(',', $news_ids);
							$news_ids[] = $id;

							$update_data = array ();
							$news_ids = array_unique($news_ids);
							$update_data['news_total'] = count($news_ids);
							$update_data['news_ids'] = implode(',', $news_ids);
							db::update(mod_special_section::$table_name)->set($update_data)
								->where($special_where)
								->execute();
						}
					}

					//删除旧的章节
					if(!empty($old_section_ids))
					{
						foreach ($old_section_ids as $k => $v)
						{
							$special_where = array ();
							$special_where[] = array ('id', '=', $v);
							$news_ids = db::select('news_ids')->from(mod_special_section::$table_name)
								->where($special_where)
								->as_field()
								->execute();

							if(!empty($news_ids))
							{
								$news_ids = explode(',', $news_ids);

								$update_data = array ();
								$news_ids = array_diff($news_ids, array ($id));
								$update_data['news_total'] = count($news_ids);
								$update_data['news_ids'] = implode(',', $news_ids);
								db::update(mod_special_section::$table_name)->set($update_data)
									->where($special_where)
									->execute();
							}
						}
					}
				}
			}

			//转移图片文件
			pub_mod_news::move_file($cover_img);

			if(!empty($atlas_img))
			{
				pub_mod_news::move_file(explode(',', $atlas_img));
			}

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新闻修改 {$id}");

            cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $this->_go_url());
        }
        else 
        {

			$info['cover_img'] = empty($info['cover_img']) ? array () : explode(',', $info['cover_img']);
			$info['cover_img_url_list'] = array ();

			if(!empty($info['cover_img']))
			{
				foreach ($info['cover_img'] as $k => $iv)
				{
					$info['cover_img_url_list'][] = pub_mod_news::handle_img($iv);
				}
			}

			$atlas_list = array (
					'imgs' => '',
					'descs' => '',
					'imgs_arr' => array (),
					'descs_arr' => array (),
				);
			if($info['type'] == 4)
			{
				$atlas_list = unserialize($info['atlas']);
				if(!empty($atlas_list['imgs'])) $atlas_list['imgs_arr'] = explode(',', $atlas_list['imgs']);
				if(!empty($atlas_list['descs'])) $atlas_list['descs_arr'] = explode(',', $atlas_list['descs']);
			}

			//获取所有专题新闻
			$special_news_list = db::select('id,title')->from(mod_news::$table_name)
				->where('type', '=', 3)
				->where('is_issue', '=', 1)
				->where('delete_user', '=', 0)
				->execute();

			tpl::assign('info', $info);
			tpl::assign('atlas_list', $atlas_list);
			tpl::assign('special_list', $special_news_list);
			tpl::assign('special_section_list', $special_section_list);
			tpl::assign('img_url', URL_UPLOADS.'/image/');
			tpl::assign('member_level_list', pub_mod_member_level::get_all_list());
			tpl::assign('channel_list', pub_mod_channel::get_all_list());
			tpl::assign('area_list', pub_mod_area::get_all_list());
			tpl::assign('gourl', $this->_go_url());
            tpl::display('news.edit.tpl');
        }
    }

	//批量修改
	public function edit_batch()
	{
		// 排序列表类型：1=置顶，2=推荐，3=普通
		$list_type = req::item('list_type', 1, 'int');

		if(!empty(req::$posts))
		{
			$ids = req::item('ids', array());
			$sorts = req::item('sorts', array());

			if (empty($ids))
			{
				cls_msgbox::show('系统提示', "未选中任何数据", -1);
			}
			foreach ($ids as $id)
			{
				$update_data = array ();
				$update_data['sort'] = $sorts[$id];
				switch ($list_type)
				{
					case 1:
						$update_data['top_time'] = time();
						break;
					case 2:
						$update_data['recom_time'] = time();
						break;
					case 3:
						break;
				}

				$update_data['update_user'] = cls_auth::$user->fields['uid'];
				$update_data['update_time'] = time();
				db::update(mod_news::$table_name)->set($update_data)
					->where('id', $id)->execute();
			}

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新闻批量修改 ".implode(",", $ids));

			$gourl = '?ct=news&ac=edit_batch';
			cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $gourl);
		}
		else
		{
			$keyword = req::item('keyword', '');
			$level_id = req::item('level_id');
			$channel_id = req::item('channel_id');
			$start_time = req::item('start_time');
			$end_time = req::item('end_time');
			$type = req::item('type', 0, 'int');

			$where = array();

			if(!empty($type))
			{
				$where[] = array('type', '=', $type);
			}

			if(!empty($channel_id))
			{
				$where[] = array('channel_id', '=', $channel_id);
			}

			if(is_numeric($level_id))
			{
				$where[] = array('level_id', '=', $level_id);
				$level_id = intval($level_id);
			}

			if(!empty($start_time))
			{
				$where[] = array('issue_time', '>=', strtotime($start_time. ' 00:00:00'));
			}

			if(!empty($end_time))
			{
				$where[] = array('issue_time', '<=', strtotime($end_time. ' 23:59:59'));
			}

			if (!empty($keyword))
			{
				$where[] = array( 'name', 'like', "%$keyword%" );
			}

			$order_by_list = array ();
			switch ($list_type)
			{
				case 1:
					$where[] = array( 'is_top', '=', 1);
					$order_by_list = array (
						array ('sort', 'desc'),
						array ('top_time', 'desc'),
					);
					break;
				case 2:
					$where[] = array( 'is_hot', '=', 1);
					$order_by_list = array (
						array ('sort', 'desc'),
						array ('recom_time', 'desc'),
					);
					break;
				case 3:
					$where[] = array( 'is_top', '=', 0);
					$where[] = array( 'is_hot', '=', 0);
					$order_by_list = array (
						array ('sort', 'desc'),
						array ('issue_time', 'desc'),
					);
					break;
			}

			$where[] = array( 'is_issue', '=', 1);
			$where[] = array( 'delete_user', '=', 0);

			$row = db::select('count(*) AS `count`')
				->from(mod_news::$table_name)
				->where($where)
				->as_row()
				->execute();

			$pages = pub_page::make($row['count'], req::item('page_size', 10));

			$instance = db::select(mod_news::get_field())->from(mod_news::$table_name)
				->where($where);

			foreach ($order_by_list as $k => $v)
			{
				$instance->order_by($v[0], $v[1]);
			}

			$list = $instance->limit($pages['page_size'])
				->offset($pages['offset'])
				->execute();

			if(!empty($list))
			{
				foreach ($list as $k => $v)
				{
					//获取频道
					$channel_list = array ();
					if(!empty($v['channel_ids']))
					{
						$channel_list = db::select('id,name')->from(mod_channel::$table_name)
							->where('id', 'in', explode(',', $v['channel_ids']))
							->where('delete_user', '=', 0)
							->execute();
					}

					$list[$k]['channel_list'] = $channel_list;

					//获取归属专题
					$list[$k]['special_list'] = array ();
					$special_ids = db::select('special_id')->from(mod_special_section::$table_name)
						->where('news_ids', 'FIND_IN_SET', $v['id'])
						->execute();
					if(!empty($special_ids))
					{
						foreach ($special_ids as $sk => $sv)
						{
							$list[$k]['special_list'][$sk] = db::select('id,title')
								->from(mod_news::$table_name)
								->where('id', '=', $sv['special_id'])
								->as_row()
								->execute();
						}
					}

					//新闻状态
					$list[$k]['news_status'] = mod_news::new_status($v['is_issue'], $v['delete_user']);

					$list[$k]['type_name'] = mod_news::$type_list[$v['type']];

					if($v['cover_img'])
					{
						$cover_imgs = explode(',', $v['cover_img']);
						$list[$k]['cover_img'] = pub_mod_news::handle_img($cover_imgs[0]);
					}

				}
			}

			tpl::assign('list_type', $list_type);
			tpl::assign('type', $type);
			tpl::assign('channel_id', $channel_id);
			tpl::assign('list', $list);
			tpl::assign('pages', $pages['show']);
			tpl::assign('type_list', mod_news::$type_list);
			tpl::assign('channel_list', pub_mod_channel::get_all_list());
			tpl::display('news.edit_batch.tpl');
		}
	}

	//删除
	public function del()
	{
		$ids = req::item('ids', array ());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "请选择要删除的新闻", -1);
		}

		$del_data = array ();
		$del_data['delete_user'] = cls_auth::$user->fields['uid'];
		$del_data['delete_time'] = time();

		db::update(mod_news::$table_name)->set($del_data)
			->where('id','in', $ids)
			->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "专题新闻删除 ". implode(',', $ids));

		cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_delete', '删除成功'), $this->_go_url());
	}

	//恢复
	public function recover()
	{
		$ids = req::item('ids', array ());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "请选择要恢复的新闻", -1);
		}

		$del_data = array ();
		$del_data['update_user'] = cls_auth::$user->fields['uid'];
		$del_data['delete_user'] = 0;
		$del_data['update_time'] = time();

		db::update(mod_news::$table_name)->set($del_data)
			->where('id','in', $ids)
			->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "专题新闻恢复 ". implode(',', $ids));

		cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_delete', '恢复成功'), $this->_go_url());
	}

	//新闻发布
	public function issue()
	{
		$ids = req::item('ids', array ());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "请选择要发布的新闻", -1);
		}

		$issue_data = array ();
		$issue_data['is_issue'] = 1;
		$issue_data['update_user'] = cls_auth::$user->fields['uid'];
		$issue_data['issue_time'] = time();

		db::update(mod_news::$table_name)->set($issue_data)
			->where('id','in', $ids)
			->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新闻发布 ". implode(',', $ids));

		$this->_ajax_return(array (), 1, 'success');
	}

	//获取专题章节json数据
	public function ajax_special_section_list()
	{
		$id = req::item('id', 0, 'int');

		if($id <= 0)
		{
			$this->_ajax_return(array (), 0, '请传入专题ID');
		}

		$list = db::select('id,title')->from(mod_special_section::$table_name)
			->where('special_id', '=', $id)
			->where('delete_user', '=', 0)
			->execute();

		$this->_ajax_return($list, 1, 'success');
	}

	//获取label标签json数据
	public function ajax_label_list()
	{
		$content = strip_tags(req::item('content'));

		$url = 'http://api.bosonnlp.com/keywords/analysis?top_k=5';
		$header = array(
			'Content-Type:application/json',
			'Accept:application/json',
			'X-Token:eeHjTFI9.25872.PLeuBaW4Qp6B',
		);

		$params = array($content);
		$label_list = $this->_http($url, $params, 'POST', $header);

		$list = array ();
		if(!empty($label_list))
		{
			foreach ($label_list[0] as $k => $v)
			{
				$list[] = $v[1];
			}
		}

		$this->_ajax_return($list, 1, 'success');
	}

	//获取视频时长
	private function _get_video_time_length($file){

		if(empty($file) || !file_exists($file))
		{
			return false;
		}

		$vtime = exec("/usr/local/Cellar/ffmpeg/4.0/bin/ffmpeg -i ".$file." 2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,//");//总长度

		//转化为秒
		$duration = explode(":",$vtime);
		$duration_in_seconds = $duration[0]*3600 + $duration[1]*60+ round($duration[2]);

		return sprintf("%02d", floor($duration_in_seconds/60)). ':' . sprintf("%02d", $duration_in_seconds%60);
	}


	//表单验证
	private function _validate()
	{
		$type = req::item('type', '3', 'int');

		$config = array(
			array(
				'field' => 'title',
				'rules' => 'required',
				'errors' => array(
					'required' => '标题不能为空',
				),
			),
			array(
				'field' => 'channel_ids[]',
				'rules' => 'required',
				'errors' => array(
					'required' => '请选择频道',
				),
			),
		);

		if($type == 1)
		{
			$config[] = array(
				'field' => 'content',
				'rules' => 'required',
				'errors' => array(
					'required' => '内容不能为空',
				),
			);
		}

		if($type == 2)
		{
			$config[] = array(
				'field' => 'video[]',
				'rules' => 'required',
				'errors' => array(
					'required' => '请上传视频',
				),
			);

		}

		if($type == 4)
		{
			$config[] = array(
				'field' => 'atlas_img',
				'rules' => 'required',
				'errors' => array(
					'required' => '请上传图集图片',
				),
			);

			$config[] = array(
				'field' => 'atlas_desc',
				'rules' => 'required',
				'errors' => array(
					'required' => '图集图片描述不能为空！',
				),
			);
		}

		if($type != 4)
		{
			$config[] = array(
				'field' => 'cover_img[]',
				'rules' => 'required',
				'errors' => array(
					'required' => '请上传封面图',
				),
			);

		}

		$instance = cls_validation::instance();
		$instance->set_rules($config);

		if ($instance->run() === FALSE)
		{
			$error = $instance->error();
			cls_msgbox::show('系统提示', $error, '-1');
		}

	}

	//返回json数据
	private function _ajax_return($array, $status = 1, $msg = 'success')
	{
		$return_data = array(
			'status' => $status,
			'msg' => $msg,
			'data' => $array,
		);

		//header('Content-type: application/json');
		exit(json_encode($return_data, JSON_UNESCAPED_UNICODE));
	}

	//跳转URL
	private function _go_url()
	{
		$list_type = req::item('list_type', '0', 'int');

		switch ($list_type)
		{
			//已发表
			case 1:
				$gourl = '?ct=news&ac=publish_list';
				break;
			//草稿
			case 2:
				$gourl = '?ct=news&ac=draft_list';
				break;
			//已删除
			case 3:
				$gourl = '?ct=news&ac=del_list';
				break;
			//全部
			default:
				$gourl = '?ct=news&ac=index';
				break;
		}

		return $gourl;
	}

	/**
	 * 发送HTTP请求方法，目前只支持CURL发送请求
	 *
	 * @param  string $url    请求URL
	 * @param  array  $params 请求参数
	 * @param  string $method 请求方法GET/POST
	 * @param  array  $header 发送头部信息 例如:$header = array('token:JxRaZezavm3HXM3d9pWnYiqqQC1SJbsU','language:zh','region:GZ');
	 *
	 * @return array   $data   响应数据
	 * @author 、lin
	 */
	private function _http($url, $params = array(), $method = 'GET', $header = array())
	{
		if($method != 'GET' && !empty($params)) $params = json_encode($params, JSON_UNESCAPED_UNICODE);
		$opts = array(
			CURLOPT_TIMEOUT => 30,
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_SSL_VERIFYPEER => FALSE,
			CURLOPT_SSL_VERIFYHOST => FALSE,
		);
		/* 根据请求类型设置特定参数 */
		switch(strtoupper($method)) {
			case 'GET':
				$getQuerys = !empty($params) ? '?' . http_build_query($params) : '';
				$opts[CURLOPT_URL] = $url . $getQuerys;
				break;
			case 'POST':
				$opts[CURLOPT_URL] = $url;
				$opts[CURLOPT_POST] = 1;
				$opts[CURLOPT_POSTFIELDS] = $params;
				break;
		}

		$opts[CURLOPT_HTTPHEADER] = $header;

		/* 初始化并执行curl请求 */
		$ch = curl_init();
		curl_setopt_array($ch, $opts);
		$data = curl_exec($ch);
		$err = curl_errno($ch);
		$errmsg = curl_error($ch);
		curl_close($ch);
		if($err > 0) {
			return $errmsg;
		} else {
			return json_decode($data, TRUE);
		}
	}

}
