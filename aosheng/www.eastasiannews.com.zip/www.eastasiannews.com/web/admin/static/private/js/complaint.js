$(function() {
    // echart demo
    var dom = document.querySelector(".chart-wrap");
    var myChart = echarts.init(dom);

    var option = {
        tooltip : {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        series : [
            {
                type: 'pie',
                radius : '65%',
                center: ['50%', '50%'],
                selectedMode: 'single',
                data:[
                    {value:30, name: '恶意投诉'},
                    {value:50, name: '确认投诉属实'},
                    {value:20, name: '其他'},
                ],
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };

    if (option && typeof option === "object") {
        myChart.setOption(option, true);
    }

    // 投诉处理  textarea联动
    $("input[name='resolve']").change(function() {
        if($(this).val() == 2) {
            $(".resolve-con").show();
        } else {
            $(".resolve-con").hide();
        }
    })
})