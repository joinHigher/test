<?php
/**
 * This file is part of phpspider.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author    seatle<seatle@foxmail.com>
 * @copyright seatle<seatle@foxmail.com>
 * @link      http://www.phpspider.org/
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
//namespace phpcall;

/**
 * autoloader.
 */
class phpcall_autoloader
{
    /**
     * Autoload root path.
     *
     * @var string
     */
    protected static $_autoload_root_path = '';

    /**
     * Set autoload root path.
     *
     * @param string $root_path
     * @return void
     */
    public static function set_root_path($root_path)
    {
        self::$_autoload_root_path = $root_path;
    }

    /**
     * 自动加载类库处理
     * 加载优先级 /call/library => 应用目录/model => 根目录/model
     * (如果不在这些位置, 则需自行手工加载，对于小型项目，也可以把model全放到library以减少类文件查找时间)
     * @return void
     */
    public static function load($class)
    {
        $class = preg_replace("/[^0-9a-z_]/i", '', $class);
        $class = strtolower($class);
        // smarty 的类库，不要去加载
        if (strpos($class, 'smarty') !== false) 
        {
            return;
        }

        $classfile = $class.'.php';
        try
        {
            $file = '';
            if ( is_file ( PATH_LIBRARY.'/'.$classfile ) )
            {
                $file = PATH_LIBRARY.'/'.$classfile;
            }
            else if( is_file ( PATH_MODEL.'/'.$classfile ) )
            {
                $file = PATH_MODEL.'/'.$classfile;
            }
            else if( is_file ( PHPCALL.'/model/'.$classfile ) )
            {
                $file = PHPCALL.'/model/'.$classfile;
            }
            else
            {
                throw new Exception ( 'Error: Cannot find the '.$class );
            }
            //echo $file."\n";
            require $file;

            // if the loaded file contains a class...
            if (class_exists($class, false))
            {
                if (method_exists($class, 'init') and is_callable($class.'::init'))
                {
                    call_user_func($class.'::init');
                }
            }
            // or an interface...
            elseif (interface_exists($class, false))
            {
                // nothing to do here
            }
            // or a trait if you're not on 5.3 anymore...
            elseif (function_exists('trait_exists') and trait_exists($class, false))
            {
                // nothing to do here
            }
            // else something went wrong somewhere, barf and exit now
            elseif ($file)
            {
                throw new Exception("File {$file} does not contain class {$class}");
            }
            else 
            {
                throw new Exception('Class "'.$class.'" is not defined');
            }

        }
        catch ( Exception $e )
        {
            call::fatal_error( 'autoloader.php load()', $e->getMessage().'|'.$class.' url:'.util::get_cururl() );
        }
    }

    /**
     * Load files by namespace.
     *
     * @param string $name
     * @return boolean
     */
    public static function load_by_namespace($name)
    {
        $class_path = str_replace('\\', DIRECTORY_SEPARATOR, $name);

        if (strpos($name, 'phpspider\\') === 0) 
        {
            $class_file = __DIR__ . substr($class_path, strlen('phpspider')) . '.php';
        }
        else 
        {
            if (self::$_autoload_root_path) 
            {
                $class_file = self::$_autoload_root_path . DIRECTORY_SEPARATOR . $class_path . '.php';
            }
            if (empty($class_file) || !is_file($class_file)) 
            {
                $class_file = __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . "$class_path.php";
            }
        }

        if (is_file($class_file)) 
        {
            require_once($class_file);
            if (class_exists($name, false)) 
            {
                return true;
            }
        }
        return false;
    }

}

/**
 * 自动加载类库处理
 * 加载优先级 /core/library => 应用目录/model => 根目录/model
 * (如果不在这些位置, 则需自行手工加载，对于小型项目，也可以把model全放到library以减少类文件查找时间)
 */
//注册autoload类
if (version_compare(phpversion(), '5.3.0', '>=')) 
{
    spl_autoload_register('phpcall_autoloader::load', true, false);
}
else 
{
    spl_autoload_register('phpcall_autoloader::load');
}
//spl_autoload_register('phpcall_autoloader::load_by_namespace');

/* vim: set expandtab: */

