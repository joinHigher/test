<?php
header('Access-Control-Allow-Origin: *');
require '../core/call.php';

//只允许某个域名
//header('Access-Control-Allow-Origin:'. URL_H5);
 //header('Access-Control-Allow-Origin:*');
//允许访问的方式
header('Access-Control-Allow-Method:POST,GET');

// 所有访问开启程序分析器
//cls_profiler::instance()->enable_profiler(true);

//设置时区
$time_zone = req::item('time_zone', '-8');
$time_zone = "Etc/GMT{$time_zone}";
date_default_timezone_set( $time_zone );

$app_config = [];
$app = new call( $app_config );
$app->run();
