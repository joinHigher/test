<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 文件上传
 * $FILES[ 'file' ][ 'error' ]一共有7种类型：
 * 1、UPLOAD_ERR_OK
 * 其值为 0，没有错误发生，文件上传成功。
 * 2、UPLOAD_ERR_INI_SIZE
 * 其值为 1，上传的文件超过了 php.ini 中 upload_max_filesize选项限制的值。
 * 3、UPLOAD_ERR_FORM_SIZE
 * 其值为 2，上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值。
 * 4、UPLOAD_ERR_PARTIAL
 * 其值为 3，文件只有部分被上传。
 * 5、UPLOAD_ERR_NO_FILE
 * 其值为 4，没有文件被上传。
 * 6、UPLOAD_ERR_NO_TMP_DIR
 * 其值为 6，找不到临时文件夹。PHP 4.3.10 和 PHP 5.0.3 引进。
 * 7、UPLOAD_ERR_CANT_WRITE
 * 其值为 7，文件写入失败。PHP 5.1.0 引进。
 *
 */
class ctl_upload
{
    public static $allowed_ext = array(
        'image' => array('jpg', 'jpeg', 'gif', 'png', 'bmp', 'webp'),
        'flash' => array('swf', 'flv'),
        'media' => array('swf', 'flv', 'mp3', 'wav', 'wma', 'wmv', 'mid', 'avi', 'mpg', 'asf', 'rm', 'rmvb'),
        'file' => array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'htm', 'html', 'txt', 'zip', 'rar', 'gz', 'bz2'),
    );

	public function index()
	{
		// file 文件表单名称
		$guid       = req::item("guid", util::random('alnum', 32));
		$tmp_path   = req::item("tmp_path", 'tmp');      // 文件上传临时目录
		$chunk      = req::item("chunk", 0, 'int');
		$chunks     = req::item("chunks", 1, 'int');

		$result = mod_upload::index($tmp_path, $guid, $chunk, $chunks);

		if($result === false)
		{
			mod_response::error(mod_upload::$err_msg, mod_upload::$err_code);
		}

		mod_response::success($result);
	}

}
