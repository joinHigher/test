<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 客户中心控制器
 *
 * @version $Id$
 */
class ctl_member_center
{
	//列表分页数量
	const LIST_PAGE_SIZE = 10;

	//客户信息
	protected $user_info = array ();

	function __construct()
	{
		$info = mod_member::get_info();
		if($info === false)
		{
			mod_response::error(mod_member::$err_msg, mod_member::$err_code);
		}
		else
		{
			$this->user_info = $info;
		}
	}

	//首页
	public function index()
	{
		/*
		$this->user_info['level_name'] = db::select('name')->from('#PB#_member_level')
			->where('id', '=', $this->user_info['level_id'])
			->as_field()
			->execute();
		*/

		mod_response::success($this->user_info);
	}

	//修改头像
	public function edit_head_img()
	{

		// file 文件表单名称
		$guid       = req::item("guid", util::random('alnum', 32));
		$tmp_path   = req::item("tmp_path", 'image');      // 文件上传临时目录
		$chunk      = req::item("chunk", 0, 'int');
		$chunks     = req::item("chunks", 1, 'int');

		$result = mod_upload::index($tmp_path, $guid, $chunk, $chunks);

		if($result === false)
		{
			mod_response::error(mod_upload::$err_msg, mod_upload::$err_code);
		}

		//修改会员头像
		$update_data = array ();
		$update_data['head_img'] = $result['filename'];
		$update_data['update_user'] = $this->user_info['id'];
		$update_data['update_time'] = time();

		$update_result = db::update(mod_member::$table_name)
			->where('id', '=', $this->user_info['id'])
			->set($update_data)
			->execute();

		if(empty($update_result))
		{
			mod_response::error('修改会员头像失败');
		}

		unset($result['filename']);
		$result['update_result'] = $update_result;

		mod_response::success($result);
	}

	//修改呢称
	public function edit_nickname()
	{
		$name = req::item('name');

		if(empty($name))
		{
			mod_response::error('昵称不能为空');
		}

		$update_data = array ();
		$update_data['nickname'] = $name;
		$update_data['update_time'] = time();

		$result = db::update(mod_member::$table_name)->set($update_data)
			->where('id', $this->user_info['id'])
			->execute();

		if(empty($result))
		{
			mod_response::error('修改昵称失败');
		}

		mod_response::success();
	}

	//修改密码
	public function edit_password()
	{
		$old_password = req::item('old_password');
		$new_password = req::item('new_password');

		if(empty($old_password))
		{
			mod_response::error('旧密码不能为空');
		}

		if(empty($new_password))
		{
			mod_response::error('新密码不能为空');
		}

		if (pub_mod_member::get_password($old_password) != $this->user_info['password'])
		{
			mod_response::error('旧密码不正确');
		}

		//修改用户密码
		$update_data = array ();
		$update_data['password'] = pub_mod_member::get_password($new_password);
		$update_data['update_time'] = time();

		$result = db::update(mod_member::$table_name)->set($update_data)
			->where('id', $this->user_info['id'])
			->execute();

		if(empty($result))
		{
			mod_response::error('修改密码失败');
		}

		mod_response::success();
	}

	//收藏
	public function get_collect()
	{

		$page_no = req::item('page_no', 1, 'int');
		$page_size = req::item('page_size', self::LIST_PAGE_SIZE);
		$page_no = $page_no <= 0 ? 1 : $page_no;

		$where = array ();
		$where[] = array ('#PB#_member_collect_log.member_id', '=', $this->user_info['id']);
		$where[] = array ('#PB#_member_collect_log.delete_user', '=', 0);
		$where[] = array (mod_news::$table_name.'.is_issue', '=', 1);
		$where[] = array (mod_news::$table_name.'.delete_user', '=', 0);

		$count = db::select('count(*) AS `count`')
			->from('#PB#_member_collect_log')
			->join(mod_news::$table_name, 'LEFT')
			->on('#PB#_member_collect_log.news_id', '=', mod_news::$table_name.'.id')
			->where($where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, $page_size);

		$field = array (
			'#PB#_member_collect_log.id id',
			mod_news::$table_name.'.type type',
			mod_news::$table_name.'.title title',
			mod_news::$table_name.'.cover_img cover_img',
			mod_news::$table_name.'.publisher publisher',
			mod_news::$table_name.'.browse_total browse_total',
			mod_news::$table_name.'.issue_time issue_time',
		);

		$news_list = db::select($field)->from('#PB#_member_collect_log')
			->join(mod_news::$table_name, 'LEFT')
			->on('#PB#_member_collect_log.news_id', '=', mod_news::$table_name.'.id')
			->where($where)
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->order_by('#PB#_member_collect_log.create_time', 'desc')
			->execute();

		if(!empty($news_list))
		{
			foreach ($news_list as $k => $v)
			{
				$news_list[$k]['cover_img'] = mod_news::handle_img($v['cover_img']);
				$news_list[$k]['issue_date'] = mod_news::handle_issue_time($v['issue_time']);
				$news_list[$k]['detail_url'] = mod_news::handle_url($v['id'], $v['type']);
			}
		}

		$news_list = empty($news_list) ? array () : $news_list;

		//是否有数据： 1=有，0=没有
		$is_have_data = (($page_no * $page_size) >= $count) ? 0 : 1;

		$list = array (
			'is_have_data' => $is_have_data,
			'list' => $news_list,
		);

		mod_response::success($list);
	}

	//删除收藏
	public function del_collect()
	{
		$ids = req::item('ids', array ());

		if(empty($ids))
		{
			mod_response::error('请选择需要删除的收藏');
		}

		if(!is_array($ids))
		{
			mod_response::error('参数类型不正确');
		}

		$update_data = array ();
		$update_data['delete_user'] = $this->user_info['id'];
		$update_data['delete_time'] = time();

		$result = db::update('#PB#_member_collect_log')
			->where('id', 'in', $ids)
			->where('member_id', '=', $this->user_info['id'])
			->set($update_data)
			->execute();

		if(empty($result))
		{
			mod_response::error('删除失败');
		}


		mod_response::success();
	}

	//消息
	public function message_list()
	{
		$page_no = req::item('page_no', 1, 'int');
		$page_size = req::item('page_size', self::LIST_PAGE_SIZE);
		$page_no = $page_no <= 0 ? 1 : $page_no;

		$field = array (
			'id',
			'type',
			'is_read',
			'foreign_id',
			'title',
			'describe',
			'remark',
			'create_time',
		);

		$where = array ();
		$where[] = array ('member_id', '=', $this->user_info['id']);
		$where[] = array ('delete_user', '=', 0);

		$count = db::select('count(*) AS `count`')
			->from('#PB#_message')
			->where($where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, $page_size);

		$list = db::select($field)->from('#PB#_message')
			->where($where)
			->order_by('create_time', 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		$new_list = array ();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$date_time = date('Y-m-d', $v['create_time']);

				$new_list[$date_time]['date'] = $date_time;
				$new_list[$date_time]['list'][] = $v;
			}
		}

		sort($new_list);

		//是否有数据： 1=有，0=没有
		$is_have_data = (($page_no * $page_size) >= $count) ? 0 : 1;

		$date_list = array (
			'is_have_data' => $is_have_data,
			'list' => $new_list,
		);

		mod_response::success($date_list);
	}

	//投诉详情
	public function complaint_detail()
	{
		$id = req::item('id');

		if(empty($id))
		{
			mod_response::error('消息ID不能为空');
		}

		$msg_info = db::select('id,is_read,foreign_id')->from(mod_message::$table_name)
			->where('id', '=', $id)
			->where('member_id', '=', $this->user_info['id'])
			->as_row()
			->execute();

		if(empty($msg_info))
		{
			mod_response::error('消息不存在');
		}

		$info = db::select(mod_member_complaint::$field)->from(mod_member_complaint::$table_name)
			->where('id', '=', $msg_info['foreign_id'])
			->where('member_id', '=', $this->user_info['id'])
			->as_row()
			->execute();

		if(empty($info))
		{
			mod_response::error('投诉消息不存在');
		}

		$info['detail_url'] = mod_news::handle_url($info['news_id'], $info['news_type']);

		//修改消息为已读
		if($msg_info['is_read'] == 0)
		{
			$update_date = array ();
			$update_date['is_read'] = 1;
			$update_date['update_user'] = $this->user_info['id'];
			$update_date['update_time'] = time();
			db::update(mod_message::$table_name)->set($update_date)->execute();
		}

		mod_response::success($info);
	}

	//反馈详情
	public function feedback_detail()
	{
		$id = req::item('id');

		if(empty($id))
		{
			mod_response::error('消息ID不能为空');
		}

		$msg_info = db::select('id,is_read,foreign_id')->from(mod_message::$table_name)
			->where('id', '=', $id)
			->where('member_id', '=', $this->user_info['id'])
			->as_row()
			->execute();

		if(empty($msg_info))
		{
			mod_response::error('消息不存在');
		}

		$info = db::select(mod_member_feedback::$field)->from(mod_member_feedback::$table_name)
			->where('id', '=', $msg_info['foreign_id'])
			->where('member_id', '=', $this->user_info['id'])
			->as_row()
			->execute();

		if(empty($info))
		{
			mod_response::error('反馈消息不存在');
		}

		$info['img'] = mod_news::handle_img($info['img']);

		//修改消息为已读
		if($msg_info['is_read'] == 0)
		{
			$update_date = array ();
			$update_date['is_read'] = 1;
			$update_date['update_user'] = $this->user_info['id'];
			$update_date['update_time'] = time();
			db::update(mod_message::$table_name)->set($update_date)->execute();
		}

		mod_response::success($info);
	}

	//系统详情
	public function system_detail()
	{
		$id = req::item('id');

		if(empty($id))
		{
			mod_response::error('消息ID不能为空');
		}

		$msg_info = db::select('id,is_read,title,describe,create_time')->from(mod_message::$table_name)
			->where('id', '=', $id)
			->where('member_id', '=', $this->user_info['id'])
			->as_row()
			->execute();

		if(empty($msg_info))
		{
			mod_response::error('消息不存在');
		}

		//修改消息为已读
		if($msg_info['is_read'] == 0)
		{
			$update_date = array ();
			$update_date['is_read'] = 1;
			$update_date['update_user'] = $this->user_info['id'];
			$update_date['update_time'] = time();
			db::update(mod_message::$table_name)->set($update_date)->execute();
		}

		unset($msg_info['is_read']);

		mod_response::success($msg_info);
	}

	//添加反馈
	public function add_feedback()
	{
		$img = req::item('img', array ());
		$content = req::item('content');

		if(empty($content))
		{
			mod_response::error('反馈内容不能为空');
		}

		$add_data = array ();
		$add_data['create_user'] = $add_data['member_id'] = $this->user_info['id'];
		$add_data['member_name'] = empty($this->user_info['nickname']) ? $this->user_info['account'] : $this->user_info['nickname'];
		$add_data['status'] = 0;
		if(!empty($img)) $add_data['img'] = implode(',', $img);
		$add_data['content'] = $content;
		$add_data['create_time'] = time();

		list($result, $rows_affected) = db::insert('#PB#_member_feedback')->set($add_data)->execute();

		if($result)
		{
			//转移图片文件
			if(!empty($img)) pub_mod_news::move_file($img);

			mod_response::success();
		}
		else
		{
			mod_response::error('反馈失败');
		}
	}

	//添加会员想看的新闻等级
	public function add_show_levels()
	{
		$levels = req::item('levels', array ());

		if(empty($levels))
		{
			mod_response::error('请选择等级');
		}

		$update_data = array ();
		$update_data['show_level_ids'] = implode(',', $levels);
		$update_data['update_time'] = time();
		$update_data['update_user'] = $this->user_info['id'];

		$result = db::update(mod_member::$table_name)->set($update_data)
			->where('id', $this->user_info['id'])
			->execute();

		if(empty($result))
		{
			mod_response::error('添加过滤新闻失败');
		}

		mod_response::success();
	}

}
