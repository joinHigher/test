<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 客户控制器
 *
 * @version $Id$
 */
class ctl_member
{
	function __construct()
	{

	}

	//用户登录
	public function login()
	{
		//用户标示
		$userid = req::item('userid');
		$username = req::item('username');
		$password = req::item('password');
		$device = req::item('device', '');
		$system = req::item('system', '');
		$network_type = req::item('network_type', '');
		$country_en_short_name = req::item('country_en_short_name', '');

		if (empty($username))
		{
			mod_response::error('账号不能为空');
		}

		if (empty($password))
		{
			mod_response::error('密码不能为空');
		}

		if(empty(cls_validation::instance()->email($username)))
		{
			$info = db::select(mod_member::$field)
				->from(mod_member::$table_name)
				->where('account', $username)
				->as_row()
				->execute();
		}
		else
		{
			$info = db::select(mod_member::$field)
				->from(mod_member::$table_name)
				->where('email', $username)
				->as_row()
				->execute();
		}

		if (empty($info) || $info['password'] !== pub_mod_member::get_password($password))
		{
			mod_response::error('账号或密码错误');
		}

		try {

			// 获取token
			$token = mod_member::get_token($info['id']);

			// 更新token
			$update_data = array ();
			$update_data['token'] = $token;
			$update_data['login_time'] = $update_data['update_time'] = time();
			$update_data['update_user'] = $info['id'];

			db::update(mod_member::$table_name)->set($update_data)->where('id', $info['id'])->execute();

			$info['token'] = $token;
			unset($info['password']);

			//添加登录记录
			$add_data = array ();
			$add_data['create_user'] = $add_data['member_id'] = $info['id'];
			$add_data['login_ip'] = util::get_client_ip();
			$add_data['device'] = $device;
			$add_data['system'] = $system;
			$add_data['network_type'] = $network_type;
			$add_data['country'] = $country_en_short_name;
			$add_data['create_time'] = time();

			db::insert('#PB#_member_login_log')->set($add_data)->execute();

			$info['head_img'] = empty($info['head_img']) ? '' : URL_UPLOADS . '/image/' . $info['head_img'];

			/********  修改设置的频道开始 ********/

			//查找用户是否已经设置
			$userid_count = db::select('COUNT(*) count')->from(mod_member_channel::$table_name)
				->where('member_id', '=', $userid)
				->as_field()
				->execute();

			/********  修改设置的频道结束 ********/

			$list = array (
				'member_info' => $info,
				'member_channel' => mod_member_channel::get_member_channel(self::$userid, $info['id']),
				'area_list' => pub_mod_area::get_all_list(),
				'news_channel_list' => pub_mod_channel::get_all_list('', 1),
				'video_channel_list' => pub_mod_channel::get_all_list('', 1),
			);

			//修改浏览记录
			db::update('#PB#_member_news')->where('member_id', $userid)->set([
					'member_id' => $info['id'],
				])->execute();

			mod_response::success($list);
		}
		catch (Exception $e)
		{
			mod_response::error('服务器错误，请稍后重试');
		}
	}

	//退出
	public function logout()
	{
		try {

			$info = mod_member::get_info();
			if($info === false)
			{
				mod_response::error(mod_member::$err_msg, mod_member::$err_code);
			}

			// 退出登录
			$update_data = array ();
			$update_data['token'] = '';
			$update_data['update_time'] = time();
			$update_data['update_user'] = $info['id'];

			db::update(mod_member::$table_name)->set($update_data)->where('id', $info['id'])->execute();

			mod_response::success();

		}
		catch (Exception $e)
		{
			mod_response::error('服务器错误，请稍后重试');
		}
	}

	//注册
	public function register()
	{
		$account = req::item('account');
		$password = req::item('password');
		$email = req::item('email');
		$device = req::item('device');
		$system = req::item('system', '');
		$network_type = req::item('network_type', '');
		$country_en_short_name = req::item('country_en_short_name', '');

		if(empty($account))
		{
			mod_response::error('用户名不能为空');
		}

		if(empty($password))
		{
			mod_response::error('密码不能为空');
		}

		if(empty($email))
		{
			mod_response::error('邮箱不能为空');
		}

		if(empty(cls_validation::instance()->email($email)))
		{
			mod_response::error('邮箱格式不正确');
		}

		//验证用户名是否存在,并且唯一
		$count = db::select('COUNT(*) count')->from(mod_member::$table_name)
			->where('account', '=', $account)
			->as_field()
			->execute();

		if($count > 0)
		{
			mod_response::error('用户名已经存在');
		}

		//验证邮箱是否存在,并且唯一
		$count = db::select('COUNT(*) count')->from(mod_member::$table_name)
			->where('email', '=', $email)
			->as_field()
			->execute();

		if($count > 0)
		{
			mod_response::error('邮箱已经存在');
		}

		//添加用户
		$add_data = array ();
		$add_data['level_id'] = 0;
		$add_data['sex'] = 0;
		$add_data['account'] = $account;
		$add_data['password'] = pub_mod_member::get_password($password);
		$add_data['email'] = $email;
		$add_data['status'] = 0;
		$add_data['reg_ip'] = util::get_client_ip();
		$add_data['device'] = $device;
		$add_data['update_time'] = $add_data['create_time'] = time();

		list($insert_id, $rows_affected) = db::insert(mod_member::$table_name)->set($add_data)->execute();

		if(empty($insert_id))
		{
			mod_response::error('注册会员失败');
		}

		// 更新token
		$token = mod_member::get_token($insert_id);
		$update_data = array ();
		$update_data['token'] = $token;
		$update_data['login_time'] = time();
		$update_data['update_user'] = $insert_id;

		$result = db::update(mod_member::$table_name)->set($update_data)->where('id', $insert_id)->execute();

		if(empty($result))
		{
			mod_response::error('注册会员失败');
		}

		//添加登录记录
		$add_data = array ();
		$add_data['create_user'] = $add_data['member_id'] = $insert_id;
		$add_data['login_ip'] = util::get_client_ip();
		$add_data['device'] = $device;
		$add_data['system'] = $system;
		$add_data['network_type'] = $network_type;
		$add_data['country'] = $country_en_short_name;
		$add_data['create_time'] = time();

		db::insert('#PB#_member_login_log')->set($add_data)->execute();

		$info = array(
			'id' => $insert_id,
			'token' => $token,
			'account' => $account,
			'email' => $email,
			'level_id' => 0,
			'sex' => 0,
			'nickname' => '',
			'head_img' => '',
			'profession' => '',
			'interest' => '',
		);

		$list = array (
			'member_info' => $info,
		);

		mod_response::success($list);
	}

	//忘记密码
	public function forget_password()
	{
		$email = req::item('email');
		$code = req::item('code');
		$password = req::item('password');

		if(empty($email))
		{
			mod_response::error('邮箱不能为空');
		}

		if(empty(cls_validation::instance()->email($email)))
		{
			mod_response::error('邮箱格式不正确');
		}

		if(empty($code))
		{
			mod_response::error('验证码不能为空');
		}

		if(empty($password))
		{
			mod_response::error('新密码不能为空');
		}

		//判断验证码是否正确，有效时间1小时
		$code_info = db::select('id,code')->from('#PB#_member_verify_code_log')
			->where('type', '=', 1)
			->where('account', '=', $email)
			->where('is_use', '=', 0)
			->where('create_time', '<=', strtotime(' +1 hour'))
			->order_by('id', 'desc')
			->as_row()
			->execute();

		if(empty($code_info) || $code != $code_info['code'])
		{
			mod_response::error('邮箱或者验证码不正确');
		}

		//修改用户密码
		$update_data = array ();
		$update_data['password'] = pub_mod_member::get_password($password);
		$update_data['update_time'] = time();

		$result = db::update(mod_member::$table_name)->set($update_data)
			->where('email', $email)
			->execute();

		//修改验证码状态
		$update_data = array ();
		$update_data['is_use'] = 1;
		$update_data['update_time'] = time();

		db::update('#PB#_member_verify_code_log')->set($update_data)
			->where('id', $code_info['id'])
			->execute();
		
		if(empty($result))
		{
			mod_response::error('重置密码失败');
		}
		
		mod_response::success();
	}

	//发送邮件
	public function send_email()
	{
		$email = req::item('email');

		if(empty($email))
		{
			mod_response::error('邮箱不能为空');
		}

		if(empty(cls_validation::instance()->email($email)))
		{
			mod_response::error('邮箱格式不正确');
		}

		$code = util::random('numeric', 6);
		$email_name = '东亚新闻';
		$email_title = '重置密码';
		$email_content = '亲爱的用户：</br>
							您好！感谢您使用东亚新闻，您正在进行邮箱验证，本次请求的验证码为：<span style="color: #cc6600;">'. $code .' </span>（为了保障您账号的安全性，请在1小时内完成验证。）</br>

						 东亚新闻运营团队';

		$send_account = $GLOBALS['config']['send_email'];

		$mail = new cls_mail();
		//$mail->debug = true;
		//设置smtp服务器，到服务器的SSL连接
		$mail->setServer($send_account['host'], $send_account['user'], $send_account['pass']);
		//设置发件人
		$mail->setFrom($send_account['user']);
		//发件人呢称
		$mail->setEmailName($email_name);
		//设置收件人，多个收件人，调用多次
		$mail->setReceiver($email);

		//设置邮件主题、内容
		$mail->setMail($email_title, $email_content);
		//发送
		$result = $mail->sendMail();

		if($result)
		{
			//插入邮箱验证内容
			$add_data = array ();
			$add_data['type'] = 1;
			$add_data['is_use'] = 0;
			$add_data['account'] = $email;
			$add_data['code'] = $code;
			$add_data['create_time'] = time();

			db::insert('#PB#_member_verify_code_log')->set($add_data)->execute();

			mod_response::success();
		}
		else
		{
			mod_response::error('发送失败');
		}
	}

	//添加用户选择的频道
	public function change_select_channel()
	{
		//用户标示
		$userid = req::item('userid');
		//频道类型：0=新闻，1=视频
		$type = req::item('type', 0 , 'int');
		$countrys = req::item('countrys');
		$channel_ids = req::item('channel_ids');
		//用户自己的排序
		$sort_channels = req::item('sort_channels');

		if(empty($channel_ids))
		{
			mod_response::error('精选频道不能为空');
		}

		if(empty($sort_channels))
		{
			mod_response::error('用户排序的频道不能为空');
		}

		//判断用户是否登录
		$info = mod_member::get_info();
		if($info === false)
		{
			//查找用户是否已经设置
			$count = db::select('COUNT(*) count')->from(mod_member_channel::$table_name)
				->where('member_id', '=', $userid)
				->where('type', '=', $type)
				->as_field()
				->execute();

			$edit_data = array ();
			$edit_data['member_id'] = $userid;
			$edit_data['type'] = $type;
			$edit_data['common_channel'] = implode(',', $channel_ids);
			$edit_data['country_channel'] = implode(',', $countrys);
			$edit_data['sort_channel'] = implode(',', $sort_channels);

			if($count > 0)
			{
				//存在旧数据则删除
				db::delete(mod_member_channel::$table_name)->set($edit_data)
					->where('member_id', '=', $userid)
					->where('type', '=', $type)
					->execute();
			}

			$result = db::insert(mod_member_channel::$table_name)->set($edit_data)->execute();
		}
		else
		{
			//查找用户是否已经设置
			$count = db::select('COUNT(*) count')->from(mod_member_channel::$table_name)
				->where('member_id', '=', $info['id'])
				->where('type', '=', $type)
				->as_field()
				->execute();

			$edit_data = array ();
			$edit_data['member_id'] = $info['id'];
			$edit_data['type'] = $type;
			$edit_data['common_channel'] = implode(',', $channel_ids);
			$edit_data['country_channel'] = implode(',', $countrys);
			$edit_data['sort_channel'] = implode(',', $sort_channels);

			if($count > 0)
			{
				db::delete(mod_member_channel::$table_name)->set($edit_data)
					->where('member_id', '=', $info['id'])
					->where('type', '=', $type)
					->execute();
			}

			$result = db::insert(mod_member_channel::$table_name)->set($edit_data)->execute();

			//修改成功删除未登录设置的频道
			if(!empty($result))
			{
				db::delete(mod_member_channel::$table_name)->where('member_id', $userid)->execute();
			}
		}

		if(empty($result))
		{
			mod_response::error('添加新闻频道失败');
		}

		mod_response::success();
	}
}
