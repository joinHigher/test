<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 新闻控制器
 *
 * @version $Id$
 */
class ctl_news
{

	//列表分页数量
	const LIST_PAGE_SIZE = 10;

	//专题章节新闻分页数量
	const SPECIAL_SECTION_NEWS_PAGE_SIZE = 4;

	//详情推荐新闻数量
	const DETAIL_PAGE_SIZE = 5;

	//客户信息
	public static $member_info = array ();

	function __construct()
	{
		$info = mod_member::get_info();
		if($info === false)
		{
			return true;
		}

		self::$member_info = $info;
	}

	//首页
	public function index()
	{
		$country_short_name = req::item('country_short_name', 'GLOBAL');
		$channel_id = req::item('channel_id');
		$page_no = req::item('page_no', 1, 'int');
		$page_size = req::item('page_size', self::LIST_PAGE_SIZE);
		$page_no = $page_no <= 0 ? 1 : $page_no;

		$field = mod_news::get_list_field();

		$where = array ();
		$where[] = array ('is_issue', '=', 1);

		if(!empty(self::$member_info))
		{
			$where[] = array ('level_id', '<=', self::$member_info['level_id']);
		}
		else
		{
			$where[] = array ('level_id', '<=', 0);
		}

		if($channel_id === 0)
		{
			$where[] = array ('is_main', '=', 1);
		}

		if(!empty($channel_id))
		{
			//判断频道是否有权限查看
			if(empty(self::$member_info))
			{
				if(mod_channel::is_valid($channel_id, 0) === false)
				{
					mod_response::error(mod_channel::$err_msg, mod_channel::$err_code);
				}
			}
			else
			{
				if(mod_channel::is_valid($channel_id, self::$member_info['level_id']) === false)
				{
					mod_response::error(mod_channel::$err_msg, mod_channel::$err_code);
				}
			}


			$where[] = array ('channel_ids', 'FIND_IN_SET', $channel_id);
		}

		$where[] = array ('delete_user', '=', 0);

		//置顶新闻,一条普通新闻，一条专题新闻
		if($page_no == 1)
		{
			if(empty($country_short_name) || $country_short_name == 'GLOBAL')
			{
				$special_top_list = db::select($field)->from(mod_news::$table_name)
					->where('type', '=', 3)
					->where('is_top', '=', 1)
					->where('countrys', '=', 'GLOBAL')
					->where($where)
					->limit(1)
					->order_by('sort', 'desc')
					->order_by('top_time', 'desc')
					->execute();

				$general_top_list = db::select($field)->from(mod_news::$table_name)
					->where('type', '!=', 3)
					->where('is_top', '=', 1)
					->where('countrys', '=', 'GLOBAL')
					->where($where)
					->limit(1)
					->order_by('sort', 'desc')
					->order_by('top_time', 'desc')
					->execute();
			}
			else
			{
				$special_top_list = db::select($field)->from(mod_news::$table_name)
					->where('type', '=', 3)
					->where('is_top', '=', 1)
					->or_where_open()
					->or_where('countrys', '=', 'GLOBAL')
					->or_where('countrys', 'FIND_IN_SET', $country_short_name)
					->or_where_close()
					->where($where)
					->limit(1)
					->order_by('sort', 'desc')
					->order_by('top_time', 'desc')
					->execute();

				$general_top_list = db::select($field)->from(mod_news::$table_name)
					->where('type', '!=', 3)
					->where('is_top', '=', 1)
					->or_where_open()
					->or_where('countrys', '=', 'GLOBAL')
					->or_where('countrys', 'FIND_IN_SET', $country_short_name)
					->or_where_close()
					->where($where)
					->limit(1)
					->order_by('sort', 'desc')
					->order_by('top_time', 'desc')
					->execute();
			}

			$special_top_list = empty($special_top_list) ? array () : $special_top_list;
			$general_top_list = empty($general_top_list) ? array () : $general_top_list;
			$top_list = array_merge($special_top_list, $general_top_list);

			//推荐新闻, 排除的新闻ID
			$recom_where = array ();
			$recom_where[] = array ('is_hot', '=', 1);
			$except_news_ids = array();
			if(!empty($special_top_list))
			{
				foreach ($special_top_list as $k => $v)
				{
					$except_news_ids[] = $v['id'];
				}
			}

			if(!empty($general_top_list))
			{
				foreach ($general_top_list as $k => $v)
				{
					$except_news_ids[] = $v['id'];
				}
			}

			if(!empty($except_news_ids))
			{
				$recom_where[] = array ('id', 'not in', $except_news_ids);
			}

			$recom_where = array_merge($recom_where, $where);

			if(empty($country_short_name) || $country_short_name == 'GLOBAL')
			{
				$recom_list = db::select($field)->from(mod_news::$table_name)
					->where($recom_where)
					->where('countrys', '=', 'GLOBAL')
					->limit(6)
					->order_by('sort', 'desc')
					->order_by('recom_time', 'desc')
					->execute();
			}
			else
			{
				$recom_list = db::select($field)->from(mod_news::$table_name)
					->where($recom_where)
					->or_where_open()
					->or_where('countrys', '=', 'GLOBAL')
					->or_where('countrys', 'FIND_IN_SET', $country_short_name)
					->or_where_close()
					->limit(6)
					->order_by('sort', 'desc')
					->order_by('recom_time', 'desc')
					->execute();
			}

			if(!empty($recom_list))
			{
				foreach ($recom_list as $k => $v)
				{
					$recom_list[$k] = mod_news::handle_news_data($v, false);
				}
			}

			if(!empty($recom_list))
			{
				$recom_list = array (
					array(
						'style_num' => 6,
						'detail_url' => URL_H5 . '/hot.html',
						'list' =>$recom_list
					)
				);
			}
		}

		//普通新闻
		if(empty($country_short_name) || $country_short_name == 'GLOBAL')
		{
			$count = db::select('COUNT(*) count')->from(mod_news::$table_name)
				//->where('is_top', '=', 0)
				//->where('is_hot', '=', 0)
				//->where('countrys', '=', 'GLOBAL')
				->where($where)
				->as_field()
				->execute();

			$pages = pub_page::make($count, $page_size);

			$general_list = db::select($field)->from(mod_news::$table_name)
				//->where('is_top', '=', 0)
				//->where('is_hot', '=', 0)
				//->where('countrys', '=', 'GLOBAL')
				->where($where)
				->limit($pages['page_size'])
				->offset($pages['offset'])
				->order_by('sort', 'desc')
				->order_by('issue_time', 'desc')
				->execute();
		}
		else
		{
			$count = db::select('COUNT(*) count')->from(mod_news::$table_name)
				->where('is_top', '=', 0)
				->where('is_hot', '=', 0)
				->where($where)
				->or_where_open()
				->or_where('countrys', '=', 'GLOBAL')
				->or_where('countrys', 'FIND_IN_SET', $country_short_name)
				->or_where_close()
				->as_field()
				->execute();

			$pages = pub_page::make($count, $page_size);

			$general_list = db::select($field)->from(mod_news::$table_name)
				->where('is_top', '=', 0)
				->where('is_hot', '=', 0)
				->where($where)
				->or_where_open()
				->or_where('countrys', '=', 'GLOBAL')
				->or_where('countrys', 'FIND_IN_SET', $country_short_name)
				->or_where_close()
				->limit($pages['page_size'])
				->offset($pages['offset'])
				->order_by('sort', 'desc')
				->order_by('issue_time', 'desc')
				->execute();
		}

		$top_list = empty($top_list) ? array () : $top_list;
		$recom_list = empty($recom_list) ? array () : $recom_list;
		$general_list = empty($general_list) ? array () : $general_list;
		$news_list = array_merge($top_list, $recom_list, $general_list);

		if(!empty($news_list))
		{
			foreach ($news_list as $k => $v)
			{
				if(isset($v['style_num']))
				{
					continue;
				}

				$news_list[$k] = mod_news::handle_news_data($v);
			}
		}

		//是否有数据： 1=有，0=没有
		$is_have_data = (($page_no * $page_size) >= $count) ? 0 : 1;

		$list = array (
			'is_have_data' => $is_have_data,
			'list' => $news_list,
		);

		mod_response::success($list);

	}

	//刷新获取新闻总数
	public function refreshs_count()
	{
		//刷新时间
		$refresh_time = req::item('refresh_time', 0, 'int');
		$country_short_name = req::item('country_short_name');
		$channel_id = req::item('channel_id', 0, 'int');

		if(empty($refresh_time))
		{
			mod_response::error('请传入刷新时间');
		}

		$where = array ();
		$where[] = array ('is_issue', '=', 1);

		if(!empty(self::$member_info))
		{
			$where[] = array ('level_id', '<=', self::$member_info['level_id']);
		}

		if(!empty($refresh_time))
		{
			$where[] = array ('issue_time', '>=', $refresh_time);
		}

		if(!empty($channel_id))
		{
			$where[] = array ('channel_ids', 'FIND_IN_SET', $channel_id);
		}

		if(!empty($country_short_name))
		{
			$where[] = array ('countrys', 'FIND_IN_SET', $country_short_name);
		}

		$where[] = array ('delete_user', '=', 0);

		//普通新闻
		$count = db::select('COUNT(*) count')->from(mod_news::$table_name)
			->where('is_top', '=', 0)
			->where('is_hot', '=', 0)
			->where($where)
			->as_field()
			->execute();

		$list = array (
			'count' => $count,
		);

		mod_response::success($list);
	}

	//获取列表
	public function get_list()
	{
		//用户标示
		$userid = req::item('userid');
		//浏览模式：0=经典模式，1=喜好模式
		$read_mode = req::item('read_mode', 0, 'int');
		$keyword = req::item('keyword');
		$is_hot = req::item('is_hot');
		$is_recom = req::item('is_recom', 0, 'int');
		$countrys = req::item('countrys');
		$channel_ids = req::item('channel_ids');
		$type = req::item('type', 0, 'int');
		$page_no = req::item('page_no', 1, 'int');
		$page_size = req::item('page_size', self::LIST_PAGE_SIZE);
		$page_no = $page_no <= 0 ? 1 : $page_no;

		$where = array ();

		if(!empty($type))
		{
			$where[] = array ('type', '=', $type);
		}

		if(!empty($is_hot))
		{
			$where[] = array ('is_hot', '=', intval($is_hot));
		}

		$where[] = array ('is_issue', '=', 1);

		if(!empty($keyword))
		{
			$where[] = array ('title', 'like', '%' . $keyword . '%');

			//添加搜索日志
			$add_data = array ();
			if(!empty(self::$member_info))
			{
				$add_data['create_user'] = $add_data['member_id'] = self::$member_info['id'];
			}

			$add_data['content'] = $keyword;
			$add_data['ip'] = util::get_client_ip();
			$add_data['create_time'] = time();

			db::insert('#PB#_member_search_log')->set($add_data)->execute();

		}

		//获取时间段的时间
		$where[] = array ('issue_time', '>=', strtotime(' -4 day'));

		$where[] = array ('delete_user', '=', 0);

		//判断频道会员是否有权限查看
		$channel_ids_list = array ();
		if(!empty($channel_ids))
		{
			$channel_ids_list = explode(',', $channel_ids);

			foreach ($channel_ids_list as $k => $channel_id)
			{
				//判断频道是否有权限查看
				if(empty(self::$member_info))
				{
					if(mod_channel::is_valid($channel_id, 0) === false)
					{
						mod_response::error(mod_channel::$err_msg, mod_channel::$err_code);
					}
				}
				else
				{
					if(mod_channel::is_valid($channel_id, self::$member_info['level_id']) === false)
					{
						mod_response::error(mod_channel::$err_msg, mod_channel::$err_code);
					}
				}
			}
		}

		//过滤用户浏览过的新闻
		if(!empty(self::$member_info))
		{
			$userid = self::$member_info['id'];
		}

		if(!empty($userid))
		{
			$remove_news_list = db::select('news_id')->from('#PB#_member_news')
				->where('member_id', $userid)
				->execute();

			if(!empty($remove_news_list))
			{
				$remove_news_ids = array ();
				foreach ($remove_news_list as $k => $v)
				{
					$remove_news_ids[] = $v['news_id'];
				}

				$where[] = array ('id', 'not in', $remove_news_ids);
			}
		}

		//过滤会员等级
		if(empty(self::$member_info) || (!empty(self::$member_info) && self::$member_info['level_id'] == 0))
		{
			$where[] = array ('level_id', '=', 0);
		}
		else
		{
			$where[] = array ('level_id', '<=', self::$member_info['level_id']);
			if(self::$member_info['show_level_ids']) $where[] = array ('level_id', 'in', explode(',', self::$member_info['show_level_ids']));
		}

		//获取专题新闻
		$special_top_list = array ();

		if(req::item('is_home_page') == 1)
		{
			$special_top_list = (array)db::select(mod_news::get_list_field())->from(mod_news::$table_name)
				->where('type', '=', 3)
				->where('is_top', '=', 1)
				->limit(1)
				->order_by('sort', 'desc')
				->order_by('top_time', 'desc')
				->execute();

			if(!empty($special_top_list))
			{
				$special_top_ids = array ();
				foreach ($special_top_list as $k => $v)
				{
					$special_top_list[$k] = mod_news::handle_news_data($v);
					$special_top_ids[] = $v['id'];
				}

				$where[] = array ('id', 'not in', $special_top_ids);
			}
		}

		//获取总数开始
		//$count_instance = db::select('COUNT(*) count')->from(mod_news::$table_name)->where($where);

		//where处理开始
		//$this->_get_list_handld_where($count_instance, $channel_ids_list, $countrys, $read_mode, $is_recom);

		//$count = $count_instance->as_field()->execute();

		//$pages = pub_page::make($count, $page_size);

		//获取列表开始
		$news_list_instance = db::select(mod_news::get_list_field())->from(mod_news::$table_name)->where($where);

		//where处理开始
		$this->_get_list_handld_where($news_list_instance, $channel_ids_list, $countrys, $read_mode, $is_recom);

		$count = rand(9,12);
		$news_list = (array)$news_list_instance
			//->order_by('is_top', 'desc')
			->order_by('rand()')
			//->order_by('sort', 'desc')
			//->order_by('issue_time', 'desc')
			->limit($count)
			//->offset($pages['offset'])
			->execute();

		//var_dump($news_list);die;
		if(!empty($news_list))
		{
			foreach ($news_list as $k => $v)
			{
				$news_list[$k] = mod_news::handle_news_data($v);

				//只有搜索视频新闻的时候才需要查找是否收藏
				if($type == 2)
				{
					$news_list[$k]['is_collect'] = 0;
					if(!empty(self::$member_info))
					{
						$count = db::select('COUNT(*) count')->from('#PB#_member_collect_log')
							->where('member_id', '=', self::$member_info['id'])
							->where('news_id', '=', $v['id'])
							->where('status', '=', 1)
							->as_field()
							->execute();

						$news_list[$k]['is_collect'] = $count > 0 ? 1 : 0;
					}
				}

				//添加浏览记录
				db::insert('#PB#_member_news')->set([
					  'member_id' => $userid,
					  'news_id' => $v['id'],
					  'create_time' => time(),
				  ])->execute();
			}
		}

		//是否有数据： 1=有，0=没有
		$is_have_data = (($page_no * $page_size) >= $count) ? 0 : 1;
		$is_have_data = 1;

		if(empty($news_list))
		{
			$where = array ();

			if(!empty($type))
			{
				$where[] = array ('type', '=', $type);
			}
			$news_list = (array)db::select(mod_news::get_list_field())->from(mod_news::$table_name)
				->where($where)
				->where('is_issue', 1)
				->where('delete_user', 0)
				->order_by('rand()')
				->limit($count)
				->execute();

			if(!empty($news_list))
			{
				foreach ($news_list as $k => $v)
				{
					$news_list[$k] = mod_news::handle_news_data($v);
				}
			}
		}

		$news_list = array_merge($special_top_list, $news_list);

		$list = array (
			'is_have_data' => $is_have_data,
			'count' => count($news_list),
			'list' => $news_list,
		);

		mod_response::success($list);
	}

	//获取新闻列表处理
	private function _get_list_handld_where($query_instance, $channel_ids_list, $countrys, $read_mode, $is_recom)
	{
		$is_main = 0;

		//频道处理
		if(!empty($channel_ids_list))
		{
			$query_instance->where_open();

			foreach ($channel_ids_list as $k => $channel_id)
			{
				//判断是否有要闻
				if($channel_id == 0)
				{
					$is_main = 1;
					continue;
				}

				$query_instance->or_where('channel_ids', 'FIND_IN_SET', $channel_id);
			}

			$query_instance->where_close();
		}

		if($is_main === 1) $query_instance->where('is_main', '=', $is_main);

		//国家处理
		if($read_mode === 1 && !empty($countrys))
		{
			$countrys_list = explode(',', $countrys);

			$query_instance->where_open();
			$query_instance->or_where('countrys', '=', 'GLOBAL');

			foreach ($countrys_list as $k => $en_country)
			{
				$query_instance->or_where('countrys', 'FIND_IN_SET', $en_country);
			}

			$query_instance->where_close();
		}

		//推荐新闻, 需要使用会员的label匹配数据
		if($is_recom === 1 && !empty(self::$member_info) && !empty(self::$member_info['label']))
		{
			$label_list = explode(',', self::$member_info['label']);

			$query_instance->where_open();
			$query_instance->or_where('countrys', '=', 'GLOBAL');

			foreach ($label_list as $k => $label)
			{
				$query_instance->or_where('label', 'FIND_IN_SET', $label);
			}

			$query_instance->where_close();
		}
	}

	//详情
	public function detail()
	{
		$id = req::item('id', 0, 'int');

		if(empty($id))
		{
			mod_response::error('请传入新闻ID');
		}

		$where = array ();

		$where[] = array ('is_issue', '=', 1);

		if(!empty(self::$member_info))
		{
			$where[] = array ('level_id', '<=', self::$member_info['level_id']);
		}

		$where[] = array ('delete_user', '=', 0);

		$info = db::select(mod_news::get_detail_field())->from(mod_news::$table_name)
			->where('id', '=', $id)
			->where($where)
			->as_row()
			->execute();

		if(empty($info))
		{
			mod_response::error('此新闻已经被删除', mod_error_code::NEWS_DELETE);
		}

		//判断用户等级
		if((empty(self::$member_info) && $info['level_id'] != 0) || (!empty(self::$member_info) && $info['level_id'] > self::$member_info['level_id']))
		{
			mod_response::error('该新闻暂未对外开放，如需帮助请联系客服人员。', mod_error_code::NEWS_NOT_AUTH);
		}

		//如果是专题新闻
		$special_section_list = array ();
		if($info['type'] == 3)
		{
			$special_section_list = $this->_get_special_section_list($id);
		}

		$info = mod_news::handle_news_data($info);
		$info['is_collect'] = 0;

		//判断该新闻是否已经被收藏
		if(!empty(self::$member_info))
		{
			$count = db::select('COUNT(*) count')->from('#PB#_member_collect_log')
				->where('member_id', self::$member_info['id'])
				->where('news_id', $id)
				->where('status', 0)
				->as_field()
				->execute();

			if($count > 0) $info['is_collect'] = 1;
		}

		//专题新闻没有热点，与推荐新闻
		if($info['type'] != 3)
		{

			//热点新闻,过滤详情的新闻
			$hot_news_ids = array ();
			$hot_where = array ();
			$hot_where[] = array ('is_hot', '=', 1);
			$hot_where[] = array ('id', '!=', $id);
			$hot_where[] = array ('is_issue', '=', 1);
			$hot_where[] = array ('delete_user', '=', 0);
			$hot_list = db::select(mod_news::get_list_field())->from(mod_news::$table_name)->where($hot_where)->order_by('sort', 'desc')->order_by('issue_time', 'desc')->limit(6)->execute();

			if (!empty($hot_list))
			{
				foreach ($hot_list as $k => $v)
				{
					$hot_list[$k] = mod_news::handle_news_data($v);
					$hot_news_ids[] = $v['id'];
				}
			}

			//推荐新闻：获取与新闻label相关的新闻，限制5条
			// TODO  需要添加 label条件
			$recom_where = array ();
			$recom_where[] = array ('is_issue', '=', 1);
			if (!empty($hot_news_ids))
			{
				$recom_where[] = array ('id', 'not in', $hot_news_ids);
			}
			$recom_where[] = array ('delete_user', '=', 0);
			$recom_list = db::select(mod_news::get_list_field())->from(mod_news::$table_name)->where($recom_where)->order_by('issue_time', 'desc')->limit(self::DETAIL_PAGE_SIZE)->execute();

			if (!empty($recom_list))
			{
				foreach ($recom_list as $k => $v)
				{
					$recom_list[$k] = mod_news::handle_news_data($v);
				}
			}
		}

		//添加新闻浏览次数
		$update_data = array ();
		$update_data['browse_total'] = $info['browse_total'] + 1;
		$update_data['update_time'] = time();

		db::update(mod_news::$table_name)->set($update_data)->where('id', $id)->execute();

		//添加用户浏览记录
		if(!empty(self::$member_info))
		{
			$add_data = array ();
			$add_data['create_user'] = $add_data['member_id'] = self::$member_info['id'];
			$add_data['news_id'] = $id;
			$add_data['label'] = $info['label'];

			$read_log_id = db::select('id')->from('#PB#_member_read_log')
				->where('member_id', self::$member_info['id'])
				->where('news_id', $id)
				->as_field()
				->execute();

			if(empty($read_log_id))
			{
				$add_data['read_end_time'] = $add_data['create_time'] = $add_data['read_start_time'] = time();
				db::insert('#PB#_member_read_log')->set($add_data)->execute();
			}
			else
			{
				$add_data['read_end_time'] = $add_data['read_start_time'] = time();
				db::update('#PB#_member_read_log')->where('id', $read_log_id)->set($add_data)->execute();
			}

		}

		//删除多余的字段
		unset($info['style_num']);
		unset($info['detail_url']);
		unset($info['label']);

		$hot_list = empty($hot_list) ? array () : $hot_list;
		$recom_list = empty($recom_list) ? array () : $recom_list;

		$list = array (
			'info' => $info,
			'special_section_list' => $special_section_list,
			'hot_list' => $hot_list,
			'recom_list' => $recom_list,
		);

		mod_response::success($list);
	}

	//视频详情
	public function vedio_detail()
	{
		$id = req::item('id', 0, 'int');
		$page_no = req::item('page_no', 1, 'int');
		$page_size = req::item('page_size', self::LIST_PAGE_SIZE);
		$page_no = $page_no <= 0 ? 1 : $page_no;

		$recom_news_ids = array ($id);

		if(empty($id))
		{
			mod_response::error('请传入新闻ID');
		}

		$where = array ();
		$where[] = array ('is_issue', '=', 1);

		if(!empty(self::$member_info))
		{
			$where[] = array ('level_id', '<=', self::$member_info['level_id']);
		}

		$where[] = array ('delete_user', '=', 0);

		$info = db::select(mod_news::get_detail_field())->from(mod_news::$table_name)
			->where('id', '=', $id)
			->where('type', '=', 2)
			->where($where)
			->as_row()
			->execute();

		if(empty($info))
		{
			mod_response::error('此新闻已经被删除', mod_error_code::NEWS_DELETE);
		}

		//判断用户等级
		if((empty(self::$member_info) && $info['level_id'] != 0) || (!empty(self::$member_info) && $info['level_id'] > self::$member_info['level_id']))
		{
			mod_response::error('该新闻暂未对外开放，如需帮助请联系客服人员。', mod_error_code::NEWS_NOT_AUTH);
		}

		$info = mod_news::handle_news_data($info);
		$info['is_collect'] = 0;

		if($page_no == 1)
		{
			//判断该新闻是否已经被收藏
			if(!empty(self::$member_info))
			{
				$count = db::select('COUNT(*) count')->from('#PB#_member_collect_log')
					->where('member_id', self::$member_info['id'])
					->where('news_id', $id)
					->where('status', 0)
					->as_field()
					->execute();

				if($count > 0) $info['is_collect'] = 1;
			}

			//添加新闻浏览次数
			$update_data = array ();
			$update_data['browse_total'] = $info['browse_total'] + 1;
			$update_data['update_time'] = time();

			db::update(mod_news::$table_name)->set($update_data)->where('id', $id)->execute();

			//添加用户浏览记录
			if(!empty(self::$member_info))
			{
				$add_data = array ();
				$add_data['create_user'] = $add_data['member_id'] = self::$member_info['id'];
				$add_data['news_id'] = $id;
				$add_data['label'] = $info['label'];

				$read_log_id = db::select('id')->from('#PB#_member_read_log')
					->where('member_id', self::$member_info['id'])
					->where('news_id', $id)
					->as_field()
					->execute();

				if(empty($read_log_id))
				{
					$add_data['read_end_time'] = $add_data['create_time'] = $add_data['read_start_time'] = time();
					db::insert('#PB#_member_read_log')->set($add_data)->execute();
				}
				else
				{
					$add_data['read_end_time'] = $add_data['read_start_time'] = time();
					db::update('#PB#_member_read_log')->where('id', $read_log_id)->set($add_data)->execute();
				}

			}

			//推荐新闻：获取与新闻label相关的新闻，限制5条
			// TODO  需要添加 label条件
			$recom_where = array ();
			$recom_where[] = array ('is_issue', '=', 1);
			if(!empty(self::$member_info))
			{
				$recom_where[] = array ('level_id', '<=', self::$member_info['level_id']);
			}
			$recom_where[] = array ('type', '=', 2);
			$recom_where[] = array ('delete_user', '=', 0);
			$recom_list = db::select(mod_news::get_list_field())->from(mod_news::$table_name)
				->where($recom_where)
				->order_by('issue_time', 'desc')
				->limit(self::DETAIL_PAGE_SIZE)
				->execute();

			if(!empty($recom_list))
			{
				foreach ($recom_list as $k => $v)
				{
					$recom_news_ids[] = $v['id'];
				}
			}

			//删除多余的字段
			unset($info['style_num']);
			unset($info['detail_url']);
			unset($info['label']);
			unset($info['describe']);
			unset($info['atlas']);
			unset($info['content']);
		}

		//获取其余视频
		$where = array ();
		$where[] = array ('is_issue', '=', 1);
		$where[] = array ('type', '=', 2);
		if(!empty(self::$member_info))
		{
			$where[] = array ('level_id', '<=', self::$member_info['level_id']);
		}
		if(!empty($recom_news_ids)) $where[] = array ('id', 'not in', $recom_news_ids);
		$where[] = array ('delete_user', '=', 0);
		$count = db::select('COUNT(*) count')->from(mod_news::$table_name)
			->where($where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, $page_size);

		$list = db::select(mod_news::get_list_field())->from(mod_news::$table_name)
			->where($where)
			->order_by('sort', 'desc')
			->order_by('issue_time', 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		$list = empty($list) ? array () : $list;
		$recom_list = empty($recom_list) ? array () : $recom_list;
		$new_list = array_merge($recom_list, $list);

		if(!empty($new_list))
		{
			foreach ($new_list as $k => $v)
			{
				$v = mod_news::handle_news_data($v);

				//删除多余的字段
				unset($v['style_num']);
				unset($v['detail_url']);
				unset($v['label']);
				unset($v['describe']);
				unset($v['atlas']);
				unset($v['content']);

				$new_list[$k] = $v;

				//判断是否收藏
				$new_list[$k]['is_collect'] = 0;
				if(!empty(self::$member_info))
				{
					$count = db::select('COUNT(*) count')->from('#PB#_member_collect_log')
						->where('member_id', '=', self::$member_info['id'])
						->where('news_id', '=', $v['id'])
						->where('status', '=', 1)
						->as_field()
						->execute();

					$new_list[$k]['is_collect'] = $count > 0 ? 1 : 0;
				}
			}
		}

		//是否有数据： 1=有，0=没有
		$is_have_data = (($page_no * $page_size) >= $count) ? 0 : 1;

		$list = array (
			'is_have_data' => $is_have_data,
			'info' => $info,
			'list' => $new_list,
		);

		mod_response::success($list);
	}

	//获取专题新闻章节
	private function _get_special_section_list($special_id)
	{
		$page_size = self::SPECIAL_SECTION_NEWS_PAGE_SIZE;

		$section_list = db::select(mod_special_section::$field)->from(mod_special_section::$table_name)
			->where('special_id', '=', $special_id)
			->where('delete_user', '=', 0)
			->order_by('create_time', 'asc')
			->execute();

		if(empty($section_list))
		{
			return array ();
		}

		foreach ($section_list as $k => $v)
		{
			$section_news_where = array ();
			$section_news_where[] = array ('id', 'in', explode(',', $v['news_ids']));
			$section_news_where[] = array ('is_issue', '=', 1);
			$section_news_where[] = array ('delete_user', '=', 0);

			$count = db::select('COUNT(*) count')->from(mod_news::$table_name)
				->where($section_news_where)
				->as_field()
				->execute();

			$section_news_list = db::select(mod_news::get_list_field())->from(mod_news::$table_name)
				->where($section_news_where)
				->limit($page_size)
				->order_by('issue_time', 'desc')
				->execute();

			if(!empty($section_news_list))
			{
				foreach ($section_news_list as $sk => $v)
				{
					$section_news_list[$sk] = mod_news::handle_news_data($v);
				}
			}

			$section_list[$k]['is_have_data'] = $count > $page_size ? 1 : 0;
			$section_list[$k]['news_list'] = empty($section_news_list) ? array () : $section_news_list;

			unset($section_list[$k]['news_ids']);
		}

		return $section_list;
	}

	//获取更多专题章节新闻
	public function section_news_list()
	{
		$special_id = req::item('special_id');
		$section_id = req::item('section_id');
		$page_no = req::item('page_no', 1, 'int');
		$page_size = self::SPECIAL_SECTION_NEWS_PAGE_SIZE;
		$page_no = $page_no <= 1 ? 2 : $page_no;

		if(empty($special_id) || empty($section_id))
		{
			mod_response::error('请传入专题与章节ID');
		}

		$news_ids = db::select('news_ids')->from(mod_special_section::$table_name)
			->where('id', '=', $section_id)
			->where('special_id', '=', $special_id)
			->where('delete_user', '=', 0)
			->as_field()
			->execute();

		if(empty($news_ids))
		{
			mod_response::error('该专题章节没有新闻');
		}

		$section_news_where = array ();
		$section_news_where[] = array ('id', 'in', explode(',', $news_ids));
		$section_news_where[] = array ('is_issue', '=', 1);
		$section_news_where[] = array ('delete_user', '=', 0);

		$count = db::select('COUNT(*) count')->from(mod_news::$table_name)
			->where($section_news_where)
			->as_field()
			->execute();

		$pages = pub_page::make($count, $page_size);

		$section_news_list = db::select(mod_news::get_list_field())->from(mod_news::$table_name)
			->where($section_news_where)
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->order_by('issue_time', 'desc')
			->execute();

		if(!empty($section_news_list))
		{
			foreach ($section_news_list as $k => $v)
			{
				$section_news_list[$k] = mod_news::handle_news_data($v);
			}
		}

		//是否有数据： 1=有，0=没有
		$is_have_data = (($page_no * $page_size) >= $count) ? 0 : 1;

		$list = array (
			'is_have_data' => $is_have_data,
			'list' => $section_news_list,
		);

		mod_response::success($list);

	}

	//获取频道与地区
	public function channel_area()
	{
		$level_id = '';
		if(!empty(self::$member_info))
		{
			$level_id = self::$member_info['level_id'];
		}

		$list = array (
			'location' => mod_area::get_location(),
			'area_list' => pub_mod_area::get_all_list(),
			'news_channel_list' => pub_mod_channel::get_all_list($level_id, 1),
			'video_channel_list' => pub_mod_channel::get_all_list($level_id, 1),
		);

		mod_response::success($list);
	}

	//用户收藏或者取消收藏新闻
	public function collect()
	{
		$id = req::item('id', 0, 'int');
		$status = req::item('status', 0, 'int');

		if(empty($id))
		{
			mod_response::error('新闻ID不能为空');
		}

		if(empty(self::$member_info))
		{
			mod_response::error(mod_member::$err_msg, mod_member::$err_code);
		}

		$where = array ();
		$where[] = array ('member_id', '=', self::$member_info['id']);
		$where[] = array ('news_id', '=',  $id);

		$news_status = db::select('status')->from('#PB#_member_collect_log')
			->where($where)
			->as_field()
			->execute();

		if($news_status === null)
		{
			$add_data = array ();
			$add_data['member_id'] = self::$member_info['id'];
			$add_data['news_id'] = $id;
			$add_data['status'] = $status;
			$add_data['update_time'] = $add_data['create_time'] = time();

			list($result, $rows_affected) = db::insert('#PB#_member_collect_log')->set($add_data)->execute();
		}
		elseif($news_status == $status)
		{
			$result = true;
		}
		else
		{
			$update_data = array ();
			$update_data['status'] = $status;
			$update_data['update_time'] = time();
			$update_data['delete_user'] = 0;
			$result = db::update('#PB#_member_collect_log')->where($where)->set($update_data)->execute();
		}

		if($status == 1)
		{
			$msg = '取消收藏';
		}
		else
		{
			$msg = '收藏';
		}

		if($result)
		{
			mod_response::success();
		}
		else
		{
			mod_response::error($msg.'失败');
		}

	}

	//搜索下面今日热点 获取10条数据
	public function today_hot()
	{
		//统计今日浏览记录最多前10条，没有则用热点新闻代替
		$today_list = db::select('COUNT(*) count, news_id')->from('#PB#_member_read_log')
			->where('create_time', '>=', strtotime(' 00:00:00'))
			->group_by('news_id')
			->order_by('count', 'desc')
			->limit(10)
			->execute();

		$today_news_ids = array ();
		$news_list = array ();

		if(!empty($today_list))
		{
			foreach ($today_list as $k => $v)
			{
				$today_news_ids[] = $v['news_id'];
			}

			$news_list = db::select('id,type,title')->from(mod_news::$table_name)
				->where('is_issue', '=', 1)
				->where('type', '!=', 2)
				->where('id', 'in', $today_news_ids)
				->where('delete_user', '=', 0)
				->order_by('sort', 'desc')
				->order_by('issue_time', 'desc')
				->execute();
		}

		//获取热点新闻
		$hot_news_list = array ();
		$news_list_count = count($news_list);
		if($news_list_count < 10)
		{
			$where = array ();
			$where[] = array ('is_hot', '=', 1);
			$where[] = array ('is_issue', '=', 1);
			$where[] = array ('type', '!=', 2);
			$where[] = array ('delete_user', '=', 0);
			if(!empty($today_news_ids)) $where[] = array ('id', 'not in', $today_news_ids);

			$hot_news_list = db::select('id,type,title')->from(mod_news::$table_name)
				->where($where)
				->order_by('sort', 'desc')
				->order_by('issue_time', 'desc')
				->limit(10 - $news_list_count)
				->execute();
		}

		$news_list = empty($news_list) ? array () : $news_list;
		$news_list = array_merge($news_list, $hot_news_list);

		if(!empty($news_list))
		{
			foreach ($news_list as $k => $v)
			{
				$news_list[$k]['detail_url'] = mod_news::handle_url($v['id'], $v['type']);
			}
		}

		mod_response::success($news_list);
	}

	//新闻投诉
	public function complaint()
	{
		$news_id = req::item('id', 0, 'int');
		$type = req::item('type');
		$title = req::item('title');
		$content = req::item('content');

		if(empty($news_id))
		{
			mod_response::error('新闻ID不能为空');
		}

		if(empty($type))
		{
			mod_response::error('新闻类型不能为空');
		}

		if(empty($title))
		{
			mod_response::error('新闻标题不能为空');
		}

		if(empty($content))
		{
			mod_response::error('投诉内容不能为空');
		}

		if(empty(self::$member_info))
		{
			mod_response::error(mod_member::$err_msg, mod_member::$err_code);
		}

		$where = array ();
		$where[] = array ('member_id', '=', self::$member_info['id']);
		$where[] = array ('news_id', '=',  $news_id);

		$id = db::select('id')->from('#PB#_member_complaint')
			->where($where)
			->as_field()
			->execute();

		if(!empty($id))
		{
			mod_response::error('该新闻您已经投诉过了，我们会尽快跟进的，谢谢');
		}

		$add_data = array ();
		$add_data['member_id'] = self::$member_info['id'];
		$add_data['member_name'] = empty(self::$member_info['name']) ? self::$member_info['account'] : self::$member_info['name'];
		$add_data['news_id'] = $news_id;
		$add_data['news_type'] = $type;
		$add_data['news_title'] = $title;
		$add_data['status'] = 0;
		$add_data['content'] = $content;
		$add_data['update_time'] = $add_data['create_time'] = time();

		list($result, $rows_affected) = db::insert('#PB#_member_complaint')->set($add_data)->execute();

		if($result)
		{
			mod_response::success();
		}
		else
		{
			mod_response::error('投诉失败');
		}
	}

}
