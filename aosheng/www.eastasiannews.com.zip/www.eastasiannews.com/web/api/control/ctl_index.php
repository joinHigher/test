<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 首页控制器
 *
 * @version $Id$
 */
class ctl_index
{
	//客户信息
	public static $userid = '';
	public static $member_info = array ();

	function __construct()
	{
        // 接口类型
        $display = req::item('display', 'web'); // app、web

		/*
        // 如果是web
        if ($display == 'web') 
        {
        	//获取不到$_COOKIE值
            $userid = empty($_COOKIE['userid']) ? '' : $_COOKIE['userid'];
            if (empty($userid)) 
            {
                // 生成一个随机不重复的用户ID
                $userid = util::random('web');
                // 把用户ID存到cookie和当前类变量
                $_COOKIE['userid'] = $userid;
                self::$userid = $userid;
            }
        }
        // 如果是app
        else 
        {
            $userid = req::item('userid');
            if (empty($userid))
            {
                $userid = util::random('web');
                self::$userid = $userid;
            }
        }

		*/

		$userid = req::item('userid');

		if (empty($userid))
		{
			$userid = util::random('web');
		}

		self::$userid = $userid;

		$info = mod_member::get_info();
		if($info === false)
		{
			return true;
		}

		self::$member_info = $info;
	}

	//初始化接口
	public function init()
	{
		$level_id = '';
		$member_id = '';
		if(!empty(self::$member_info))
		{
			$level_id = self::$member_info['level_id'];
			$member_id = self::$member_info['id'];
		}
		self::$userid = '305d412cf9abfad41f9755644a12c383';
		$list = array (
			'version' => '1.0.0',
			'member_channel' => mod_member_channel::get_member_channel(self::$userid, $member_id),
			'userid' => self::$userid,
			'member_info' => self::$member_info,
			'location' => mod_area::get_location(),
			'area_list' => pub_mod_area::get_all_list(),
			'news_channel_list' => pub_mod_channel::get_all_list($level_id, 1),
			'video_channel_list' => pub_mod_channel::get_all_list($level_id, 1),
		);

		mod_response::success($list);
	}

	public function index()
	{

	}

	//选择国家
	public function select_country()
	{
		$list = pub_mod_area::get_all_list();
		mod_response::success($list);
	}

	//选择新闻频道
	public function select_channel()
	{
		$type = req::item('type', 0, 'int');

		$where = array ();
		$where[] = array ('status', '=', 0);
		if(!empty($type)) $where[] = array ('type', '=', $type);
		$where[] = array ('delete_user', '=', 0);

		if(!empty(self::$member_info))
		{
			$where[] = array ('level_id', '<=', self::$member_info['level_id']);
		}

		$list = db::select('id,is_fix,name')
			->from(mod_channel::$table_name)
			->where($where)
			->execute();

		mod_response::success($list);
	}

}
