<?php

class mod_error_code
{
    // 成功
    const SUCCESS                 = 0;
    // 普通错误
    const ERROR                   = -1;
    // 数据格式错误
    const PARAM_FIELD_INVALID     = -2;
    // 参数错误
    const PARAM_INVALID           = -3;
    // 未登录或登录超时
    const AUTH_FAIL               = 4001;
    // 账号异常
    const ACCOUNT_INFO_INVALID    = 4002;
    // 无权限
    const NO_PERMISSION           = 4003;
    // 用户登录错误信息
    const PASSWORD_ERROR          = 1001;
    const PASSWORD_ERROR_TOO_MUCH = 1002;
    const ACCOUNT_INFO_ERROR      = 1003;
    const ACCOUNT_AUDITING        = 1004;
    const ACCOUNT_AUDIT_FAIL      = 1005;
    const PASSWORD_CHECK_FAIL     = 1006;
    // 库存不足
    const STOCK_NOT_ENOUGH        = 3001;
	//频道没有权限查看
	const CHANNEL_NOT_AUTH        = 5001;
	//频道已经删除
	const CHANNEL_DELETE          = 5002;
	//新闻没有权限查看
	const NEWS_NOT_AUTH           = 5003;
	//新闻已经删除
	const NEWS_DELETE             = 5004;
}