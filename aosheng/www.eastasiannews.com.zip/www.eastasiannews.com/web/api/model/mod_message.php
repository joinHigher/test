<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 消息模块
 *
 * @version $Id$
 */
class mod_message
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_message';

    //表字段
    public static $field = array (
		'id',
		'member_id',
		'type',
		'is_read',
		'foreign_id',
		'describe',
		'remark',
		'create_time',
	);

    //状态
	public static $status_list = array(
		0 => '启用',
		1 => '禁用',
	);

	//性别
	public static $sex_list = array(
		0 => '未知',
		1 => '男',
		2 => '女',
	);

	//错误码
	public static $err_code = -1;

	//错误信息
	public static $err_msg = '';

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	public static function get_field($field = '', $is_contrary_field = false)
	{
		if(!empty($field))
		{
			if(!is_array($field))
			{
				$field = explode(',', $field);
			}

			if(!empty($field) && $is_contrary_field === true)
			{
				return array_diff(self::$field, $field);
			}
		}

		return empty($field) ? self::$field : $field;
	}

	// 创建token
	public static function get_token($id)
	{
		return md5($id . '-' . time());
	}


	// 获取会员信息
	public static function get_info($app_token = '')
	{
		$token  = empty($app_token) ? req::item('_token', '') : $app_token;
		$token  = empty($token) && ! empty($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : $token;

		if (empty($token))
		{
			self::$err_code = mod_error_code::AUTH_FAIL;
			self::$err_msg = '未登录，请先登录';

			return false;
		}

		$info = db::select(self::$field)->from(self::$table_name)->where('token', $token)->as_row()->execute();

		if (empty($info))
		{
			self::$err_code = mod_error_code::AUTH_FAIL;
			self::$err_msg = '未登录或登录超时';

			return false;
		}

		return $info;
	}
}
