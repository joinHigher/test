<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员反馈模块
 *
 * @version $Id$
 */
class mod_member_feedback
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_member_feedback';

    //表字段
    public static $field = array (
		'id',
		'img',
		'content',
		'reply',
		'create_time',
		'update_time',
	);

    //状态：0=待处理，1=已回复
	public static $status_list = array(
		0 => '待处理',
		1 => '已回复',
	);

}
