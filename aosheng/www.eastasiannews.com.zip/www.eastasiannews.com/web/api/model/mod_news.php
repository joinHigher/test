<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 新闻模块
 *
 * @version $Id$
 */
class mod_news
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_news';

	//新闻类型
	public static $type_list = array(
		1 => '图文',
		2 => '视频',
		3 => '专题',
		4 => '图集',
	);

	// 获取详情字段
	public static function get_detail_field()
	{
		$field = array (
			'id',
			'title',
			'describe',
			'cover_img',
			'video',
			'atlas',
			'level_id',
			'is_top',
			'is_hot',
			'type',
			'label',
			'browse_total',
			'content',
			'publisher',
			'issue_time',
		);

		return $field;
	}

	// 获取列表字段
	public static function get_list_field()
	{
		$field = array (
			'id',
			'title',
			'cover_img',
			'is_top',
			'is_hot',
			'type',
			'video',
			'atlas',
			'browse_total',
			'publisher',
			'issue_time',
		);

		return $field;
	}

	//发布时间处理
	public static function handle_issue_time($issue_time)
	{
		$now_time = time();
		$issue_date = '';

		if(strtotime(' +10 minute', $issue_time) > $now_time)
		{
			$issue_date = '刚刚';
		}
		elseif(strtotime(' +1 hour', $issue_time) > $now_time)
		{
			$issue_date = floor(($now_time-$issue_time)/60).'分钟前';
		}
		elseif(strtotime(' +24 hour', $issue_time) > $now_time)
		{
			$issue_date = floor(($now_time-$issue_time)/(60*60)).'小时前';
		}


		/*
		if(strtotime(' +1 hour', $issue_time) >= $now_time)
		{
			$issue_date = '刚刚';
		}
		elseif(strtotime(' +24 hour', $issue_time) > $now_time)
		{
			$issue_date = floor(($now_time-$issue_time)/(60*60)).'小时前';
		}
		elseif(strtotime(' +3 day', $issue_time) > $now_time)
		{
			$issue_date = floor(($now_time-$issue_time)/(24*60*60)).'天前';
		}
		elseif(strtotime(' +3 day', $issue_time) <= $now_time)
		{
			$issue_date = date('m-d', $issue_time);
		}
		*/

		return $issue_date;
	}

	//图片处理
	public static function handle_img($img, $type = '')
	{

		if(empty($img))
		{
			return array ();
		}

		$img_list = explode(',', $img);

		foreach ($img_list as $k => $v)
		{
			$img_list[$k] = strpos($v,'http://') === false ? URL_UPLOADS . '/image/' . $v : $v;
		}

		return $img_list;
	}

	//视频处理
	public static function handle_video($video)
	{
		if(empty($video))
		{
			return '';
		}

		return strpos($video,'http://') === false ? URL_UPLOADS . '/video/' . $video : $video;
	}

	//样式处理,样式排版：1=专题，2=图文1张封面图，3=图文2至3张封面图，4=视频新闻，5=图集新闻,6=热点推荐新闻
	public static function handle_style($type, $cover_img_list)
	{
		$style = 0;

		switch ($type)
		{
			case 1:
					if(count($cover_img_list) == 1)
					{
						$style = 2;
					}
					else
					{
						$style = 3;
					}
				break;
			case 2:
					$style = 4;
				break;
			case 3:
					$style = 1;
				break;
			case 4:
					$style = 5;
				break;
		}

		return $style;
	}

	//处理图集新闻
	public static function handle_atlas($atlas_content)
	{
		$atlas_list = array ();

		if(empty($atlas_content))
		{
			return $atlas_list;
		}

		$content_list = unserialize($atlas_content);
		$img_list = explode(',', $content_list['imgs']);
		$descs_list = explode(',', $content_list['descs']);

		foreach ($img_list as $k => $v)
		{
			//$atlas_list[$k]['img'] = $v;
			$atlas_list[$k]['img'] = strpos($v,'http://') === false ? URL_UPLOADS . '/video/' . $v : $v;
			$atlas_list[$k]['desc'] = isset($descs_list[$k]) ? $descs_list[$k] : '';
		}

		return $atlas_list;
	}


	//处理详情URL
	public static function handle_url($news_id, $type)
	{
		$detail_url = '';

		switch ($type)
		{
			case 1:
				$detail_url = URL_H5 . '/detail.html?id=' . $news_id;
				break;
			case 2:
				$detail_url = URL_H5 . '/video.html?id=' . $news_id;
				break;
			case 3:
				$detail_url = URL_H5 . '/special.html?id=' . $news_id;
				break;
		}

		return $detail_url;
	}

	/**
	 * 处理新闻数据
	 *
	 * @param $info
	 * @param bool $is_need_style_num
	 * @return mixed
	 */
	public static function handle_news_data($info, $is_need_style_num = true)
	{
		$style_num = 0;
		$info['issue_date'] = mod_news::handle_issue_time($info['issue_time']);
		if($info['type'] == 2) $info['video'] = mod_news::handle_video($info['video']);
		if($is_need_style_num) $style_num = $info['style_num'] = mod_news::handle_style($info['type'], $info['cover_img']);
		$info['cover_img'] = mod_news::handle_img($info['cover_img'], $style_num);

		$atlas_list = array ();
		if($info['type'] == 4)
		{
			$atlas_list = mod_news::handle_atlas($info['atlas']);
		}

		$info['atlas'] = $atlas_list;
		$info['video_time'] = '02:10';

		$info['detail_url'] = self::handle_url($info['id'], $info['type']);
		$info['logo_url'] = URL_API . '/static/image/logo.png';

		if(!empty($info['content'])) $info['content'] = htmlspecialchars_decode($info['content']);

		return $info;
	}
}
