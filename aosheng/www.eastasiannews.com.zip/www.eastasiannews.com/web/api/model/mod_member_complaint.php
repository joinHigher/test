<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员投诉模块
 *
 * @version $Id$
 */
class mod_member_complaint
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_member_complaint';

    //表字段
    public static $field = array (
		'id',
		'news_id',
		'news_type',
		'news_title',
		'content',
		'reply',
		'create_time',
		'update_time',
	);

    //状态：0=待处理，1=已处理
	public static $status_list = array(
		0 => '待处理',
		1 => '已处理',
	);

	//回复类型：1=确认属实， 2=恶意投诉， 3=其他
	public static $reply_type_list = array(
		0 => '待处理',
		1 => '确认属实',
		2 => '恶意投诉',
		3 => '其他',
	);

}
