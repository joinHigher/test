<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 地区模块
 *
 * @version $Id$
 */
class mod_area
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_area';

    //根据IP获取用户位置
	public static function get_location()
	{
		$location = array (
			'short_name' => 'GLOBAL',
			'name' => '全球',
		);

		$area_short_name = util::get_country();
		if(!empty($area_short_name))
		{
			$area_name = db::select('name')->from(self::$table_name)
				->where('en_short_name', $area_short_name)
				->as_field()
				->execute();

			if(!empty($area_name))
			{
				$location = array (
					'short_name' => $area_short_name,
					'name' => $area_name,
				);
			}
		}

		return $location;
	}
}
