<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 专题章节模块
 *
 * @version $Id$
 */
class mod_special_section
{
	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_special_section';

    //表字段
    public static $field = array (
		'id',
		'title',
		'news_ids',
	);

}
