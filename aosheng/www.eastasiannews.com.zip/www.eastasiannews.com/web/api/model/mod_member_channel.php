<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员选择的频道模块
 *
 * @version $Id$
 */
class mod_member_channel
{
	//错误码
	public static $err_code = '';

	//错误信息
	public static $err_msg = '';

	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_member_channel';

	//表字段
	public static $field = array (
		'type',
		'common_channel',
		'country_channel',
	);

    //获取用户选择的频道
	public static function get_channel($userid, $member_id, $type = '')
	{
		$new_channel_list = array (
			0 => array (
				'channel_list' => '',
				'area_list' => '',
			),
			1 => array (
				'channel_list' => '',
				'area_list' => '',
			),
		);

		if(empty($userid))
		{
			if(is_numeric($type) && ($type == 0 || $type == 1))
			{
				return $new_channel_list[$type];
			}
			else
			{
				return $new_channel_list;
			}
		}

		//判断未登录会员是否以后存在频道
		$userid_count = db::select('COUNT(*) count')->from(self::$table_name)
			->where('member_id', '=', $userid)
			->as_field()
			->execute();

		//判断是否登录，如果登录的话需要将未登录的频道修改成已登录的频道
		if(!empty($member_id))
		{
			//判断登录会员是否以后存在频道
			$count = db::select('COUNT(*) count')->from(self::$table_name)
				->where('member_id', '=', $member_id)
				->as_field()
				->execute();

			if($userid_count > 0)
			{
				//存在则删除
				if($count > 0)
				{
					db::delete(self::$table_name)->where('member_id', '=', $member_id)->execute();
				}

				//将未登录设置的频道，设置为登录会员的频道
				db::update(self::$table_name)->where('member_id', $userid)->set([
					'member_id' => $member_id
															])->execute();
			}

			$userid = $member_id;
		}

		//获取会员设置的频道
		$channel_list = db::select(self::$field)
			->from(self::$table_name)
			->where('member_id', '=', $userid)
			->execute();

		if(empty($channel_list))
		{
			if(is_numeric($type) && ($type == 0 || $type == 1))
			{
				return $new_channel_list[$type];
			}
			else
			{
				return $new_channel_list;
			}
		}
		else
		{
			foreach ($channel_list as $k => $v)
			{

			}
		}

	}

	//将未登录的会员频道转成登录后的会员频道
	public static function change_member_channel($userid, $member_id)
	{
		if(!empty($member_id))
		{
			return false;
		}

		//判断未登录会员是否以后存在频道
		$userid_count = db::select('COUNT(*) count')->from(self::$table_name)
			->where('member_id', '=', $userid)
			->as_field()
			->execute();

		//判断登录会员是否以后存在频道
		$count = db::select('COUNT(*) count')->from(self::$table_name)
			->where('member_id', '=', $member_id)
			->as_field()
			->execute();

		if($userid_count > 0)
		{
			//存在则删除
			if($count > 0)
			{
				db::delete(self::$table_name)->where('member_id', '=', $member_id)->execute();
			}

			//将未登录设置的频道，设置为登录会员的频道
			db::update(self::$table_name)->where('member_id', $userid)->set([
																				'member_id' => $member_id
																			])->execute();
		}
	}

	//获取用户选择的频道
	public static function get_member_channel($userid, $member_id)
	{
		$new_channel_list = array (
			'select_news_channel' => '',
			'select_video_channel' => '',
		);

		if(!empty($member_id))
		{
			$userid = $member_id;
		}

		//获取会员设置的频道
		$channel_list = db::select('type,sort_channel')
			->from(self::$table_name)
			->where('member_id', '=', $userid)
			->execute();

		if(empty($channel_list))
		{
			return $new_channel_list;
		}

		foreach ($channel_list as $k => $v)
		{
			if($v['type'] == 1)
			{
				$new_channel_list['select_video_channel'] = $v['sort_channel'];
			}
			else
			{
				$new_channel_list['select_news_channel'] = $v['sort_channel'];
			}
		}

		return $new_channel_list;

	}
}
