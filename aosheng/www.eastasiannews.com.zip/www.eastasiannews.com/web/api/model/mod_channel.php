<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 频道模块
 *
 * @version $Id$
 */
class mod_channel
{
	//错误码
	public static $err_code = '';

	//错误信息
	public static $err_msg = '';

	//主键
	public static $pk = 'id';

	//表名称
    public static $table_name = '#PB#_channel';

	//判断频道是否有效：删除与没有权限
    public static function is_valid($id, $level_id)
	{
		if($id == 0)
		{
			return true;
		}

		$channel_level_id = db::select('level_id')->from(mod_channel::$table_name)
			->where('id', '=', $id)
			->where('status', '=', 1)
			->where('delete_user', '=', 0)
			->as_field()
			->execute();

		if(is_numeric($channel_level_id))
		{
			if($channel_level_id > $level_id)
			{
				self::$err_code = mod_error_code::CHANNEL_NOT_AUTH;
				self::$err_msg = '该频道暂未对外开放，如需帮助请联系客服人员。';
				return false;
			}
		}
		else
		{
			self::$err_code = mod_error_code::CHANNEL_DELETE;
			self::$err_msg = '此频道已经被删除';
			return false;
		}

		return true;
	}
}
