<?php
/**
 * 上传模型
 */
class mod_upload
{
	public static $err_code = -1;
	public static $err_msg = '';

	public static $allowed_ext = array(
		'image' => array('jpg', 'jpeg', 'gif', 'png', 'bmp', 'webp'),
		'flash' => array('swf', 'flv'),
		'media' => array('swf', 'flv', 'mp3', 'wav', 'wma', 'wmv', 'mid', 'avi', 'mpg', 'asf', 'rm', 'rmvb'),
		'file' => array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'htm', 'html', 'txt', 'zip', 'rar', 'gz', 'bz2'),
	);

	public static function index($tmp_path = 'tmp', $guid = '', $chunk = 0, $chunks = 1)
	{
		// Make sure file is not cached (as it happens for example on iOS devices)
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: no-store, no-cache, must-revalidate");
		header("Cache-Control: post-check=0, pre-check=0", false);
		header("Pragma: no-cache");

		// 5 minutes execution time
		@set_time_limit(5 * 60);
		$cleanup_target_dir = true;     // Remove old files
		$max_file_age = 5 * 3600;       // Temp file age in seconds

		//$guid       = req::item("guid", util::random('alnum', 32));
		//$tmp_path   = req::item("tmp_path", 'tmp');      // 文件上传临时目录
		$limit_type = req::item("limit_type");           // 文件上传限制类型
		$randname   = req::item("randname", 1, 'int');   // 是否生成随机名
		//$token      = req::item("token", "");          // token
		//$chunk      = req::item("chunk", 0, 'int');
		//$chunks     = req::item("chunks", 1, 'int');

		//$target_dir = ini_get("upload_tmp_dir")."/plupload";
		$target_dir = PATH_ROOT."/uploads/tmp/{$guid}";
		$upload_dir = PATH_ROOT."/uploads/{$tmp_path}";
		// 目录不存在则生成
		util::path_exists($target_dir);
		util::path_exists($upload_dir);

		$filename   = req::get_file_info('file', 'name');
		$filepath   = $target_dir . '/' . $filename;
		$uploadpath = $upload_dir . '/' . $filename;

		// Remove old temp files
		if ($cleanup_target_dir)
		{
			if (!is_dir($target_dir) || !$dir = opendir($target_dir))
			{
				self::$err_code = '100';
				self::$err_msg = 'Failed to open temp directory';
				return false;
			}

			while (($file = readdir($dir)) !== false)
			{
				$tmpfile_path = $target_dir . '/' . $file;

				// If temp file is current file proceed to the next
				if ($tmpfile_path == "{$filepath}_{$chunk}.part" || $tmpfile_path == "{$filepath}_{$chunk}.parttmp")
				{
					continue;
				}

				// Remove temp file if it is older than the max age and is not the current file
				if (preg_match('/\.(part|parttmp)$/', $file)
					&& file_exists($tmpfile_path)
					&& (@filemtime($tmpfile_path) < time() - $max_file_age))
				{
					@unlink($tmpfile_path);
				}
			}
			closedir($dir);
		}

		// Open temp file
		if (!$out = @fopen("{$filepath}_{$chunk}.parttmp", "wb"))
		{
			self::$err_code = '101';
			self::$err_msg = 'Failed to open output stream';
			return false;
		}

		if (!empty(req::$files))
		{
			if ( !req::is_upload_file('file') )
			{
				self::$err_code = '102';
				self::$err_msg = 'Failed to move uploaded file';
				return false;
			}

			// Read binary input stream and append it to temp file
			if (!$in = @fopen(req::get_tmp_name('file'), "rb"))
			{
				self::$err_code = '103';
				self::$err_msg = 'Failed to open input stream';
				return false;
			}
		}
		else
		{
			if (!$in = @fopen("php://input", "rb"))
			{
				self::$err_code = '104';
				self::$err_msg = 'Failed to open input stream';
				return false;

			}
		}

		while ($buff = fread($in, 4096))
		{
			fwrite($out, $buff);
		}

		@fclose($out);
		@fclose($in);

		rename("{$filepath}_{$chunk}.parttmp", "{$filepath}_{$chunk}.part");

		$index = 0;
		$done = true;
		for( $index = 0; $index < $chunks; $index++ )
		{
			if ( !file_exists("{$filepath}_{$index}.part") )
			{
				$done = false;
				break;
			}
		}

		if ( $done )
		{
			if (!$out = @fopen($uploadpath, "wb"))
			{
				self::$err_code = '105';
				self::$err_msg = 'Failed to open output stream';
				return false;
			}

			if ( flock($out, LOCK_EX) )
			{
				for( $index = 0; $index < $chunks; $index++ )
				{
					if (!$in = @fopen("{$filepath}_{$index}.part", "rb"))
					{
						break;
					}

					while ($buff = fread($in, 4096))
					{
						fwrite($out, $buff);
					}

					@fclose($in);
					@unlink("{$filepath}_{$index}.part");
				}
				flock($out, LOCK_UN);
			}
			@fclose($out);
			// 删除目录
			@rmdir($target_dir);
			// 是否随机生成名称
			if ($randname)
			{
				$ext = req::get_shortname('file');
				$filename = uniqid() . "." . $ext;
				rename("{$uploadpath}", "{$upload_dir}/{$filename}");
			}
			$filelink = URL_UPLOADS."/".$tmp_path."/".$filename;

			$list = array (
				'filename' => $filename,
				'filelink' => $filelink,
			);

			return $list;

		}

		self::$err_code = '106';
		self::$err_msg = 'null';
		return false;
	}


}