<?php
/**
 * 响应类模型l
 */
class mod_response
{
    // 返回成功json数据
    public static function success($data=[], $msg='success')
    {
        self::json(mod_error_code::SUCCESS, $msg, $data);
    }

    // 返回失败json数据
    public static function error($msg='error', $code=-1, $data=[])
    {
        self::json($code, $msg, $data);
    }

    // 返回json数据
    public static function json($code, $msg, $data)
    {
        header('Content-Type: application/json; charset=utf-8');

        // php7.1 json_encode float精度会溢出
        if (version_compare(phpversion(), '7.1', '>=')) {
            ini_set( 'serialize_precision', -1 );
        }

		$data = empty($data) ? array () : $data;

        $return_data = [
            'code'   => (int) $code,
            'msg'    => (string) $msg,
            'data'   => $data
        ];

        exit(json_encode($return_data, JSON_UNESCAPED_UNICODE));
    }
}