### 项目
东亚新闻

### 域名

说明|线上|测试|
----|---|-----|
管理后台|adminssl.eastasiannews.com | www1.eastasiannews.com/admin |  
API |api.eastasiannews.com   | www1.eastasiannews.com/api   | 
静态资源(图片) |static.eastasiannews.com/uploads   | www1.eastasiannews.com/uploads   | 
首页 | www.eastasiannews.com | -  | 
下载页 | download.eastasiannews.com | -  | 
h5页|m.eastasiannews.com|www1.eastasiannews.com/h5|


### 数据库
库名|线上地址|测试地址|
----|--------|-------|
asianews|-|192.168.0.45 

### 部署

测试环境，自动部署，查看 [执行日志](http://www.gitlab.center/ultron/www.eastasiannews.com/pipelines)


```
# 机器
ssh -p 25680 www@192.168.0.46 #密码www，可以sudo

# nginx配置
/etc/nginx/sites-enabled/www1.eastasiannews.com.conf

# 代码目录
/data/web/www1.eastasiannews.com/
```
