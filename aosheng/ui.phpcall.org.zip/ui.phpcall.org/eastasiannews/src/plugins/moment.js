const moment = require('moment');
export default {
    install : function (Vue, options) {
        moment.locale('zh-cn');
        Vue.prototype.$moment = moment;
    }
}