require('es6-promise').polyfill();
import '../less/main.less'

import Vue from 'vue'
import VueLazyload from 'vue-lazyload'
import axios from '../plugins/axios.js'
import moment from '../plugins/moment.js'
import toast from '../plugins/toast.js'
import config from './config.js'

import utils from '../utils';

//暴露一个全局的事件给window
window.$zEvent = new Vue();
$zEvent.$on('ERROR',e=>{
    console.error(e);
})

Vue.prototype.$config = config;
Vue.prototype.$utils = utils;
// let loadImg = require('../assets/default.png');
Vue.use(VueLazyload)
    .use(moment)
    .use(axios)
    .use(config)
    .use(toast)

Vue.config.productionTip = false

export default Vue;