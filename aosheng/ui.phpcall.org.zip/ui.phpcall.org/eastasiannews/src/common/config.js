let domain = process.env.NODE_ENV == 'dev' ? '' : '/h5';

export default {
    domain,
    api: (process.env.NODE_ENV == 'dev' ? 'http://demo.news.com' : location.origin) + '/api/',
    pages:{
        index: domain + '/index.html',
        search: domain + '/search.html',
        tabVideo: domain + '/tab_video.html',
        recommend: domain + '/recommend.html',
        detail: domain + '/detail.html',
        hot: domain + '/hot.html',
        special: domain + '/special.html',
        myCenter: domain + '/my_center.html',
        message: domain + '/message.html',
        updatePwd: domain + '/update_pwd.html',
        filter: domain + '/filter.html',
        history: domain + '/history.html',
        fav: domain + '/fav.html',
        feedback: domain + '/feedback.html',
        setting: domain + '/setting.html',
        reset_pwd: domain + '/reset_pwd.html',
        register: domain + '/register.html',
        about: domain + '/about.html',
        agreement: domain + '/agreement.html',
        login: domain + '/login.html',
        personalData: domain + '/personal_data.html',
        feedbackDetails: domain + '/feedback_details.html',
        complainDetails: domain + '/complain_details.html',
        system_message: domain + '/system_message.html',
        model_setting: domain + '/model_setting.html',
    }
    
}