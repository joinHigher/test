import Vue from './common/bootstrap.js'
import App from './page/model_setting.vue'

new Vue({
    render: h => h(App)
}).$mount('#app')