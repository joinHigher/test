<template>
    <div class="area-bar">
        <a class="item">
            <i></i><span>更多区域</span>
        </a>
        <div class="item">
            <img :src="config.icon"><span>{{config.text}}</span>
        </div>
    </div>
</template>
<script>
export default {
    name:'ui-weather',
    props:['config']
}
</script>
<style>

</style>


