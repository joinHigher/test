<template>
  <div class="ui-tabs">
    <div class="slide">
      <ul class="swiper-wrapper" >
        <li class="swiper-slide" :class="{'active': idx == onIndex}" v-for="(tab,idx) in tabs" :key="tab.id">
          <a href="javascript:void(0)" @click="pick(tab,idx)">{{tab.name}}</a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import Swiper from 'swiper';

function getIndexById(arr,id){
  let index = 0;
    for(let i=0,len = arr.length;i++;i<len){
      if(arr.id == id){
        index = i;
        break;
      }
    }
    return index;
}
export default {
  name: 'ui-tabs',
  props: ['list','active'],
  data(){
    return {
      onIndex:0,
      swiper:'',
      tabs:[]
    }
  },
  mounted(){
    this.tabs = this.list;
    // let index = getIndexById(this.tabs,this.active);
    // this.onIndex = index;
    this.$nextTick(()=>{
      this.swiper = new Swiper('.ui-tabs>.slide', {
          initialSlide:this.onIndex,
          freeMode: true,
          slidesPerView: 'auto',
          freeModeSticky: true,
      });
      this.$on('update',params=>{
          console.log(params);
        this.tabs = params.list
        this.$nextTick(()=>{
          this.swiper.updateSlides();
          this.onIndex = params.active;
        //   this.swiper.slideTo(this.onIndex);
          if(this.onIndex>5){
            this.swiper.slideTo(this.onIndex);
          }
        })
      });

      this.$on('update_slide',(index)=>{
        if(this.onIndex !== index){
          this.onIndex = index;
          this.swiper.slideTo(index);
        }
      })

      this.$emit('init');
    })
    
    
    
  },

  methods:{
    pick(item,idx){
      this.$emit('choose',item);
      this.onIndex = idx;
    }
  }
}
</script>

<style lang="less">
.ui-tabs {
  position:relative;
  flex:1;
  z-index:2;
  display: flex;
  height:87px;
  box-sizing: content-box;
  border-bottom:1px solid #efefef;
  background-color:#fff;

  &.sticky {
        position:fixed;
        top:0;
        left:0;
        width:100%;
        z-index:999;
    }
  .slide {
    display: flex;
    flex:1;
    overflow: hidden;
  }
  ul {
    display: flex;

    li {
      position:relative;
      display: flex;
      justify-content: center;
      align-items: center;
      padding:0 30px;
      flex-shrink: 0;
      a {
        font-size:28px;
        color:#919191;
      }
      &.active a {
        font-size:30px;
        color:#141414;
        font-weight: bold;

        &::before {
          content:'';
          position: absolute;
          bottom:0;
          left:0;
          right:0;
          margin:auto;
          width:42px;
          height:6px;
          border-radius:3px;
          background-color:#e64a19;
        }
      }
    }
  }
}
</style>
