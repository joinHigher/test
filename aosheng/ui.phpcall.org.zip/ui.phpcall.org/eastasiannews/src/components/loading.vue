<template>
    <div class="loading-box">
            <slot name="icon">
                <i class="uicon uicon-loading run"></i>
            </slot>
            <slot name="content">
                <div class="placeholder">
                <div class="bt"></div>
                <div class="bi">
                    <div class="pl">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="pr"></div>
                </div>
                <div class="bi">
                    <div class="pl">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="pr"></div>
                </div>
                <div class="bi">
                    <div class="pl">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="pr"></div>
                </div>
                <div class="bi">
                    <div class="pl">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="pr"></div>
                </div>
                <div class="bi">
                    <div class="pl">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="pr"></div>
                </div>
            </div>
            </slot>
            
        </div>
</template>
<script>
export default {
    name:'ui-loading'
}
</script>

