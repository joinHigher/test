<template>
    <div class="tabbar">
        <a href="javascript:void(0);" @click="changeTab(tab)" :class="{'active':tab.id == active}" v-for="tab in list" :key="tab.id">
            <i class="uicon uicon-tabbar" :class="'uicon-'+tab.ico"></i>
            <p>{{tab.name}}</p>
        </a>

    </div>
</template>
<script>
export default {
    name:'ui-tab-bar',
    props:{
        active:Number
    },
    data(){
        return {
            list:[
                {
                    id:0,
                    name:'新闻',
                    ico:'news'
                },
                {
                    id:1,
                    name:'视频',
                    ico:'video'
                },{
                    id:2,
                    name:'推荐',
                    ico:'rec'
                },{
                    id:3,
                    name:'我的',
                    ico:'me'
                }
            ]
        }
    },
    methods:{
        changeTab(item){
            if(this.active == item.id) return false;
            this.$emit('change',item.id);
            // switch(item.id){
            //     case 0:
            //         location.href = '/index.html';
            //         break;
            //     case 1:
            //         break;
            //     case 2:
            //         location.href = '/recommend.html';
            //         break;
            //     case 3:
            //         location.href = '/myCenter.html';
            //         break;
            // }
        }
    }
}
</script>
<style lang="less">
.tabbar {
    position: fixed;
    z-index:9999;
    left:0;
    right:0;
    bottom:0;
    display: flex;
    height:104px;
    background-color:#fff;
    border-top:1px solid #efefef;

    a {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        flex:1;
        font-size:20px;
        color:#919191;

        &.active {
            color:#e64a19;
        }

        p {
            margin-top:12px;
            line-height: 1
        }
    }
}
</style>


