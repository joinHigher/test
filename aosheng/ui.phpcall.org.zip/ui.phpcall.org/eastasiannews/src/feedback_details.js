import Vue from './common/bootstrap.js'
import App from './page/feedback_details.vue'

new Vue({
  render: h => h(App)
}).$mount('#app')
