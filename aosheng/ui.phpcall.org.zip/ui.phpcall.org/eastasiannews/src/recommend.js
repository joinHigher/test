import Vue from './common/bootstrap.js'
import App from './page/recommend.vue'

new Vue({
  render: h => h(App)
}).$mount('#app')
