import Vue from './common/bootstrap.js'
import App from './page/history.vue'

new Vue({
  render: h => h(App)
}).$mount('#app')
