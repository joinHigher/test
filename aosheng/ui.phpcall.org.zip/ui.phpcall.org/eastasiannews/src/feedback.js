import Vue from './common/bootstrap.js'
import App from './page/feedback.vue'

new Vue({
  render: h => h(App)
}).$mount('#app')
