import Vue from './common/bootstrap.js'
import App from './page/system_message.vue'

new Vue({
    render: h => h(App)
}).$mount('#app')
