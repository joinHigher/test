import Vue from './common/bootstrap.js'
import App from './page/tabVideo.vue'
import VueDND from './directive/dragging.js'
Vue.use(VueDND)
new Vue({
  render: h => h(App)
}).$mount('#app')
