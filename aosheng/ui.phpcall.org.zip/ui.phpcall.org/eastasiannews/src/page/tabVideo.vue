<template>
    <div id="app" class="with-bar tab-video" :class="{'page-loading':page.loading || initLoading}">
        <ui-loading v-if="initLoading" class="page-init-loading">
             <div slot="content"></div>
        </ui-loading>
        <scroll-fixed>
            <div class="ui-header">
                <div class="tabs">
                    <div class="tabs-wrap">
                        <ui-tabs ref="tabs" :list="channel.my" :active="page.channel_id" @choose="changeTab" @init="initTabs"/>
                    </div>
                    <a href="javascript:;" @click="channel.status = true" class="add-on">
                        <i class="uicon uicon-add"></i>
                    </a>
                </div>
            </div><!-- end ui-header -->
        </scroll-fixed>

        <ui-loading v-if="page.loading" />
       <page-error v-else-if="page.is_end && news.list.length == 0">
            <div slot="logo">
                <img src="../assets/page-empty.png" class="logo">
            </div>
            <div slot="text">
                <p class="text">暂无内容</p>
            </div>
        </page-error>
        <page-error v-else-if="pageError" @refresh="pageRefresh"></page-error>
        <scroll-list v-else ref="scroll" class="ui-list" :config="scroll" @pull="pullLoad" @bottom="loadmore">
             <div class="area-bar" v-if="this.page.country_short_name!== ''">
                <div class="wrap">
                    <a href="javascript:void(0);" @click="area.status = true" class="item">
                        <i class="uicon uicon-gps"></i><span>更多区域</span>
                    </a>
                    <div class="item">
                        <img :src="page.area.weather_icon"><span>{{page.area.weather_desc}}</span>
                    </div>
                </div>
            </div>
            <transition-group name="list" tag="div">
                <ui-item v-for="item in news.list" :item="item" :key="item.type + '_' +item.id" @more="popupMore" @playVideo="playVideo" ></ui-item>
            </transition-group>
        </scroll-list><!-- en dui-list -->

        <offline :withbar="true"/>
        <ui-tab-bar :active="page.tabBarActive" @change="tabChange"></ui-tab-bar>
        <popup-channel ref="channel" v-if="channel.status" :config="channel" :type="'video'"  @done="channelChange" />
        <popup-more :status="moreConfig.status" :config="moreConfig" @report="report_status = true,moreConfig.status=false" @unlick="removeItem"  @close="moreConfig.status = false" @fav="changeFav" @night="changeNight"></popup-more>
        
        <ui-report v-if="report_status" :id="moreConfig.item.id" :type="moreConfig.item.type" :title="moreConfig.item.title" @cancel="reportCancel" @done="reportDone"/>
        <ui-player ref="player" :config="player" @muted="mutedChange"/>
        <popup-area :status="area.status" :active="page.area" :list="channel" @done="areaDone" @close="area.status = false"></popup-area>
    </div>
</template>
<script>
import Area from "../components/area.vue";
import Items from '../components/items.vue'
import ScrollList from '../components/scrollList.vue'
import pageBar from '../components/pagebar.vue'
import scrollFixed from '../components/scrollFixed.vue'
import moreBox from '../components/morebox.vue'
import pageError from '../components/pageError.vue'
import offline from '../components/offline.vue'
import UILoading from '../components/loading.vue'

import mxNavTab from '../mixins/navtab.js'
import mxTabBar from '../mixins/tabbar.js'
import mxPlayer from '../mixins/player.js'
import mxReport from '../mixins/report.js'
export default {
    name:'tab-video',
    data(){
        return {
            page:{
                tabBarActive:1,
                cache_channel_type:'video_channel',
                is_end:false,//是否已经没有数据
                page_no:1,
                channel_id:'',
                country_short_name:'',
                loading:true,
                area:{}
            },
            area: {
                status: false
            },
            pageError:false,
            initLoading:true,
            moreConfig:{
                id:'',
                status:false,
                fav:false,
                night:false,
                item:''
            },
            news:{
                list:[]
            },
            scroll:{
                pull:false,
                bottom:false,
            },
        }
    },
    mixins: [mxNavTab,mxTabBar,mxPlayer,mxReport],
    components:{
        [Area.name]: Area,
        [Items.name]:Items,
        [scrollFixed.name]:scrollFixed,
        [ScrollList.name]:ScrollList,
        [offline.name]:offline,
        [UILoading.name]:UILoading,
        [pageError.name]:pageError,
        [moreBox.name]:moreBox,
    },
    mounted(){
        this.$on("RELOADDATA",type=>{
            this.$emit('PLYAER_CLOSE');
            this.page.page_no = 1;
            this.page.loading = true;
            this.page.is_end = false;

            this.loadPageData(true).then(rs=>{
            }).catch(e=>{
                this.pageError = true;
            }).finally(()=>{
                this.$nextTick(()=>{
                    this.initLoading = false;
                    this.page.loading = false;
                })
            })
        });
      
    },
    methods:{
        loadPageData(needClean = false,isUnshift = false){
            let url ,params = {
            }

            let pchannel = [],
                pcounry = [];

            this.channel.my.forEach(item=>{
                if(item.short_name){
                    pcounry.push(item.short_name);
                }else{
                    pchannel.push(item.id);
                }
            })

            if (this.page.channel_id === "") {//选中了地区
                if(pchannel.length>0) params.channel_ids = pchannel.join(',');
                params.countrys = this.page.country_short_name
            }

            if (this.page.country_short_name === "") {//选中频道
               if(pcounry.length>0) params.countrys = pcounry.join(',');
               params.channel_ids = this.page.channel_id;
            }
        
            url = '?ct=news&ac=get_list';
            params.type = 2; 

            // if (this.page.channel_id === 0) {
            //     params.is_home_page = 1;
            // }
         
            return this.$http.get(url,{params}).then(response=>{
                let {data} = response;
                if(needClean) this.news.list = [],document.body.scrollTop = 0;
                if(data.code == 0){
                    this.page.is_end = !data.data.is_have_data;
                    let list = [];
                    data.data.list && data.data.list.forEach && data.data.list.forEach(item=>{
                        if(this.$utils.unlike.check(item.id)) return;
                        let tmpItem = item;
                        tmpItem.url = item.detail_url;
                        tmpItem.type = 'video-item';
                        tmpItem.src = item.cover_img[0];

                        tmpItem.source = {
                            name:item.publisher
                        }
                        tmpItem.view = item.browse_total;
                        tmpItem.time = this.$moment(item.issue_time * 1000).fromNow().replace(' ','');
                        if(!item.is_hot && item.style_num != 1){
                            tmpItem.close = true;
                        }
                        list.push(tmpItem)
                    })

                    if(!needClean){
                        if(isUnshift){
                            let savelist = [];
                            this.news.list.forEach(item=>{
                                if(item.is_top !== 1){
                                    savelist.push(item); 
                                }
                            })
                            this.news.list = list.concat(savelist);
                            return data.data.count
                        }else{
                           let savelist = [];
                            list.forEach(item=>{
                                if(item.is_top !== 1){
                                    savelist.push(item); 
                                }
                            })
                            this.news.list = this.news.list.concat(savelist);
                        }
                    }else{
                        this.news.list = list;
                    }
                    
                    this.page.page_no++;
                }else{
                    this.$toast(data.msg);
                }
            }).catch(err=>{
                window.$zEvent.$emit('ERROR',err);
                this.$toast(err);
            })
          
        },
        pullLoad(cb){
           this.loadPageData(false,true).then((count)=>{
                this.$nextTick(() => {
                    this.$refs.scroll.$emit('refresh_done',count)
                    cb()
                });
            })
        },
        loadmore(){
            if(this.page.is_end || this.scroll.bottom) return false;
            console.log('load more');
            this.scroll.bottom = true;
            this.loadPageData().finally(()=>{
                this.$nextTick(()=>{
                    this.scroll.bottom = false;
                })
            })
        },
        popupMore(item){
            console.log('more',item);
            this.moreConfig.id = item.id;
            this.moreConfig.item = item;
            this.moreConfig.fav = !!item.is_collect;
            this.moreConfig.night = false;
            this.moreConfig.status = true;
        },
        changeFav(flag){
            this.moreConfig.fav = flag;
            this.moreConfig.item.is_collect = flag ? 1 : 0
            this.moreConfig.status = false;
        },
        changeNight(flag){
            this.moreConfig.night = flag;
            this.moreConfig.status = false;
             
        },
        pageRefresh(){
            this.pageError = false;
            this.$emit('RELOADDATA');
        },
        removeItem() {
            let item = this.moreConfig.item;
            let idx = this.news.list.indexOf(item);
            this.news.list.splice(idx, 1);
        },
        areaDone(item) {
            if(item.short_name !== this.page.area.short_name){
                for(let i = 0,len = this.channel.my.length;i<len;i++){
                    let channel = this.channel.my[i];
                    if(channel.short_name == this.page.area.short_name){
                        this.channel.my.splice(i,1,item);
                        this.page.area = item;
                        this.page.country_short_name = item.short_name;
                        this.updateTabData(this.channel.my);
                        this.$nextTick(()=>{
                            this.$emit('RELOADDATA','channelChange');
                        })
                        break;
                    }
                }
            }
            this.area.status = false;
        },
    }
}
</script>
<style lang="less">
.tab-video {
    .video-item + .video-item {
        margin-top:12px;
    }
}

</style>


