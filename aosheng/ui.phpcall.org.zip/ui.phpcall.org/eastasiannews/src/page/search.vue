<template>
    <div id="app" class="page-search">
        <div class="search-box">
            <form class="input-box">
                <i class="uicon uicon-search-dark search" @click="search"></i>
                <input type="search" v-model.trim="keyword" :placeholder="placeholder" @keypress.enter="search(keyword)">
                <i class="uicon uicon-close" @click="clearKeyWord"></i>
            </form>
            <a href="javascript:history.back();">取消</a>
        </div>
        <!-- end search-box -->
        <div class="scroll-box">
            <div class="history-box">
                <a href="javascript:;" v-if="item.isShow" @click="searchItem(item)" class="hitem" v-for="(item, index) in initHistoryList" :key="index">
                    <i class="uicon uicon-history"></i>
                    <span>{{ item.keyword }}</span>
                    <a href="javascript:;" @click.stop="remove(index)" class="close">&times;</a>
                </a>
                <a href="javascript:;"  class="all" @click="showAllOrClear" v-if="initHistoryList.length > 2">
                    {{ isShowAll ? '全部搜索记录' : '清除历史记录' }}
                </a>
            </div>
            <div class="search-empty" v-if="searchResult.status">
                <div class="cont">
                    <p>抱歉，没有找到</p>
                    <p>“
                        <span>{{searchResult.keyword}}</span>”相关内容</p>
                </div>
            </div>
            <!-- end search-empty -->
            <!-- 有搜索结果的情况 -->
            <div class="result-box" v-if="!searchResult.status">
                <div class="result-item" v-for="lists in searchResult.list" :key="lists.type" v-if="lists.list.length > 0">
                    <p class="classify" v-if="lists.type === 1">图文新闻</p>
                    <p class="classify" v-if="lists.type === 2">视频新闻</p>
                    <p class="classify" v-if="lists.type === 3">专题新闻</p>
                    <p class="classify" v-if="lists.type === 4">图集新闻</p>
                    <ul>
                        <li v-for="item in lists.list" :key="item.id">
                            <a :href="item.detail_url" class="news-box">
                                <div>
                                    <p class="news-title" v-html="item.title"></p>
                                    <p class="news-bottom">
                                        <span class="news-source">{{ item.publisher }}</span>
                                        <span>{{ item.issue_date }}</span>
                                        <span>{{ item.browse_total }}阅</span>
                                    </p>
                                </div>
                                <div>
                                    <img :src="item.cover_img[0]" alt="" class="news-img">
                                    <i class="icon-play-btn" v-if="lists.type === 4"></i>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <a @click="go($config.pages.hot)" class="view-more">
                        查看更多热点事件
                        <i class="icon-more"></i>
                    </a>
                </div>
            </div>
            <div class="hot-box">
                <div class="hot-header">
                    <p>
                        <i class="uicon uicon-hot-list"></i>
                        <span>今日热点</span>
                    </p>
                    <a @click="go($config.pages.hot)">更多
                        <i class="uicon uicon-link"></i>
                    </a>
                </div>
                <div class="list">
                    <a :href="item.detail_url" class="item" v-for="item in hot" :key="item.id">{{item.title}}</a>
                </div>
            </div>
            <!-- end hot-box -->
        </div>
    </div>
</template>
<script>
import Utils from "../utils/index.js";
import Items from "../components/items.vue";

export default {
    name: "page-search",
    components: {
        [Items.name]: Items
    },
    data() {
        return {
            keyword: "",
            placeholder: "个人照遭公开售卖",
            history: [],
            initHistoryList: [],
            isShowAll: true,
            searchResult: {
                status: false, //false-有搜索结果   true-无搜索结果
                list: []
            },
            hot: [],
        };
    },

    created () {
        this.initHistoryFn();
        this.getHot();
    },

    methods: {
        go(url){
            location.href = url;
        },
        initHistoryFn () {
            localStorage.getItem('search') ? this.initHistoryList = JSON.parse(localStorage.getItem('search')) : '';
        },

        clearKeyWord () {
            this.keyword = '';
        },

        search (keyword) {
            if (!keyword) {
                return false;
            }
            let keywordHandle = '<span class="mark">' + keyword + "</span>";
            this.$http.get("?ct=news&ac=get_list", { params: keyword }).then(res => {
                    if (res.code !== 0) {
                        this.searchResult.status = true;
                        this.searchResult.list = [];
                    }
                    this.searchResult.status = false;
                    let list = res.data.data.list;
                    this.searchResult.list = [
                        {
                            type: 1,
                            list: []
                        },
                        {
                            type: 2,
                            list: []
                        },
                        {
                            type: 3,
                            list: []
                        },
                        {
                            type: 4,
                            list: []
                        }
                    ];
                    //按类型分类存储
                    list.forEach(item => {
                        this.searchResult.list[item.type - 1].list.push(item);
                    });
                    // 替换关键字
                    for (let i = 0; i < this.searchResult.list.length; i++) {
                        let sublist = this.searchResult.list[i].list;
                        for (let j = 0; j < sublist.length; j++) {
                            sublist[j].title = sublist[j].title.replace(keyword,keywordHandle);
                        }
                    }
                    console.log(this.searchResult);
                });

            localStorage.getItem('search') ? this.history = JSON.parse(localStorage.getItem('search')) : '';

            if (this.history.length === 0) {
                this.history.unshift( {"keyword": keyword, isShow: true} );
            } else {
                let isExistSame = false;
                this.history.forEach(item => {
                    if (item.keyword === keyword) {
                        isExistSame = true;
                    }
                });
                !isExistSame ? this.history.unshift( {"keyword": keyword, isShow: true} ) : '';
            }
            this.history.forEach((item, index) => {
                index >=2 ? item.isShow = false : '';
            });
            localStorage.setItem('search', JSON.stringify(this.history));
            this.initHistoryFn();
            this.isShowAll = true;
        },

        searchItem (item) {
            this.keyword = item.keyword;
            this.search(item.keyword);
        },

        remove (index) {
            this.initHistoryList.splice(index, 1);
            if (this.isShowAll) {
                this.initHistoryList.forEach((item, index) => {
                    index < 2 ? item.isShow = true : item.isShow = false;
                });
            }
            this.initHistoryList.length === 0 ? this.isShowAll = true : '';
            localStorage.setItem('search', JSON.stringify(this.initHistoryList));
            this.initHistoryFn();
        },

        showAllOrClear () {
            if (this.isShowAll) {
                this.initHistoryList.forEach(item => {
                    item.isShow = true;
                });
                this.isShowAll = false;
            } else {
                this.initHistoryList = [];
                this.isShowAll = true;
                localStorage.setItem('search', JSON.stringify(this.initHistoryList));
            }
        },

        getHot () {
            this.$http.get("?ct=news&ac=today_hot").then(res => {
                this.hot = res.data.data;
            })
        },
    } // methods end
};
</script>
<style lang="less">

.page-search {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    display: flex;
    flex-direction: column;
    background-color: #f6f6f6;

    .search-box {
        display: flex;
        align-items: center;
        padding-top: 14px;
        padding-bottom: 14px;
        height: 60px;
        box-sizing: content-box;
        .input-box {
            display: flex;
            flex: 1;
            align-items: center;
            height: 100%;
            padding: 14px 30px 14px 20px;
            background-color: #f6f6f6;
            border-radius: 30px;

            .search {
                margin-right: 12px;
            }

            input {
                background-color: transparent;
                border: none;
                outline: none;
                flex: 1;
                color: #282828;
                font-size: 28px;
                caret-color: #e64a19;
                &::-webkit-input-placeholder {
                    color: #c6c6c6;
                }
            }
        }

        a {
            padding-left: 30px;
            font-size: 30px;
            color: #e64a19;
        }
    }
    .scroll-box {
        flex: 1;
        overflow: auto;
        -webkit-overflow-scrolling: touch;
    }

    .history-box,
    .search-box,
    .list-box {
        background-color: #fff;
        padding-left: 30px;
        padding-right: 30px;
    }

    .history-box {
        .hitem,
        .all {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .close {
            color: #dcdcdc;
            padding: 0 20px;
        }
        .hitem {
            font-size: 32px;
            height: 80px;
            color: #282828;
            box-sizing: content-box;
            border-bottom: 1px solid #eeeeee;
            span {
                margin-left: 20px;
                flex: 1;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
        }
        .all {
            font-size: 30px;
            height: 90px;
            color: #919191;
        }
    }
    .result-item,
    .hot-box {
        margin-top: 10px;
    }
    .hot-box {
        padding: 20px 30px 0;
        background-color: #fff;
    }

    .hot-header {
        padding: 10px 0;
        font-size: 30px;
        &,
        p,
        a {
            display: flex;
            align-items: center;
        }
        p {
            flex: 1;
            font-weight: bold;
            color: #282828;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;

            i {
                margin-right: 12px;
            }
        }

        a {
            margin-left: 12px;
            color: #5a4640;

            i {
                margin-left: 10px;
            }
        }
    }

    .list {
        a {
            display: block;
            line-height: 90px;
            height: 90px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            font-size: 32px;
            color: #282828;

            & + a {
                border-top: 1px solid #eee;
            }
        }
    }

    .search-empty {
        padding-bottom: 66px;
        height: 495px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        align-items: center;
        background-color: #fff;
        background-size: 690px 248px;
        background-repeat: no-repeat;
        background-image: url(../assets/search-empty.jpg);
        background-position: center 80px;

        p {
            text-align: center;
            font-size: 32px;
            color: #282828;
            line-height: 42px;

            span {
                color: #e64a19;
            }
        }
    }

    .result-box {
        .result-item {
            padding: 0 24px;
            background: #fff;
        }
        .classify {
            padding: 30px 0 20px;
            font-size: 36px;
            line-height: 1;
            font-weight: bold;
            color: #282828;
        }
        .news-box {
            display: flex;
            justify-content: space-between;
            padding: 24px 0;
            border-bottom: 1px solid #e3e3e3;
        }
        .news-box > div:first-child {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .news-title {
            display: -webkit-box;
            line-height: 1.4;
            overflow: hidden;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            font-size: 34px;
            color: #282828;
        }
        .mark {
            color: #e64a19;
        }
        .news-bottom {
            margin-bottom: 3px;
            font-size: 22px;
            color: #919191;
            span {
                margin-right: 15px;
            }
            .news-source {
                color: #a98273;
            }
        }
        .news-box > div:last-child {
            position: relative;
            .news-img {
                display: inline-block;
                width: 235px;
                height: 165px;
                margin-left: 32px;
                border-radius: 10px;
            }
            .icon-play-btn {
                display: inline-block;
                width: 70px;
                height: 70px;
                background-image: url(../assets/icon-play-btn.png);
                background-size: 100% 100%;
                position: absolute;
                top: 25%;
                left: 45%;
                z-index: 999;
            }
        }
        .view-more {
            display: inline-block;
            width: 100%;
            text-align: center;
            font-size: 30px;
            color: #5a4640;
            padding-top:10px;
            padding-bottom:30px;
            i {
                position: relative;
                top: 2px;
                display: inline-block;
                width: 26px;
                height: 26px;
                background-image: url(../assets/icon-view-more.png);
                background-size: 100% 100%;
            }
        }

        ul {
            li:last-child a{
                border: 0;
            }
        }
    }
}
</style>


