<template>
    <div id="app" class="about-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">关于</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <section>
            <div>
                <img src="../assets/guanyu_logo.png" alt="">
            </div>
            <div>
                <p>东亚新闻</p>
                <span>版本V1.0.0</span>
            </div>
        </section>
        <footer>
            Copyright©️2017 Callu Inc. All Rights Reserved
        </footer>
    </div>
</template>

<script>
import scrollFixed from "../components/scrollFixed.vue";
import pageBar from "../components/pagebar.vue";
export default {
    name: "about",
    components: {
        [scrollFixed.name]: scrollFixed,
        [pageBar.name]: pageBar
    },
    data() {
        return {};
    },
    created() {},
    methods: {}
};
</script>

<style lang="less">
.about-page {
    display: flex;
    flex-direction: column;
    background-color: #fff;

    .header-middle {
        font-size: 36px;
        color: #333;
    }

    section {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding-top: 200px;
        background-color: #f6f6f6;
        p {
            margin: 20px 0 10px 0;
            font-size: 36px;
            color: #000;
        }
        span {
            font-size: 24px;
            color: #9e9e9e;
        }
        div:last-child {
            text-align: center;
        }
    }

    footer {
        position: absolute;
        bottom: 60px;
        align-self: center;
        background-color: #f6f6f6;
        text-align: center;
        color: #b3b3b3;
    }
}
</style>


