<template>
    <div id="app" class="with-bar index" :class="{'page-loading':page.loading|| initLoading}">
        <ui-loading v-if="initLoading" class="page-init-loading">
             <div slot="content"></div>
        </ui-loading>
        <scroll-fixed>
            <div class="ui-header">
                <div class="header-search">
                    <a href="/" class="logo">
                        <img src="../assets/logo.png" alt="">
                    </a>
                    <a @click="go('search')" class="search">
                        <i class="uicon uicon-search"></i>
                        <!-- <input type="text" placeholder="搜索新闻"> -->
                        <span>搜索新闻</span>
                    </a>
                    <!-- <div class="loc">
                        <span>{{page.area.name}}</span>
                        <i class="uicon uicon-gps" @click="area.status = true"></i>
                    </div> -->
                </div>
                <!-- end header-search -->
                <div class="tabs">
                    <div class="tabs-wrap">
                        <ui-tabs ref="tabs" :list="channel.my" :active="page.channel_id" @choose="changeTab" @init="initTabs" />
                    </div>
                    <a href="javascript:;" @click="channel.status = true" class="add-on">
                        <i class="uicon uicon-add"></i>
                    </a>
                </div>
            </div>
            <!-- end ui-header -->
        </scroll-fixed>
        <ui-loading v-if="page.loading" />
        <page-error v-else-if="page.is_end && news.list.length == 0">
            <div slot="logo">
                <img src="../assets/page-empty.png" class="logo">
            </div>
            <div slot="text">
                <p class="text">暂无内容</p>
            </div>
        </page-error>
        <page-error v-else-if="pageError" @refresh="pageRefresh"></page-error>
        <scroll-list ref="scroll" v-else class="ui-list" :config="scroll" @pull="pullLoad" @bottom="loadmore">
            <div class="area-bar" v-if="this.page.country_short_name!== ''">
                <div class="wrap">
                    <a href="javascript:void(0);" @click="changeAreaChange" class="item">
                        <i class="uicon uicon-gps"></i><span>更多区域</span>
                    </a>
                    <div class="item">
                        <img :src="page.area.weather_icon"><span>{{page.area.weather_desc}}</span>
                    </div>
                </div>
            </div>
            <transition-group name="list" tag="div">
                <ui-item v-for="(item,index) in news.list" :item="item" :key="item.type + '_' +item.id" @playVideo="playVideo" @close="removeItem(item,index)"></ui-item>
            </transition-group>
        </scroll-list>
        <!-- en dui-list -->

        <offline :withbar="true" />
        <ui-tab-bar :active="page.tabBarActive" @change="tabChange"></ui-tab-bar>
        <popup-area :status="area.status" :active="page.area"  :list="channel" @done="areaDone" @close="area.status = false"></popup-area>
        <popup-channel ref="channel" v-if="channel.status" :config="channel" @done="channelChange" />

        <ui-player ref="player" :config="player" />

         <ui-popup :status="alert.status" @close="alert.status = false">
            <div class="ui-alert">
                <div class="alert-content">
                    <p>切换地区</p>
                    <span>检测到你在{{alert.name}},是否切换到该地区?</span>
                </div>
                <div class="alert-footer">
                    <a href="javascript:;" @click="alert.status = false">取消</a>
                    <a href="javascript:;" @click="confirm">确定</a>
                </div>
            </div>
        </ui-popup>
    </div>
</template>
<script>
import Items from "../components/items.vue";
import ScrollList from "../components/scrollList.vue";
import Area from "../components/area.vue";
import scrollFixed from "../components/scrollFixed.vue";
import offline from "../components/offline.vue";
import UILoading from "../components/loading.vue";
import pageError from "../components/pageError.vue";
import UIPopup from "../components/popup.vue";

import mxNavTab from "../mixins/navtab.js";
import mxTabBar from "../mixins/tabbar.js";
import mxPlayer from "../mixins/player.js";

export default {
    name: "index",
    data() {
        return {
            initLoading:true,
            page: {
                tabBarActive: 0,
                cache_channel_type: "news_channel",
                is_end: false, //是否已经没有数据
                page_no: 1,
                channel_id: 0,
                country_short_name: "",
                loading: true,
                area: {},
                gps: ""
            },
            alert: {
                status: false,
                item: "",
                name: ""
            },
            pageError: false,

            scroll: {
                pull: false,
                bottom: false
            },

            area: {
                status: false
            },
            news: {
                list: []
            }
        };
    },
    mixins: [mxNavTab, mxTabBar, mxPlayer],
    components: {
        [Items.name]: Items,
        [Area.name]: Area,
        [scrollFixed.name]: scrollFixed,
        [offline.name]: offline,
        [ScrollList.name]: ScrollList,
        [UILoading.name]: UILoading,
        [pageError.name]: pageError,
        [UIPopup.name]: UIPopup
    },
    mounted() {
        // this.getGPS();
        this.$on("GPS_DONE", name => {
            this.changeNameInArea(name);
        });

        this.$on("RELOADDATA", type => {
            this.$emit("PLYAER_CLOSE");
            this.page.page_no = 1;
            this.page.loading = true;
            this.page.is_end = false;

            this.loadPageData(true)
                .then(rs => {})
                .catch(e => {
                    this.pageError = true;
                })
                .finally(() => {
                    this.$nextTick(()=>{
                        this.page.loading = false;
                        this.initLoading = false;
                    })
                });
        });
    },
    methods: {
        go(key) {
            location.href = this.$config.pages[key];
        },
        confirm() {
            this.alert.status = false;
            this.areaDone(this.alert.item);
        },
        changeNameInArea(name) {
            if (this.page.area.name == name) return false;
            let item = this.getAreaByName(name);
            if (item) {
                this.page.gps = "";
                this.alert.name = name;
                this.alert.item = item;
                this.alert.status = true;
            } else {
                this.page.gps = name;
            }
        },
        loadPageData(needClean = false, isUnshift = false) {
            let url,
                params = {};

            let pchannel = [],
                pcounry = [];

            this.channel.my.forEach(item => {
                if (item.short_name) {
                    pcounry.push(item.short_name);
                } else {
                    pchannel.push(item.id);
                }
            });

            if (this.page.channel_id === "") {
                //选中了地区
                if (pchannel.length > 0) {
                    params.channel_ids = pchannel.join(",");
                }
                params.countrys = this.page.country_short_name
            }

            if (this.page.country_short_name === "") {
                //选中频道
                if (pcounry.length > 0) params.countrys = pcounry.join(",");
                params.channel_ids = this.page.channel_id;
            }

            url = "?ct=news&ac=get_list";

            if (this.page.channel_id === 0) {
                params.is_home_page = 1;
            }

            return this.$http
                .get(url, { params })
                .then(response => {
                    let { data } = response;
                    if (needClean)
                        (this.news.list = []), (document.body.scrollTop = 0);
                    if (data.code == 0) {
                        this.page.is_end = !data.data.is_have_data;
                        let list = [];
                        data.data.list &&
                            data.data.list.forEach &&
                            data.data.list.forEach(item => {
                                if (this.$utils.unlike.check(item.id)) return;
                                let tmpItem = {};
                                if (item.style_num == 6) {
                                    //热点新闻
                                    tmpItem.url = this.$config.pages.hot;
                                    tmpItem.type = "hot-list";
                                    let childList = [];
                                    toString.call(item.list) ==
                                        "[object Array]" &&
                                        item.list.forEach(child => {
                                            if (
                                                this.$utils.unlike.check(
                                                    child.id
                                                )
                                            )
                                                return;
                                            let citem = child;
                                            citem.type =
                                                child.type == 3 ? "专题" : "";
                                            citem.url = item.detail_url;

                                            citem.source = child.publisher;
                                            citem.view = child.browse_total;
                                            citem.time = this.$moment(
                                                child.issue_time * 1000
                                            )
                                                .fromNow()
                                                .replace(" ", "");
                                            citem.src = child.cover_img[0];
                                            childList.push(citem);
                                        });
                                    tmpItem.list = childList;
                                } else {
                                    tmpItem = item;
                                    tmpItem.url = item.detail_url;
                                    tmpItem.type = (() => {
                                        switch (item.style_num) {
                                            case 1:
                                                return "special";
                                            case 2:
                                                return "normal";
                                            case 3:
                                                return "grid";
                                            case 4:
                                                return "video";
                                            case 5:
                                                return "single";
                                        }
                                    })();
                                    if (tmpItem.type !== "grid") {
                                        tmpItem.src = item.cover_img[0];
                                    } else {
                                        tmpItem.src = item.cover_img;
                                    }

                                    tmpItem.source = item.publisher;
                                    tmpItem.view = item.browse_total;
                                    tmpItem.time = this.$moment(
                                        item.issue_time * 1000
                                    )
                                        .fromNow()
                                        .replace(" ", "");
                                    if (item.style_num != 1) {
                                        tmpItem.close = true;
                                    }
                                }
                                list.push(tmpItem);
                            });

                        if (!needClean) {
                            if(isUnshift){
                                let savelist = [];
                                
                                this.news.list.forEach(item=>{
                                    if(item.is_top !== 1){
                                       savelist.push(item); 
                                    }
                                })
                                this.news.list = list.concat(savelist);
                                return data.data.count
                            }else{
                                let savelist = [];
                                list.forEach(item=>{
                                    if(item.is_top !== 1){
                                       savelist.push(item); 
                                    }
                                })
                                this.news.list = this.news.list.concat(savelist);
                            }
                        } else {
                            this.news.list = list;
                        }

                        this.page.page_no++;
                    } else {
                        this.$toast(data.msg);
                    }
                })
                .catch(err => {
                    console.log(err);
                    this.$toast(err);
                });
        },
        pullLoad(cb) {
            console.log("load pull");
            this.loadPageData(false,true).then((count)=>{
                this.$nextTick(() => {
                    this.$refs.scroll.$emit('refresh_done',count)
                    cb()
                });
            })
        },
        pageRefresh() {
            this.pageError = false;
            this.$emit("RELOADDATA");
        },
        areaDone(item) {
            if(item.short_name !== this.page.area.short_name){
                for(let i = 0,len = this.channel.my.length;i<len;i++){
                    let channel = this.channel.my[i];
                    if(channel.short_name == this.page.area.short_name){
                        this.channel.my.splice(i,1,item);
                        this.page.area = item;
                        this.page.country_short_name = item.short_name;
                        this.updateTabData(this.channel.my);
                        this.$nextTick(()=>{
                            this.$emit('RELOADDATA','channelChange');
                        })
                        break;
                    }
                }
            }
            this.area.status = false;
          
        },
        loadmore() {
            if (this.page.is_end || this.scroll.bottom) return false;
            console.log("load more");
            this.scroll.bottom = true;
            this.loadPageData().finally(() => {
                this.$nextTick(() => {
                    this.scroll.bottom = false;
                });
            });
        },
        removeItem(item, idx) {
            console.log(item, idx);
            this.$utils.unlike.set(item.id);
            this.news.list.splice(idx, 1);
        },
        getGPS() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    pos => {
                        this.$http
                            .post(
                                `https://maps.googleapis.com/maps/api/geocode/json?latlng=${
                                    pos.coords.latitude
                                },${
                                    pos.coords.longitude
                                }&key=AIzaSyAcIGkvGvmvvGOfW6pVvvLeNyW1f7dh7JY`
                            )
                            .then(response => {
                                let data = response.data.results;
                                console.log(data);
                                for (let i = 0; i < data.length; i++) {
                                    if (
                                        data[i].types.indexOf("country") != -1
                                    ) {
                                        this.$emit(
                                            "GPS_DONE",
                                            data[i].formatted_address
                                        );
                                        return;
                                    }
                                }
                            });
                    },
                    function(err) {
                        console.log("error", err);
                    },
                    {
                        enableHighAccuracy: true, // 是否获取高精度结果
                        timeout: 5000, //超时,毫秒
                        maximumAge: 0 //可以接受多少毫秒的缓存位置
                    }
                );
            }
        },
        changeAreaChange(){
            this.area.status = true;
        }
    }
};
</script>
<style lang="less">
.header-search {
    display: flex;
    align-items: center;
    height: 82px;
    font-size: 28px;
    padding: 0 24px;
    background-color: #fff;

    .logo img {
        margin-left: 6px;
        display: block;
        width: 50px;
        height: 50px;
    }
    .search {
        display: flex;
        align-items: center;
        padding: 0 20px;
        margin: 0 10px 0 30px;
        flex: 1;
        border-radius: 30px;
        background-color: #f6f6f6;
        font-size: 28px;
        color: #c6c6c6;
        height: 60px;

        i {
            margin-right: 12px;
        }
        input {
            background-color: transparent;
            border: none;
            outline: none;
            flex: 1;
            color: #282828;
            font-size: 28px;
            ::-webkit-input-placeholder {
                color: #c6c6c6;
            }
        }
    }

    .loc {
        display: flex;
        align-items: center;
        color: #5a4640;

        i {
            margin-left: 12px;
        }
    }
}

.ui-alert {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 600px;
    height: 330px;
    background: #fff;
    z-index: 999;
    transform: translate(-50%, -50%);
    border-radius: 10px;
    .alert-content {
        text-align: center;
        padding: 30px;
        p {
            margin: 15px auto 35px;
            font-size: 36px;
            font-weight: 500;
            color: #282828;
        }
        span {
            line-height: 1.2;
            font-size: 32px;
            color: #666;
        }
    }
    .alert-footer {
        position: absolute;
        bottom: 0;
        width: 100%;
        display: flex;
        a {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 81px;
            width: 50%;
            text-align: center;
            font-size: 36px;
            border-top: 1px solid #e2e2e2;
            color: #666;

            &:last-child {
                color: #e64a19;
            }

            & + a {
                border-left: 1px solid #e2e2e2;
            }
        }
    }
}
</style>


