<template>
    <div id="app" class="detail" :class="{'night':moreConfig.night,'page-loading':pageLoading}">
        <scroll-fixed v-if="!isApp">
            <page-bar @right="moreConfig.status = true">
                <div slot="middle" class="header-middle">{{info.publisher}}</div>
            </page-bar>
        </scroll-fixed>
        <ui-loading v-if="pageLoading">
            <div slot="content"></div>
        </ui-loading>
        <page-error v-else-if="pageError" @refresh="pageRefresh"></page-error>
        <div v-else>       
            <div class="detail-cont">
                <div class="header wrap"  v-if="!isApp">
                    <p class="tit">{{info.title}}</p>
                    <p class="info">
                        <span>{{info.publisher}}</span>
                        <span>{{info.format_time}}</span>
                    </p>
                </div>
                <div class="cont" @click="previewImageAction($event)" v-lazy-container="{ selector: 'img' }" :class="{'xs':moreConfig.range == 1,'sm':moreConfig.range == 2,'normal':moreConfig.range==3,'md':moreConfig.range == 4,'lg':moreConfig.range == 5}" v-html="info.content"></div>
            </div><!-- detaiil-cont -->
            
            <a class="hot-rec" href="/hot.html" v-if="hot_list && hot_list.length > 0">
                <div class="hot-rec-tit">
                    <p>热点</p><p>精选</p>
                </div>
                <a :href="hot_list[0].detail_url" class="hot-rec-cont">
                    hot_list[0].title
                </a>
            </a><!-- end hot-rec -->

            <div class="push-list" v-if="recom_list.length > 0">
                <div class="header">
                    <span>延展阅读</span>
                    <i></i>
                </div>
                <div class="list">
                    <ui-item v-for="item in recom_list" :item="item" :key="item.id"></ui-item>
                </div>
            </div><!-- end pull-list -->
            
            <p class="detail-end">已显示全部内容</p><!-- detail-end -->
        </div> 
        <offline />
    
        <popup-more :status="moreConfig.status" :config="moreConfig" @font="fontChange" @report="report_status = true,moreConfig.status=false" @close="moreConfig.status = false" @fav="changeFav" @night="changeNight"></popup-more>
        <transition name="anim-report">
            <ui-report v-if="report_status" :id="info.id" :type="info.type" :title="info.title" @cancel="reportCancel" @done="reportDone"/>
        </transition>

        <ui-preview :config="preview" v-if="preview.status" @close="preview.status = false"/>
    </div>
</template>
<script>
import Items from '../components/items.vue'
import pageBar from '../components/pagebar.vue'
import scrollFixed from '../components/scrollFixed.vue'
import UILoading from '../components/loading.vue'
import pageError from '../components/pageError.vue'
import offline from '../components/offline.vue'

import uiPreview from '../components/preview.vue'

import MoreBox from '../components/morebox.vue'

import mxReport from '../mixins/report.js'


export default {
    name:'detail',
    data(){
        return {
            id:'',
            info:{},
            isApp:this.$utils.app.isApp,
            moreConfig:{
                id:'',
                status:false,
                fav:false,
                night:false,
                font:true,
                range:3,
            },
            preview:{
                status:false,
                delete:false,
                active:0,
                list:[]
            },
            pageLoading:true,
            pageError:false,
            recom_list:[],
            hot_list:[],
        }
    },
    mixins:[mxReport],
    mounted(){
        this.$on('pageRefresh',()=>{
            this.pageLoading = true;
            this.loadPage().then(rs=>{

            }).catch(e=>{
                this.pageError = true;
            }).finally(()=>{
                this.pageLoading = false;
            })
        })
        //获取默认字体大小
        let font = this.$utils.caches.get('font');
        this.moreConfig.range = isNaN(parseInt(font)) ? 3: parseInt(font);

        let parse = this.$utils.urlFactory.parse(location.search);
        if(parse && parse.id && !isNaN(parse.id)){
            this.id = parse.id;
            this.$emit('pageRefresh');
        }else{
            this.$toast('参数有误').then(()=>{
                history.back();
            })
        }
    },
    components:{
        [Items.name]:Items,
        [pageBar.name]:pageBar,
        [scrollFixed.name]:scrollFixed,
        [pageError.name]:pageError,
        [offline.name]:offline,
        [UILoading.name]:UILoading,
        [MoreBox.name]:MoreBox,
        [uiPreview.name]:uiPreview,
    },
    methods:{
        loadPage(){
            return this.$http.get('?ct=news&ac=detail&id=' + this.id).then(response=>{
                let {data} = response;
                if(data.code == 0){
                    let rs = data.data;
                    rs.info.content = rs.info.content.replace(/<img([\s\S]*?)src\s*=\s*(['"])([\s\S]*?)\2([^>]*)>/gi,'<img$1data-src=$2$3$2$4>')
                    this.info = rs.info;
                    rs.info.detail_url = location.href;
                    //添加历史记录
                    this.$utils.history.set(rs.info);


                    this.info.format_time = this.$moment(this.info.issue_time * 1000).format("MM/DD hh:mm");
                    
                    //是否已经收藏
                    this.moreConfig.fav = !!this.info.is_collect;
                    this.moreConfig.id = this.info.id;

                    let list = [];
                    rs.recom_list.forEach(item=>{
                        if(this.$utils.unlike.check(item.id)) return;
                        let tmpItem = item;
                      
                        tmpItem.url = item.detail_url;
                        tmpItem.type = (()=>{
                            switch(item.style_num){
                                case 1:
                                    return 'special';

                                case 2:
                                    return 'normal';
                                case 3:
                                    return 'grid';
                                case 4:
                                    return 'video';
                                case 5:
                                    return 'single';
                            }
                        })();
                        if(tmpItem.type !== 'grid'){
                            tmpItem.src = item.cover_img[0];
                        }else{
                            tmpItem.src = item.cover_img;
                        }

                        tmpItem.source = item.publisher;
                        tmpItem.view = item.browse_total;
                        tmpItem.time = this.$moment(item.issue_time * 1000).fromNow().replace(' ','');
                        
                        //设计稿这里只有normal类型的新闻
                        tmpItem.type = 'normal';
                        
                        list.push(tmpItem);
                    });

                    this.recom_list = list;

                }else{
                    let co = this.$toast(data.msg);
                    if(data.code == 5003 || data.code == 5004){
                        co.then(()=>{
                            history.back();
                        })
                    }
                    throw new Error(data.msg);
                }
            }).catch(e=>{
                this.$toast(e);
                throw e;
            })
        },
        fontChange(range){
            this.moreConfig.range = range;
            this.$utils.caches.set('font',range);
        },
        changeFav(flag){
            this.moreConfig.fav = flag;
            this.moreConfig.status = false;
        },
        changeNight(flag){
            this.moreConfig.night = !this.moreConfig.night;
            this.moreConfig.status = false;
        },
        pageRefresh(){
            this.pageError = false;
            this.$emit('pageRefresh');
        },
        previewImage(idx){
            this.preview.active = idx;
            this.preview.status = true;
        },
        previewImageAction(e){
            if(e.target.tagName.toUpperCase() === 'IMG'){
                if(this.preview.list.length == 0){
                    let imgs = e.currentTarget.querySelectorAll('img');
                    for(let i = 0,len = imgs.length;i<len;i++){
                        imgs[i].dataset.idx = i;
                        let src = imgs[i].getAttribute('data-src')
                        this.preview.list.push(src);
                    }
                }
                if(this.preview.list.length>0){
                    let idx = e.target.dataset.idx;
                    this.previewImage(idx);
                }
               
            }
        }
    }    
}
</script>
<style lang="less">
.detail {
    background-color:#fff;
    color:#282828;
    
    &.night {
        &,.page-bar,.list-item {
            background-color:#282423;
        }
        color:#fff;

        .list-item{
             .tit {
                 color:#fff;
             }
        }
    }

    .sticky {
       .header-middle {
           opacity:1;
       } 
    }
    .header-middle {
        transition: opacity .2s;
        font-size:34px;
        color:#141414;
        opacity: 0;
    }

    .detail-cont {
        padding-bottom:58px;
        .header.wrap {
            margin-bottom:40px;
            padding:0 30px;
        }
        .tit {
            font-size:44px;
            line-height: 64px;
            font-weight: bold;
        }
        .info {
            margin-top:20px;
            font-size:24px;
            color:#919191;
            span:first-child {
                color:#a98273;
            }
            span + span {
                margin-left:12px;
            }
        }
        
        .cont {
            padding:0 30px;
            line-height: 62/36;
            word-break: break-all;
            overflow: hidden;
            
            &.normal {
                font-size:36px;
            }
            &.xs {
                font-size:28px;
            }
            &.sm {
                font-size:32px;
            }
            &.md {
                font-size:40px;
            }
            &.lg {
                font-size:44px;
            }
            img {
                display: block;
                width:100%;
                height:auto;
                margin:40px auto;
            }
            
            p {
                // padding:0 30px;
            }
        }
    }
    .push-list {
        .header {
            margin-bottom:40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-size:38px;
            font-weight: bold;
            line-height: 1;

            i {
                margin-top:20px;
                display: block;
                width:32px;
                height:12px;
                background-color:#a98273;
                border-radius:6px;
            }
        }
    }
    .font-setting {
        position: absolute;
        left:0;
        right:0;
        bottom:0;
        z-index:2;
        background-color:#fff;
        overflow: hidden;

        .option {
            padding-top:50px;
            margin-bottom:50px;
            display: flex;
            
            .item {
                flex:1;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                font-size:28px;
                color:#282828;
                span {
                    margin-top:12px;
                    line-height: 1;
                }
            }
        }
        .slide {
            padding-top:32px;
            border-bottom:1px solid #efefef;
            .pick {
                position:relative;
                height:30px;
                span {
                    position: absolute;
                    top:0;
                    line-height: 30px;
                    color:#919191;
                    font-size:28px;
                    text-align: center;
                    &:first-child {
                        left:0%;
                    }
                    &:nth-of-type(2){
                        left:25%;
                        transform: translateX(-50%)
                    }
                    &:nth-of-type(3){
                        left:50%;
                        transform: translateX(-50%)
                        
                    }
                    &:nth-of-type(4){
                        left:75%;
                        transform: translateX(-50%)
                        
                    }
                    &:nth-of-type(5){
                        right:0;
                    }

                    &.on {
                        color:#e64a19;
                    }
                    
                }
            }
            .range {
                position: relative;
                height:130px;
                display: flex;
                justify-content: center;
                align-items: center;
                .line {
                    position:relative;
                    height: 4px;
                    width:100%;
                    border-radius:10px;
                    background-color:#efefef;

                    span {
                        position: absolute;
                        height:100%;
                        background: #e64a19;

                        &::after {
                            content:'';
                            position: absolute;
                            right:0;
                            width:30px;
                            height:30px;
                            border-radius:50%;
                            background-color:#e64a19;
                            transform: translate(50%,-50%);
                        }
                    }
                }
                input[type=range] {
                    position:absolute;
                    top:0;
                    left:0;
                    width:100%;
                    height:100%;
                    opacity:0;
                    -webkit-appearance: none; /* Hides the slider so that custom slider can be made */
                    width: 100%; /* Specific width is required for Firefox. */
                    // background: transparent; /* Otherwise white in Chrome */
                }


                input[type=range]:focus {
                    outline: none; /* Removes the blue border. You should probably do some kind of focus styling for accessibility reasons though. */
                }

                input[type=range]::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    border: none;
                    height: 30px;
                    width: 30px;
                    border-radius: 50%;
                    background: #e64a19;
                    cursor: pointer;
                    margin-top: -13px; /* You need to specify a margin in Chrome, but in Firefox and IE it is automatic */
                }

                input[type=range]::-webkit-slider-runnable-track {
                    height: 4px;
                    background-color:#efefef;
                    border-radius: 10px; /*将轨道设为圆角的*/
                }
                input[type=range]:focus::-webkit-slider-runnable-track {
                    background: #e64a19;
                }
            }
        }
        .slide,.cancel {
            margin:0 30px;
            
        }
        .cancel {
            display: flex;
            justify-content: center;
            align-items: center;
            border-top:1px solid #efefef;
            height:100px;
            color:#919191;
            font-size:32px;
        }
    }

    .detail-end {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 106px;
        color:#c6c6c6;
        font-size:28px;
    }

    .hot-rec {
        margin:0 30px 60px;
        border:1px solid #efefef;
        border-left:3px solid #e64a19;
        height:140px;
    }

    .hot-rec,.hot-rec-tit {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .hot-rec-tit {
        flex-shrink: 0;
        flex-grow: 0;
        flex-direction: column;
        font-weight: bold;
        font-size:36px;
        line-height: 42px;
        color:#282828;
        width:138px;
        height:79px;
        border-right: 2px solid #efefef;
    }
    .hot-rec-cont {
        flex:1;
        padding:0 30px;
        font-size:32px;
        color:#282828;
        line-height: 48px;
    }
}


</style>

