<template>
    <div id="app" class="system-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">系统消息详情</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <section class="color29 f30" v-html="message.describe">
        </section>
    </div>
</template>

<script>
    import scrollFixed from "../components/scrollFixed.vue";
    import pageBar from "../components/pagebar.vue";
    export default {
        name: "system_message",
        components: {
            [scrollFixed.name]: scrollFixed,
            [pageBar.name]: pageBar
        },
        data() {
            return {
                self: this,
                message: {}
            };
        },

        created () {
            this.getMessage();
        },

        methods: {
            getMessage () {
                let id = localStorage.getItem('msgId');
                let data = '';
                this.$http.get('?ct=member_center&ac=system_detail', {params: {id: id}}).then( res => {
                    data = res.data;
                    console.log(data);
                    if (data.code === 0) {
                        this.message = data.data;
                    }
                });
            },


        }
    };
</script>

<style lang="less">
    .system-page {

        .color29 {
            color: #292929;
        }

        .f30 {
            font-size: 30px;
        }

        display: flex;
        flex-direction: column;
        background-color: #fff;

        .header-middle {
            font-size: 36px;
            color: #333;
        }

        section {
            border-top: 1px solid #eee;
            position: fixed;
            top: 82px;
            left: 0;
            width: 100%;
            height: 100%;
            line-height: 1.5;
            padding: 45px 30px 0 30px;
            background: #fff;
        }
    }
</style>


