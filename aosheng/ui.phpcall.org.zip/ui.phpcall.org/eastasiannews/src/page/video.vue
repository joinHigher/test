<template>
    <div id="app" class="page-video" :class="{'page-loading':pageLoading}">
        <scroll-fixed>
            <page-bar>
                <a href="javascript:history.back();" slot="left">
                    <i class="uicon uicon-back-w"></i>
                </a>
                <a href="javascript:;" slot="right" @click="player.voice = !player.voice">
                    <i class="uicon uicon-voice" :class="{'uicon-voice':player.voice ,'uicon-voice-off':!player.voice }"></i>
                </a>
            </page-bar>
        </scroll-fixed>
        <ui-loading v-if="pageLoading">
            <div slot="content"></div>
        </ui-loading>
        <page-error v-else-if="pageError" @refresh="pageRefresh"></page-error>
        <scroll-list v-else class="ui-list" :config="scroll" :disabled="true" >
            <transition-group name="list" tag="div">
                <div class="video-dec-item" :class="{'active':active == item.id}" v-for="item in info" :key="item.id" :data-id="'p_'+item.id" @click="itemClick($event,item)">
                    <div class="player" @click.stop="playVideo($event,item)">
                        <i class="uicon uicon-play"></i>
                        <img v-lazy="item.src" class="bg">
                    </div>
                    <div class="cont">
                        <div class="tit">{{item.title}}</div>
                        <div class="info">
                            <p>
                                <span class="sname">
                                    <div class="slogo">
                                        <img v-lazy="item.logo_url" />
                                    </div>
                                    <span>{{item.source.name}}</span>
                                </span>
                                <span>{{item.time}}</span>
                            </p>
                            <p class="tool">
                                <span><i class="uicon uicon-view"></i> {{item.view}}</span>
                                <span><i class="uicon uicon-bar-more-w" @click.stop="popupMore(item)"></i></span>
                            </p>
                        </div>
                    </div>
                </div>
            </transition-group>
            <div class="list-header">
                <p>相关视频</p>
            </div>
            <transition-group name="list" tag="div">
                <div class="video-dec-item" :class="{'active':active == item.id}" v-for="item in recom_list" :data-id="'l_'+item.id" :key="item.id"  @click="itemClick($event,item)">
                    <div class="player" @click.stop="playVideo($event,item)">
                        <i class="uicon uicon-play"></i>
                        <img v-lazy="item.src" class="bg">
                    </div>
                    <div class="cont">
                        <div class="tit">{{item.title}}</div>
                        <div class="info">
                            <p>
                                <span class="sname">
                                    <div class="slogo">
                                        <img v-lazy="item.logo_url" />
                                    </div>
                                    <span>{{item.source.name}}</span>
                                </span>
                                <span>{{item.time}}</span>
                            </p>
                            <p class="tool">
                                <span><i class="uicon uicon-view"></i> {{item.view}}</span>
                                <span><i class="uicon uicon-bar-more-w" @click.stop="popupMore(item)"></i></span>
                            </p>
                        </div>
                    </div>
                </div>
            </transition-group>
         </scroll-list><!-- en dui-list -->
        
        <popup-more :status="moreConfig.status" :config="moreConfig" @report="popupReport" @close="moreConfig.status = false" @unlick="removeItem" @fav="changeFav" @night="changeNight"></popup-more>
        <ui-report v-if="report_status" :id="moreConfig.item.id" :type="moreConfig.item.type" :title="moreConfig.item.title" @cancel="reportCancel" @done="reportDone"/>
        <ui-player ref="player" :config="player"/>
    </div>
</template>
<script>
import Items from '../components/items.vue'
import pageBar from '../components/pagebar.vue'
import scrollFixed from '../components/scrollFixed.vue'
import ScrollList from '../components/scrollList.vue'
import MoreBox from '../components/morebox.vue'
import pageError from '../components/pageError.vue'
import offline from '../components/offline.vue'
import UILoading from '../components/loading.vue'

import mxPlayer from '../mixins/player.js'
import mxReport from '../mixins/report.js'

//滚动监听器，用于判断是否在滚动
let scrollTime;

function parseItem(item,vue){
    let tmpItem = item;
        tmpItem.url = item.detail_url;
        tmpItem.type = 'video-item';
        tmpItem.src = item.cover_img[0];
        tmpItem.source = {
            name:item.publisher
        }
        tmpItem.view = item.browse_total;
        tmpItem.time = vue.$moment(item.issue_time * 1000).fromNow().replace(' ','');
        return tmpItem
}

export default {
    name:'page-video',
    components:{
        [Items.name]:Items,
        [pageBar.name]:pageBar,
        [scrollFixed.name]:scrollFixed,
        [MoreBox.name]:MoreBox,
        [ScrollList.name]:ScrollList,
        [offline.name]:offline,
        [UILoading.name]:UILoading,
        [pageError.name]:pageError,
    },
    mixins: [mxPlayer,mxReport],
    data(){
        return {
            page:{
                id:'',
                is_end:false,
                page_no:2
            },
            pageLoading:true,
            pageError:false,
            moreConfig:{
                status:false,
                id:'',
                fav:false,
                night:false,
                item:''
            },
            scroll:{
                pull:false,
                bottom:false,
            },
            active:0,
            info:[],
            recom_list:[]
        }
    },
    mounted(){
        this.$on('pageRefresh',()=>{
            this.page.page_no = 1;
            this.page.is_end = false;
            this.pageLoading = true;
            this.loadPage(true).then(rs=>{

            }).catch(e=>{
                this.pageError = true;
            }).finally(()=>{
                this.pageLoading = false;
            })
        })

        window.addEventListener('scroll',this.scrollChangeTag,false);

        let parse = this.$utils.urlFactory.parse(location.search);
        if(parse && parse.id && !isNaN(parse.id)){
            this.page.id = parse.id;
            this.$emit('pageRefresh');
        }else{
            this.$toast('参数有误').then(()=>{
                history.back();
            })
        }


        this.$on('PLAYER_PLAY',item=>{
             this.active = item.id;
        })
       
    },
    destroyed(){
        window.removeEventListener('scroll',this.scrollChangeTag,false);
    },
    methods:{
        loadPage(needClean = false){
            return this.$http.get('?ct=news&ac=vedio_detail',{
                params:{
                    id:this.page.id,
                    page_no:this.page.page_no
                }
            }).then(response=>{
                let {data} = response;
                if(data.code == 0){
                    let rs = data.data;
                    this.page.is_end = !rs.is_have_data;
                    this.active = rs.info.id;
                    rs.info.detail_url = location.href;
                    //添加历史记录
                    this.$utils.history.set(rs.info);
                    
                    if(!this.$utils.unlike.check(rs.info.id)){
                        this.info = [parseItem(rs.info,this)];
                    }
                
                    let list = [];
                    rs.list.forEach(item=>{
                        if(this.$utils.unlike.check(item.id)) return;
                        let tmpItem = parseItem(item,this);
                        list.push(tmpItem);
                    });
                    if(!needClean){
                        this.recom_list = this.recom_list.concat(list);
                    }else{
                        this.recom_list = list;
                    }
                    
                    this.page.page_no++;
                }else{
                    let co = this.$toast(data.msg);
                    if(data.code == 5003 || data.code == 5004){
                        co.then(()=>{
                            history.back();
                        })
                    }
                    throw new Error(data.msg);
                }
            }).catch(e=>{
                this.$toast(e);
                throw e;
            })
        },
        compareTop(arr,h){
            //每次先计算中间那个
            let midx = parseInt(arr.length / 2);
            let middle = arr[midx];
            let rect = document.querySelector('[data-id="l_'+ middle.id +'"]').getBoundingClientRect().top;
            if(rect > h/2){ //从middle前面开始比较
                let len = midx + 1;
                let choose;
                for(let i = len-1;i>=0 ;i--){
                    let lrect = document.querySelector('[data-id="l_'+ arr[i].id +'"]').getBoundingClientRect().top;
                    if(lrect < 0) break;
                    //最接近中线的就是被选中的孩子啦；
                    let ltop =Math.abs(lrect - h/2);
                    if(!choose || choose.top > ltop){
                        choose = {
                            item:arr[i],
                            top:ltop,
                        }
                    }
                }
                return choose;
            }else{//从middle后面开始比较
                let choose;
                for(let i = midx,len = arr.length;i<len ;i++){
                    let lrect =  document.querySelector('[data-id="l_'+ arr[i].id +'"]').getBoundingClientRect().top;
                    if(lrect >= h) break;
                    //最接近中线的就是被选中的孩子啦；
                    let ltop =Math.abs(lrect - h/2);
                    if(!choose || choose.top > ltop){
                        choose = {
                            item:arr[i],
                            top:ltop,
                        }
                    }
                }
                
                return choose;
            }
        },
        scrollChangeTag(e){
            if(scrollTime){
                clearTimeout(scrollTime);
                scrollTime = '';
            }
            scrollTime = setTimeout(()=>{
                console.log('scrolling ends..')
                let ReacArr = '';
                let winH = window.innerHeight;
                let items = this.recom_list;
                if(items.length>0){
                //如果第一个的top不是负数的话，那就选择第一个
                    let first,el,choose;
                    if(this.info.length !== 0){
                        el = document.querySelector('[data-id="p_'+ this.info[0].id +'"]');
                        first  = el.getBoundingClientRect().top;
                    }else{
                        el = document.querySelector('[data-id="l_'+ this.recom_list[0].id +'"]');
                        first  = el.getBoundingClientRect().top;
                    }
                

                    if(first >=0){
                        if(this.info.length !== 0){
                            choose = this.info[0];
                        }else{
                            choose = this.recom_list[0];
                        }
                    }else{
                        choose = this.compareTop(items,winH).item
                        el = document.querySelector('[data-id="l_'+ choose.id +'"]');
                    }
                    
                    this.active = choose.id
                    
                    if(this.active == choose.id){
                        el.querySelector('.player').click();
                    }
                }
            },800);
        },
        itemClick(e){
            e.currentTarget.querySelector('.player').click();
        },
        itemActive(item){
            this.active = item.id;
        },
        pullLoad(){
            console.log('load');
        },
        changeFav(flag){
            this.moreConfig.fav = flag;
            this.moreConfig.item.is_collect = flag ? 1 : 0;
            this.moreConfig.status = false;
        },
        changeNight(flag){
            this.moreConfig.night = flag;
            this.moreConfig.status = false;
        },
        pageRefresh(){
            this.pageError = false;
            this.$emit('RELOADDATA');
        },
        popupMore(item){
            //关闭视频
            this.moreConfig.id = item.id;
            this.moreConfig.item = item;
            this.moreConfig.fav = !!item.is_collect;
            this.moreConfig.night = false;
            this.moreConfig.status = true;
        },
        loadmore(){
            if(this.page.is_end || this.scroll.bottom) return false;
            console.log('load more');
            this.scroll.bottom = true;
            this.loadPage().finally(()=>{
                this.$nextTick(()=>{
                    this.scroll.bottom = false;
                })
            })
        },
        popupReport(){
            this.report_status = true
            this.moreConfig.status=false
            this.$emit('PLYAER_CLOSE')
        },
        removeItem() {
            this.$emit('PLYAER_CLOSE');
            let item = this.moreConfig.item;
            if(this.info.length >0 && item.id == this.info[0].id){
                this.info = [];
            }else{
                let idx = this.recom_list.indexOf(item);
                this.recom_list.splice(idx, 1);
            }

        },
    }
}
</script>
<style lang="less">
.page-video {
    .page-bar {
        background-color:transparent;
        border:none!important;
    }

    background-color:#282423;
    .player {
        position: relative;
        display:flex;
        padding-top:100 * 211/375%;
        overflow:hidden;
        img,video,i{
            position: absolute;
            top:0;
            left:0;
            right:0;
            bottom:0;
        }
        img {
            width:100%;
            height:100%;
        }
        video {
            width:100%;
            height:100%;
            display: none;
        }
        i {
            z-index:2;
            margin:auto;
        }
    }

    .cont {
        padding:30px 24px;
        .tit {
            font-size:32px;
            color:#fff;
            line-height: 48px;
        }
    }
    .info {
        margin-top:22px;
        &,&>p {
            display: flex;
            align-items: center;
        }
        justify-content: space-between;
        height:46px;

        p {
            height:100%;
            color:#919191;
            &:first-child {
                flex:1;
            }
            .sname {
                &,.slogo {
                display: flex;
                align-items: center;
                }
                
                .slogo {
                    justify-content: center;
                    margin-right:20px;
                    width:58px;
                    height:58px;
                    padding:10px;
                    border-radius: 50%;
                    overflow: hidden;
                    background-color:#fff;
                    border:1px solid #efefef;
                }
                img {
                    display: block;
                    width:40px;
                    height:auto;
                }
            font-size: 30px;
        }
            span + span {
                margin-left:10px;
            }
            .uicon-bar-more-w {
                margin-left:30px;
            }
        }
    }
    .tool {
        span {
            display:flex;
            justify-content: center;
            align-items: center;
            height:100%;

            .uicon-view {
                margin-right:.5em;
            }
        }
       
    }
    .video-dec-item {
        position:relative;

        &:not(.active) {
            &::after {
                content:'';
                position:absolute;
                top:0;
                left:0;
                width:100%;
                height:100%;
                background-color:rgba(0,0,0,.5);
            }
        }
    }

    .list-header {
        padding:50px 0;
        display: flex;
        justify-content: center;
        align-items: center;
        color:#919191;
        font-size:32px;

        p {
            position:relative;

            &::before,
            &::after {
                content:'';
                position:absolute;
                top:50%;
                transform: translateY(-50%);
                width:33px;
                height:2px;
                background-color:#919191;
            }

            &::before {
                left:-40px;
            }

            &::after {
                right:-40px;
            }
        }
    }
}
</style>


