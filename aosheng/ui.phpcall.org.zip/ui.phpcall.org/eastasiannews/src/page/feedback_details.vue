<template>
    <div id="app" class="feedback-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">反馈详情</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <section>
            <div class="feedback-content">
                <div class="feedback-box">
                    <div class="feedback-body color6 f30">
                        反馈内容：{{ message.content }}
                    </div>
                    <div class="feedback-footer">
                        <p class="f28 color9">
                            <span>反馈时间：{{ create_time }}</span>
                        </p>
                    </div>
                    <div class="images" v-if="hasImg">
                        <img :src="img" alt="" v-for="img in message.img" :key="img">
                    </div>
                </div>
            </div>
            <div class="reply-box">
                <p class="reply-header f28 color9">
                    <span>客服回复：</span>
                    <span>回复时间：{{ update_time }}</span>
                </p>
                <p class="color29 f30">
                    {{ message.reply }}
                </p>

            </div>
        </section>
    </div>
</template>

<script>
import scrollFixed from "../components/scrollFixed.vue";
import pageBar from "../components/pagebar.vue";
export default {
    name: "feedback_details",
    components: {
        [scrollFixed.name]: scrollFixed,
        [pageBar.name]: pageBar
    },
    data() {
        return {
            message: {},
            create_time: '',
            update_time: '',
            hasImg: true
        };
    },
    created () {
        this.getMessage();
    },
    methods: {
        getMessage () {
            let id = localStorage.getItem('msgId');
            let data = '';
            this.$http.get('?ct=member_center&ac=feedback_detail', {params: {id: id}}).then( res => {
                data = res.data;
                if (data.code === 0) {
                    this.message = data.data;
                    console.log(this.message);
                    this.create_time = this.$moment(this.message.create_time * 1000).format("hh:mm:ss");
                    this.update_time = this.$moment(this.message.update_time * 1000).format("hh:mm:ss");
                    this.hasImg = this.message.img.length > 0 ? true : false ;
                }
            });
        },

    }
};
</script>

<style lang="less">
.feedback-page {
    .color9 {
        color: #999;
    }
    .color29 {
        color: #292929;
    }
    .color6 {
        color: #666;
    }
    .colore6 {
        color: #e64a19;
    }
    .f28 {
        font-size: 28px;
    }
    .f30 {
        font-size: 30px;
    }

    .header-middle {
        font-size: 36px;
        color: #333;
    }

    display: flex;
    flex-direction: column;
    background-color: #fff;

    section {
        border-top: 1px solid #eee;

        .feedback-content {
            padding: 30px 30px 0 30px;
            .feedback-box {
                padding-bottom: 30px;
                border-bottom: 1px solid #e6e6e6;
            }
        }

        .feedback-footer {
            margin-top: 20px;
        }

        .images {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            img {
                display: inline-block;
                width: 150px;
                height: 150px;
                border-radius: 5px;
            }
        }

        .reply-box {
            padding: 30px;
            .reply-header {
                display: flex;
                justify-content: space-between;
                margin-bottom: 20px;
            }
        }
    }
}
</style>


