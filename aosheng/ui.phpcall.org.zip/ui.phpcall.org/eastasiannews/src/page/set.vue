<template>
    <div id="app" class="set-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">设置</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <div class="gap"></div>
        <a href="javascript:;" class="section"  @click=getPop(2)>
            <article>
                <div>
                    清空缓存
                </div>
                <div class="right">
                    <span></span>
                    <i class="icon"></i>
                </div>
            </article>
        </a>

        <a class="section" :href="this.$config.pages.about">
            <article>
                <div>
                    <span>关于</span>
                </div>
                <div class="right">
                    <a href="javascript:;" class="icon"></a>
                </div>
            </article>
        </a>
        <a class="section" :href="this.$config.pages.agreement">
            <article>
                <div>
                    <span>隐私协议</span>
                </div>
                <div class="right">
                    <a href="javascript:;" class="icon"></a>
                </div>
            </article>
        </a>
        <a class="section" href="javascript:;">
            <article>
                <div>
                    去评分
                </div>
                <div class="right">
                    <i class="icon"></i>
                </div>
            </article>
        </a>
        <a class="section" :href="this.$config.pages.model_setting">
            <article class="no-border">
                <div>
                    浏览模式
                </div>
                <div class="right">
                    <i class="icon"></i>
                </div>
            </article>
        </a>
        <div class="gap"></div>
        <a class="section" href="javascript:;" @click="getPop(1)" v-if="member_info">
            <article class="no-border">
                <div>
                    退出登录
                </div>
            </article>
        </a>

        <ui-popup :status="popup.status" @close="popupClose">
            <div class="exit-pop">
                <div class="exit-content">
                    <p> {{ popInfo.title }} </p>
                    <span> {{ popInfo.content }} </span>
                </div>
                <div class="footer">
                    <a href="javascript:;" @click="popupClose">取消</a>
                    <a href="javascript:;" @click="confirm">确定</a>
                </div>
            </div>
        </ui-popup>
    </div>
</template>

<script>
import popup from "../components/popup.vue";
import scrollFixed from "../components/scrollFixed.vue";
import pageBar from "../components/pagebar.vue";

export default {
    name: "set",
    components: {
        [popup.name]: popup,
        [scrollFixed.name]: scrollFixed,
        [pageBar.name]: pageBar
    },
    data() {
        return {
            popType: '',
            popInfo: {
                title: "",
                content: ""
            },
            member_info: "",
            popup: {
                status: false
            },

        };
    },
    mounted() {
        try{
            let member_info = JSON.parse(localStorage.getItem('member_info'));
            if(toString.call(member_info) === '[object Object]'){
                this.member_info = member_info;
            }
        }catch(e){
            
        }
    },
    methods: {
        getPop (type) {
            this.popType = type;
            if (type === 1) {
                this.popInfo.title = "退出登录";
                this.popInfo.content = "确认要退出登录吗？";
            } else if (type === 2) {
                this.popInfo.title = "清理缓存";
                this.popInfo.content = "确认要清理缓存吗？";
            }
            this.popup.status = true;
        },

        confirm () {
            if (this.popType === 1) {
                this.$http.get('?ct=member&ac=logout').then( res => {
                    let data = res.data;
                    if (data.code ===0 || data.code === 4001) {
                        localStorage.removeItem('token');
                        localStorage.removeItem('member_info');
                        this.popup.status = false;
                        window.location.href= 'login.html';
                    } else {
                        this.$toast(data.msg);
                    }
                });

            } else if (this.popType === 2) {
                this.popup.status = false;
            }

        },

        popupClose () {
            this.popup.status = false;
        }
    }
};
</script>

<style lang="less">
.set-page {
    display: flex;
    flex-direction: column;
    background-color: #fff;

    .header-middle {
        font-size: 36px;
        color: #333;
    }

    .gap {
        height: 20px;
        background-color: #f6f6f6;
    }

    .section {
        padding-left: 30px;
        article {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 40px 0;
            border-bottom: 1px solid #eee;
            div:first-child {
                color: #282828;
                font-size: 34px;
            }
            .right {
                margin-right: 30px;
                span {
                    font-size: 28px;
                    color: #919191;
                }
                .icon {
                    display: inline-block;
                    margin-left: 15px;
                    width: 9px;
                    height: 15px;
                    background-image: url("../assets/jinriredian_more.png");
                    background-size: 100% 100%;
                }
            }
            span {
                color: #282828;
            }
        }
    }

    .no-border {
        border-bottom: 0;
    }

    .exit-pop {
        position: absolute;
        top: 35%;
        left: 11%;
        width: 600px;
        height: 330px;
        background: #fff;
        z-index: 999;
        border-radius: 10px;
        .exit-content {
            margin-top: 40px;
            text-align: center;
            p {
                margin-bottom: 35px;
                font-size: 36px;
                font-weight: 500;
                color: #282828;
            }
            span {
                font-size: 32px;
                color: #666;
            }
        }
        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            display: flex;
            a {
                display: inline-block;
                width: 50%;
                padding: 20px 0;
                text-align: center;
                font-size: 36px;
                border-top: 1px solid #e2e2e2;
                &:first-child {
                    color: #666;
                    border-right: 1px solid #e2e2e2;
                }
                &:last-child {
                    color: #e64a19;
                }
            }
        }
    }
}



</style>


