<template>
    <div id="app" class="personal-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">个人资料</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <div class="gap"></div>
        <section>
            <div>
                修改头像
            </div>
            <a href="javascript:;" id="filePicker">
                <img v-if="info.head_img" :src="info.head_img" id="head-img" />
                <img v-else src="../assets/icon-un-login.png" id="head-img" />
                <i></i>
            </a>
        </section>
        <div class="gap"></div>
        <section>
            <div>
                修改昵称
            </div>
            <div class="nickname">
                <input type="text" v-model="info.name" @keypress.enter="upNickName" ref="nickname">
            </div>
        </section>
        <div class="gap"></div>
        <section>
            <a class="link-box" :href="this.$config.pages.updatePwd">
                <div>修改密码</div>
            </a>
        </section>
    </div>
</template>

<script>
import scrollFixed from "../components/scrollFixed.vue";
import pageBar from "../components/pagebar.vue";
export default {
    name: "personal_data",
    components: {
        [scrollFixed.name]: scrollFixed,
        [pageBar.name]: pageBar
    },
    data() {
        return {
            info: {
                head_img: "",
                name: ""
            }
        };
    },
    mounted() {
        let _this = this;
        let info = window.localStorage.getItem("member_info");

        if (info) {
            info = JSON.parse(info);
            _this.info.name = info.nickname;
            if(info.head_img) {
                window.document.querySelector("#head-img").setAttribute("src", info.head_img);
            }

            // 修改头像
            window.upload = WebUploader.create({
                // 选完文件后，是否自动上传。
                auto: true,
                // 文件接收服务端。
                server: this.$config.api + "?ct=member_center&ac=edit_head_img",
                pick: "#filePicker",
                // 只允许选择图片文件。
                accept: {
                    capture: "",
                    title: "Images",
                    extensions: "gif,jpg,jpeg,bmp,png",
                    mimeTypes: "image/*"
                },
                chunked: true,
                chunkSize: 1 * 1024 * 1024,
                formData: {
                    _token: window.localStorage.getItem("token"),
                    file: "file"
                }
            });

            // 图片不能大于2M
            upload.on("beforeFileQueued", file => {
                if (file.size > 2 * 1024 * 1024) {
                    _this.$toast("图片不能超过2M");
                    return false;
                }

                file.guid = WebUploader.Base.guid();
            });

            upload.on("uploadBeforeSend", (object, data, headers) => {
                data.guid = object.file.guid;
            });

            // 上传成功
            upload.on("uploadSuccess", (file, response) => {
                var res = JSON.parse(response._raw);
                window.document
                    .querySelector("#head-img")
                    .setAttribute("src", res.data.filelink);

                let memberInfo = window.JSON.parse(window.localStorage.getItem("member_info"));
                memberInfo.head_img = res.data.filelink
                window.localStorage.setItem("member_info", window.JSON.stringify(memberInfo))
            });
        }
    },
    methods: { 
        upNickName() {
            let _data = {
                name: this.info.name
            };
            this.$http.post("?ct=member_center&ac=edit_nickname", _data).then(res => {
                let data = res.data;
                if (data.code !== 0) {
                    this.$toast(data.msg);
                } else {
                    let memberInfo = window.JSON.parse(window.localStorage.getItem("member_info"));
                    memberInfo.nickname = this.info.name;
                    window.localStorage.setItem("member_info", window.JSON.stringify(memberInfo))
                    this.$refs.nickname.blur();
                }
            });
        }
    }
};
</script>

<style lang="less">
.personal-page {
    display: flex;
    flex-direction: column;
    background-color: #fff;

    #filePicker {
        input {
            display: none;
        }
    }

    .header-middle {
        font-size: 36px;
        color: #333;
    }

    .gap {
        height: 20px;
        background-color: #f6f6f6;
    }

    section {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px 30px;
        & > div:first-child,
        & > .link-box > div {
            color: #000;
            font-size: 32px;
        }
        a:last-child {
            & > div {
                align-items: center;
                display: flex;
            }
            &.link-box {
                width: 100%;
            }

            img {
                width: 100px;
                height: 100px;
                border-radius: 50%;
                border: 1px solid red;
            }
            i {
                width: 9px;
                height: 15px;
                margin-left: 30px;
                background-image: url("../assets/jinriredian_more.png");
                background-size: 100% 100%;
            }
        }
        .nickname {
            input {
                border: none;
                font-size: 32px;
                text-align: right;
                color: #666;
                caret-color: red;
            }
        }
    }
}
</style>


