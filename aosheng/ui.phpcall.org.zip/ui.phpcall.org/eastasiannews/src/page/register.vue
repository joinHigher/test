<template>
    <div id="app" class="reg-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">注册</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <section>
            <div>
                <i :class="[ accountFocus ? 'icon-header-active' : 'icon-header', 'left20' ]"></i>
                <input v-model.trim="account" type="text" placeholder="请输入用户名" @focus="focusEvent(1)" @blur="blurEvent(1)" @keyup.enter="register">
            </div>
            <div>
                <i :class="[ pwdFocus ? 'icon-lock-active': 'icon-lock', 'left20' ]"></i>
                <input v-model.trim="password"  :type="pwdType" placeholder="请输入密码" @focus="focusEvent(2)" @blur="blurEvent(2)" @keyup.enter="register">
                <i class="icon-eye" @click="showPwd"></i>
            </div>
            <div>
                <i :class="[ mailFocus ? 'icon-mail-active': 'icon-mail', 'left20' ]"></i>
                <input v-model.trim="email" type="text" placeholder="请输入邮箱（用于找回密码，必填）" @focus="focusEvent(3)" @blur="blurEvent(3)" @keyup.enter="register">
            </div>
            <button @click="register">注册</button>
            <p>注册即表示同意
                <b>《东亚新闻用户协议》</b>
            </p>
        </section>

        <footer>
            <div>
                <span></span>
                <p>第三方登录</p>
                <span></span>
            </div>
            <div>
                <a href="javascript:;">
                    <img src="../assets/icon-potato.png" alt="">
                </a>
                <a href="javascript:;">
                    <img src="../assets/icon-weixin.png" alt="">
                </a>
                <a href="javascript:;">
                    <img src="../assets/icon-facebook.png" alt="">
                </a>
                <a href="javascript:;">
                    <img src="../assets/icon-twitter.png" alt="">
                </a>
            </div>
        </footer>
    </div>
</template>

<script>
import scrollFixed from "../components/scrollFixed.vue";
import pageBar from "../components/pagebar.vue";
export default {
    name: "register",
    components: {
        [scrollFixed.name]: scrollFixed,
        [pageBar.name]: pageBar
    },
    data() {
        return {
            account: '',
            password: '',
            email: '',
            accountFocus: false,
            pwdFocus: false,
            mailFocus: false,
            pwdType: "password",
            tips: ["请输入用户名", "请输入密码", "请输入邮箱", "请输入正确的邮箱", "注册成功"],
        };
    },
    created () {

    },

    methods: {
        focusEvent (type) {
            switch (type) {
                case 1:
                    this.accountFocus = true;
                    break;
                case 2:
                    this.pwdFocus = true;
                    break;
                case 3:
                    this.mailFocus = true;
                    break;
            }
        },

        blurEvent (type) {
            switch (type) {
                case 1:
                    this.accountFocus = false;
                    break;
                case 2:
                    this.pwdFocus = false;
                    break;
                case 3:
                    this.mailFocus = false;
                    break;
            }
        },

        showPwd () {
            this.pwdType = this.pwdType === "password" ? "text" : "password";
        },

        register () {
            let reg = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
            if ( !this.account ) {
                this.$toast(this.tips[0]);
                return false;
            }
            if ( !this.password ) {
                this.$toast(this.tips[1]);
                return false;
            }
            if ( !this.email ) {
                this.$toast(this.tips[2]);
                return false;
            }
            if ( !reg.test(this.email) ) {
                this.$toast(this.tips[3]);
                return false;
            }
            let params = {
                account: this.account,
                password: this.password,
                email: this.email
            };
            this.$http.post('?ct=member&ac=register',params).then( res => {
                let data = res.data;
                if (data.code !== 0) {
                    this.$toast(data.msg);
                    return false;
                }
                this.$toast(this.tips[4]);
                localStorage.setItem('token', data.data.member_info.token);
                localStorage.setItem('member_info', JSON.stringify(data.data.member_info));
                window.location.href = this.$config.pages.myCenter;
            });
        }
    } // methods end
};
</script>

<style lang="less">
.reg-page {
    .left20 {
        left: 20px;
    }

    display: flex;
    flex-direction: column;
    justify-content: space-between;

    .header-middle {
        font-size: 36px;
        color: #333;
    }

    section {
        border-top: 1px solid #eee;
        position: fixed;
        top: 82px;
        left: 0;
        width: 100%;
        height: 100%;
        padding: 60px 50px 50px 50px;
        background: #fff;
        div {
            position: relative;
            margin-bottom: 40px;
            input {
                height: 90px;
                line-height: 50px;
                width: 100%;
                padding: 20px 100px;
                background: #fff;
                font-size: 34px;
                color: #282828;
                outline: none;
                border: 0;
                border-bottom: 1px solid #e2e2e2;
                caret-color: red;
                &:active,
                &:focus {
                    border-color: #5a4640;
                }
                &:nth-child(2) {
                    padding-right: 0 !important;
                }
            }
            i {
                position: absolute;
                top: 0;
                background-repeat: no-repeat;
                background-position-y:center;
                background-size: 100%;
                height: 90px;
            }
            .icon-header {
                width: 40px;
                background-image: url("../assets/icon-header.png");
            }
            .icon-header-active {
                width: 40px;
                background-image: url("../assets/icon-header-active.png");
            }

            .icon-mail {
                width: 32px;
                background-image: url("../assets/icon-mail.png");
            }

            .icon-mail-active {
                width: 32px;
                background-image: url("../assets/icon-mail-active.png");
            }

            .icon-lock {
                width: 32px;
                background-image: url("../assets/icon-lock.png");
            }
            .icon-lock-active {
                width: 32px;
                background-image: url("../assets/icon-lock-active.png");
            }
            .icon-eye {
                right: 45px;
                width: 29px;
                background-image: url("../assets/icon-eye.png");
            }
            ::-webkit-input-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
            :-moz-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
            ::-moz-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
            :-ms-input-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
        }
        button {
            display: block;
            width: 100%;
            height: 1.14rem;
            line-height: 1;
            margin: 80px 0 30px 0;
            font-size: 36px;
            color: #ffbfab;
            background: #e64a19;
            padding: 25px 0;
            border-radius: 10px;
            border: none;
            outline: none;
            -webkit-appearance: none;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        }
        p {
            text-align: center;
            font-size: 28px;
            color: #c6c6c6;
            b {
                font-weight: normal;
                color: #5a4640;
            }
        }
    }

    footer {
        position: fixed;
        bottom: 50px;
        left: 0;
        width: 100%;
        background: #fff;
        div:first-child {
            margin-bottom: 20px;
            text-align: center;
            display: flex;
            justify-content: center;
            align-content: flex-end;
            p {
                position: relative;
                top: -20px;
                margin: 0 20px;
                font-size: 28px;
                color: #c6c6c6;
            }
            span {
                display: block;
                width: 210px;
                height: 2px;
                background-color: #eee;
            }
        }

        div:last-child {
            padding: 0 120px;
            display: flex;
            justify-content: space-between;
            img {
                display: inline-block;
                width: 84px;
                height: 84px;
            }
        }
    }

}
</style>


