<template>
    <div id="app" class="login-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="page-title">登录</div>
                <i slot="right"></i>
            </page-bar>
        </scroll-fixed>
        <div class="main">
            <div class="wrap">
                <header>
                    <img src="../assets/login_logo.png" alt="">
                </header>
                <section>
                    <div>
                        <i :class="[ accountFocus ? 'icon-header-active' : 'icon-header', 'left20' ]"></i>
                        <input type="text" v-model.trim="username" placeholder="请输入账号" @focus="focusEvent(1)" @blur="blurEvent(1)" @keyup.enter="login">
                        <i class="icon-wrong" @click="username = ''"></i>
                    </div>
                    <div>
                        <i :class="[ pwdFocus ? 'icon-lock-active' : 'icon-lock', 'left20' ]"></i>
                        <input :type="pwdType" v-model.trim="password" placeholder="请输入密码" @focus="focusEvent(2)" @blur="blurEvent(2)" @keyup.enter="login">
                        <i class="icon-eye" @click="showPwd"></i>
                    </div>
                    <button @click="login">登录</button>
                    <p>
                        <a :href=this.$config.pages.reset_pwd>忘记密码</a>
                        <a :href="this.$config.pages.register">注册</a>
                    </p>
                </section>
                <footer>
                    <div>
                        <span></span>
                        <p>第三方登录</p>
                        <span></span>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <img src="../assets/icon-potato.png" alt="">
                        </a>
                        <a href="javascript:;">
                            <img src="../assets/icon-weixin.png" alt="">
                        </a>
                        <a href="javascript:;">
                            <img src="../assets/icon-facebook.png" alt="">
                        </a>
                        <a href="javascript:;">
                            <img src="../assets/icon-twitter.png" alt="">
                        </a>
                    </div>
                </footer>
            </div>
        </div>
    </div>
</template>

<script>
import pageBar from '../components/pagebar.vue'
import scrollFixed from '../components/scrollFixed.vue'

export default {
    name: "login",
    data () {
        return {
            accountFocus: false,
            pwdFocus: false,
            username: "",
            password: "",
            pwdType: "password",
            tips: ["请输入账号", "请输入密码", "账号或密码输入有误", "登录成功"],
        };
    },
    components:{
        [pageBar.name]:pageBar,
        [scrollFixed.name]:scrollFixed,
    },
    methods: {
        focusEvent (type) {
            type === 1 ? this.accountFocus = true : this.pwdFocus = true;
        },

        blurEvent (type) {
            type === 1 ? this.accountFocus = false : this.pwdFocus = false;
        },

        showPwd () {
            this.pwdType === "password" ? this.pwdType = "text" : this.pwdType = "password";
        },

        login () {
            if ( !this.username ) {
                this.$toast(this.tips[0]);
                return false;
            }
            if ( !this.password ) {
                this.$toast(this.tips[1]);
                return false;
            }

            let params = {
                username: this.username,
                password: this.password
            };
            this.$http.post('?ct=member&ac=login', params).then( res => {
                let data = res.data;
                console.log(data);
                if (data.code !== 0) {
                    this.$toast(data.msg);
                    return false;
                }
                //this.$toast(this.tips[3]);
                localStorage.setItem('token', data.data.member_info.token);
                localStorage.setItem('member_info', JSON.stringify(data.data.member_info));
                window.location.href = this.$config.pages.myCenter;
            });
        }
    }
};
</script>

<style lang="less">
.login-page {
    position: absolute;
    top:0;
    left:0;
    right:0;
    bottom:0;
    background: #fff;
    display: flex;
    flex-direction: column;

    .left20 {
        left: 20px;
    }

    .scroll-fixed {
        border-bottom: 0.013333rem solid #eee;
    }

    .page-title {
        font-size: 36px;
        color: #282828;
    }

    .main {
        border-top:1px solid #eee;
        flex:1;
        overflow: auto;
        -webkit-overflow-scrolling: touch;
        .wrap {
            position:relative;
            padding: 50px 50px 200px;
            width:100%;
            min-height: 100%;
        }
    }

    header {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 1.48rem 0;
    }

    section {
        div {
            position: relative;
            margin-bottom: 40px;
            input {
                height: 90px;
                line-height: 50px;
                width: 100%;
                padding: 20px 100px;
                background: #fff;
                font-size: 34px;
                color: #282828;
                outline: none;
                border: 0;
                border-bottom: 1px solid #e2e2e2;
                caret-color: red;
                &:active,
                &:focus {
                    border-color: #5a4640;
                }
            }
            i {
                position: absolute;
                top: 0;
                height:90px;
                background-size: 100%;
                background-repeat: no-repeat;
                background-position-y: center;
            }
            .icon-header {
                width: 40px;
                background-image: url("../assets/icon-header.png");
            }
            .icon-header-active {
                width: 40px;
                background-image: url("../assets/icon-header-active.png");
            }

            .icon-wrong {
                width: 28px;
                background-image: url("../assets/icon-wrong.png");
                right: 40px;
            }
            .icon-lock {
                width: 32px;
                background-image: url("../assets/icon-lock.png");
            }
            .icon-lock-active {
                width: 32px;
                background-image: url("../assets/icon-lock-active.png");
            }

            .icon-eye {
                width: 29px;
                background-image: url("../assets/icon-eye.png");
                right: 45px;
            }
            ::-webkit-input-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
            :-moz-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
            ::-moz-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
            :-ms-input-placeholder {
                font-size: 28px;
                color: #c6c6c6;
            }
        }
        button {
            display: block;
            width: 100%;
            height: 1.14rem;
            line-height: 1;
            margin: 50px 0 30px 0;
            font-size: 36px;
            color: #ffbfab;
            background: #e64a19;
            padding: 25px 0;
            border-radius: 10px;
            border: none;
            outline: none;
            -webkit-appearance: none;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        }
        p {
            display: flex;
            justify-content: space-between;
            font-size: 28px;
            color: #5a4640;
        }
    }

    footer {
        position:absolute;
        left: 0;
        bottom:50px;
        width: 100%;
        
        background: #fff;
        div:first-child {
            margin-bottom: 20px;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            p {
                margin: 0 20px;
                font-size: 28px;
                color: #c6c6c6;
            }
            span {
                display: block;
                width: 210px;
                height: 2px;
                background-color: #eee;
            }
        }

        div:last-child {
            padding: 0 120px;
            display: flex;
            justify-content: space-between;
            img {
                display: inline-block;
                width: 84px;
                height: 84px;
            }
        }
    }

}
</style>


