<template>
    <div class="my-center" :class="{'page-loading':page.loading || initLoading}">
        <ui-loading v-if="initLoading" class="page-init-loading">
            <div slot="content"></div>
        </ui-loading>
        <scroll-fixed>
            <page-bar>
                <div slot="left"></div>
                <div slot="middle" class="header-middle">我的</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <ui-loading v-if="page.loading" />
        <div class="section info">
            <div class="left">
                <div>
                    <img v-if="!head_img" src="../assets/icon-un-login.png" alt="">
                    <img v-else :src="head_img" alt="">
                </div>
                <div class="name" v-if="isLogin">
                    <p>
                        {{ member_info.account }}
                    </p>
                    <p v-show="isVip">
                        <i></i>
                        <span>vip.{{ member_info.level_id }}</span>
                    </p>
                </div>
                <div class="btns" v-if="!isLogin">
                    <a :href="this.$config.pages.login">登录</a>
                    <a :href="this.$config.pages.register">注册</a>
                </div>
            </div>
            <div class="right" v-if="isLogin">
                <a :href="this.$config.pages.personalData"></a>
            </div>
        </div>

        <a v-for="item in items" :key="item.url" :href="item.url" class="zsection" :class="item.class" v-if="item.isShow">
            <i class="uicon" :class="'uicon-'+item.class"></i>
            <p>
                <span>{{item.name}}</span>
                <i class="uicon uicon-uc-more"></i>
            </p>
        </a>
        <ui-tab-bar :active="page.tabBarActive" @change="tabChange"></ui-tab-bar>
    </div>
</template>

<script>
import scrollFixed from "../components/scrollFixed.vue";
import pageBar from "../components/pagebar.vue";
import mxTabBar from "../mixins/tabbar.js";
import UILoading from '../components/loading.vue';
export default {
    data() {
        return {
            page: {
                tabBarActive: 3,
                is_end: false,//是否已经没有数据
                loading: true,
            },
            pageError: '',
            initLoading: false,
            items: [],
            isLogin: false,
            isVip: false,
            member_info: "",
            head_img: "",
        };
    },
    components: {
        [scrollFixed.name]: scrollFixed,
        [pageBar.name]: pageBar,
        [UILoading.name]:UILoading,
    },
    mixins: [mxTabBar],

    mounted(){
        this.$on("RELOADDATA",type=> {
            this.page.loading = true;
            this.page.is_end = false;
            this.initPage();
        });
        this.$emit('RELOADDATA');
    },

    methods: {
        initPage () {console.log(3)
            this.$http.get('?ct=member_center&ac=index').then(res => {
                let data = res.data;
                console.log(data);
                if (data.code === 0) {
                    this.isLogin = true;
                    this.member_info = data.data;
                    this.head_img = this.member_info.head_img;
                    this.isVip = this.member_info.level_id >= 1 ? true : false;
                    localStorage.setItem('member_info', JSON.stringify(this.member_info));
                } else {
                    this.isLogin = false;
                    this.isVip = false;
                }
                this.$nextTick(() => {
                    this.items = [
                        {
                            url: this.$config.pages.filter,
                            name: "新闻过滤",
                            class: "filter",
                            isShow: this.isVip
                        },
                        {
                            url: this.$config.pages.message,
                            name: "消息",
                            class: "message",
                            isShow: true
                        },
                        {
                            url: this.$config.pages.history,
                            name: "历史/收藏",
                            class: "history",
                            isShow: true
                        },
                        {
                            url: this.$config.pages.feedback,
                            name: "反馈",
                            class: "feedback",
                            isShow: true,
                        },
                        {
                            url: this.$config.pages.setting,
                            name: "设置",
                            class: "set",
                            isShow: true
                        }
                    ];
                })
            }, (response) => {
                this.isLogin = false;
                this.isVip = false;
            }).finally(() => {
                this.$nextTick(()=>{
                    this.initLoading = false;
                    this.page.loading = false;
                })
            });
        },
    }
};
</script>

<style lang="less">
.my-center {
    
    .header-middle {
        font-size: 36px;
        color: #333;
    }

    .zsection {
        padding-left: 40px;
        background: #fff;
        &,
        p {
            display: flex;
            align-items: center;
        }
        p {
            line-height: 112px;
            height:112px;
            flex: 1;
            margin-left: 30px;
            padding-right:0.53rem;
        }
        span {
            margin-right: 30px;
            flex: 1;
            font-size: 32px;
            color: #282828;
        }
        & + .zsection {
            p {
                border-bottom: 1px solid #eee;
            }
        }
    }
    .feedback{
        p {
            border-bottom:none !important;
        }
    }
    .section {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding: 0 50px;
        background: #fff;

        .icon {
            display: inline-block;
            position: relative;
            top: 2px;
            width: 32px;
            height: 32px;
            background-image: url("../assets/xinwenguolv.png");
            background-size: 100% 100%;
        }
        .item-name {
            margin-left: 28px;
            color: #282828;
            font-size: 32px;
        }
        .more {
            display: inline-block;
            width: 9px;
            height: 15px;
            background-image: url("../assets/jinriredian_more.png");
            background-size: 100% 100%;
        }
    }

    .info {
        height: 230px;
        margin-top: 20px;
        .left {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            img {
                display: inline-block;
                width: 130px;
                height: 130px;
                border-radius: 50%;
            }
            .name {
                margin-left: 40px;
                p:first-child {
                    margin-bottom: 10px;
                    font-weight: bold;
                    font-size: 34px;
                    color: #333;
                }
                p:last-child {
                    i {
                        display: inline-block;
                        position: relative;
                        top: 2px;
                        width: 22px;
                        height: 20px;
                        background-image: url("../assets/vip.png");
                        background-size: 100% 100%;
                        margin-right: 10px;
                    }
                    span {
                        color: #b08bf4;
                        font-size: 24px;
                    }
                }
            }
            .btns {
                margin-left: 40px;
                a {
                    display: inline-block;
                    width: 100px;
                    height: 55px;
                    line-height: 55px;
                    text-align: center;
                    margin-right: 45px;
                    border: 1px solid #000;
                    border-radius: 4px;
                    font-size: 28px;
                    color: #000;
                    &:first-child {
                        color: #e64a19;
                        border-color: #e64a19;
                    }
                }
            }
        }
        .right {
            a {
                display: inline-block;
                width: 30px;
                height: 30px;
                background-image: url("../assets/gerenzhonxing_bianji.png");
                background-size: 100% 100%;
            }
        }
    }

    .filter {
        margin: 20px 0;
    }
    .set {
        margin-top: 20px;
        p {
            border-bottom: none !important;
        }
    }

    .middle {
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
        padding: 0 0 0 50px;
        background: #fff;
        .item {
            width: 100%;
            display: flex;
            justify-content: flex-start;
            margin-bottom: 0;
            padding: 0 !important;
            div:first-child {
                align-self: center;
            }
            div:last-child {
                display: flex;
                justify-content: space-between;
                width: 100%;
                padding: 50px 0;
                margin-left: 30px;
                border-bottom: 1px solid #e2e2e2;
                .item-name {
                    margin: 0 !important;
                }
                .more {
                    margin-right: 50px;
                    align-self: center;
                }
            }
        }
        .no-border {
            border-bottom: 0 !important;
        }
        .message {
            .icon {
                background-image: url("../assets/xiaoxi.png");
            }
        }
        .history {
            .icon {
                background-image: url("../assets/history.png");
            }
        }
        .feedback {
            .icon {
                background-image: url("../assets/fankui.png");
            }
        }
    }
}
</style>


