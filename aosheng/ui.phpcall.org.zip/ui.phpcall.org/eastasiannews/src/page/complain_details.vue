<template>
    <div id="app" class="complain-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">投诉详情</div>
                <div slot="right"></div>
            </page-bar>
        </scroll-fixed>
        <section>
            <div class="feedback-content" @click="getDetail">
                <div class="feedback-box">
                    <div class="feedback-body color6 f30">
                        {{ message.content }}
                    </div>
                    <div class="feedback-footer">
                        <p>
                            <span class="f28 color9">投诉理由：</span>
                            <span class="f28 color29">{{ message.news_title }}</span>
                        </p>
                        <p class="f28 color9">
                            <span>投诉时间：{{ create_time }}</span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="reply-box">
                <p class="reply-header f28 color9">
                    <span>客服回复：</span>
                    <span>回复时间：{{ update_time }}</span>
                </p>
                <p class="color29 f30">
                    {{ message.reply }}
                </p>
            </div>
        </section>
    </div>
</template>

<script>
import scrollFixed from "../components/scrollFixed.vue";
import pageBar from "../components/pagebar.vue";
export default {
    name: "complain_details",
    components: {
        [scrollFixed.name]: scrollFixed,
        [pageBar.name]: pageBar
    },
    data() {
        return {
            self: this,
            message: {},
            create_time: '',
            update_time: ''
        };
    },

    created () {
        this.getMessage();
    },

    methods: {
        getMessage () {
            let id = localStorage.getItem('msgId');
            let data = '';
            this.$http.get('?ct=member_center&ac=complaint_detail', {params: {id: id}}).then( res => {
                data = res.data;
                console.log(data);
                if (data.code === 0) {
                    this.message = data.data;
                    this.create_time = this.$moment(this.message.create_time * 1000).format("hh:mm:ss");
                    this.update_time = this.$moment(this.message.update_time * 1000).format("hh:mm:ss");
                }
            });
        },

        getDetail () {
            window.location.href= this.message.detail_url;
        }

    }
};
</script>

<style lang="less">
.complain-page {
    .color9 {
        color: #999;
    }
    .color29 {
        color: #292929;
    }
    .color6 {
        color: #666;
    }
    .colore6 {
        color: #e64a19;
    }
    .f28 {
        font-size: 28px;
    }
    .f30 {
        font-size: 30px;
    }

    display: flex;
    flex-direction: column;
    background-color: #fff;

    .header-middle {
        font-size: 36px;
        color: #333;
    }

    section {
        border-top: 1px solid #eee;

        .feedback-content {
            padding: 30px 30px 0 30px;
            .feedback-box {
                padding-bottom: 30px;
                border-bottom: 1px solid #e6e6e6;
            }
        }

        .feedback-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            p:first-child {
                display: inline-block;
                width: 60%;
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
            }
        }

        .reply-box {
            padding: 30px;
            .reply-header {
                display: flex;
                justify-content: space-between;
                margin-bottom: 20px;
            }
        }
    }
}
</style>


