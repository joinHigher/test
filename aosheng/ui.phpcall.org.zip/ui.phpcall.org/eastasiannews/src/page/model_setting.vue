<template>
    <div id="app" class="model-page">
        <scroll-fixed>
            <page-bar>
                <div slot="middle" class="header-middle">浏览模式设置</div>
                <div slot="right" class="complete-btn" @click="setting">完成</div>
            </page-bar>
        </scroll-fixed>
        <section>
            <p>请选择浏览模式</p>
            <div class="opt" v-for="item in models">
                <input class="magic-radio" type="radio" name="radio" :id="item.id" :v-model="item.value" :checked="item.checked" @click="select(item.value)">
                <label :for="item.id">{{ item.name }}</label>
            </div>
        </section>
    </div>
</template>

<script>
    import scrollFixed from "../components/scrollFixed.vue";
    import pageBar from "../components/pagebar.vue";
    export default {
        name: "model_setting",
        components: {
            [scrollFixed.name]: scrollFixed,
            [pageBar.name]: pageBar
        },
        data() {
            return {
                models: [
                    {
                        id: 'r1',
                        value: 0,
                        name: '经典模式',
                        checked: false,
                    },
                    {
                        id: 'r2',
                        value: 1,
                        name: '喜好模式',
                        checked: false,
                    },
                ],
                modelType: '',
            };
        },
        created () {
            this.initPage();

        },
        methods: {
            initPage () {
                let read_mode = localStorage.getItem('read_mode');
                this.models.forEach(item => {
                    if (item.value == read_mode) {
                        item.checked = true;
                    }
                })
            },

            select (type) {
                this.modelType = type;
            },

            setting () {
                if ( !this.modelType.toString() ) {
                    this.$toast('请选择浏览模式')
                } else {
                    localStorage.setItem('read_mode', this.modelType);
                    this.$toast('浏览模式设置成功');
                }
            },

        }
    };
</script>

<style lang="less">

    .model-page {
        display: flex;
        flex-direction: column;
        background-color: #fff;
        .header-middle {
            font-size: 36px;
            color: #333;
        }

        .page-bar-right {
            display: flex;
            align-items: center;
            padding: 0.4rem;
        }

        .complete-btn {
            font-size: 30px;
            color: #e64a19;
        }

        section {
            border-top: 1px solid #eee;
            padding: 20px 30px 0 30px;
            background-color: #f6f6f6;
            p {
                font-size: 28px;
                color: #666;
            }
        }

        .opt {
            margin-top: 30px;
            font-size: 28px;
        }

        .magic-radio {
            position: absolute;
            display: none; }

        .magic-radio[disabled] {
            cursor: not-allowed; }

        .magic-radio + label{
            position: relative;
            display: block;
            padding-left: 30px;
            cursor: pointer;
            vertical-align: middle;
        }


        .magic-radio + label:before {
            position: absolute;
            top: 0;
            left: 0;
            display: inline-block;
            width: 28px;
            height: 28px;
            content: '';
            border: 1px solid #c0c0c0;
        }

        .magic-radio + label:after {
            position: absolute;
            display: none;
            content: '';
        }

        .magic-radio[disabled] + label {
            cursor: not-allowed;
            color: #e4e4e4;
        }

        .magic-radio[disabled] + label:before,
        .magic-radio[disabled] + label:after {
            cursor: not-allowed;
        }

        .magic-radio[disabled] + label:before {
            border-color: #e4e4e4;
        }

        .magic-radio:checked + label:before {
            animation-name: none;
        }

        .magic-radio:checked + label:after  {
            display: block;
        }

        .magic-radio + label:before {
            border-radius: 50%;
        }

        .magic-radio + label:after {
            top: 9px;
            left: 9px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #e64a19;
        }

        .magic-radio:checked + label:before {
            border: 1px solid #e64a19;
        }

        .magic-radio:checked[disabled] + label:before {
            border: 1px solid #c9e2f9;
        }

        .magic-radio:checked[disabled] + label:after {
            background: #c9e2f9;
        }


    }


</style>


