const caches = require('./cache');
/**这俩货可以封装在一起 */
import unlike from './unlike';
import history from './history';
import app from './app';
const {urlFactory} = require('./urlFactory');
export default {
    caches,
    unlike,
    history,
    urlFactory,
    app
}