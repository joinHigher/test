/**
 * url生成器 parse url to object or object to url
 */
!function(global,factory){
    "object" == typeof exports && "undefined" != typeof module
        ? module.exports = factory()
        : "function" == typeof define && define.amd
            ? define(factory)
            : global.urlFactory = factory()
}(this,function(){
     function parse(url){
         var arr = [],obj={};
         if(url.indexOf('?') !== -1){
            arr = url.split('?')[1];
         }else {
             arr = url;
         }
        arr = arr.split('&')
        arr.forEach(function(val,index,arr){
            var tmp = val.split('=');
            if(!!tmp[0])
                obj[tmp[0]] = tmp[1];
        });
       return obj;
     }
     function toURL(object,isFirst){
         var url = '';
         var arr = [];
        for(var key in object){
            arr.push(key + '=' + object[key]);
        }

        if(arr.length>0){
            url = !!isFirst ? '?' : '&';
            url += arr.join('&');
        }
        return url;
     }

    return {
        parse:parse,
        toURL:toURL
    };
});