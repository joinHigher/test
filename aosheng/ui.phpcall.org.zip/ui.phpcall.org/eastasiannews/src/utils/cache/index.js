/**
 * 使用sessionStorage 和 localStorage
 */
let storage = {
    get(name) {
        if(!name) return;
        return localStorage.getItem(name);
    },
    set(name,val){
        if(!name) return;
        localStorage.setItem(name,val);
    },
    clear(name){
        if(!name) return;
        localStorage.removeItem(name);
    }
}

let session = {
    get(name) {
        if(!name) return;
        return sessionStorage.getItem(name);
    },
    set(name,val){
        if(!name) return;
        sessionStorage.setItem(name,val);
    },
    clear(name){
        if(!name) return;
        sessionStorage.removeItem(name);
    }
}

module.exports = {
    get(name,type = 'storage'){
        if(type == 'session'){
            return session.get(name);
        }else if(type == 'storage'){
            return storage.get(name);
        }
    },
    set(name,val,type = 'storage'){
        if(type == 'session'){
            return session.set(name,val);
        }else if(type == 'storage'){
            return storage.set(name,val);
        }
    },
    clear(name,type = 'storage'){
        if(type == 'session'){
            return session.clear(name);
        }else if(type == 'storage'){
            return storage.clear(name);
        }
    }
}