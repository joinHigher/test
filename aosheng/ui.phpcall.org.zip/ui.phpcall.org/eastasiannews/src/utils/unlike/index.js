const caches = require('../cache');
let unLikeList = caches.get('unlike');
try{
    unLikeList = JSON.parse(unLikeList);
    if(toString.call(unLikeList) !== "[object Array]") throw new Error('type error')
}catch(e){
    unLikeList = [];
}
function update(list){
    caches.set('unlike',JSON.stringify(list));
}

export default {
    list:unLikeList,
    check(id){
        id = parseInt(id);
        return this.list.indexOf(id) !== -1
    },
    set(id){
        id = parseInt(id);
        if(!this.check(id)) this.list.push(id),update(this.list)
        
    },
    remove(id){
        id = parseInt(id);
        let idx = this.list.indexOf(id);
        if(idx !== -1){
            this.list.splice(idx,1);
            update(this.list)
        }
    }
}