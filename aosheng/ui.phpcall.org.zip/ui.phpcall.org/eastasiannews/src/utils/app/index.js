export default {
    isApp:navigator.userAgent.indexOf('#AwesomeNews')!== -1,
    link:{
        back:'js://back',
        collect:'js://collect',
        report:'js://report'
    }
}