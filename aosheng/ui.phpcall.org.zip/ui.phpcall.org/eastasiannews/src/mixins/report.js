import reportCom from '../components/report.vue'

export default {
    name:'mx-report',
    components:{
        [reportCom.name]:reportCom,
    },
    data(){
        return {
            report_status:false,
        }
    },
    watch:{
        report_status(flag){
            this.$nextTick(()=>{
                if(flag){
                    document.body.classList.add('lock');
                }else{
                    document.body.classList.remove('lock');
                }
            })
            
        }
    },
    mounted(){
       
    },
    methods:{
        reportCancel(isDone){
            this.report_status = false;
        },
        reportDone(){
            this.report_status = false;
        }
    }
}