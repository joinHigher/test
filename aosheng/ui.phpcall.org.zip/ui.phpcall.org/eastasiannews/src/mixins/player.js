import player from '../components/player.vue'

export default {
    name:'mx-player',
    components:{
        [player.name]:player,
    },
    data(){
        return {
            player:{
                status:false,
                top:0,
                video:'',
                voice:true,
                style:''
            }
        }
    },
    mounted(){
        this.$refs.player.$emit('PLYAER_CLOSE');
        this.$on('PLYAER_CLOSE',()=>{
            this.$refs.player.$emit('PLYAER_CLOSE');
            this.player.status = false;
            this.player.video = '';
        })        
    },
    methods:{
        mutedChange(muted){
            this.player.voice = !muted;
        },
        playVideo(e,item){
            let play = e.currentTarget;
            let rect = play.getBoundingClientRect();
		    let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            this.player.style = {
                top:scrollTop + rect.top + 'px',
                width:rect.width + 'px',
                height:rect.height + 'px',
                left:rect.left + 'px',
                right:rect.right + 'px'
            }
            this.player.video = item.video;
            this.player.top = rect.top;
            this.player.status = true;

            this.$emit('PLAYER_PLAY',item)
        },
    }
}