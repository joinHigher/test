import TabBar from '../components/tabbar.vue';
export default {
    name:'mx-tabbar',
    components:{
        [TabBar.name]:TabBar,
    },
    methods:{
        tabChange(id){
            this.page.tabBarActive = id;
            switch(id){
                case 0: //新闻
                    // this.$emit('RELOADDATA')
                    location.href = this.$config.pages.index;
                    break;
                case 1: //视频
                    // this.$emit('RELOADDATA')
                    location.href = this.$config.pages.tabVideo;
                    break;
                case 2://推荐
                    location.href = this.$config.pages.recommend;
                    break;
                case 3://我
                    location.href = this.$config.pages.myCenter;
                    break;

            }
        },
    }
}