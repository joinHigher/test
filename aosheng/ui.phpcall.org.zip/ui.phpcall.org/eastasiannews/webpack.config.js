const path = require("path");
const webpack = require("webpack");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CleanWebpackPlugin = require("clean-webpack-plugin");
const ExtractTextPlugin = require("extract-text-webpack-plugin");

const merge = require("webpack-merge");
const glob = require("glob");

var vueLoaderConfig = require("./build/vue-loader.conf");

let entryHtml = glob.sync("./public/*.html");
let entryJs = glob.sync("./src/*.js");
let utils = {
    getEntery() {
        let entry = {};
        entryJs.forEach(filePath => {
            let filename = filePath.substring(
                filePath.lastIndexOf("/") + 1,
                filePath.lastIndexOf(".")
            );
            entry[filename] = filePath;
        });
        return entry;
    },
    getHtml() {
        let plugin = [];
        entryHtml.forEach(filePath => {
            let filename = filePath.substring(
                filePath.lastIndexOf("/") + 1,
                filePath.lastIndexOf(".")
            );
            let conf = {
                // 模板来源
                template: filePath,
                // 文件名称
                filename: filename + ".html",
                // 页面模板需要加对应的js脚本，如果不加这行则每个页面都会引入所有的js脚本
                chunks: ["manifest", "vendor", filename],
                inject: true,
                cache: true
            };
            if (process.env.NODE_ENV === "production") {
                conf = merge(conf, {
                    minify: {
                        removeComments: true,
                        collapseWhitespace: true,
                        removeAttributeQuotes: true
                    },
                    chunksSortMode: "dependency"
                });
            }
            plugin.push(new HtmlWebpackPlugin(conf));
        });
        return plugin;
    }
};
module.exports = {
    entry: utils.getEntery(),
    output: {
        filename: "[name].js",
        path: path.resolve(__dirname, "public")
    },
    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: "vue-loader",
                options: vueLoaderConfig
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: ["css-loader?importLoaders=1", "postcss-loader"]
                })
            },
            {
                test: /\.less$/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: [
                        "css-loader?importLoaders=1",
                        "postcss-loader",
                        "less-loader"
                    ]
                })
            },
            {
                test: /\.js$/,
                loader: "babel-loader",
                exclude: /node_modules/
            },
            {
                test: /\.(png|jpg|gif|svg)$/,
                loader: "file-loader",
                options: {
                    name: "[name].[ext]?[hash]"
                }
            }
        ]
    },
    plugins: [
        new webpack.DefinePlugin({
            'process.env': {
                NODE_ENV: '"dev"'
            }
        }),
        // new CleanWebpackPlugin(['dist']),
        new webpack.HotModuleReplacementPlugin(),
        new ExtractTextPlugin({
            filename: "[name].css",
            disable: false,
            allChunks: true
        }),
        new webpack.optimize.CommonsChunkPlugin({
            name: "vendor",
            minChunks: function(module) {
                return (
                    module.resource &&
                    /\.js$/.test(module.resource) &&
                    module.resource.indexOf(
                        path.join(__dirname, "../node_modules")
                    ) === 0
                );
            }
        }),
        new webpack.DllReferencePlugin({
            context: __dirname,
            name: '[name]_[hash]',
            manifest: require('./manifest.json'),
        })
    ].concat(utils.getHtml()),
    devtool: "cheap-source-map",
    devServer: {
        contentBase: "./public",
        host: "0.0.0.0",
        hotOnly: true
    }
};
