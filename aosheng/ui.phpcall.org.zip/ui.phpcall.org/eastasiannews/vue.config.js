const glob = require('glob')
const merge = require('webpack-merge')

let entryJs = glob.sync('./src/*.js')

let getPages = ()=>{
    let pages = {};
    entryJs.forEach((filePath)=>{
      let filename = filePath.substring(filePath.lastIndexOf('\/') + 1, filePath.lastIndexOf('.'));
      pages[filename] = {
        entry: `./src/${filename}.js`,
        template: `./public/${filename}.html`
      }
    });
    return pages;
  }
module.exports = {
    pages: getPages(),
    chainWebpack:config => {
        // config.module
        // .rule('images')
        // .test(/\.(png|jpe?g|gif)(\?.*)?$/)
        // .use('url-loader')
        // .loader('file-loader')
        // .options({
        //   name:'img/[name].[hash:8].[ext]'
        // })

        config.module
        .rule('images')
        .use('url-loader')
        .tap(options =>
          merge(options, {
            limit: 1
          })
        )
      }
  }