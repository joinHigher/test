### 项目名
皇玺会

### 域名

说明|线上|测试|
----|---|-----|
皇玺会 管理后台|adminssl.lemajesticglobal.com | adminssl1.lemajesticglobal.com |  
皇玺会 会员后台（PC端）|member.lemajesticglobal.com   | member1.lemajesticglobal.com   |  
皇玺会 商户后台|shop.lemajesticglobal.com     | shop1.lemajesticglobal.com |      
皇玺会 商户后台|memberapi.lemajesticglobal.com| memberapi1.lemajesticglobal.com|  
图片访问|static.lemajesticglobal.com|static1.lemajesticglobal.com|

### 数据库
库名|线上地址|测试地址|
----|--------|-------|
lemajestic|-|192.168.0.45 

### 部署

测试环境

```
# 机器
ssh -p 25680 www@192.168.0.46 #密码www，可以sudo

# nginx配置
/etc/nginx/sites-enabled/www1.lemajesticglobal.com.conf

# 代码目录
/data/web/www1.lemajesticglobal.com/
```
