<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 全局配置文件
 * 本文件为初始化时固定的配置，相关参数不可在后台直接调整
 *
 */

// 在线项目配置
if( file_exists(dirname(__FILE__).'/inc_online_config.php') )
{
	include dirname(__FILE__).'/inc_online_config.php';
	return;
}

// debug配置

//-------------------------------------------------------------
// 基本常量
//-------------------------------------------------------------
define('PATH_MODEL',    './model');
define('PATH_CONTROL',  './control');
define('PATH_ROOT',     PHPCALL);
define('PATH_LIBRARY',  PHPCALL . '/core/library');
define('PATH_CONFIG',   PHPCALL . '/config');
define('PATH_SHARE',    PHPCALL . '/share');
define('PATH_TEMPLATE', PHPCALL . '/templates');
define('PATH_UPLOADS',  PHPCALL . '/uploads');
define('PATH_DATA',     PHPCALL . '/data');
define('PATH_CACHE',    PATH_DATA . '/cache');

// 主应用URL
define('URL', 'http://adminssl1.lemajesticglobal.com');
define('URL_ADMIN', 'http://adminssl1.lemajesticglobal.com');
define('URL_UPLOADS', 'http://static1.lemajesticglobal.com/uploads');
define('URL_UPLOADS_CDN', 'http://uploads.bcdn.customermanage.org');
define('URL_API', 'http://memberapi1.lemajesticglobal.com');
define('URL_WEBSOCKET', 'wss://wss.phpcall.org:9528');
define('WEBSOCKET_ADDR', '127.0.0.1');
define('WEBSOCKET_PORT', '9527');

// 开启调试模式
define('DEBUG_MODE', true);

// 全局禁用cache( cache::get 强制返回 false)
define('NO_CACHE', false);

//------------------------------------------------------------------------------------------
// 配置变量，或系统定义的全局性变量，建议都用 config 开头，在路由器中默认拦截这种变量名
//------------------------------------------------------------------------------------------

// 指定某些IP允许开启调试，数组格式为 array('ip1', 'ip2'...)
$GLOBALS['config']['safe_client_ip'] = array(
	'127.0.0.1',
	'101.1.18.36'
);

// 程序分析
$GLOBALS['config']['profiler'] = array(
	'benchmarks'         => true,
	'config'             => true,
	'controller_info'    => true,
	'http_headers'       => true,
	'uri_string'         => true,
	'get'                => true,
	'post'               => true,
	'cookie_data'        => true,
	'session_data'       => true,
	'memory_usage'       => true,
	'queries'            => true,
	'query_toggle_count' => 25,
);

//MySql配置
//slave数据库从库可以使用多个
//$GLOBALS['config']['db'] = array(
   //'enable'  => true,
   //'user'    => 'ultron',
   //'pass'    => 'c83854b',
   //'name'    => 'customermanage',
   //'charset' => 'utf-8',
   //'prefix'  => 'mp',
   //'host' => array(
       //'master' => '192.168.0.131:3306',
       //'slave'  => array('192.168.0.131:3306')
   //),
//);

$GLOBALS['config']['db'] = array(
   'enable'  => true,
   'user'    => 'ultron',
   'pass'    => 'c83854b',
   'name'    => 'lemajestic',
   'charset' => 'utf-8',
   'prefix'  => 'mp',
   'host' => array(
       'master' => '192.168.0.45:25686',
       'slave'  => array('192.168.0.45:25686'),
   ),
	'crypt_key' => 'tPVPnynVnsiqh',
	'crypt_fields' => array(
		'mp_adjust_credit_log' => array( 'from_limit', 'to_limit'),
		'mp_currency_type' => array( 'name', 'code_name', 'symbol', 'exg_rate'),
		'mp_app_feedback' => array( 'content' ),
		'mp_app_message' => array( 'title', 'content', 'link'),
		'mp_cart' => array( 'price'),
		'mp_credit_audit' => array( 'apply_limit', 'current_limit', 'audited_limit', 'apply_reason', 'fail_reason'),
		'mp_credit_audit_admin' => array( 'apply_limit', 'current_limit'),
		'mp_goods' => array( 'name', 'price', 'pics', 'desc', 'audit_fail_reason'),
		'mp_goods_category' => array( 'name', 'parentpath'),
		'mp_level' => array( 'name', 'parentpath'),
		'mp_order' => array( 'goods_name', 'currency_code', 'amount', 'question'),
		'mp_order_audit_op' => array( 'file', 'file_number'),
		'mp_order_goods' => array( 'price'),
		'mp_person' => array( 'name', 'code', 'company', 'position', 'supplier_code', 'budget', 'manager', 'uidpath'),
		'mp_safe_question' => array( 'title'),
		'mp_safe_question_answer' => array( 'answer'),
		'mp_member' => array( 'name', 'contact_ways', 'username', 'password', 'app_token', 'ios_push_token', 'pay_password', 'regip', 'loginip'),
		'mp_member_bank_log' => array( 'currency_code', 'amount', 'remark'),
		'mp_member_bill' => array( 'currency_code', 'amount', 'remark'),
		'mp_member_bill_audit' => array( 'currency_code', 'apply_money', 'audit_money', 'remark', 'images', 'reject_reason', 'op_remark', 'extra_charge', 'extra_currency_code'),
		'mp_member_bill_month' => array( 'fixed_limit', 'tmp_limit', 'usage_limit', 'repay_limit', 'al_repay_limit', 'delay_remark', 'currency_code'),
		'mp_member_bill_month_curr' => array( 'repay_money', 'drift_percen', 'default_curr_code', 'currency_code', 'exg_rate', 'exg_money'),
		'mp_member_bill_repay' => array( 'repay_limit', 'al_repay_imit', 'amount', 'pics', 'remark', 'currency_code'),
		'mp_member_custom_code_audit' => array( 'old_custom_code', 'custom_code', 'fail_reason'),
		'mp_member_group' => array( 'name'),
		'mp_member_info' => array( 'name', 'card_pics', 'contacts', 'contact_ways', 'address', 'parentcode', 'parentname', 'fail_reason', 'currency_code', 'card_name', 'card_code', 'reserve_information'),
		'mp_member_login' => array( 'username', 'loginip'),
		'mp_member_money_bank' => array( 'currency_code', 'money'),
		'mp_member_money_credit' => array( 'currency_code', 'fixed_money', 'tmp_money', 'used_money'),
		'mp_member_oplog' => array( 'username', 'msg', 'do_ip', 'do_url'),
		'mp_shop' => array( 'name', 'card_pics', 'card_name', 'card_num', 'address', 'gutee_money', 'contract_num', 'contract_pics', 'contact_per', 'contact_ways', 'email'),
		'mp_shop_account' => array( 'name', 'username', 'password'),
		'mp_shop_bank_log' => array( 'currency_code', 'amount', 'remark'),
		'mp_shop_bill' => array( 'currency_code', 'amount', 'remark'),
        'mp_shop_bill_audit' => array( 'currency_code', 'apply_money', 'audit_money', 'remark', 'images', 'reject_reason', 'op_remark', 'extra_charge', 'extra_currency_code'),
		'mp_shop_category' => array('name'),
		'mp_shop_gutee_op' => array( 'money', 'gutee_money', 'remark', 'currency_code'),
		'mp_shop_interfaces' => array( 'name', 'shop_name', 'key', 'email'),
		'mp_shop_login' => array( 'username', 'loginip'),
		'mp_shop_money_bank' => array( 'currency_code', 'money'),
		'mp_shop_role' => array( 'name'),
	),
);

// cache配置(df_prifix建议按网站名分开,如mc_phpcall_ / mc_tuan_ 等)
// cache_type一般是memcache、redis，如无可用则用file，如有条件，用memcached
$GLOBALS['config']['cache'] = array(
	'enable'     => true,
	'prefix'     => 'mc_df_',
	'cache_type' => 'file',
	'cache_time' => 7200,
	'cache_name' => PATH_CACHE.'/cfc_data',
	'memcache' => array(
		'timeout' => 1,
		'servers' => array(
			array( 'host' => '127.0.0.1', 'port' => 11211, 'weight' => 1 ),
		)
	)
);

// Redis 配置 (这个在腾讯云的安全策略里面限制了外网不能访问了)
$GLOBALS['config']['redis'] = array(
	'prefix'  => 'mc_df_',
	'timeout' => 30,
	'host'    => '127.0.0.1',
	'port'    => 6379,
	'pass'    => 'foobared',
);

// 网站日志配置
// ERROR => 1, DEBUG => 2, WARNING => 3, INFO => 4
$GLOBALS['config']['log'] = array(
	'file_path' => PATH_DATA.'/log',
	'log_type'  => 'file',
	'log_threshold' => array(1, 2, 3, 4),
	'log_date_format' => 'Y-m-d H:i:s',
);

// session
$GLOBALS['config']['session'] = array(
	'session_type'   => 'file',  // session类型 default || file || mysql || memcache || redis
	'session_expire' => 86400,   // session 回收时间
);

// cookie
$GLOBALS['config']['cookie'] = array(
	'prefix'   => 'phpcall_',       // cookie前缀
	'pwd'      => 'VKghmkBjpipoX',  // cookie加密码，密码前缀
	'expire'   => 7200,             // cookie超时时间
	'path'     => '/',              // cookie路径
	'domain'   => '',               // 正式环境中如果要考虑二级域名问题的应该用 .xxx.com
	'secure'   => FALSE,
	'httponly' => FALSE,
);

// 表单令牌,防止CSRF跨站请求伪造，防止表单重复提交
$GLOBALS['config']['csrf'] = array(
	'token_on'     => false,               // 是否开启令牌验证
	'token_name'   => 'csrf_token_name',  // 令牌验证的表单隐藏字段名称
	'token_reset'  => true,               // 令牌验证出错后是否重置令牌 默认为true
	'cookie_name'  => 'csrf_cookie_name', // 令牌存放的cookie名称
	'expire'       => 7200,               // 令牌过期时间
	'exclude_uris' => array(              // 不检查的url，通常是ajax的url
		'ct=upload&ac=image',
		'ct=index&ac=add_cart',
		'ct=index&ac=remove_cart'
	),
);

// 发送邮箱
$GLOBALS['config']['send_email'] = array(
	'host' => 'smtp.sina.cn',
	'user' => 'smtptester2@sina.cn',
	'pass' => 'test123456',
	'name' => '鼎盛互动',
	'html' => "
<p>亲爱的鼎盛互动用户{{username}}，您好！</p>
<p>您的验证码是：{{code}}<br/>
此验证码将用于验证身份，修改密码密保等。请勿将验证码透露给其他人。</p>
<p>本邮件由系统自动发送，请勿直接回复！<br/>
感谢您的访问，祝您使用愉快</p>
");

// 默认时区
$GLOBALS['config']['timezone_set'] = 'Asia/Shanghai';

// 默认编码
$GLOBALS['config']['charset'] = 'UTF-8';

// 全局xss过滤
$GLOBALS['config']['global_xss_filtering'] = false;

// 需处理的网址必须使用<{rewrite}><{/rewriet}>括起来
// 此项需要修改 PATH_DATA/rewrite.ini
$GLOBALS['config']['use_rewrite'] = false;

// 框架版本标识
$GLOBALS['config']['frame_name'] = 'phpcall';
$GLOBALS['config']['frame_ver']  = '2.1';

// 对接人类型
$GLOBALS['config']['butt_type'] = array(
	1 => '指定业务对接人',
	2 => '指定商旅对接人',
	3 => '指定财务对接人',
	4 => '指定技术对接人',
);
$GLOBALS['config']['butt_type_local_map'] = array(
    1 => 'common_butt_type1',
    2 => 'common_butt_type2',
    3 => 'common_butt_type3',
    4 => 'common_butt_type4',
);

// 联系方式类型
$GLOBALS['config']['contact_ways'] = array(
    'potato'    => 'Potato',
    'telegram'  => 'Telegram',
    'whatsapp'  => 'Whatsapp',
    'wechat'    => 'Wechat',
    'qq'        => 'QQ',
    'tel'       => 'Tel',
);

// 可用语言
$GLOBALS['config']['lang'] = array(
	'en'    => 'English',
	'zh-cn' => '简体中文'
);

// 框架版本标识
$GLOBALS['config']['frame_name'] = 'phpcall';
$GLOBALS['config']['frame_ui']   = '1';
$GLOBALS['config']['frame_ver']  = '1.1';

