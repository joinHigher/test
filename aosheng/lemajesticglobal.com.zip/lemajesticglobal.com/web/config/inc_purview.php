<?php exit(); ?>
<pools:admin name="管理员" auttype="session" login_control="?ct=index&ac=login">

    <!-- //公开的控制器，不需登录就能访问 -->
    <ctl:public>index-login,index-loginout,index-validate_image,index-xsvalidation</ctl:public>

    <!-- //保护的控制器，当前池会员登录后都能访问 -->
    <ctl:protected>index-index,index-adminmsg,users-editpwd,users-mypurview,upload-image</ctl:protected>

    <!-- //私有控制器，只有特定组才能访问 -->
    <ctl:private>
        <admin name="管理员">*</admin>
        <common name="普通管理员组">index-index,users-iplimit,users-editpwd,users-log,users-login_log</common>
        <test name="测试组">index-index,users-editpwd</test>
    </ctl:private>

</pools:admin>

<pools:member name="网站会员" auttype="cookie" login_control="?ct=index&ac=login">

    <!-- //公开的控制器，不需登录就能访问 -->
    <ctl:public>index-login,index-loginout,index-register,index-xsvalidation,index-get_password,index-validate_image,index-test_user_name,index-test_email</ctl:public>

    <!-- //保护的控制器，当前池会员登录后都能访问 -->
    <ctl:protected>index-index</ctl:protected>

    <!-- //私有控制器，只有特定组才能访问 -->
    <ctl:private>
        <normal name="普通会员">*</normal>
    </ctl:private>

</pools:member>
