<?php exit(); ?>
<root>
    <!--<menu name='测试的' class='home' url='?ct=demo&ac=index' ct='demo' ac='index'></menu>-->

    <!-- <menu name='人员管理' class='list'>-->

    <!-- <item name='人员管理' url='?ct=person&ac=index' ct='person' ac='index' /> -->
    <!-- <item name='人员添加' url='?ct=person&ac=add'   ct='person' ac='add' display='none' />-->
    <!-- <item name='人员修改' url='?ct=person&ac=edit'  ct='person' ac='edit' display='none' />-->
    <!--  <item name='人员删除' url='?ct=person&ac=del'   ct='person' ac='del' display='none' />-->

    <!-- <item name='等级管理' url='?ct=level&ac=index' ct='level' ac='index' />-->
    <!--  <item name='等级添加' url='?ct=level&ac=add'   ct='level' ac='add' display='none' />-->
    <!-- <item name='等级修改' url='?ct=level&ac=edit'  ct='level' ac='edit' display='none' />-->
    <!-- <item name='等级删除' url='?ct=level&ac=del'   ct='level' ac='del' display='none' />-->

    <!--  <item name='账号管理' url='?ct=member&ac=index' ct='member' ac='index' />-->
    <!-- <item name='账号添加' url='?ct=member&ac=add'   ct='member' ac='add' display='none' />-->
    <!-- <item name='账号修改' url='?ct=member&ac=edit'  ct='member' ac='edit' display='none' />-->
    <!-- <item name='账号删除' url='?ct=member&ac=del'   ct='member' ac='del' display='none' />-->

    <!-- <item name='操作日志' url='?ct=member&ac=oplog' ct='member' ac='oplog' default='1' />-->

    <!-- </menu>-->
    <!-- <menu name='账号审核' class='user'>-->
    <!-- <item name='账号添加审核' url='?ct=member&ac=audit_add_list' ct='member' ac='index' />-->
    <!-- <item name='账号修改审核' url='?ct=member&ac=audit_edit_list' ct='member' ac='index' />-->
    <!--  <item name='账号删除审核' url='?ct=member&ac=audit_del_list' ct='member' ac='index' />-->
    <!--  </menu>-->
    <menu name='首页' class='fa fa-indent'>
        <item name='首页' url='?ct=home&ac=index' ct='home' ac='index' default="1"/>
    </menu>
    <menu name='客户管理' class='fa fa-user'>
        <item name='客户管理' url='?ct=member_info&ac=index' ct='member_info' ac='index' />
        <item name='客户审核' url='?ct=member_info&ac=audit' ct='member_info' ac='audit' />
        <item name='客户已审核' url='?ct=member_info&ac=al_reject' ct='member_info' ac='al_reject' display='none' />
        <item name='客户详情' url='?ct=member_info&ac=info' ct='member_info' ac='info' display='none' />
        <item name='客户审核驳回' url='?ct=member_info&ac=reject' ct='member_info' ac='reject' display='none' />
        <item name='客户审核同意' url='?ct=member_info&ac=agree' ct='member_info' ac='agree' display='none' />
        <item name='客户编辑' url='?ct=member_info&ac=edit' ct='member_info' ac='edit' display='none' />
        <item name='禁止登录' url='?ct=member_info&ac=forbid_login' ct='member_info' ac='forbid_login' display='none' />
        <item name='恢复登录' url='?ct=member_info&ac=allow_login' ct='member_info' ac='allow_login' display='none' />
    </menu>
    <menu name='本期账单' class='fa fa-dollar'>
        <item name='本期账单' url='?ct=current_bill&ac=index' ct='current_bill' ac='index' />
        <item name='账单明细' url='?ct=current_bill&ac=info' ct='current_bill' ac='info' display='none' />
        <item name='账单还款' url='?ct=current_bill&ac=repay_money' ct='current_bill' ac='repay_money' display='none' />
        <item name='延迟还款' url='?ct=current_bill&ac=set_delay' ct='current_bill' ac='set_delay' display='none' />
        <!-- <item name='账单明细' url='?ct=current_bill&ac=audit' ct='current_bill' ac='index' />-->
    </menu>
    <menu name='结算系统' class='fa fa-credit-card'>
        <item name='未还款账单' url='?ct=settlement&ac=index' ct='settlement' ac='index' />
        <item name='历史账单' url='?ct=settlement&ac=history' ct='settlement' ac='history' />
        <item name='账单明细' url='?ct=settlement&ac=info' ct='settlement' ac='info' display='none' />
        <item name='账单还款' url='?ct=settlement&ac=repay_money' ct='settlement' ac='repay_money' display='none' />
        <item name='延迟还款' url='?ct=settlement&ac=set_delay' ct='settlement' ac='set_delay' display='none' />
        <item name='付款系统' url='?ct=shop_settlement&ac=index' ct='shop_settlement' ac='index' />
        <item name='结算历史账单' url='?ct=shop_settlement&ac=history' ct='shop_settlement' ac='history' />
        <item name='结算明细' url='?ct=shop_settlement&ac=info' ct='shop_settlement' ac='info' display='none' />
        <item name='结算' url='?ct=shop_settlement&ac=repay_money' ct='shop_settlement' ac='repay_money' display='none' />
        <item name='延迟结算' url='?ct=shop_settlement&ac=set_delay' ct='shop_settlement' ac='set_delay' display='none' />
    </menu>
    <menu name='授信管理' class='fa fa-adjust'>
        <item name='授信管理' url='?ct=credit_audit&ac=index' ct='credit_audit' ac='index' />
        <item name='授信审核' url='?ct=credit_audit&ac=audit' ct='credit_audit' ac='audit' />
        <item name='授信已审核' url='?ct=credit_audit&ac=al_audit' ct='credit_audit' ac='al_audit' display='none' />
        <item name='查看授信' url='?ct=credit_audit&ac=show' ct='credit_audit' ac='show' display='none' />
        <item name='调整授信' url='?ct=credit_audit&ac=adjust_audit' ct='credit_audit' ac='adjust_audit' display='none' />
        <item name='同意授信申请' url='?ct=credit_audit&ac=consent' ct='credit_audit' ac='consent' display='none' />
        <item name='驳回授信申请' url='?ct=credit_audit&ac=rejected' ct='credit_audit' ac='rejected' display='none' />
    </menu>
    <menu name='商户管理' class='fa fa-balance-scale'>
        <item name='商户管理' url='?ct=shop&ac=index' ct='shop' ac='index' />
        <item name='商户添加' url='?ct=shop&ac=add' ct='shop' ac='add' display='none' />
        <item name='商户修改' url='?ct=shop&ac=edit' ct='shop' ac='edit' display='none' />
        <item name='商户停用' url='?ct=shop&ac=del' ct='shop' ac='del' display='none' />

        <item name='商户接口管理' url='?ct=shop_interfa&ac=index' ct='shop_interfa' ac='index' display='none' />
        <item name='商户接口添加' url='?ct=shop_interfa&ac=add' ct='shop_interfa' ac='add' display='none' />
        <item name='商户接口编辑' url='?ct=shop_interfa&ac=edit' ct='shop_interfa' ac='edit' display='none' />
        <item name='商户接口停用' url='?ct=shop_interfa&ac=edit' ct='shop_interfa' ac='edit' display='none' />
        <item name='商户接口生成随机key' url='?ct=shop_interfa&ac=make_key' ct='shop_interfa' ac='make_key' display='none' />

        <item name='商户分类管理' url='?ct=shop_cate&ac=index' ct='shop_cate' ac='index' />
        <item name='添加商户分类' url='?ct=shop_cate&ac=add' ct='shop_cate' ac='add' display='none' />
        <item name='修改商户分类' url='?ct=shop_cate&ac=edit' ct='shop_cate' ac='edit' display='none' />
        <item name='删除商户分类' url='?ct=shop_cate&ac=del' ct='shop_cate' ac='del' display='none' />
    </menu>
    <menu name='用户管理' class='fa fa-user-secret'>
        <item name='用户组管理' url='?ct=admin_group&ac=index' ct='admin_group' ac='index' />
        <item name='用户组添加' url='?ct=admin_group&ac=add'   ct='admin_group' ac='add' display='none' />
        <item name='用户组修改' url='?ct=admin_group&ac=edit'  ct='admin_group' ac='edit' display='none' />
        <item name='用户组删除' url='?ct=admin_group&ac=del'   ct='admin_group' ac='del' display='none' />

        <item name='用户管理' url='?ct=admin&ac=index' ct='admin' ac='index' />
        <item name='用户添加' url='?ct=admin&ac=add'   ct='admin' ac='add' display='none' />
        <item name='用户修改' url='?ct=admin&ac=edit'  ct='admin' ac='edit' display='none' />
        <item name='用户删除' url='?ct=admin&ac=del'   ct='admin' ac='del' display='none' />

        <item name='修改密码' url='?ct=admin&ac=editpwd'   ct='admin' ac='editpwd' />
        <item name='我的权限' url='?ct=admin&ac=mypurview' ct='admin' ac='mypurview' />
    </menu>
    <menu name='系统管理' class='fa fa-wrench'>
        <item name='汇率管理' url='?ct=currency&ac=index' ct='currency' ac='index' />
        <item name='汇率添加' url='?ct=currency&ac=add' ct='currency' ac='add' display='none' />
        <item name='汇率修改' url='?ct=currency&ac=edit' ct='currency' ac='edit' display='none' />
        <item name='汇率批量修改' url='?ct=currency&ac=batch_edit' ct='currency' ac='batch_edit' display='none' />
        <item name='平台设置' url='?ct=config&ac=platform' ct='config' ac='platform' />
        <item name='配置管理' url='?ct=config&ac=index' ct='config' ac='index' />
        <item name='配置添加' url='?ct=config&ac=add'   ct='config' ac='add' display='none' />
        <item name='配置修改' url='?ct=config&ac=edit'  ct='config' ac='edit' display='none' />
        <item name='配置删除' url='?ct=config&ac=del'   ct='config' ac='del' display='none' />

        <item name='菜单配置' url='?ct=system&ac=edit_member_menu' ct='system' ac='edit_member_menu' />
        <item name='操作日志' url='?ct=admin&ac=oplog' ct='admin' ac='oplog' />
        <item name='登录日志' url='?ct=admin&ac=login_log' ct='admin' ac='login_log' />
        <item name='全局权限XML配置' url='?ct=admin&ac=purview_xml' ct='admin' ac='purview_xml' />

        <!-- <item name='文件管理' url='?ct=filemanage&ac=index' ct='filemanage' ac='index' /> -->
        <!-- <item name='文件新增' url='?ct=filemanage&ac=add'   ct='filemanage' ac='add' display='none' /> -->
        <!-- <item name='文件修改' url='?ct=filemanage&ac=edit'  ct='filemanage' ac='edit' display='none' /> -->
        <!-- <item name='文件删除' url='?ct=filemanage&ac=del'   ct='filemanage' ac='del' display='none' /> -->

        <!-- <item name='缓存管理' url='?ct=cache&ac=index' ct='cache' ac='index' /> -->
        <!-- <item name='缓存删除' url='?ct=cache&ac=del'   ct='cache' ac='del' display='none' /> -->
        <!-- <item name='缓存清理' url='?ct=cache&ac=clear' ct='cache' ac='clear' display='none' /> -->
        <!-- <item name='Redis键值管理' url='?ct=cache&ac=redis_keys' ct='cache' ac='redis_keys' /> -->
        <!-- <item name='Redis服务器信息' url='?ct=cache&ac=redis_info' ct='cache' ac='redis_info' /> -->

        <item name='计划任务管理' url='?ct=crond&ac=index' ct='crond' ac='index' />
        <item name='计划任务新增' url='?ct=crond&ac=add'   ct='crond' ac='add' display='none' />
        <item name='计划任务修改' url='?ct=crond&ac=edit'  ct='crond' ac='edit' display='none' />
        <item name='计划任务删除' url='?ct=crond&ac=del'   ct='crond' ac='del' display='none' />
    </menu>
</root>
