<?php
/**
 * 框架核心入口文件
 *
 * 环境检查，核心文件加载
 *
 * @author seatle<seatle@foxmail.com>
 * @version $Id$
 */

////////////////////////////////////////////////////////////////////
//init start 系统初始化开始

// 严格开发模式
error_reporting( E_ALL );

//开启register_globals会有诸多不安全可能性，因此强制要求关闭register_globals
if ( ini_get('register_globals') )
{
    exit('php.ini register_globals must is Off! ');
}

//核心库目录
define('PHPCALL', substr(dirname(__FILE__), 0, -5));

// Get the start time and memory for use later
defined('PHPCALL_START_TIME') or define('PHPCALL_START_TIME', microtime(true));
defined('PHPCALL_START_MEM') or define('PHPCALL_START_MEM', memory_get_usage());

//系统配置
require PHPCALL . '/config/inc_config.php';

//设置时区
date_default_timezone_set( $GLOBALS['config']['timezone_set'] );


//引入加载器
require_once PHPCALL . '/core/autoloader.php';

//程序结束后执行的动作
register_shutdown_function(function() 
{
    tpl::output();

    if( PHP_SAPI != 'cli' )
    {
        show_debug_error();
    }

    if( defined('CLS_CACHE') ) 
    {
        cache::free();
    }

    if( defined('PUB_NATIVE_CACHE') ) 
    {
        pub_native_cache::close();
    }

});

//加载核心类库
require PHPCALL.'/core/cache.php';
require PHPCALL.'/core/config.php';
require PHPCALL.'/core/log.php';
require PHPCALL.'/core/lang.php';
require PHPCALL.'/core/util.php';
require PHPCALL.'/core/db.php';
require PHPCALL.'/core/tpl.php';

// 启动计时器。。。嘀嗒嘀嗒。。。
pub_benchmark::mark('total_execution_time_start');
pub_benchmark::mark('loading_time:_base_classes_start');

// WEB模式才需要debug，启动路由、启用session
if( PHP_SAPI != 'cli' )
{
    //debug设置
    if( in_array( util::get_client_ip(), $GLOBALS['config']['safe_client_ip']) ) 
    {
        $_debug_safe_ip = true;
    }
    else 
    {
        $_debug_safe_ip = false;
    }

    require PATH_LIBRARY.'/debug/lib_debug.php';

    if( DEBUG_MODE === true || $_debug_safe_ip )
    {
        ini_set('display_errors', 'On');
    }
    else
    {
        ini_set('display_errors', 'Off');
    }

    set_error_handler('handler_debug_error', E_ALL);
    set_exception_handler('handler_debug_exception');

    //session接口(使用session前需自行调用session_start，可以app_config里设定，验证码类程序建议使用独立的app)
    require PHPCALL.'/core/session.php';

    //外部请求程序处理(路由)
    require PHPCALL.'/core/req.php';
    req::init();
}

// 加载用户自定义配置
// PHP通过 config::get($key) 调用
// 模板通过 <{$config.key}> 调用
config::get();

/**
 * req::item 别名函数
 */
function request($key, $df='', $filter='')
{
    return req::item($key, $df, $filter);
}

// Set a mark point for benchmarking
pub_benchmark::mark('loading_time:_base_classes_end');

/**
 * app类
 * 框架里每一个入口文件都称之为一个app，可以在子目录里，也可以放在外面目录
 * 文件只需引入 call.php 并使用这个类进行设置即可（如果是cli程序，则不需要设置，但仍要引入此类）
 *
 * @author seatle<seatle@foxmail.com>
 */
class call
{
    // app配置数组
    public $app_config = array();

    // app标题(一些自动化程序默认会把这个作为title)
    public $app_title = '';

    // app名称(必须为无空格英文，app控制器和模板默认目录，根目录下此项为空)
    public $app_name  = '';

    // 是否启动session
    public $session_start = false;

    public $purview_config = array();

    // 如果是ajax的应用，可以自行改变这个变量，避免输出debug信息
    public static $is_ajax  = false;

    // 当前启动的实例
    public static $instance = null;

    // 权限类的实例
    public static $auth = null;

    // 当前ct和ac
    public static $ct = '';
    public static $ac = '';

    /**
     * 构造函数
     * @return void
     */
    public function __construct( $config = array() )
    {
        // 获取当前控制器及action
        $this->_get_action();

        // 获取配置
        $this->app_config = $config;

        if( isset($config['app_title']) ) 
        {
            $this->app_title = $config['app_title'];
        }
        if( isset($config['app_name']) ) 
        {
            $this->app_name = $config['app_name'];
        }
        if( isset($config['session_start']) && $config['session_start'] ) 
        {
            session_start();
            $this->session_start = $config['session_start'];
        }

        self::$instance = $this;
    }

    /**
     * 权限检查
     * @parem $backtype   返回类型: 1--是由权限控制程序直接处理 2--只返回结果(结果为：1 正常，0 没登录，-1 没组权限， -2 没应用池权限)
     * return void
     */
    public function check_purview( $backtype = 1 )
    {
        self::$auth->set_control_url( $this->purview_config['login_url'] );
        $rs = self::$auth->check_purview(self::$ct, self::$ac, $backtype);
        return $rs;
    }

    /**
     * 路由映射
     * @param $ctl  控制器
     * @parem $ac   动作
     * @return void
     */
    public function run()
    {
        //初始化权限类
        if( isset($this->app_config['purview_config']) )
        {
            $this->purview_config = $this->app_config['purview_config'];

            if( !empty($this->purview_config['user_handler']) && 
                !empty($this->purview_config['purview_key']) &&
                !empty($this->purview_config['pool_name']) )
            {
                self::$auth = new cls_auth( $this->purview_config['user_handler'],
                    $this->purview_config['purview_key'],
                    $this->purview_config['pool_name'] );

                if( $this->purview_config['auto_check'] )  
                {
                    $this->check_purview( 1 );
                }
            }
        }

        $ac = self::$ac;
        $ct = self::$ct;
        $ctl  = 'ctl_'.$ct;
        $control_path = ($this->app_name == '' ? PATH_CONTROL : PATH_CONTROL.'/'.$this->app_name);
        $path_file = $control_path . '/' . $ctl . '.php';
        $path_file2 = './control/' . $ctl . '.php';

        //禁止 _ 开头的方法
        if( $ac[0]=='_' )
        {
            call::fatal_error( 'call.php run_controller() action {$ac} is not allow url:'.util::get_cururl() );
        }

        if( file_exists( $path_file ) )
        {
            require $path_file;
        }
        else if( file_exists( $path_file2 ) )
        {
            require $path_file2;
        }
        else 
        {
            throw new Exception ( "Contrl {$ctl}--{$path_file} is not exists!" );
        }
        if( method_exists ( $ctl, $ac ) === true )
        {
            // 验证token
            cls_security::csrf_verify();

            pub_benchmark::mark('controller_execution_time_( '.$ct.' / '.$ac.' )_start');
            $instance = new $ctl();
            $instance->$ac();
            pub_benchmark::mark('controller_execution_time_( '.$ct.' / '.$ac.' )_end');
        } 
        else 
        {
            throw new Exception ( "Method {$ctl}::{$ac}() is not exists!" );
        }
    }

    /**
     * 获取ac和ct
     * return void
     */
    public function _get_action()
    {
        if( PHP_SAPI == 'cli' ) 
        {
            return false;
        }
        self::$ct = preg_replace("/[^0-9a-z_]/i", '', req::item('ct') );
        self::$ac = preg_replace("/[^0-9a-z_]/i", '', req::item('ac') );
        if( self::$ct=='' ) self::$ct = 'index';
        if( self::$ac=='' ) self::$ac = 'index';
    }

	public static function app_total()
	{
		return array(
			microtime(true) - PHPCALL_START_TIME,
			memory_get_peak_usage() - PHPCALL_START_MEM,
		);
	}

    /**
     * 致命错误处理接口
     * 系统发生致命错误后的提示
     * (致命错误是指发生错误后要直接中断程序的错误，如数据库连接失败、找不到控制器等)
     *
     * @parem $errtype
     * @parem $msg
     * @return void
     */
    public static function fatal_error( $errtype, $msg )
    {
        global $_debug_safe_ip;
        $log_str = $errtype.': '.$msg;
        if ( DEBUG_MODE === true || $_debug_safe_ip || PHP_SAPI == 'cli' )
        {
            throw new Exception( $log_str );
        }
        else
        {
            log::write('fatal_error', $msg);
            header ( "location:/404.html" );
            exit();
        }
    }

    /**
     * 框架版本标识
     */
    public static function get_ver()
    {
        return $GLOBALS['config']['frame_name'].' V'.$GLOBALS['config']['frame_ver'];
    }

} //end class
