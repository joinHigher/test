<?php
/**
 * UI框架栏目 
 * 
 * @version 2.7.0
 * @copyright 1997-2018 The PHP Group
 * @author seatle <seatle@foxmail.com> 
 * @created time :2018-01-15
 */
class cls_menu
{
    public static $is_auth = true;
    public static $is_hide = true;

    public static function set_parentid($arr)
    {
        foreach($arr as $k => $em) 
        {
            $display = !empty($em['display']) ? $em['display'] : '';
            if ( $display == 'none' ) 
            {
                unset($arr[$k]);
                continue;
            }
            $em = self::_set_parentid($em);
            if ( empty($em) ) 
            {
                unset($arr[$k]);
                continue;
            }

            $arr[$k] = $em;
        }
        $arr = array_values($arr);
        return $arr;
    }

    private static function _set_parentid($arr, $parentid = 0, $topid = 0)
    {
        $arr['parentid'] = $parentid;
        $arr['topid']    = $topid;
        if( $parentid==0 ) $topid = $arr['id'];
        // 如果不存在子节点，说明是末梢节点
        if( !isset($arr['children']) ) 
        {
            $ct      = !empty($arr['ct']) ? $arr['ct'] : '';
            $ac      = !empty($arr['ac']) ? $arr['ac'] : '';
            $display = !empty($arr['display']) ? $arr['display'] : '';
            // 去掉ct和ac为空的栏目
            if ( empty($ct) || empty($ac)) 
            {
                return null;
            }
            if ( self::$is_hide && $display=='none' ) 
            {
                return null;
            }
            // 如果有做验证 而且 验证权限不通过，也去掉
            if ( self::$is_auth && !self::_has_purview($ct, $ac) ) 
            {
                return null;
            }
            if (empty($arr['url'])) 
            {
                $arr['url'] = "?ct={$ct}&ac={$ac}";
            }
            return $arr;
        }

        // 如果存在子节点，进入子节点递归处理
        foreach($arr['children'] as $k => $son) 
        {
            $child = self::_set_parentid($son, $arr['id'], $topid);
            if (empty($child)) 
            {
                // 当前子栏目为空，去掉此节点
                unset($arr['children'][$k]);
            }
            else 
            {
                $arr['children'][$k] = $child;
            }
        }

        // 去完没有权限的子栏目以后，子栏目为空，干掉整个节点
        if (empty($arr['children'])) 
        {
            return null;
        }
        $arr['children'] = array_values($arr['children']);
        return $arr;
    }

    public static function xml_to_array($xml) 
    {
        $parser = xml_parser_create();
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
        xml_parse_into_struct($parser, $xml, $tags);
        xml_parser_free($parser);

        $elements = array();  // the currently filling [child] array
        $stack = array();
        foreach ($tags as $tag) 
        {
            $index = count($elements);
            if ($tag['type'] == "complete" || $tag['type'] == "open") 
            {
                $elements[$index] = array();
                //$elements[$index]['name'] = $tag['tag'];
                $elements[$index]['id'] = 0;
                $elements[$index]['parentid'] = 0;
                $elements[$index]['topid'] = 0;
                if (isset($tag['attributes'])) 
                {
                    $elements[$index] = array_merge($elements[$index], $tag['attributes']);
                }
                if ($tag['type'] == "open") 
                {  
                    // push
                    $elements[$index]['children'] = array();
                    $stack[count($stack)] = &$elements;
                    $elements = &$elements[$index]['children'];
                }
            }
            if ($tag['type'] == "close") 
            {  
                // pop
                $elements = &$stack[count($stack) - 1];
                unset($stack[count($stack) - 1]);
            }
        }
        // xml的不需要
        return $elements[0]['children'];
    }

    /**
     * 处理应用菜单的操作
     * @parem string $menu
     * @return bool
     */
    public static function replace_app_menu( $xml )
    {
        $lines = explode("\n", $xml);
        $i = 0;
        foreach ($lines as $line) 
        {
            // 空的和注释的行去掉
            if (empty(trim($line)) || preg_match("#^<!--#", trim($line)))
            {
                continue;
            }

            if (preg_match("#<menu #", $line))
            {
                $i++;
                $line = str_replace("<menu", "<menu id='{$i}'", $line);
            }
            $menu_array[] = $line;
        }
        $xml = implode("\n", $menu_array);
        $xml = str_replace("&amp;", "&", $xml);
        $xml = str_replace("&", "&amp;", $xml);
        //$xml = str_replace('<tpl>catalogmenu</tpl>', mod_catalog::get_catalog_menu(), $xml);
        //echo '<xmp>', $xml, '</xmp>'; exit();
        return $xml;

        //$lines = explode("\n", $menu);
        //$menu_array = array();
        //foreach ($lines as $line) 
        //{
            //$line = trim($line);
            //// 空的和注释的行去掉
            //if (empty($line) || preg_match("#^<!--#", $line))
            //{
                //continue;
            //}
            //$menu_array[] = $line;
        //}
        //$menu = implode("\n", $menu_array);

        ////$menu = str_replace('<tpl>catalogmenu</tpl>', mod_catalog::get_catalog_menu(), $menu);
        ////echo '<xmp>', $menu, '</xmp>'; exit();
        //return $menu;
    }

    /**
     * 检测用户是否有指定权限
     * @parem string $ct
     * @parem string $ac
     * @return bool
     */
    protected static function _has_purview($ct, $ac)
    {
        $rs = call::$auth->check_purview($ct, $ac, 2);
        if( $rs==1 )
        {
            return true;
        } 
        else
        {
            return false;
        }
    }

}
