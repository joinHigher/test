<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 配置文件类
 *
 * @version $Id$
 *
 */
class config
{
    public static $cfg_groups       = '';
    public static $call_configs     = array();
    public static $cfg_cache_prefix = 'acc_cfg';
    public static $cfg_cache_key    = 'configs';
   
   /**
    * 获得配置
    * @parem string $key 为空时返回所有key-value对(不含详细描述) 
    * @return mix
    */
    public static function get( $key='' )
    {
        if( empty(self::$call_configs) )
        {
            //检查缓存
            self::$call_configs = cache::get(self::$cfg_cache_prefix, self::$cfg_cache_key);
            if( self::$call_configs === false )
            {
                if (!$GLOBALS['config']['db']['enable']) 
                {
                    return '';
                }
                $rows = db::select('name, value')->from('#PB#_config')->execute();
                if( $rows )
                {
                    foreach ($rows as $row) 
                    {
                        self::$call_configs[ $row['name'] ] = $row['value'];
                    }
                    cache::set(self::$cfg_cache_prefix, self::$cfg_cache_key, self::$call_configs, 0);
                }
                else
                {
                    return '';
                }
            }
        }
        if( $key=='' ) 
        {
            return self::$call_configs;
        }
        else 
        {
            return isset(self::$call_configs[$key]) ? self::$call_configs[$key] : '';
        }
    }
    
   /**
    * 保存某项配置的值
    * @parem string $key  项
    * @parem mix $value 值(为字符串时只修改value, 为数组时修改所有相关值)
    * @return bool
    */
    public static function save( $key, $value, $upcache = true )
    {
        db::$safe_test = false;
        db::update('#PB#_config')->set(array(
            'value' => $value
        ))
        ->where('name', $key)
        ->execute();
        if( $upcache ) 
        {
            self::$call_configs[$key] = stripslashes( $value );
            cache::set(self::$cfg_cache_prefix, self::$cfg_cache_key, self::$call_configs, 0);
        }
        return true;
    }

   /**
    * 获得所有配置数组(包含详细信息)
    * @return array()
    */
    public static function get_all( $groupid = 0 )
    {
        $rows = array();
        $where = array();
        if( $groupid > 0 ) 
        {
            $where[] = array('groupid', '=', $groupid);
        }
        $rows = db::select()->from('#PB#_config')->where($where)->order_by('sort', 'desc')->execute();
        $rt = array();
        foreach ($rows as $row) 
        {
            $rt[ $row['name'] ] = $row;
        }
        return $rt;
    }

    /**
     * 重载全部系统变量
     * @return [type] [description]
     */
    public static function reload( )
    {
        $rows = db::select('name, value')->from('#PB#_config')->execute();
        if( $rows )
        {
            foreach ($rows as $row) 
            {
                self::$call_configs[ $row['name'] ] = $row['value'];
            }
            cache::set(self::$cfg_cache_prefix, self::$cfg_cache_key, self::$call_configs, 0);
        }
        return true;
    }


}


