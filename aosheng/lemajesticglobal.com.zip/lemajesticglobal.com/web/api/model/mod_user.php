<?php

class mod_user
{
    public static function check_login()
    {
        $token = req::item("token");
        if (empty($token)) 
        {
            exit(json_encode(array(
                "code" => -2,
                "msg"  => "You have to pass the token",
            )));
        }

        $info = pub_token::check_token($token);
        if (empty($info)) 
        {
            exit(json_encode(array(
                "code" => -2,
                "msg"  => "Token expired",
            )));
        }

        // 强制让前端退出
        //exit(json_encode(array(
            //"code" => -2,
            //"msg"  => "Token expired",
        //)));

        return $info;
    }

    public static function save_member_log($username, $msg)
    {
        $username = addslashes( $username );
        $msg = addslashes( $msg );
        $url = '?ct='.call::$ct.'&ac='.call::$ac;
        foreach(req::$forms as $k => $v)
        {
            if( preg_match('/pwd|password|sign|cert/', $k) || $k=='ct' || $k=='ac' ) 
            {
                continue;
            }
            $nstr = "&{$k}=".(is_array($v) ? 'array()' : $v);
            if( strlen($url.$nstr) < 100 )
            {
                $url .= $nstr;
            }
            else 
            {
                break;
            }
        }
        $do_url  = addslashes( $url );
        $do_time = time();
        $do_ip   = util::get_client_ip();
        $sql = "Insert Into `#PB#_member_oplog`(`username`,`msg`,`do_time`,`do_ip`,`do_url`) 
                             Values('{$username}','{$msg}','{$do_time}','{$do_ip}','{$do_url}');";
        $rs = db::query( $sql );


        // 使用 WebSocket 通知客户端
        $client = new cls_websocket();
        //$client->connect($_SERVER['HTTP_HOST'], 9527, '/');
        $client->connect("127.0.0.1", 9527, '/json?utma=jjj&userid=1&username=yangzetao');

        $payload = json_encode(array(
            'Event' => 'IncrMessageCount',
            'Msg' => 'Hello'
        ));
        $rs = $client->send_data($payload);

        //if( $rs !== true )
        //{
            //echo "send data error...\n";
        //}
        //else
        //{
            //echo "ok\n";
        //}

        $client->disconnect();

        return $rs;
    }

}
