<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 人员接口
 *
 * @version $Id$
 */
class ctl_person
{
    public static $userinfo = array();

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        // 如果不是post方式
        //if (empty(req::$posts)) 
        //{
            //exit(json_encode(array(
                //"code" => -1,
                //"msg" => "Method Error.",
            //)));
        //}

        self::$userinfo = mod_member::check_login();

    }

    public function index()
    {
        $keyword = req::item("keyword");
        $where = array();
        $where[] = "`isdeleted`=0";
        if (!empty($keyword)) 
        {
            $where[] = "`code`='{$keyword}'";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select `id`,`name`,`code`,`company`,`position`,`supplier_code`,`level`,`budget` From `#PB#_person` {$where}";
        $rows = db::get_all($sql);

        $level_list = $this->_get_level();
        foreach ($rows as $k => $val) {
            $rows[$k]['level'] = $level_list[$val['level']]; 
        }

        if (!empty($keyword)) 
        {
            mod_member::save_member_log(self::$userinfo['username'], "人员查询搜索");
        }
        else 
        {
            mod_member::save_member_log(self::$userinfo['username'], "人员查询列表");
        }

        $data = array(
            'code' => 0,
            'msg'  => "successful",
            'data' => $rows,
        );
        exit(json_encode($data));
    }

    /**
     * 添加人员接口
     * 
     * @return void
     */
    public function add()
    {   
        //查询数据
        if(empty(req::$posts))
        {
            $row['level_list'] = $this->_get_level();
            exit(json_encode(array(
                "code" => 0,
                "msg"  => "successful",
                "data" => $row,
            )));
        }
        //添加数据
        else
        {
            $name = req::item('name');
            $code = req::item('code');
            $company  = req::item('company');
            $position = req::item('position');
            $supplier_code  = req::item('supplier_code');
            $level  = req::item('level');
            $budget  = req::item('budget');
            
            $row = db::get_one("Select * From `#PB#_person` Where `isdeleted`=0  And `code`='{$code}'");
            if( is_array($row) )
            {
                exit(json_encode(array(
                    "code" => -1,
                    "msg" => "代号已经存在！",
                )));
            }

            $insert_data = array(
                "name"   => $name,
                "code"   => $code,
                "company"    => $company,
                "position"   => $position,
                "supplier_code"    => $supplier_code,
                "level"   => $level,
                "budget" => $budget,
                "uid" => self::$userinfo['uid'],
                "manager" => self::$userinfo['username'],
                "uidpath" => self::$userinfo['parentpath'],
                "uptime"    => time(),
                "addtime"    => time(),
            );

            $insert_id = db::insert('#PB#_person', $insert_data);

            exit(json_encode(array(
                "code" => 0,
                "msg" => "添加成功",
            )));
        }

    }

    /**
     * 编辑人员接口
     * 
     * @return void
     */
    public function edit()
    {   
        $id = req::item('id');
        $name = req::item('name');
        $code = req::item('code');
        $company  = req::item('company');
        $position = req::item('position');
        $supplier_code  = req::item('supplier_code');
        $level  = req::item('level');
        $budget  = req::item('budget');
        
        if (empty($id)) {
           exit(json_encode(array(
                "code" => -1,
                "msg" => "请选择编辑人员！",
            )));
        }
        //查询数据
        if(empty(req::$posts))
        {
            $row = db::get_one("Select * From `#PB#_person` Where `isdeleted`=0 And `id`='{$id}'");
            if( empty($row) )
            {
                exit(json_encode(array(
                    "code" => -1,
                    "msg" => "人员不存在！",
                )));
            }
            else
            {   
                $row['level_list'] = $this->_get_level();
                exit(json_encode(array(
                    "code" => 0,
                    "msg"  => "successful",
                    "data" => $row,
                )));
            }
        }
        //修改数据
        else
        {
            $row = db::get_one("Select * From `#PB#_person` Where `isdeleted`=0  And `code`='{$code}'  And `id`!='{$id}'");
            if( is_array($row) )
            {
                exit(json_encode(array(
                    "code" => -1,
                    "msg" => "代号已经存在！",
                )));
            }

            $update_data = array(
                "name"   => $name,
                "code"   => $code,
                "company"    => $company,
                "position"   => $position,
                "supplier_code"    => $supplier_code,
                "level"   => $level,
                "budget" => $budget,
                "uptime"    => time(),
            );

            db::update('#PB#_person',  $update_data, "`id`='{$id}'");
            exit(json_encode(array(
                "code" => 0,
                "msg" => "修改成功",
            )));

        }
    }

    //获取人员等级
    private function _get_level()
    {
        $rows = db::get_all("Select `id`,`name` From `#PB#_level`");

        foreach ($rows as $row) 
        {
            $options[$row['id']] = $row['name'];
        }

        return $options;
    }

    /**
     * 删除人员接口
     * 
     * @return void
     */
    public function del()
    {   
        $id = req::item('id');
        
        if (empty($id)) {
           exit(json_encode(array(
                "code" => -1,
                "msg" => "请选择需要删除的人员！",
            )));
        }

        $row = db::get_one("Select * From `#PB#_person` Where `isdeleted`=0  And `id`='{$id}'");
        if( empty($row) )
        {
            exit(json_encode(array(
                "code" => -1,
                "msg" => "删除的人员不存在！",
            )));
        }

        $update_data = array(
            "isdeleted"   => 1,
        );

        db::update('#PB#_person',  $update_data, "`id`='{$id}'");
        exit(json_encode(array(
            "code" => 0,
            "msg" => "删除成功",
        )));

    }

}
