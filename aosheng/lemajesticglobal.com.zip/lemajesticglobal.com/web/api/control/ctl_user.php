<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 登录接口
 *
 * @version $Id$
 */
class ctl_user
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
    }

    public function login()
    {
        $username = req::item("username");
        $password = req::item("password");
        if (empty($username) || empty($password)) 
        {
            exit(json_encode(array(
                "code" => -1,
                "msg"  => "账号密码不能为空",
            )));
        }

        //print_r(req::$posts);
        $sql = "Select `id`,`username`,`password`,`lifetime`,`status` From `#PB#_member` Where `username`='{$username}' Limit 1";
        $row = db::get_one($sql);
           
        if(empty($row))
        {
            exit(json_encode(array(
                "code" => -1,
                "msg"  => "账号不存在",
            )));
        }
           
        // 判断渠道账号是否停用状态
        if( $row['status'] == 0 )
        {
            exit(json_encode(array(
                "code" => -1,
                "msg"  => "账号未审核通过",
            )));
        }
        if( $row['status'] == -1 )
        {
            exit(json_encode(array(
                "code" => -1,
                "msg"  => "账号已被停用",
            )));
        }
           
        if( $row['password'] && $row['password'] == md5($password) )
        {
            $info = array(
                'uid'      => $row['id'],
                'username' => $row['username'],
                'lifetime' => $row['lifetime'],
                'status'   => $row['status'],
            );

            // 更新最后登录时间和IP
            $update_data = array(
                "logintime" => time(),
                "loginip"   => util::get_client_ip(),
            );
            db::update("#PB#_member", $update_data, "`id`={$info['uid']}");

            mod_member::save_member_log($username, "账号登录");

            list($token, $life) = pub_token::make_token($info);
            exit(json_encode(array(
                "code" => 0,
                "msg"  => "登录成功",
                "life" => $life,
                "token" => $token,
            )));
        }
        else 
        {
            exit(json_encode(array(
                "code" => -1,
                "msg"  => "账号密码错误",
            )));
        }

    }


    public function userinfo()
    {
        $token = req::item("token");
        if (empty($token)) 
        {
            exit(json_encode(array(
                "code" => -2,
                "msg"  => "Token not exists",
            )));
        }

        $info = pub_token::check_token($token);
        if (empty($info)) 
        {
            exit(json_encode(array(
                "code" => -2,
                "msg"  => "Token expired",
            )));
        }

        exit(json_encode(array(
            "code" => 0,
            "msg"  => "successful",
            "data" => $info,
        )));
    }
}
