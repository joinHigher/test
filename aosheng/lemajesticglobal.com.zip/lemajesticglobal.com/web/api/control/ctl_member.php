<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 账号接口
 *
 * @version $Id$
 */
class ctl_member
{
    public static $userinfo = array();

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        // 如果不是post方式
        //if (empty(req::$posts)) 
        //{
            //exit(json_encode(array(
                //"code" => -1,
                //"msg" => "Method Error.",
            //)));
        //}

        self::$userinfo = mod_member::check_login();
    }

    public function index()
    {
        $keyword = req::item("keyword");
        $parentid = req::item("parentid");
        $where = array();
        if (!empty($parentid)) 
        {
            // 只取子集
            //$where[] = "`parentid`='{$parentid}'";
            // 取子集已经下面所有子集
            $where[] = "FIND_IN_SET($parentid, `parentpath`)";
        }
        if (!empty($keyword)) 
        {
            $where[] = "`username`='{$keyword}'";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select `id`,`username`,`status`,`audit_type` From `#PB#_member` {$where}";
        $rows = db::get_all($sql);
        $data = array(
            'code' => 0,
            'msg'  => "successful",
            'data' => $rows,
        );
        exit(json_encode($data));
    }

    /**
     * 添加用户接口
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2017-10-29 15:58
     */
    public function add()
    {
        $username = req::item('username');
        $password = req::item('password');
        $protato  = req::item('protato');
        $telegram = req::item('telegram');
        $contact  = req::item('contact');

        if (empty($username) || empty($password)) 
        {
            exit(json_encode(array(
                "code" => -1,
                "msg" => "用户名密码不能为空！",
            )));
        }

        $row = db::get_one("Select * From `#PB#_member` Where `username`='{$username}'");
        if( is_array($row) )
        {
            exit(json_encode(array(
                "code" => -1,
                "msg" => "账号已经存在！",
            )));
        }

        // 查询父账号的父级路径
        $row = db::get_one("Select `parentpath`,`rule` From `#PB#_member` Where `id`='".self::$userinfo['uid']."'");
        $parentpath = empty($row['parentpath']) ? self::$userinfo['uid'] : $row['parentpath'].",".self::$userinfo['uid'];
        $insert_data = array(
            "username"   => $username,
            "password"   => md5($password),
            "protato"    => $protato,
            "telegram"   => $telegram,
            "contact"    => $contact,
            "parentid"   => self::$userinfo['uid'],
            "parentname" => self::$userinfo['username'],
            "parentpath" => $parentpath,
            "rule"       => $row['rule'],
            "audit_type" => 1,
            "addtime"    => time(),
        );

        $insert_id = db::insert('#PB#_member', $insert_data);

        mod_member::save_member_log(self::$userinfo['username'], "账号添加 {$insert_id} {$username}");
        //cls_auth::save_admin_log(cls_auth::$user->fields['username'], "账号添加 {$insert_id}");

        exit(json_encode(array(
            "code" => 0,
            "msg" => "添加成功",
        )));

    }

    public function edit()
    {
        $id = req::item('id');

        if (empty($id)) 
        {
            exit(json_encode(array(
                "code" => -1,
                "msg"  => "用户名ID不能为空！",
            )));
        }

        // 修改数据
        if (!empty(req::$posts)) 
        {
            $row = db::get_one("Select Count(*) As `count` From `#PB#_member` Where `id`='{$id}'");
            if( !$row['count'] )
            {
                exit(json_encode(array(
                    "code" => -1,
                    "msg"  => "账号不存在！",
                )));
            }

            $row = db::get_one("Select Count(*) As `count` From `#PB#_member_edit` Where `member_id`='{$id}'");
            if( $row['count'] )
            {
                exit(json_encode(array(
                    "code" => -1,
                    "msg"  => "账号正在操作中！",
                )));
            }

            $password = req::item('password');
            $protato  = req::item('protato');
            $telegram = req::item('telegram');
            $contact  = req::item('contact');

            $password = empty($password) ? '' : md5($password);
            $insert_data = array(
                "member_id" => $id,
                "password"  => $password,
                "protato"   => $protato,
                "telegram"  => $telegram,
                "contact"   => $contact,
                "uptime"    => time(),
            );

            $insert_id = db::insert('#PB#_member_edit', $insert_data);

            $sql = "Update `#PB#_member` Set `audit_type`='2' Where `id`='{$id}'";
            db::query($sql);

            mod_member::save_member_log(self::$userinfo['username'], "账号修改 {$id}");
            //cls_auth::save_admin_log(cls_auth::$user->fields['username'], "账号添加 {$insert_id}");

            exit(json_encode(array(
                "code" => 0,
                "msg" => "提交修改审核成功",
            )));
        }
        // 查询数据
        else 
        {
            $row = db::get_one("Select `username`,`audit_type`,`protato`,`telegram`,`contact` From `#PB#_member` Where `id`='{$id}'");
            if( !is_array($row) )
            {
                exit(json_encode(array(
                    "code" => -1,
                    "msg"  => "账号不存在！",
                )));
            }

            if( $row['audit_type'] )
            {
                $str = "添加";
                if ($row['audit_type'] == 2) 
                {
                    $str = "修改";
                }
                elseif ($row['audit_type'] == 3) 
                {
                    $str = "删除";
                }
                exit(json_encode(array(
                    "code" => -1,
                    "msg"  => "账号{$str}审核中，不能进行修改！",
                )));
            }

            unset($row['audit_type']);
            exit(json_encode(array(
                "code" => 0,
                "msg"  => "successful",
                "data" => $row,
            )));

        }

    }

    /**
     * 删除用户接口
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2017-10-29 15:58
     */
    public function del()
    {
        $id = req::item('id');

        if (empty($id)) 
        {
            exit(json_encode(array(
                "code" => -1,
                "msg" => "用户ID不能为空！",
            )));
        }

        $row = db::get_one("Select `audit_type` From `#PB#_member` Where `id`='{$id}'");
        if( !is_array($row) )
        {
            exit(json_encode(array(
                "code" => -1,
                "msg" => "账号不存在！",
            )));
        }

        // 账号操作审核中
        if ($row['audit_type'] != 0) 
        {
            $str = "添加";
            if ($row['audit_type'] == 2) 
            {
                $str = "修改";
            }
            if ($row['audit_type'] == 3) 
            {
                $str = "删除";
            }
            exit(json_encode(array(
                "code" => -1,
                "msg" => "账号{$str}审核中！",
            )));
        }

        $sql = "Update `#PB#_member` Set `audit_type`='3' Where `id`='{$id}'";
        db::query($sql);

        mod_member::save_member_log(self::$userinfo['username'], "账号删除 {$id}");
        //cls_auth::save_admin_log(cls_auth::$user->fields['username'], "账号添加 {$insert_id}");

        exit(json_encode(array(
            "code" => 0,
            "msg" => "添加成功",
        )));

    }
}
