<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * API接口
 *
 * @version $Id$
 */
class ctl_index
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
    }

    public function index()
    {
        $data = array(
            'code' => -1,
            'msg'  => "Sorry, You can not do it",
        );
        exit(json_encode($data));

    }


}
