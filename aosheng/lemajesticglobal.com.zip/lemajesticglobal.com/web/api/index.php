<?php
header('Content-Type: text/html; charset=utf-8');
require '../core/call.php';

//APP信息
$app_config = array(
    'app_title' => 'Search Person API',
);

// 接口类型
//call::$is_ajax = true;
$app = new call( $app_config );
$app->run();
