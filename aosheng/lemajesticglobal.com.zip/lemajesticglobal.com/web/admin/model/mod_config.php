<?php

class mod_config
{
    const KEY_BILL_END_DATE         = 'bill_end_date';
    const KEY_EXCHANGE_FEE_RATE     = 'clear_rate_per';
    const KEY_DEFAULT_CURRENCY_CODE = 'transact_curcy';

    public static function get_field($key)
    {
		$data = db::select('value')
			->from('#PB#_config')
			->where('name', $key)
			->as_row()
			->execute();

        return empty($data) ? null : $data['value'];
    }
}