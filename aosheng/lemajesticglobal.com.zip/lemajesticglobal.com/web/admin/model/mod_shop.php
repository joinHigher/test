<?php
if (!defined('PHPCALL'))
{
	exit('Request Error!');
}

/**
 * 商户模块
 *
 * @version $Id$
 */
class mod_shop
{
	static private $prefix_cache = "mod_shop_";

	//状态
	static public $status_list = array (
		0 => '正常',
		1 => '停用',
	);

	//联系方式
	static public $contact_way_list = array (
		1 => 'Potato',
		2 => 'Telegram',
		3 => 'Whatsapp',
		4 => 'Wechat',
		5 => 'QQ',
		6 => 'Tel'
	);

	//证件类型
	static public $card_type_list = array (
		2 => '营业执照',
		//1 => '集团注册号',
		3 => '其它',
	);

	//合同类型
	static public $contract_type_list = array (
		2 => '在线合同',
		1 => '已签合同',
	);

	//主键字段名
	static private $pk = 'id';

	//数据表名
	static private $table = '#PB#_shop';

	//数据表字段
	static private $field = array (
		'id',
		'name',
		'catid',
		'end_date',
		'is_long_date',
		'card_type',
		'card_pics',
		'card_name',
		'card_num',
		'address',
		'payment_days',
		'gutee_money',
		'contract_type',
		'contract_num',
		'contract_pics',
		'contact_per',
		'contact_ways',
		'email',
		'status',
		'audit_status',
		'audit_id',
		'audit_time',
		'addtime',
		'uptime',
		'deltime',
	);

	public function __construct()
	{
		$lang = util::get_language();
		lang::load("model", $lang);

		self::$status_list[0] = lang::get('model_normal');
		self::$status_list[1] = lang::get('model_disabled');

		//self::$card_type_list[1] = lang::get('model_group_registration_number');
		self::$card_type_list[2] = lang::get('model_business_license');
		self::$card_type_list[3] = lang::get('model_other');

		self::$contract_type_list[1] = lang::get('model_signed_contract');
		self::$contract_type_list[2] = lang::get('model_online_contract');

	}

	/**
	 * 判断商户分类是否使用
	 *
	 * @param $cate_id 分类ID
	 * @return bool 存在返回true，否则返回false
	 */
	public static function cate_exist($cate_id)
	{
		if(empty($cate_id))
		{
			return false;
		}

		$info = self::get_info(array ('catid', '=', $cate_id), 'id');

		if(empty($info))
		{
			return false;
		}

		return true;
	}

	/**
	 * 月结开始与结束时间
	 *
	 * @param bool $is_last_day 是否使用月尾做月结日
	 * @return array
	 */
	public static function month_start_and_end_time()
	{
		$year = date('Y',strtotime("-1 month"));
		$month = date('m',strtotime("-1 month"));
		$start_time = strtotime("{$year}-{$month}-01 00:00:00");

		$last_day = self::month_last_day();
		$end_time = strtotime("{$year}-{$month}-{$last_day} 23:59:59");

		return array ('start_time' => $start_time, 'end_time' => $end_time);
	}

	//上个月最后一天
	public static function month_last_day()
	{
		$last= strtotime("-1 month", time());
		$last_lastday = date("t", $last);
		return $last_lastday;
	}

	//获取当年最后一天的日期
	public static function get_year_last_date()
	{
		$pre_year = date('Y',strtotime('+1 year'));
		return date('Y-m-d',strtotime('-1 day',strtotime("{$pre_year}-01-01")));
	}

	//获取总数
	public static function get_sum($where, $sum_field)
	{
		$query = db::select('sum('. $sum_field .') as `sum`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['sum'];
	}

	//获取列表数据
	public static function get_list($where = array (), $field = '', $limit = 0, $offset = 0, $order_by = array (), $group_by = '')
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		if($limit > 0)
		{
			$query->limit($limit);

			if($offset >= 0)
			{
				$query->offset($offset);
			}
		}

		if(!empty($group_by))
		{
			$query->group_by($group_by);
		}

		$list = $query->execute();

		return $list;
	}

	//获取总数
	public static function get_count($where = array ())
	{

		$query = db::select('Count(*) AS `count`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['count'];

	}

	//用主键查询数据
	public static function find($id, $field='', $is_master = false)
	{
		$row = db::select(self::_get_field($field))
			->from(self::$table)
			->where(self::$pk, $id)
			->as_row()
			->execute($is_master);
		return $row;
	}

	//获取详情
	public static function get_info($where, $field='', $order_by = '', $is_master = false)
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		$row = $query->as_row()->execute($is_master);

		return $row;
	}

	//获取排序顺序第一条数据
	public static function get_first_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, array ($order_field, 'ASC'), true);
	}

	//获取排序倒序第一条数据
	public static function get_last_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, $order_field, true);
	}

	//添加
	public static function add_data($add_data)
	{
		if(empty($add_data))
		{
			return 0;
		}

		list($insert_id, $rows_affected) = db::insert(self::$table)->set($add_data)->execute();

		if(empty(self::$pk))
		{
			return $rows_affected;
		}

		return $insert_id;
	}

	//修改
	public static function update_data($where,$edit_data)
	{
		$query = db::update(self::$table)->set($edit_data);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//删除
	public static function del_data($where)
	{
		if(empty($where))
		{
			return false;
		}

		$query = db::delete(self::$table);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//处理where条件
	private static function _where($query, $where)
	{
		if(empty($where))
		{
			return false;
		}

		if(isset($where['or']))
		{
			$query->where_open()->or_where($where['or'])->where_close();
		}

		if(isset($where['and']))
		{
			$query->where($where['and']);
		}

		if((!isset($where['or']) && !isset($where['and'])))
		{
			if(isset($where[0]) && is_array($where[0]))
			{
				$query->where($where);
			}
			else
			{
				if(count($where) == 2)
				{
					$query->where($where[0], $where[1]);
				}
				else
				{
					$query->where($where[0], $where[1], $where[2]);
				}
			}
		}

		return '';
	}

	//处理order by
	private static function _order_by($query, $order_by)
	{
		$direction = 'DESC';
		$sort_field = self::$pk;

		if(isset($order_by[0]) && is_array($order_by[0]))
		{
			foreach ($order_by as $obk => $obv)
			{
				$direction = isset($obv[1]) ? $obv[1] : $direction;
				$sort_field = isset($obv[0]) ? $obv[0] : $sort_field;

				if(!empty($sort_field))
				{
					$query->order_by($sort_field, $direction);
				}
			}
		}
		else
		{
			if(is_array($order_by))
			{
				$direction = isset($order_by[1]) ? $order_by[1] : $direction;
				$sort_field = isset($order_by[0]) ? $order_by[0] : $sort_field;
			}
			else
			{
				$sort_field = $order_by;
			}

			if(!empty($sort_field))
			{
				$query->order_by($sort_field, $direction);
			}
		}
	}

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	private static function _get_field($field = '', $is_contrary_field = false)
	{
		if(is_array($field))
		{
			$is_contrary_field = isset($field['is_contrary_field']) ? $field['is_contrary_field'] : $is_contrary_field;
			$field = isset($field['field']) ? $field['field'] : self::$field;

			if(!is_array($field))
			{
				$field = explode(',', $field);
			}

			if(!empty($field) && $is_contrary_field === true)
			{
				return array_diff(self::$field, $field);
			}
		}
		else
		{
			$field = empty($field) ? self::$field : $field;
		}

		return $field;
	}
}













