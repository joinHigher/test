<?php
if (!defined('PHPCALL'))
{
	exit('Request Error!');
}

/**
 * 商户分类模块
 *
 * @version $Id$
 */
class mod_shop_category
{
	static private $prefix_cache = "mod_shop_category_";

	static $select_information_name = "请选择";

	//主键字段名
	static private $pk = 'id';

	//数据表名
	static private $table = '#PB#_shop_category';

	//数据表字段
	static private $field = array (
		'id',
		'name',
		'parentid',
		'parentpath',
		'is_del',
		'addtime',
		'uptime',
		'deltime',
	);

	//获取所有的数据
	public static function get_all_list()
	{
		$list = cache::get(self::$prefix_cache, 'all_list');

		if (empty($list))
		{
			$list = self::get_list(array ('is_del', '=', 0));
			cache::set(self::$prefix_cache, 'all_list', $list);
		}

		return $list;
	}

	/**
	 * 获取所有的子集
	 * @param $data 数据
	 * @param string $pid 上级ID
	 * @param array $res 组装的数据
	 * @param string $endlevel 递归结束的层级
	 * @return array
	 */
	public static function get_child($data, $pid = '0', $res = array (), $endlevel = '0')
	{
		$res = array ();

		if(!empty($data))
		{
			foreach ($data as $k => $v)
			{
				unset($v['is_del']);
				unset($v['addtime']);
				unset($v['uptime']);
				unset($v['deltime']);
				if ($v['parentid'] == $pid)
				{
					$res[$v['id']] = $v;
					if ($endlevel != '0')
					{
						if ($v['level'] == $endlevel)
						{
							$child = array ();
						}
						else
						{
							$child = self::get_child($data, $v['id'], array (), $endlevel);
						}
						$res[$v['id']]['child'] = $child;
					}
					else
					{
						$child = self::get_child($data, $v['id'], array ());
						if ($child == '' || $child == null)
						{
							$res[$v['id']]['child'] = array ();
						}
						else
						{
							$res[$v['id']]['child'] = $child;
						}
					}

				}
			}
		}

		return $res;
	}

	//获取树形结构
	public static function get_tree()
	{
		$list = self::get_all_list();
		$tree = self::get_child($list);
		return $tree;
	}

	/**
	 * 获取选择下拉列表
	 *
	 * @param int $default 是否有选择项 1：有，0：没有
	 * @param int $parent_id 已选择的ID，这个用于编辑的时候默认选中父类
	 * @param int $myself_id 自身ID,这个主要用于编辑的时候，不能选择自己的子类
	 * @return string
	 */
	public static function get_options($default = 0, $parent_id =0,$myself_id=0)
	{
		$options = $default == 1 ? "<option value=\"\">". self::$select_information_name ."</option>" : '';
		$tree = self::get_tree();
		foreach ($tree as $item)
		{
			if($myself_id == $item['id'])continue;
			$selected = $item['id'] == $parent_id ? 'selected' : '';
			$options .= "<option value=\"{$item['id']}\" {$selected}>{$item['name']}</option>";
			$child = $item['child'];
			if(!empty($child))
			{
				foreach ($child as $item)
				{
					if($myself_id == $item['id'])continue;
					$selected = $item['id'] == $parent_id ? 'selected' : '';
					$options .= "<option value=\"{$item['id']}\" {$selected}>&nbsp;&nbsp;├{$item['name']}</option>";
					$child = $item['child'];
					if(!empty($child))
					{
						foreach ($child as $item)
						{
							if($myself_id == $item['id'])continue;
							$selected = $item['id'] == $parent_id ? 'selected' : '';
							$options .= "<option value=\"{$item['id']}\" {$selected}>&nbsp;&nbsp;&nbsp;&nbsp;├{$item['name']}</option>";
							$child = $item['child'];
							if(!empty($child))
							{
								foreach ($child as $item)
								{
									if($myself_id == $item['id'])continue;
									$selected = $item['id'] == $parent_id ? 'selected' : '';
									$options .= "<option value=\"{$item['id']}\" {$selected}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;├{$item['name']}</option>";
									$child = $item['child'];
									if(!empty($child))
									{
										foreach ($child as $item)
										{
											if($myself_id == $item['id'])continue;
											$selected = $item['id'] == $parent_id ? 'selected' : '';
											$options .= "<option value=\"{$item['id']}\" {$selected}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;├{$item['name']}</option>";
											$child = $item['child'];
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return $options;
	}

	//获取总数
	public static function get_sum($where, $sum_field)
	{
		$query = db::select('sum('. $sum_field .') as `sum`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['sum'];
	}

	//获取列表数据
	public static function get_list($where = array (), $field = '', $limit = 0, $offset = 0, $order_by = array (), $group_by = '')
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		if($limit > 0)
		{
			$query->limit($limit);

			if($offset >= 0)
			{
				$query->offset($offset);
			}
		}

		if(!empty($group_by))
		{
			$query->group_by($group_by);
		}

		$list = $query->execute();

		return $list;
	}

	//获取总数
	public static function get_count($where = array ())
	{

		$query = db::select('Count(*) AS `count`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['count'];

	}

	//用主键查询数据
	public static function find($id, $field='', $is_master = false)
	{
		$row = db::select(self::_get_field($field))
			->from(self::$table)
			->where(self::$pk, $id)
			->as_row()
			->execute($is_master);
		return $row;
	}

	//获取详情
	public static function get_info($where, $field='', $order_by = '', $is_master = false)
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		$row = $query->as_row()->execute($is_master);

		return $row;
	}

	//获取排序顺序第一条数据
	public static function get_first_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, array ($order_field, 'ASC'), true);
	}

	//获取排序倒序第一条数据
	public static function get_last_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, $order_field, true);
	}

	//添加
	public static function add_data($add_data)
	{
		if(empty($add_data))
		{
			return 0;
		}

		list($insert_id, $rows_affected) = db::insert(self::$table)->set($add_data)->execute();

		if(empty(self::$pk))
		{
			return $rows_affected;
		}

		return $insert_id;
	}

	//修改
	public static function update_data($where,$edit_data)
	{
		$query = db::update(self::$table)->set($edit_data);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//删除
	public static function del_data($where)
	{
		if(empty($where))
		{
			return false;
		}

		$query = db::delete(self::$table);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//处理where条件
	private static function _where($query, $where)
	{
		if(empty($where))
		{
			return false;
		}

		if(isset($where['or']))
		{
			$query->where_open()->or_where($where['or'])->where_close();
		}

		if(isset($where['and']))
		{
			$query->where($where['and']);
		}

		if((!isset($where['or']) && !isset($where['and'])))
		{
			if(isset($where[0]) && is_array($where[0]))
			{
				$query->where($where);
			}
			else
			{
				if(count($where) == 2)
				{
					$query->where($where[0], $where[1]);
				}
				else
				{
					$query->where($where[0], $where[1], $where[2]);
				}
			}
		}

		return '';
	}

	//处理order by
	private static function _order_by($query, $order_by)
	{
		$direction = 'DESC';
		$sort_field = self::$pk;

		if(isset($order_by[0]) && is_array($order_by[0]))
		{
			foreach ($order_by as $obk => $obv)
			{
				$direction = isset($obv[1]) ? $obv[1] : $direction;
				$sort_field = isset($obv[0]) ? $obv[0] : $sort_field;

				if(!empty($sort_field))
				{
					$query->order_by($sort_field, $direction);
				}
			}
		}
		else
		{
			if(is_array($order_by))
			{
				$direction = isset($order_by[1]) ? $order_by[1] : $direction;
				$sort_field = isset($order_by[0]) ? $order_by[0] : $sort_field;
			}
			else
			{
				$sort_field = $order_by;
			}

			if(!empty($sort_field))
			{
				$query->order_by($sort_field, $direction);
			}
		}
	}

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	private static function _get_field($field = '', $is_contrary_field = false)
	{
		if(is_array($field))
		{
			$is_contrary_field = isset($field['is_contrary_field']) ? $field['is_contrary_field'] : $is_contrary_field;
			$field = isset($field['field']) ? $field['field'] : self::$field;

			if(!is_array($field))
			{
				$field = explode(',', $field);
			}

			if(!empty($field) && $is_contrary_field === true)
			{
				return array_diff(self::$field, $field);
			}
		}
		else
		{
			$field = empty($field) ? self::$field : $field;
		}

		return $field;
	}
}













