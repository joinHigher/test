<?php
if( !defined('CORE') ) exit('Request Error!');
/**
 * 公司模块
 *
 * @version $Id$
 */
class mod_company
{
    private static $tree_data;
    
    public static function get_name($id, $default = '无')
    {
        $info = self::get_id_names();
        return empty($info[$id]) ? $default : $info[$id];
    }


    public static function get_parentids_like($keyword)
    {
        if (empty($keyword)) 
        {
            return NULL;
        }

        $sql = "Select `id` From `ds_company` Where `name` Like '%{$keyword}%'";
        $rows = db::get_all($sql);
        $ids = array();
        foreach ($rows as $row) 
        {
            $ids[] = $row['id'];
        }
        if (empty($ids)) 
        {
            return NULL;
        }

        return implode(",", $ids);
    }

    public static function get_parentids($ids)
    {
        $sql = "Select `parentid` From `ds_company` Where `id` In ({$ids})";
        $rows = db::get_all($sql);
        $ids = array();
        foreach ($rows as $row) 
        {
            $ids[] = $row['parentid'];
        }
        if(empty($ids)) 
        {
            return '';
        }
        return implode(",", $ids);
    }

    public static function get_list($where='status=1',$order = 'id Desc', $field = 'id,name,parentid,layer')
    {
        if($where){
            $where = ' WHERE '.$where;
        }

        if($order){
            $order = ' ORDER BY '.$order;
        }

        $sql = "Select {$field} From `ds_company` {$where} {$order}";
        $rows = db::get_all($sql);
        $list = array();
        foreach ($rows as $v)
        {
            $list[$v['id']] = $v;
        }

        return $list;
    }

    public static function get_id_names()
    {
        $sql = "Select `id`,`name` From `ds_company`";
        $rows = db::get_all($sql);
        $list = array();
        foreach ($rows as $row) 
        {
            $list[$row['id']] = $row['name'];
        }
        return $list;
    }

    public static function get_options($default = "无", $sel_id = 0, $dis_id = 0, $parentid = 0)
    {
        self::$tree_data = array(
            0 => array(
                'id' => 0,
                'parentid' => 0,
                'name' => $default
            )
        );

        if ($parentid == 0) 
        {
            $sql = "Select `id`,`parentid`,`name` From `ds_company` Where `status`=1 Order By `a_time` Desc";
            $rows = db::get_all($sql);
            foreach ($rows as $row) 
            {
                self::$tree_data[$row['id']] = $row;
            }
        }
        else 
        {
            self::get_options_child($parentid);
        }

        $str = "<option value=\$id \$selected \$disabled>\$spacer\$name</option>";  
        $tree = new cls_tree(self::$tree_data);  
        $option_str = $tree->get_tree(0, $str, $sel_id, $dis_id);  
        return $option_str;
    }

    public static function get_options_child($com_id = 0)
    {
        // 0 As `parentid` 把当前目录归到0下面，才能生成tree
        $sql = "Select `id`,0 As `parentid`,`name` From `ds_company` Where `id`='{$com_id}' And `status`=1 Order By `a_time` Desc";
        $row = db::get_one($sql);
        self::$tree_data[$row['id']] = $row;
        self::get_childs($com_id);
    }

    public static function get_childs($parentid = 0)
    {
        $sql = "Select `id`,`parentid`,`name` From `ds_company` Where `parentid`='{$parentid}' And `status`=1 Order By `a_time` Desc";
        $rows = db::get_all($sql);
        if (!empty($rows)) 
        {
            foreach ($rows as $row) 
            {
                self::$tree_data[$row['id']] = $row;
                self::get_childs($row['id']);
            }
        }
    }

    /*
     * 获取所属下级公司
        date：2017:7:20 11:50
        return array(id=>name)
     */
    public static function get_sub_company($company_id)
    {
        $info=array();
        $sql="SELECT id,name FROM ds_company WHERE id='{$company_id}' and status=1";
        $self_company_info=db::get_all($sql);
        foreach ($self_company_info as $key=>$val)
        {
            $info[$val["id"]]=$val["name"];
               self::get_companys_by_parent_id($val["id"],$info);
        }
        return $info;
    }
    /*
     * 根据公司ID获取所属公司信息
        date：2017:7:20 11:50
    */
    private static function get_companys_by_parent_id($company_id,&$info,$level=1)
    {
        $sql="SELECT id,name FROM ds_company WHERE  parentid='{$company_id}' and status=1 ORDER by id ASC";
        $company_info=db::get_all($sql);
        foreach ($company_info as $key => $value)
        {
            # code...
            $str="&nbsp;";
            while (--$level){
                $str.="&nbsp";
            }
            $info[$value["id"]]=$str."├".$value["name"];
            self::get_companys_by_parent_id($value["id"],$info,$level++);
        }
    }
}













