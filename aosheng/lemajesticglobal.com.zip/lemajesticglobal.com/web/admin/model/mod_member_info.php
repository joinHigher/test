<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 用户模块
 *
 * @version $Id$
 */
class mod_member_info
{
    const TYPE_PAY       = 1;
	const STATUS_PENDING = 0;
	const STATUS_PASS    = 1;
	const STATUS_FAIL    = 2;
	const STATUS_FORBID  = 3;

    static private $prefix_cache = "mod_member_info_";

    //授信默认币种
	static public $default_currency = array (
		'code' => 'CNY',
		'name' => '人民币',
	);

	//性别
	static public $sex_list = array (
		1 => '小姐',
		2 => '先生',
	);

    public static $status_map = array (
		self::STATUS_PENDING => '待审核',
		self::STATUS_PASS    => '审核通过',
		self::STATUS_FAIL    => '已驳回',
    );

    const DEFAULT_PARENT_NAME = '-';

	//公司类型
	public static $company_type_list = array(
		1 => '法人',
		2 => '事业单位',
		3 => '其他团体',
	);

    //个人证件类型
    public static $person_card_type_list = array(
		1 => '身份证',
		2 => '护照',
		3 => '其它',
	);

	//单位证件类型
	public static $company_card_type_list = array(
		//1 => '集团注册号',
		2 => '营业执照',
		3 => '其它',
	);

	//单位证件类型
	public static $type_list = array(
		1 => '机构用户',
		2 => '个人用户',
	);

	//联系方式
	static public $contact_way_list = array (
		'potato' => 'Potato',
		'telegram' => 'Telegram',
		'whatsapp' => 'Whatsapp',
		'wechat' => 'Wechat',
		'qq' => 'QQ',
		'tel' => 'Tel'
	);

	//主键
	static private $pk = 'id';

	//数据表名称
	static private $table = '#PB#_member_info';

	//数据表字段
	static private $field = array (
		'id',
		'name',
		'code',
		'company_type',
		'card_type',
		'bondsman1_id',
		'bondsman2_id',
		'card_pics',
		'contacts',
		'contact_ways',
		'gender',
		'address',
		'parentcode',
		'parentid',
		'parentname',
		'parentpath',
		'type',
		'bill_monthly',
		'status',
		'fail_reason',
		'date_day',
		'login_status',
		'currency_code',
		'is_enable_view_members',
		'is_enable_view_tran_detail',
		'card_name',
		'card_code',
		'lang',
		'reserve_information',
		'custom_code',
		'is_follow_prefix',
		'audit_id',
		'addtime',
		'uptime',
	);

	public function __construct()
	{
		$lang = util::get_language();
		lang::load("model", $lang);

		self::$default_currency['name'] = lang::get('model_rmb');

		self::$sex_list[1] = lang::get('model_miss');
		self::$sex_list[2] = lang::get('model_mr');

		self::$status_map[self::STATUS_PENDING] = lang::get('model_pending_review');
		self::$status_map[self::STATUS_PASS] 	= lang::get('model_examination_passed');
		self::$status_map[self::STATUS_FAIL] 	= lang::get('model_dismissed');

		self::$company_type_list[1] = lang::get('model_legal_person');
		self::$company_type_list[2] = lang::get('model_institution');
		self::$company_type_list[3] = lang::get('model_other_groups');

		self::$person_card_type_list[1] = lang::get('model_id_card');
		self::$person_card_type_list[2] = lang::get('model_passport');
		self::$person_card_type_list[3] = lang::get('model_identity_guarantor');

		//self::$company_card_type_list[1] = lang::get('model_group_registration_number');
		self::$company_card_type_list[2] = lang::get('model_business_license');
		self::$company_card_type_list[3] = lang::get('model_other');

		self::$type_list[1] = lang::get('model_institutional_user');
		self::$type_list[2] = lang::get('model_personal_user');

	}

	//获取客户默认币种
	public static function get_default_currency_name()
	{
		return self::$default_currency['code'];
	}

	//获取客户默认代号
	public static function get_default_currency_code()
	{
		return self::$default_currency['code'];
	}

	//保留两位数字
	public static function num_format($number, $separator = ',')
	{
		return number_format($number,2, '.', $separator);
	}

    public static function get_names($ids)
    {
        $member_infos = self::get_list(array ('id', 'in', $ids), 'name');
        $names = [];
        if(!empty($member_infos))
		{

			foreach ($member_infos as $member_info)
			{
				$names[] = $member_info['name'];
			}
		}
        return $names;
    }

    public static function contact_ways_text($contact_ways)
    {
        $way_arr = explode(',', $contact_ways);
        if (! empty($way_arr)) {
            $arr = array_map(function ($val) {
                return str_replace('-', '：', $val);
            }, $way_arr);

            return implode('<br>', $arr);
        }

        return '';
    }

	/**
	 * 月结开始与结束时间
	 *
	 * @param $mem_bill_monthly
	 * @param bool $is_last_day 是否使用月尾做月结日
	 * @return array
	 */
	public static function month_start_and_end_time($mem_bill_monthly,$is_last_day = true)
	{
		if($is_last_day)
		{
			$year = date('Y',strtotime("-1 month"));
			$month = date('m',strtotime("-1 month"));
			$start_time = strtotime("{$year}-{$month}-01 00:00:00");

			$last_day = self::month_last_day();
			$end_time = strtotime("{$year}-{$month}-{$last_day} 23:59:59");
		}
		else
		{
			$bill_monthly = empty($mem_bill_monthly) ? config::get('bill_end_date') : $mem_bill_monthly;

			$com_month_num = 2;
			$start_year = date('Y',strtotime("-{$com_month_num} month"));
			$start_month = date('m',strtotime("-{$com_month_num} month"));
			$start_time = strtotime('+1 day',strtotime("{$start_year}-{$start_month}-{$bill_monthly} 00:00:00"));

			$end_year = date('Y',strtotime("-1 month"));
			$end_month = date('m',strtotime("-1 month"));
			$end_time = strtotime("{$end_year}-{$end_month}-{$bill_monthly} 24:00:00");
		}

		return array ('start_time' => $start_time, 'end_time' => $end_time);
	}

	//上个月最后一天
	public static function month_last_day()
	{
		$last= strtotime("-1 month", time());
		$last_lastday = date("t", $last);
		return $last_lastday;
	}

	//临时额度到期时间
	public static function generate_tmp_end_date()
	{
		return date('Y-m-d', strtotime('+1 month'));
	}

	//获取用户还款日期
	public static function get_end_date($bill_monthly)
	{
		$bill_end_date = $bill_monthly ? $bill_monthly : config::get('bill_end_date');
		$bill_end_date = $bill_end_date < 10 ? '0'.$bill_end_date : $bill_end_date;
		return date('Y-m',time()).'-'.$bill_end_date;
	}

	//会员编辑时获取担保人会员信息
	public static function get_bondsman_info($bondsman_code, $bondsman_name)
	{

		$member_info_where = array ();
		$member_info_where['and'][] = array ('status', '=', 1);
		$member_info_where['and'][] = array ('name', '=', $bondsman_name);
		$member_info_where['or'][] = array ('code', '=', $bondsman_code);
		$member_info_where['or'][] = array ('custom_code', '=', $bondsman_code);

		$member_info = self::get_info($member_info_where);

		return $member_info;
	}

	//获取总数
	public static function get_sum($where, $sum_field)
	{
		$query = db::select('sum('. $sum_field .') as `sum`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['sum'];
	}

	//获取列表数据
	public static function get_list($where = array (), $field = '', $limit = 0, $offset = 0, $order_by = array (), $group_by = '')
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		if($limit > 0)
		{
			$query->limit($limit);

			if($offset >= 0)
			{
				$query->offset($offset);
			}
		}

		if(!empty($group_by))
		{
			$query->group_by($group_by);
		}

		$list = $query->execute();

		return $list;
	}

	//获取总数
	public static function get_count($where = array ())
	{

		$query = db::select('Count(*) AS `count`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['count'];

	}

	//用主键查询数据
	public static function find($id, $field='', $is_master = false)
	{
		$row = db::select(self::_get_field($field))
			->from(self::$table)
			->where(self::$pk, $id)
			->as_row()
			->execute($is_master);
		return $row;
	}

	//获取详情
	public static function get_info($where, $field='', $order_by = '', $is_master = false)
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		$row = $query->as_row()->execute($is_master);

		return $row;
	}

	//获取排序顺序第一条数据
	public static function get_first_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, array ($order_field, 'ASC'), true);
	}

	//获取排序倒序第一条数据
	public static function get_last_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, $order_field, true);
	}

	//添加
	public static function add_data($add_data)
	{
		if(empty($add_data))
		{
			return 0;
		}

		list($insert_id, $rows_affected) = db::insert(self::$table)->set($add_data)->execute();

		if(empty(self::$pk))
		{
			return $rows_affected;
		}

		return $insert_id;
	}

	//修改
	public static function update_data($where,$edit_data)
	{
		$query = db::update(self::$table)->set($edit_data);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//删除
	public static function del_data($where)
	{
		if(empty($where))
		{
			return false;
		}

		$query = db::delete(self::$table);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//处理where条件
	private static function _where($query, $where)
	{
		if(empty($where))
		{
			return false;
		}

		if(isset($where['or']))
		{
			$query->where_open()->or_where($where['or'])->where_close();
		}

		if(isset($where['and']))
		{
			$query->where($where['and']);
		}

		if((!isset($where['or']) && !isset($where['and'])))
		{
			if(isset($where[0]) && is_array($where[0]))
			{
				$query->where($where);
			}
			else
			{
				if(count($where) == 2)
				{
					$query->where($where[0], $where[1]);
				}
				else
				{
					$query->where($where[0], $where[1], $where[2]);
				}
			}
		}

		return '';
	}

	//处理order by
	private static function _order_by($query, $order_by)
	{
		$direction = 'DESC';
		$sort_field = self::$pk;

		if(isset($order_by[0]) && is_array($order_by[0]))
		{
			foreach ($order_by as $obk => $obv)
			{
				$direction = isset($obv[1]) ? $obv[1] : $direction;
				$sort_field = isset($obv[0]) ? $obv[0] : $sort_field;

				if(!empty($sort_field))
				{
					$query->order_by($sort_field, $direction);
				}
			}
		}
		else
		{
			if(is_array($order_by))
			{
				$direction = isset($order_by[1]) ? $order_by[1] : $direction;
				$sort_field = isset($order_by[0]) ? $order_by[0] : $sort_field;
			}
			else
			{
				$sort_field = $order_by;
			}

			if(!empty($sort_field))
			{
				$query->order_by($sort_field, $direction);
			}
		}
	}

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	private static function _get_field($field = '', $is_contrary_field = false)
	{
		if(is_array($field))
		{
			$is_contrary_field = isset($field['is_contrary_field']) ? $field['is_contrary_field'] : $is_contrary_field;
			$field = isset($field['field']) ? $field['field'] : self::$field;

			if(!is_array($field))
			{
				$field = explode(',', $field);
			}

			if(!empty($field) && $is_contrary_field === true)
			{
				return array_diff(self::$field, $field);
			}
		}
		else
		{
			$field = empty($field) ? self::$field : $field;
		}

		return $field;
	}
}













