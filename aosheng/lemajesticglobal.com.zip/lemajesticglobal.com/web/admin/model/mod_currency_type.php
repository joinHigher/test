<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 货币模块
 *
 * @version $Id$
 */
class mod_currency_type
{
    static private $prefix_cache = "mod_currency_type_";

	//主键字段名
	static private $pk = 'id';

	static  private $table = '#PB#_currency_type';

	static private $field = array (
		'id',
		'name',
		'code_name',
		'symbol',
		'exg_rate',
		'uptime',
		'addtime',
	);

    //获取所有的货币
    public static function get_all_list()
    {
        $list = cache::get(self::$prefix_cache,'all_list');

        if(empty($list))
        {
			$list = self::get_list();
			cache::set(self::$prefix_cache,'all_list',$list);
		}

        return $list;
    }

	//获取货币缩写与名称
	public static function get_key_val()
	{
		$list = self::get_all_list();
		foreach ($list as $v)
		{
			$arr[self::to_upper($v['code_name'])] = $v['code_name'];
		}
		return $arr;
	}

	//获取货币缩写相应的汇率
	public static function get_exg_rate_list()
	{
		$list = self::get_all_list();
		foreach ($list as $v)
		{
			$arr[self::to_upper($v['code_name'])] = $v['exg_rate'];
		}
		return $arr;
	}

	//转大写
	public static function to_upper($code_name)
	{
		return strtoupper($code_name);
	}

	//客户根据货币获取相应的支出汇率金额
	public static function get_exg_money($money,$curcy)
	{
		//浮动汇率百分比(先不算波动汇率)
		//$percent = config::get('clear_rate_per');
		$percent = 0;
		$rate_list = self::get_exg_rate_list();
		$exg_rate = $rate_list[$curcy];
		$money = $money*$percent/100 + $money*$exg_rate;
		return $money;
	}

	//客户根据货币获取相应的收入汇率金额
	public static function income_exg_money($money,$curcy)
	{
		$rate_list = self::get_exg_rate_list();
		$exg_rate = $rate_list[$curcy];
		$money = $money*$exg_rate;
		return $money;
	}

	//客户根据货币获取相应的汇率金额
	public static function get_shop_exg_money($money,$curcy)
	{
		//浮动汇率百分比
		$percent = config::get('clear_rate_per');

		//平台运营费
		$plat_oper_costper = config::get('plat_oper_costper');

		$rate_list = self::get_exg_rate_list();
		$exg_rate = $rate_list[$curcy];
		//$money = $money*$exg_rate - $money*$percent/100;
		//$money = $money - $money*$plat_oper_costper/100;
		$money = $money*$exg_rate;
		return $money;
	}

	//获取默认货币名称
	public static function get_acq_name()
	{
		$code_name = self::get_default_curr();
		$list = self::get_key_val();
		return empty($list) ? '' : $list[$code_name];
	}

	//获取默认货币
	public static function get_default_curr()
	{
		$code_name = self::to_upper(config::get('transact_curcy'));
		return $code_name;
	}

	//获取会员货币默认符号
	public static function get_symbol()
	{
		$currency_english = mod_member_info::get_default_currency_name();
		$where[] = array ('code_name', '=', $currency_english);
		$transact_curcy_info = self::get_info($where, 'symbol');
		return empty($transact_curcy_info) ? '' : $transact_curcy_info['symbol'];
	}

	//获取平台货币默认符号
	public static function get_default_symbol()
	{
		$currency_english = self::get_default_curr();
		$where[] = array ('code_name', '=', $currency_english);
		$transact_curcy_info = self::get_info($where, 'symbol');
		return empty($transact_curcy_info) ? '' : $transact_curcy_info['symbol'];
	}

	//获取两种货币兑换的汇率
	public static function get_to_default_currency_exg($enter_currency_code, $exit_currency_code)
	{
		$default = self::get_default_curr();
		$exg_list = self::get_exg_rate_list();
		if($enter_currency_code == $default)
		{

			$exg_rate = $exg_list[$exit_currency_code];
		}
		else
		{
			$old_exg_rate = 1/$exg_list[$enter_currency_code];
			$new_exg_rate = $exg_list[$exit_currency_code];
			$exg_rate = $old_exg_rate*$new_exg_rate;
		}

		return $exg_rate;
	}

	/**
	 * 获取两种货币兑换汇率金额
	 *
	 * @param $enter_currency_code 需要换算的货币
	 * @param $exit_currency_code	换算后的货币
	 * @param $money 换算金额
	 * @return float|int
	 */
	public static function get_to_default_currency_money($enter_currency_code, $exit_currency_code, $money)
	{
		$default = self::get_default_curr();
		$exg_list = self::get_exg_rate_list();
		if($enter_currency_code == $default)
		{

			$exg_rate = $exg_list[$exit_currency_code];
		}
		else
		{
			$old_exg_rate = 1/$exg_list[$enter_currency_code];
			$new_exg_rate = $exg_list[$exit_currency_code];
			$exg_rate = $old_exg_rate*$new_exg_rate;
		}

		return $exg_rate*$money;
	}

	//获取货币名称
	public static function get_name($code_name)
	{
		$list = self::get_key_val();
		return empty($list) ? '' : $list[self::to_upper($code_name)];
	}

    public static function exchange($amount, $target_code)
    {
        $fee_rate = config::get('clear_rate_per');
        $currency = self::get_currency_by_code($target_code);

        return $amount * $currency['exg_rate'] + $amount * $fee_rate / 100;
    }

    public static function get_currency_by_code($code)
    {
    	$info = self::get_info(array ('code_name', '=', $code));
        return $info;
    }

	//清除所有缓存
	public static function clear_all_cache()
	{
		cache::del(self::$prefix_cache,'all_list');
	}

	//获取总数
	public static function get_sum($where, $sum_field)
	{
		$query = db::select('sum('. $sum_field .') as `sum`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['sum'];
	}

	//获取列表数据
	public static function get_list($where = array (), $field = '', $limit = 0, $offset = 0, $order_by = array (), $group_by = '')
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		if($limit > 0)
		{
			$query->limit($limit);

			if($offset >= 0)
			{
				$query->offset($offset);
			}
		}

		if(!empty($group_by))
		{
			$query->group_by($group_by);
		}

		$list = $query->execute();

		return $list;
	}

	//获取总数
	public static function get_count($where = array ())
	{

		$query = db::select('Count(*) AS `count`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['count'];

	}

	//用主键查询数据
	public static function find($id, $field='', $is_master = false)
	{
		$row = db::select(self::_get_field($field))
			->from(self::$table)
			->where(self::$pk, $id)
			->as_row()
			->execute($is_master);
		return $row;
	}

	//获取详情
	public static function get_info($where, $field='', $order_by = '', $is_master = false)
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		$row = $query->as_row()->execute($is_master);

		return $row;
	}

	//获取排序顺序第一条数据
	public static function get_first_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, array ($order_field, 'ASC'), true);
	}

	//获取排序倒序第一条数据
	public static function get_last_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, $order_field, true);
	}

	//添加
	public static function add_data($add_data)
	{
		if(empty($add_data))
		{
			return 0;
		}

		list($insert_id, $rows_affected) = db::insert(self::$table)->set($add_data)->execute();

		if(empty(self::$pk))
		{
			return $rows_affected;
		}

		return $insert_id;
	}

	//修改
	public static function update_data($where,$edit_data)
	{
		$query = db::update(self::$table)->set($edit_data);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//删除
	public static function del_data($where)
	{
		if(empty($where))
		{
			return false;
		}

		$query = db::delete(self::$table);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//处理where条件
	private static function _where($query, $where)
	{
		if(empty($where))
		{
			return false;
		}

		if(isset($where['or']))
		{
			$query->where_open()->or_where($where['or'])->where_close();
		}

		if(isset($where['and']))
		{
			$query->where($where['and']);
		}

		if((!isset($where['or']) && !isset($where['and'])))
		{
			if(isset($where[0]) && is_array($where[0]))
			{
				$query->where($where);
			}
			else
			{
				if(count($where) == 2)
				{
					$query->where($where[0], $where[1]);
				}
				else
				{
					$query->where($where[0], $where[1], $where[2]);
				}
			}
		}

		return '';
	}

	//处理order by
	private static function _order_by($query, $order_by)
	{
		$direction = 'DESC';
		$sort_field = self::$pk;

		if(isset($order_by[0]) && is_array($order_by[0]))
		{
			foreach ($order_by as $obk => $obv)
			{
				$direction = isset($obv[1]) ? $obv[1] : $direction;
				$sort_field = isset($obv[0]) ? $obv[0] : $sort_field;

				if(!empty($sort_field))
				{
					$query->order_by($sort_field, $direction);
				}
			}
		}
		else
		{
			if(is_array($order_by))
			{
				$direction = isset($order_by[1]) ? $order_by[1] : $direction;
				$sort_field = isset($order_by[0]) ? $order_by[0] : $sort_field;
			}
			else
			{
				$sort_field = $order_by;
			}

			if(!empty($sort_field))
			{
				$query->order_by($sort_field, $direction);
			}
		}
	}

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	private static function _get_field($field = '', $is_contrary_field = false)
	{
		if(is_array($field))
		{
			$is_contrary_field = isset($field['is_contrary_field']) ? $field['is_contrary_field'] : $is_contrary_field;
			$field = isset($field['field']) ? $field['field'] : self::$field;

			if(!is_array($field))
			{
				$field = explode(',', $field);
			}

			if(!empty($field) && $is_contrary_field === true)
			{
				return array_diff(self::$field, $field);
			}
		}
		else
		{
			$field = empty($field) ? self::$field : $field;
		}

		return $field;
	}
}













