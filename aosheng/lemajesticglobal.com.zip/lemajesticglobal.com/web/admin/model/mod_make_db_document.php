<?php
/**
 *
 * 本类用于自动生成项目的数据库结构文档
 *
 */
class mod_make_db_document
{
    //分析具体表
    public static function analyse_table(&$tableinfo, $tablename)
    {
        $flines = explode("\n", $tableinfo);
        $addinfo = $tbinfo = $tb_comment = '';
        $fields = array();
        foreach($flines as $line)
        {
            $line = trim($line);
            if( $line=='' ) continue;
            if( preg_match('/CREATE TABLE/i', $line) ) continue;
            if( !preg_match('/`/', $line) )
            {
                $arr = '';
                preg_match("/ENGINE=([a-z]*)(.*)DEFAULT CHARSET=([a-z0-9]*)/i", $line, $arr);
                $tbinfo = "ENGINE=".$arr[1].'/CHARSET='.$arr[3];
                $arr = '';
                preg_match("/comment='([^']*)'/i", $line, $arr);
                if( isset($arr[1]) )
                {
                    $tb_comment = $arr[1];
                }
                continue;
            }
            if( preg_match('/KEY/', $line) )
            {
                $addinfo .= $line."<br />\n";
            }
            else
            {
                $arr = '';
                $nline = preg_replace("/comment '([^']*)'/i", '', $line);
                preg_match("/`([^`]*)` (.*)[,]{0,1}$/U", $nline, $arr);
                $f = $arr[1];
                $fields[ $f ][0] = $arr[2];
                $fields[ $f ][1] = '';
                $arr = '';
                preg_match("/comment '([^']*)'/i", $line, $arr);
                if( isset($arr[1]) )
                {
                    $fields[ $f ][1] = $arr[1];
                }
            
            }
        }
        $tablehtml = "    <table width=\"960\" align=\"center\" border=\"0\" cellpadding=\"5\" cellspacing=\"1\" bgcolor=\"#C1D1A3\" style=\"font-size:14px;margin-bottom:10px\">
    <tr>
        <td height=\"34\" colspan=\"3\" bgcolor=\"#DDEDA5\">
        <a name=\"{$tablename}\"></a>
        <table width=\"90%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">
            <tr>
                <td width=\"29%\"><strong>表名：{$tablename}</strong> <br />($tbinfo)</td>
                <td width=\"71%\">说明：{$tb_comment}</td>
            </tr>
        </table></td>
    </tr>
    <tr>
        <td width=\"20%\" height=\"28\" bgcolor=\"#F7FDEA\">字段名</td>
        <td width=\"28%\" bgcolor=\"#F7FDEA\">说明描述</td>
        <td bgcolor=\"#F7FDEA\">具体参数</td>
    </tr>\n";
        foreach($fields as $k=>$v)
        {
            $tablehtml .= "    <tr height=\"24\" bgcolor=\"#FFFFFF\">
        <td><b>{$k}</b></td>
        <td>{$v[1]}</td>
        <td>{$v[0]}</td>
    </tr>\n";
        }
        $tablehtml .= "    <tr>
        <td height=\"28\" colspan=\"3\" bgcolor=\"#F7FDEA\">
        <b>索引：</b><br />
        {$addinfo}
        </td>
    </tr>
    </table>";
        return $tablehtml;
    }
    //列出数据库的所有表
    public static function show( $type='' )
    {
        $namehtml = $tablehtml = '';
        $rows = db::get_all("Show Tables");
        foreach ($rows as $row) 
        {
            $tablename = $row["Tables_in_".$GLOBALS['config']['db']['name']];
            $tableinfos = db::get_all("Show Create Table `{$tablename}`");
            $tableinfo = $tableinfos[0]['Create Table'];
            
            if( $type != '' )
            {
                if( !preg_match("/^".$type."_/", $tablename) ) continue;
            }
            
            $namehtml .= "<a href='#{$tablename}'>{$tablename}</a> | ";
            $tablehtml .= self::analyse_table( $tableinfo,  $tablename);
        }
        $htmlhead = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<style>
* {
    font-size:14px;
    font-family:Arial, \"宋休\", \"Courier New\";
}
a {
  text-decoration:none;
}
</style>
<title>数据库说明文档</title>
</head>";

    echo $htmlhead;
    echo "<table align='center' width='960' style='margin-bottom:8px' ><tr><td>&nbsp; ".$namehtml."</td></tr></table>";
    echo $tablehtml;
    echo "</body>\n</html>";
    exit();

    }//end show
}
