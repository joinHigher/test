<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 商户资金流向日志模块
 *
 * @version $Id$
 */
class mod_shop_bank_log
{
   	//主键字段名
	static private $pk = 'id';

	//数据表名
	static private $table = '#PB#_shop_bank_log';

	//数据表字段
	static private $field = array (
		'id',
		'bill_id',
		'order_id',
		'shop_id',
		'type',
		'bank_card_id',
		'currency_code',
		'amount',
		'from_type',
		'remark',
		'date',
		'addtime',
		'uptime',
	);

	//获取总数
	public static function get_sum($where, $sum_field)
	{
		$query = db::select('sum('. $sum_field .') as `sum`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['sum'];
	}

	//获取列表数据
	public static function get_list($where = array (), $field = '', $limit = 0, $offset = 0, $order_by = array (), $group_by = '')
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		if($limit > 0)
		{
			$query->limit($limit);

			if($offset >= 0)
			{
				$query->offset($offset);
			}
		}

		if(!empty($group_by))
		{
			$query->group_by($group_by);
		}

		$list = $query->execute();

		return $list;
	}

	//获取总数
	public static function get_count($where = array ())
	{

		$query = db::select('Count(*) AS `count`')->from(self::$table);

		self::_where($query, $where);

		$row = $query->as_row()->execute();

		return $row['count'];

	}

	//用主键查询数据
	public static function find($id, $field='', $is_master = false)
	{
		$row = db::select(self::_get_field($field))
			->from(self::$table)
			->where(self::$pk, $id)
			->as_row()
			->execute($is_master);
		return $row;
	}

	//获取详情
	public static function get_info($where, $field='', $order_by = '', $is_master = false)
	{
		$query = db::select(self::_get_field($field))->from(self::$table);

		self::_where($query, $where);

		self::_order_by($query, $order_by);

		$row = $query->as_row()->execute($is_master);

		return $row;
	}

	//获取排序顺序第一条数据
	public static function get_first_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, array ($order_field, 'ASC'), true);
	}

	//获取排序倒序第一条数据
	public static function get_last_info($where, $order_field = '', $field = '')
	{
		return  self::get_info($where, $field, $order_field, true);
	}

	//添加
	public static function add_data($add_data)
	{
		if(empty($add_data))
		{
			return 0;
		}

		list($insert_id, $rows_affected) = db::insert(self::$table)->set($add_data)->execute();

		if(empty(self::$pk))
		{
			return $rows_affected;
		}

		return $insert_id;
	}

	//修改
	public static function update_data($where,$edit_data)
	{
		$query = db::update(self::$table)->set($edit_data);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//删除
	public static function del_data($where)
	{
		if(empty($where))
		{
			return false;
		}

		$query = db::delete(self::$table);

		self::_where($query, $where);

		$result = $query->execute();

		return $result;
	}

	//处理where条件
	private static function _where($query, $where)
	{
		if(empty($where))
		{
			return false;
		}

		if(isset($where['or']))
		{
			$query->where_open()->or_where($where['or'])->where_close();
		}

		if(isset($where['and']))
		{
			$query->where($where['and']);
		}

		if((!isset($where['or']) && !isset($where['and'])))
		{
			if(isset($where[0]) && is_array($where[0]))
			{
				$query->where($where);
			}
			else
			{
				if(count($where) == 2)
				{
					$query->where($where[0], $where[1]);
				}
				else
				{
					$query->where($where[0], $where[1], $where[2]);
				}
			}
		}

		return '';
	}

	//处理order by
	private static function _order_by($query, $order_by)
	{
		$direction = 'DESC';
		$sort_field = self::$pk;

		if(isset($order_by[0]) && is_array($order_by[0]))
		{
			foreach ($order_by as $obk => $obv)
			{
				$direction = isset($obv[1]) ? $obv[1] : $direction;
				$sort_field = isset($obv[0]) ? $obv[0] : $sort_field;

				if(!empty($sort_field))
				{
					$query->order_by($sort_field, $direction);
				}
			}
		}
		else
		{
			if(is_array($order_by))
			{
				$direction = isset($order_by[1]) ? $order_by[1] : $direction;
				$sort_field = isset($order_by[0]) ? $order_by[0] : $sort_field;
			}
			else
			{
				$sort_field = $order_by;
			}

			if(!empty($sort_field))
			{
				$query->order_by($sort_field, $direction);
			}
		}
	}

	/**
	 * 获取数据表字段
	 *
	 * @param string $field  数据表字段
	 * @param bool $is_contrary_field  是否获取相反的数据，排除$field 中的字段
	 *
	 * @return array
	 */
	private static function _get_field($field = '', $is_contrary_field = false)
	{
		if(is_array($field))
		{
			$is_contrary_field = isset($field['is_contrary_field']) ? $field['is_contrary_field'] : $is_contrary_field;
			$field = isset($field['field']) ? $field['field'] : self::$field;

			if(!is_array($field))
			{
				$field = explode(',', $field);
			}

			if(!empty($field) && $is_contrary_field === true)
			{
				return array_diff(self::$field, $field);
			}
		}
		else
		{
			$field = empty($field) ? self::$field : $field;
		}

		return $field;
	}
}













