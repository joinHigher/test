
$(function(){
    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for(var i=0; i<ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1);
            if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
        }
        return "";
    }

    var icon = "<i class='fa fa-times-circle'></i>  ";
    var local_messages = {
        'zh-cn': {
            required: icon + "必选字段",
            remote: icon + "请修正该字段",
            email: icon + "请输入正确格式的电子邮件",
            url: icon + "请输入合法的网址",
            date: icon + "请输入合法的日期",
            number: icon + "请输入合法的数字",
            digits: icon + "只能输入整数",
            idcard:icon + "请输入合法的身份证号",
            creditcard: icon + "请输入合法的信用卡号",
            accept: icon +"请输入拥有合法后缀名的字符串",
            maxlength: icon +"长度不能大于 {0} 位",
            minlength: icon +"长度不能小于 {0} 位",
            rangelength: icon +"长度介于 {0} 和 {1} 之间",
            range: icon +"请输入一个介于 {0} 和 {1} 之间的值",
            max:icon + "请输入一个最大为 {0} 的值",
            min:icon + "请输入一个最小为 {0} 的值",
            equalTo:icon +"请再次输入相同的值",
            alnum: icon + '密码强度不够，必须包含大小写字母以及数字',
            alnumNqoRequest: icon + '密码强度不够，必须包含大小写字母以及数字',
            imglen: icon + '请至少上传一张照片',
            contact: icon + '必填字段',
            integer: icon + '请输入正整数',
        },
        'en': {
            required: icon +            "Required Field",
            remote: icon +              "Please edit field",
            email: icon +               "Please enter correct email address format.",
            url: icon +                 "Please enter legal website address.",
            date: icon +                "Please enter legal date.",
            number: icon +              "Please enter legal number.",
            digits: icon +              "Only integer available",
            idcard:icon +               "Please enter legal ID card number.",
            creditcard: icon +          "Please enter legal credit card number.",
            accept: icon +              "Please enter sting with legal filename extension.",
            maxlength: icon +           "Length cannot larger than {0}",
            minlength: icon +           "Length cannot smaller than {0}",
            rangelength: icon +         "Length between {0} and {1}. ",
            range: icon +               "Please enter a value between {0} and {1}",
            max:icon +                  "Please enter a maximum  {0}  value.",
            min:icon +                  "Please enter a minimum  {0}  value.",
            equalTo:icon +              "Please enter the same value again.",
            alnum: icon +               "The password is not strong, it must required upcast and lowercase letters and numbers.",
            alnumNqoRequest: icon +     "The password is not strong, it must required upcast and lowercase letters and numbers.",
            imglen: icon +              "Please upload a photo at least.",
            contact: icon +             "Required Field",
            integer: icon +             "Please enter positive integer",
        },
        "km": {
            required: icon +            		"តម្រូវឲជ្រើសរើសរូបតំណាង",
            remote: icon +              		"សូមកែតម្រូវរូបតំណាងនេះ",
            email: icon +               		"សូមបញ្ចូលទំរង់អ៊ីម៉ែលដែលត្រឹមត្រូវ",
            url: icon +                 		"អស័យដ្ឋានរបស់វេបសាយស្របច្បាប់",
            date: icon +                		"សូមបញ្ចូលកាលបរិច្ឆេទស្របច្បាប់ ",
            number: icon +              		"សូមបញ្ចូលតួលេខស្របច្បាប់",
            digits: icon +              		"អាចបញ្ចូលបានតែលេខគត់",
            idcard:icon +               		"សូមបញ្ចូលលេខអត្តសញ្ញាណប័ណ្ណស្របច្បាប់",
            creditcard: icon +          		"សូមបញ្ចូលលេខប័ណ្ណឥណទានស្របច្បាប់",
            accept: icon +              		"សូមបញ្ចូលខ្សែអក្សរដែលមានឈ្មោះខាងក្រោយស្របច្បាប់",
            maxlength: icon +           		"ប្រវែងមិនអាចធំជាង {0} តួ ",
            minlength: icon +           		"ប្រវែងមិនអាចតូចជាង{0} តួ ",
            rangelength: icon +         		"ប្រវែងតំលៃលេខរវាង {0} និង{1} ",
            range: icon +               		"សូមបញ្ចូលតំលៃលេខរវាង{0} និង{1}",
            max:icon +                  		"សូមបញ្ចូលតំលៃធំមួយស្មើ {0} ",
            min:icon +                  		"សូមបញ្ចូលតំលៃតូចមួយស្មើ {0} ",
            equalTo:icon +              		"សូមបញ្ចូលតំលៃប្រហាក់ប្រហែលម្តងទៀត",
            alnum: icon +               		"លេខសំងាត់មិនមានកំរិតខ្លាំង គួរតែបញ្ចូលតួអក្សរធំតូចជាមួយតួលេខ",
            alnumNqoRequest: icon +     		"លេខសំងាត់មិនមានកំរិតខ្លាំង គួរតែបញ្ចូលតួអក្សរធំតូចជាមួយតួលេខ",
            imglen: icon +              		"សូមបង្ហោះឡើងរូបថតយ៉ាងតិចមួយសន្លឹក",
            contact: icon +             		"ត្រូវតែបំពេញរូបតំណាង",
            integer: icon +             		"សូមបញ្ចូលចំនួនលេខគត់"
        }
    };

    var lang = getCookie('language');
    // 默认英文
    if (lang === "") {
        lang = 'zh-cn';
    }
    var messages = local_messages[lang];
    $.validator.messages = messages;
    $.validator.addMethod("alnum", function (value, element) {
        var lv = 0;
        if (value.match(/[A-Z]/g)) {
            lv++;
        }
        if (value.match(/[a-z]/g)) {
            lv++;
        }
        if (value.match(/[0-9]/g)) {
            lv++;
        }
        //if (value.match(/(.[^a-z0-9])/g)) {
        //lv++;
        //}
        if (lv < 3) {
            return false;
        } else {
            return true;
        }
    }, messages['alnum']);

    $.validator.addMethod("alnumNqoRequest", function (value, element) {
        var lv = 0;
        if (value.match(/[A-Z]/g)) {
            lv++;
        }
        if (value.match(/[a-z]/g)) {
            lv++;
        }
        if (value.match(/[0-9]/g)) {
            lv++;
        }
        //if (value.match(/(.[^a-z0-9])/g)) {
        //lv++;
        //}
        if(value.length>0){
            if (lv < 3) {
                return false;
            } else {
                return true;
            }
        }else{
            return true;
        }

    }, messages['alnumNqoRequest']);
    $.validator.addMethod("imglen", function (value, element) {
        var len = 0;
        len = $(element).parents(".add-img-wrap").siblings(".pro-wrap").find("img").length;
        console.log(len)
        if(len != 0){
            return true;
        }else{
            return false;
        }
    }, messages['imglen']);
    $.validator.addMethod("fileLen", function (value, element) {
        var len = 0;
        len = $(element).siblings(".uploader-list").find(".item").length;
        if(len != 0){
            return true;
        }else{
            return false;
        }
    }, messages['imglen']);

    $.validator.addMethod("contact", function (value, element) {
        var len = 0;
        $(".add-contact-wrap").find("input").each(function(){
            len += $(this).val().length;
        })
        if(len != 0){
            $(".add-contact-wrap").find("span.help-block").remove();
            return true;

        }else{
            $(".contact-wrap").find("span.help-block").remove();
            return false;
        }
    }, messages['contact']);
    $.validator.addMethod("integer", function (value, element) {
        var reg = /^[1-9]\d*$/;
        console.log(value)
        if(reg.test(value)){
            return true;
        }else{
            return false;
        }
    }, messages['integer']);


});
$.validator.setDefaults({
    highlight: function(e) {
        $(e).closest(".form-group").removeClass("has-success").addClass("has-error");
        //$(e).siblings(".help-block.m-b-none").hide();
    },

    success: function(e) {
        e.closest(".form-group").removeClass("has-error").addClass("has-success");
        $(e).siblings("span").remove();
    },
    errorElement: "span",
    errorPlacement: function(e, r) {
        e.appendTo(r.is(":radio") || r.is(":checkbox") ? r.parent().parent().parent() : r.parent());
        if($(e).parent("div").hasClass("input-group")){
            e.appendTo(r.parent().parent());
        }

    },
    errorClass: "help-block",
    validClass: "help-block"
}),

    $().ready(function() {
        $("#validateForm").validate();
        var e = "<i class='fa fa-times-circle'></i> ";
        $("#userValidateForm").validate({
            rules: {
                username:{
                    required: !0,
                    minlength: 2
                },
                password:{
                    minlength:6,
                    alnum:true
                }

            }
        })
    });

