var qs = (function(a) {
    if (a == '') return {};
    var b = {};
    for (var i = 0; i < a.length; ++i)
    {
        var p=a[i].split('=');
        if (p.length != 2) continue;
        b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, ' '));
    }
    return b;
})(window.location.search.substr(1).split('&'));

function pageFormSubmit() {
    qs['page_no'] = $('.page_no').val();
    qs['page_size'] = $('.page_size').val();
    location.href = '?'+$.param(qs);
}

$("body").on("click", ".parent", function () {
    if (this.checked) {
        $(this).parents(".table").find(".child").each(function (i) {
            $(this).prop("checked",true);
        });

        $(this).parents(".widget-box").find(".child").each(function (i) {
            $(this).prop("checked",true);
        });
    } else {
        $(this).parents("table").find(".child").each(function (i) {
            $(this).prop("checked",false);
        });
        $(this).parents(".widget-box").find(".child").each(function (i) {
            $(this).prop("checked",false);
        });
    }
})
function selectFn(){ //select2多选

    $("body").find("select[data-plugin=select2]").each(function(index){
        var url = $(this).data("url");
        var len = $(this).data("minimum-input-length");
        if(len==undefined && url){
            len=1;
        }else{
            len = 0;
        }
        var _this = $(this);
        if($(this).data("url")){               //判断是不是ajax
            $(this).select2({
                ajax: {
                    url:url,
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            q: params.term,
                        };
                    },
                    processResults: function (data,params) {
                        return {
                            results: data.results,//itemList
                        };
                    },
                    results: function (data, page) { return data; },
                    cache: true
                },
                minimumInputLength:len,
                placeholder: "select a option"
            })
        }else{
            $(this).select2({
                minimumInputLength:len,
                placeholder: "select a option"
            });
        }
    })
    //验证
    $("select[data-plugin=select2]").change(function(){
        console.log($(this).val())
        var obj = $(this).val();
        var re = $(this).attr("required");//获取是否要验证
        if(re){
            if(obj!=null){
                if(obj.length>0){
                    $(this).parents(".form-group").removeClass("has-error").find("span.help-block").remove();
                }
            }else{
                $(this).parents(".form-group").removeClass("has-error").find("span.help-block").remove();
                $(this).parents(".form-group").addClass("has-error").children("div").append('<span  class="help-block m-b-none"><i class="fa fa-times-circle"></i>  必填字段</span>');
            }
        }
    })
    //select2 选择排序问题
    $(".select2").on("select2:select",function(evt){
        var element=evt.params.data.element;
        var $element=$(element);
        $element.detach();
        $(this).append($element);
        $(this).trigger("change");
    });
}
function tokenFn(){
    $('input[data-plugin=tokenfield]').each(function(){
        var option = $(this).attr("data-max-option");
        var tokenArr=[];
        var str=$(this).val();
        var result=str.split(",");
        var re = $(this).attr("required");
        if(str!=""){
            for(var i=0;i<result.length;i++){
                tokenArr.push(result[i])
            }
        }
        if(option){
            $(this).parents(".form-group").addClass("option-wrap");
        }
        $(this).tokenfield()
            .on('tokenfield:createdtoken', function (e) {
                var val = e.attrs.value;
                tokenArr.push(val);
                $(this).parents(".tokenfield ").siblings("input[type=hidden]").val(tokenArr)
                if(re){
                    if(tokenArr.length>0){
                        $(this).parents(".form-group").removeClass("has-error").find("span.help-block").remove();
                    }else{
                        $(this).parents(".form-group").removeClass("has-error").find("span.help-block").remove();
                        $(this).parents(".form-group").addClass("has-error").children("div").append('<span  class="help-block m-b-none"><i class="fa fa-times-circle"></i>  必填字段</span>')
                    }
                }
                console.log($(this).parents(".tokenfield ").siblings("input[type=hidden]").val())
            })
            .on('tokenfield:removedtoken', function (e) {
                var val = e.attrs.value;
                var ind = tokenArr.indexOf(val);
                tokenArr.splice(ind,1);
                $(this).parents(".tokenfield ").siblings("input[type=hidden]").val(tokenArr);

                if(re){
                    if(tokenArr.length>0){
                        $(this).parents(".form-group").removeClass("has-error").find("span.help-block").remove();
                    }else{
                        $(this).parents(".form-group").removeClass("has-error").find("span.help-block").remove();
                        $(this).parents(".form-group").addClass("has-error").children("div").append('<span  class="help-block m-b-none"><i class="fa fa-times-circle"></i>  必填字段</span>')
                    }
                }
                console.log($(this).parents(".tokenfield ").siblings("input[type=hidden]").val())
            });
    })
}
var plt = {
    confirmAction:function(e){
        var title = e.target.getAttribute('data-title'),
            content =e.target.getAttribute('data-content'),
            href =e.target.getAttribute('data-href');
        content = content ? content : "确认进行该操作吗？";
        parent.layer.confirm(content,{icon: 3, title:title},
            function(index){
                window.location.href=href;
                parent.layer.close(index);
            },function(index){

            });
    },
    subform:function(e,cl){
        var title = e.target.getAttribute('data-title'),
            href =e.target.getAttribute('data-href'),
            content = content ? content : "确认进行该操作吗？";

        $("[data-href='"+href+"']").parents("form").attr("action",href);
        var valArr = new Array;
        var k=0;
        $("."+cl).each(function(i){
            if(this.checked)
            {
                valArr[k] = $(this).val();
                k++;
            }
        });
        if(cl==undefined || valArr.length>0){
            parent.layer.confirm(content,{icon: 3, title:title},
                function(index){
                    $("[data-href='"+href+"']").parents("form").submit();
                    parent.layer.close(index);
                },function(index){

                });
        }else{
            parent.layer.alert(content,{ shadeClose: true});
            return;
        }
    },
    //弹出用户基本信息
    openIframe: function (e) {
        var title = e.target.getAttribute('data-title'),
            href =e.target.getAttribute('data-href');
        parent. layer.open({
            type: 2,
            title: decodeURI(title) + title,
            shade: 0.3,
            maxmin: true,
            shadeClose: true,
            area: ['600px', '500px'],
            content: href
        });

    },
    getDateEndMonth:function(id){//日期控件，截至月份
        //日期控件
        $("#"+id).datetimepicker({
            format: 'yyyy-mm',
            language: 'zh-CN',
            pickDate: true,
            pickTime: false,
            minView: 'year',
            startView:3,
            autoclose: true
        });
        function getNowDate(id){ //默认获取当前日期
            var today = new Date();
            var nowdate = (today.getFullYear()) + "-" + (today.getMonth() + 1) + "-" + today.getDate();
            //对日期格式进行处理
            var date = new Date(nowdate);
            var mon = date.getMonth() + 1;
            var mydate = date.getFullYear() + "-" + (mon < 10 ? "0" + mon : mon);
            $("#"+id).attr("placeholder",mydate)
        }
    }
}

function subform(url){
    $("#myform").attr('action', url);
    $("#myform").submit();
}

$(function(){
    $(document).on("click",function(e){
        if(parent.closeDrop){
            parent.closeDrop(e);
        }
    });

    //权限管理
    function purviewFn(){
        if("undefined" != typeof MenuData){
            function getData(index){  //分步循环
                if(MenuData[index].children){
                    $("#side-menu").empty();
                    var sideStr = "";
                    var arr = MenuData[index].children;
                    function render(arr,level){
                        var level=level||0;
                        level++;
                        var i= 0,len=arr.length;
                        if(level==1){
                            var str='<ul class="checkbox-wrap checkbox-item">'
                        }else{
                            str='<ul class="item-second-level col-sm-10">'
                        }
                        for(;i<len;i++){
                            if(arr[i].children&&arr[i].children.length>0){
                                str+='<li class="nav'+arr[i].id+' block"><label class="has-child pull-left m-r-sm a"  data-index="'+arr[i].id+'"><input type="checkbox" name="" class="checkall" /> '+arr[i].name+'</label>' ;
                                str+=render(arr[i].children,level);
                            }else{
                                str+='<li class="nav'+arr[i].id+' pull-left"><label class="m-r" data-index="'+arr[i].id+'"><input type="checkbox" name="purviews[]" value="'+arr[i].ct+'-'+arr[i].ac+'" /> '+arr[i].name+'</label>' ;
                            }
                            str+='</li>';
                        }
                        if(level==1){
                            str+='</ul>';
                        }else{
                            str+='</ul><div class="hr-line-dashed"></div>';
                        }

                        return str;
                    }
                    $("body").find(".form-group-item").eq(index).children(".col-sm-10").html(render(arr))
                }else{
                    return false
                }
            }

            var str = "";
            for(var i = 0;i<MenuData.length;i++){
                str+='<div class="form-group form-group-item" data-id="'+MenuData[i].id+'"><label class="col-sm-2 control-label"><input type="checkbox" name="" class="checkall" style="margin-right:5px"/>'+MenuData[i].name+':</label><div class="col-sm-10"></div></div>'
            }
            $("#checkbox-group").html(str);

            $("body").find(".form-group-item").each(function(i) {
                getData(i)
            })
            $("body").on("click",".checkall",function() {
                if (this.checked) {
                    $(this).parent().siblings().find("input").each(function (i) {
                        $(this).prop("checked",true);
                    });
                }else{
                    $(this).parent().siblings().find("input").each(function (i) {
                        $(this).prop("checked",false);
                    });

                }
            });
            if("undefined" != typeof MenuDataCheck){
                var checkArr = MenuDataCheck.split(",");
                $("#checkbox-group").find("input").each(function() {
                    var val = $(this).val();
                    if(checkArr.indexOf(val)!=-1){
                        $(this).prop("checked",true);
                    }
                })
            }
        }



    }
    selectFn();  //多选调用
    tokenFn();

    purviewFn();  //权限管理调用



})

