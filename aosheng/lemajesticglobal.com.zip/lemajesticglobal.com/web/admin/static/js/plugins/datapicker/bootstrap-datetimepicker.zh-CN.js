/**
 * Simplified Chinese translation for bootstrap-datetimepicker
 * Yuan Cheung <advanimal@gmail.com>
 */
;(function($){
    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for(var i=0; i<ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1);
            if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
        }
        return "";
    }

    if(getCookie("language")=="zh-cn"){
        $.fn.datetimepicker.dates['zh-CN'] = {
            days: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"],
            daysShort: ["周日", "周一", "周二", "周三", "周四", "周五", "周六", "周日"],
            daysMin:  ["日", "一", "二", "三", "四", "五", "六", "日"],
            months: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
            monthsShort: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
            today: "今天",
            suffix: [],
            meridiem: ["上午", "下午"]
        };
    }

    if(getCookie("language")=="en"){
        $.fn.datetimepicker.dates['zh-CN'] = {
            days:           ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            daysShort:      ["Sun.", "Mon.", "Tue.", "Wed.", "Thur.", "Fr.", "Sat.", "Sun."],
            daysMin:        ["Sun.", "Mon.", "Tue.", "Wed.", "Thur.", "Fri.", "Sat.", "Fri."],
            months:         ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            monthsShort:    ["Jan.", "Feb.", "Mar.", "Apr.", "May.", "June.", "July.", "Aug.", "Sep.", "Oct.", "Nov.", "Dec."],
            today:          "Today",
            suffix:         [],
            meridiem:       ["Morning", "Afternoon"]
        };
    }

    if(getCookie("language")=="km"){
        $.fn.datetimepicker.dates['zh-CN'] = {
            days:        ["អាទិត្យ", "ច័ន្ទ", "អង្គារ", "ពុធ", "ព្រហស្បត៍", "សុក្រ", "សៅរ៍", "អាទិត្យ"],
            daysShort:   ["អាទិត្យ", "ច័ន្ទ", "អង្គារ", "ពុធ", "ព្រហស្បត៍", "សុក្រ", "សៅរ៍", "អាទិត្យ"],
            daysMin:     ["អាទិត្យ", "ច័ន្ទ", "អង្គារ", "ពុធ", "ព្រហស្បត៍", "សុក្រ", "សៅរ៍", "អាទិត្យ"],
            months:      ["មករា", "កុម្ភៈ", "មិនា", "មេសា", "ឧសភា", "មិថុនា", "កក្កដា", "សីហា", "កញ្ញា", "តុលា", "វិច្ឆិកា", "ធ្នូ"],
            monthsShort: ["មករា", "កុម្ភៈ", "មិនា", "មេសា", "ឧសភា", "មិថុនា", "កក្កដា", "សីហា", "កញ្ញា", "តុលា", "វិច្ឆិកា", "ធ្នូ"],
            today:        "ថ្ងៃនេះ",
            suffix:      [],
            meridiem:    ["ពេលព្រឹក ", "ពេលថ្ងៃ"],
        };
    }
}(jQuery));
