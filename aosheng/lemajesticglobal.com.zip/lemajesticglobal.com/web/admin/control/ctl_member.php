<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 会员管理
 *
 * @version $Id$
 */
class ctl_member
{
	/**
	 * 构造函数
	 * @return void
	 */
	public function __construct()
	{
	}

	public function index()
	{
		$keyword = req::item('keyword', '');

		$where = array();
		if (!empty($keyword))
		{
			$where[] = array( 'name', 'like', "%$keyword%" );
		}

		//pub_benchmark::mark("操作数据库");

		$row = db::select('count(*) AS `count`')
			->from('#PB#_member')
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], 10);

		$list = db::select('id, name, age, email, address, create_user, create_time')
			->from('#PB#_member')
			->where($where)
			->order_by('id', 'desc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		//echo pub_benchmark::elapsed_time("操作数据库");

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('member.index.tpl');
	}

	public function add()
	{
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$row = db::select('count(*) AS `count`')
				->from('#PB#_member')
				->where('name', $name)
				->as_row()
				->execute();
			if( $row['count'] )
			{
				cls_msgbox::show('系统提示', '标题已经存在！', '-1');
				exit();
			}

			list($insert_id, $rows_affected) = db::insert('#PB#_member')->set(array(
																				  'name'        => $name,
																				  'age'         => req::item('age'),
																				  'email'       => req::item('email'),
																				  'address'     => req::item('address'),
																				  'create_user' => cls_auth::$user->fields['uid'],
																				  'create_time' => time(),
																			  ))
				->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "会员添加 {$insert_id}");

			$gourl = req::item('gourl', '?ct=member&ac=index');
			cls_msgbox::show('系统提示', '添加成功', $gourl);
		}
		else
		{
			$gourl = '?ct=member&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::display('member.add.tpl');
		}
	}

	public function edit()
	{
		$id = req::item("id", 0);
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$row = db::select('count(*) AS `count`')->from('#PB#_member')
				->where('name', $name)
				->where('id', '!=', $id)
				->as_row()
				->execute();
			if( $row['count'] )
			{
				cls_msgbox::show('系统提示', '标题已经存在！', '-1');
				exit();
			}

			db::update('#PB#_member')->set(array(
											   'name'        => $name,
											   'age'         => req::item('age'),
											   'email'       => req::item('email'),
											   'address'     => req::item('address'),
											   'update_user' => cls_auth::$user->fields['uid'],
											   'update_time' => time(),
										   ))
				->where('id', $id)
				->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "会员修改 {$id}");

			$gourl = req::item('gourl', '?ct=member&ac=index');
			cls_msgbox::show('系统提示', '修改成功', $gourl);
		}
		else
		{
			$v = db::select('name, age, email, address')
				->from('#PB#_member')
				->where('id', $id)
				->as_row()->execute();
			$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=member&ac=index' : $_SERVER['HTTP_REFERER'];
			tpl::assign('gourl', $gourl);
			tpl::assign('v', $v);
			tpl::display('member.edit.tpl');
		}
	}

	public function del()
	{
		$ids = req::item('ids', array());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "删除失败，请选择要删除的会员", $gourl);
		}

		db::delete('#PB#_member')->where('id', 'in', $ids)->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "会员删除 ".implode(",", $ids));

		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=member&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show('系统提示', '删除成功', $gourl);
	}

}
