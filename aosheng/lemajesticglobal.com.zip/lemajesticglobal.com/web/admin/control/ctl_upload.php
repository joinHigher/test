<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 后台管理控制器
 *
 * @version $Id$
 */
class ctl_upload
{
    public function image()
    {
        $form_filename = req::item("form_filename");
        // jpg,gif,png,bmp
        $ext = req::get_shortname($form_filename);
        if( in_array(strtolower($ext), array('jpg','png','gif','bmp')) )
        {
            $filename = uniqid() . '.' . $ext;
            $filepath = PATH_ROOT.'/uploads/tmp/';
            util::path_exists($filepath);
            if ( req::move_upload_file($form_filename, $filepath.$filename) )
            {
                // 如果宽度大于600，就进行裁剪
                $pathinfo = getimagesize($filepath.$filename);
                $width = $pathinfo[0];
                $height = $pathinfo[1];

                // 裁剪宽度超过175px的图片
                if ($width > 175) 
                {
                    $img = new cls_image($filepath.$filename);
                    $h = intval($height/$width*175);
                    $img->thumb(175, $h, $filepath.$filename); 
                    //$img->thumb(175, 98, $filepath.$filename); 
                }

            }
            exit( json_encode(array('error'=>0, 'tmpurl'=>URL_UPLOADS.'/tmp/', 'filename'=>$filename)) );
        }
        else
        {
            exit( json_encode(array('error'=>-1, 'tips'=>'请上传正确的图片格式(jpg,gif,png,bmp)')) );
        }
    }

    /**
     * html5拖动上传 
     * 
     * @access public
     * @return void
     */
    public function html5_drop_upload()
    {
        $allowed_ext = array('jpg','jpeg','png','gif');

        if(strtolower($_SERVER['REQUEST_METHOD']) != 'post')
        {
            exit(json_encode(array('status'=>'错误! 错误的 HTTP 方法!')));
        }

        $paramkey = req::$posts['paramkey'];
        //if(array_key_exists('pic', req::$files) && req::$files['pic']['error'] == 0 )
        if(array_key_exists($paramkey, req::$files) && req::$files[$paramkey]['error'] == 0 )
        {
            $pic = req::$files[$paramkey];
            $ext = req::get_shortname($pic['name']);

            if(!in_array($ext, $allowed_ext))
            {
                exit(json_encode(array('status'=>'只能上传 '.implode(',',$allowed_ext).' 图片!')));
            }	
            $filepath = PATH_ROOT.'/uploads/tmp/';
            $filename = uniqid().'.'.$ext;
            if( move_uploaded_file($pic['tmp_name'], $filepath.$filename) )
            {
                $img = new cls_image($filepath.$filename);
                $img->thumb(175, 98, $filepath.$filename); 
                @chmod($filepath.$filename, 0777);
                exit(json_encode(array('code'=>0, 'msg'=>'文件上传成功!', 'filename'=>$filename, 'paramkey'=>$paramkey)));
            }
        }
    }

    /**
     * redactor在线编辑器上传接口 
     * 
     * @access public
     * @return void
     */
    public function redactor()
    {
        $type = req::item('type', 'image');
        // 文件管理器
        if ( $type == 'file_manager_json' ) 
        {
            $filepath = PATH_ROOT . "/uploads/image/";
            $images = array();
            // scandir 函数经常被禁用，用这个替代
            //$files = glob($filepath."*.png");
            $files = glob($filepath."*.*");
            foreach ($files as $k=>$file) 
            {
                $nowtime = time();
                $fileatime = filemtime($file);
                // 只显示一天内的图片，不然图片太多了，受不了
                if ( ($nowtime - $fileatime) > 86400 ) 
                {
                    continue;
                }
                $pathinfo = pathinfo($filepath.$file);
                $filename = $pathinfo['basename'];
                $images[] = array(
                    'thumb' => file_exists(PATH_ROOT.'/uploads/thumb/'.$filename) ? URL.'/uploads/thumb/'.$filename : URL.'/uploads/image/'.$filename,
                    'image' => URL.'/uploads/image/'.$filename,
                    'title' => $filename,
                    //'folder' => $folder,
                );
            }
            header('Content-type: text/html; charset=UTF-8');
            exit(json_encode($images));
        }

        if ( $type == 'image' || $type == 'clipboard' || $type == 'html5' ) 
        {
            $filepath = PATH_ROOT.'/uploads/image/';
        }
        else 
        {
            $filepath = PATH_ROOT.'/uploads/file/';
        }

        // 选择和拖动上传
        if ( $type == 'image' || $type == 'file' ) 
        {
            $ext = req::get_shortname('file');
            $filename = uniqid().'.'.$ext;
            if ( req::move_upload_file('file', $filepath.$filename) ) 
            {
                @chmod($filepath.$filename, 0777);
            }
        }
        // 剪贴板复制黏贴上传图片
        elseif ($type == 'clipboard') 
        {
            //没啥用，无论是png、gif还是jpg，都被redactor处理成 image/png
            //$contentType = req::$posts['contentType'];    
            $filename = uniqid().'.png';
            $data = base64_decode(req::$posts['data']);
            if (@file_put_contents($filepath.$filename, $data))
            {
                @chmod($filepath.$filename, 0777);
            }
        }                
        elseif ($type == 'html5') 
        {
            $base64_image_content = req::$posts['data'];
            // 匹配出图片的格式
            if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64_image_content, $result))
            {
                $ext = $result[2];
                $ext = $ext == 'jpeg' ? 'jpg' : $ext;
                $filename = uniqid().".{$ext}";
                // 把 data:image/jpeg;base64, 去掉
                $image_content = base64_decode(str_replace($result[1], '', $base64_image_content));
                if (@file_put_contents($filepath.$filename, $image_content))
                {
                    @chmod($filepath.$filename, 0777);
                }
            }
        }  

        // 如果上传的是图片
        if ( $type == 'image' || $type == 'clipboard' || $type == 'html5' ) 
        {
            // 如果宽度大于600，就进行裁剪
            $pathinfo = getimagesize($filepath.$filename);
            $width = $pathinfo[0];
            $height = $pathinfo[1];
            // 生成缩略图
            $filepath_m = PATH_ROOT.'/uploads/thumb/';
            $h = intval($height/$width*100);
            $img = new cls_image($filepath.$filename);
            $img->thumb(100, $h, $filepath_m.$filename); 
            @chmod($filepath_m.$filename, 0777);

            // 裁剪宽度超过600px的图片
            if ($width > 600) 
            {
                $h = intval($height/$width*600);
                $img->thumb(600, $h, $filepath.$filename); 
            }
            header('Content-type: application/json'); 
            exit( json_encode(array('filelink' => URL.'/uploads/image/'.$filename, 'filename'=>$filename)) );
        }
        // 如果上传的是文件
        else 
        {
            header('Content-type: application/json'); 
            exit( json_encode(array('filelink' => URL.'/uploads/file/'.$filename, 'filename'=>$filename)) );
        }
    }

    public function webuploader()
    {
        pub_webuploader::upload();
    }

    public function webuploader_no_chunk()
    {
        pub_webuploader::upload_no_chunk();
    }
    
    /**
     * uploadify 插件上传
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2015-12-27 16:01
     */
    public function uploadify()
    {
        $randname   = req::item("randname");             // 是否随机命名
        $tmp_path   = req::item("tmp_path", 'tmp');      // 文件上传临时目录
        $limit_type = req::item("limit_type");           // 文件上传限制类型
        $filepath   = PATH_ROOT . "/uploads/{$tmp_path}/"; // 文件绝对路径
        util::path_exists($filepath);                    // 目录不存在则生成

        //只允许上传文件类型
        if($limit_type)
        {
            $limit_type_arr = explode(',',$limit_type);
            $form_filename  = req::item("Filedata");
            $file_suffix    = req::get_shortname($form_filename);
            if( preg_match("/\./", req::item("Filename")) )
            {
                $fs = explode('.', req::item("Filename"));
                $shortname = strtolower($fs[ count($fs)-1 ]);
                if(empty($file_suffix))
                {
                    $file_suffix = $shortname;
                }
            }
            if(!in_array(strtolower($file_suffix), $limit_type_arr))
            {
                header('Content-type: application/json; charset=UTF-8');
                exit(json_encode(array('code'=>-1, 'msg'=>'只能上传的文件格式为：'.$limit_type)));
            }
        }
        $verify_token = md5('unique_salt' . req::item('timestamp'));

        if (req::is_upload_file('Filedata') && req::item('token') == $verify_token) 
        {
            $filename = req::item("Filename");
            // 是否随机生成名称
            if ($randname) 
            {
                $ext = req::get_shortname('Filedata');
                $filename = uniqid() . "." . $ext;
            }

            if (!req::move_upload_file('Filedata', $filepath.$filename))
            {
                header('Content-type: application/json; charset=UTF-8');
                exit(json_encode(array('code'=>-1, 'msg'=>'Invalid file type.')));
            }
            else 
            {
                chmod($filepath.$filename, 0777);
                header('Content-type: application/json; charset=UTF-8');
                exit(json_encode(array('code'=>0, 'msg'=>'successful', 'filename'=>$filename)));
            }
        }
    }

    /**
     * kindeditor编辑器上传(批量上传也是调用的这个) 
     * 
     * @access public
     * @return void
     */
    public function upload_json()
    {
        $type = req::item("type", "image");
        $filepath = PATH_ROOT . '/uploads/' . $type . "/";
        $fileurl = URL.'/uploads/' . $type . "/";
        //定义允许上传的文件扩展名
        $ext_arr = array(
            'image' => array('gif', 'jpg', 'jpeg', 'png', 'bmp'),
            'flash' => array('swf', 'flv'),
            'media' => array('swf', 'flv', 'mp3', 'wav', 'wma', 'wmv', 'mid', 'avi', 'mpg', 'asf', 'rm', 'rmvb'),
            'file' => array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'htm', 'html', 'txt', 'zip', 'rar', 'gz', 'bz2'),
        );

        util::path_exists($filepath);
        //最大文件大小
        //$max_size = 2097152; //2M

        if (req::is_upload_file('imgFile')) 
        {
            $ext = req::get_shortname('imgFile');
            $filename = uniqid() . "." . $ext;
            if (!req::move_upload_file('imgFile', $filepath.$filename))
            {
                $this->alert("上传失败。");
            }
            // 如果宽度大于600，就进行裁剪
            $pathinfo = getimagesize($filepath.$filename);
            $width = $pathinfo[0];
            $height = $pathinfo[1];
            if ($width > 600) 
            {
                $h = intval($height/$width*600);
                $img = new cls_image($filepath.$filename);
                $img->thumb(600, $h, $filepath.$filename); 
            }
        }

        $file_url = $fileurl . $filename;
        header('Content-type: text/html; charset=UTF-8');
        exit(json_encode(array('error' => 0, 'url' => $file_url)));

    }
    
    public function file_delete()
    {
        header('Content-type: application/json; charset=UTF-8');

        $tmp_path = req::item("tmp_path");
        $filename = req::item("filename");
        if (empty($filename)) 
        {
            exit(json_encode(array('code'=>-1, 'msg'=>'Failed')));
        }

        $filepath = PATH_ROOT . "/uploads/{$tmp_path}/{$filename}";
        if (!file_exists(($filepath)))
        {
            exit(json_encode(array('code'=>-1, 'msg'=>'File does not exist.')));
        }

        if (!@unlink(($filepath)))
        {
            exit(json_encode(array('code'=>-1, 'msg'=>'Access is not allowed.')));
        }

        exit(json_encode(array('code'=>0, 'msg'=>'Successful')));
    }

    /**
     * kindeditor编辑器文件管理 
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2017-09-16 17:27
     */
    public function file_manager_json()
    {
        //根目录路径，可以指定绝对路径，比如 /var/www/attached/
        $root_path = PATH_ROOT . '/uploads/';
        //根目录URL，可以指定绝对路径，比如 http://www.yoursite.com/attached/
        $root_url = URL.'/uploads/';
        //图片扩展名
        $ext_arr = array('gif', 'jpg', 'jpeg', 'png', 'bmp');

        //目录名
        $dir_name = req::item("dir");
        if (!in_array($dir_name, array('', 'image', 'flash', 'media', 'file'))) {
            echo "Invalid Directory name.";
            exit;
        }
        if ($dir_name !== '') {
            $root_path .= $dir_name . "/";
            $root_url .= $dir_name . "/";
            if (!file_exists($root_path)) {
                mkdir($root_path);
            }
        }

        //根据path参数，设置各路径和URL
        $path = req::item("path");
        if (empty($path)) {
            $current_path = realpath($root_path) . '/';
            $current_url = $root_url;
            $current_dir_path = '';
            $moveup_dir_path = '';
        } else {
            $current_path = realpath($root_path) . '/' . $path;
            $current_url = $root_url . $path;
            $current_dir_path = $path;
            $moveup_dir_path = preg_replace('/(.*?)[^\/]+\/$/', '$1', $current_dir_path);
        }
        echo realpath($root_path);
        //排序形式，name or size or type
        $order = strtolower(req::item("order", "name"));

        //不允许使用..移动到上一级目录
        if (preg_match('/\.\./', $current_path)) {
            echo 'Access is not allowed.';
            exit;
        }
        //最后一个字符不是/
        if (!preg_match('/\/$/', $current_path)) {
            echo 'Parameter is not valid.';
            exit;
        }
        //目录不存在或不是目录
        if (!file_exists($current_path) || !is_dir($current_path)) {
            echo 'Directory does not exist.';
            exit;
        }

        //遍历目录取得文件信息
        $file_list = array();
        if ($handle = opendir($current_path)) {
            $i = 0;
            while (false !== ($filename = readdir($handle))) {
                if ($filename{0} == '.') continue;
                $file = $current_path . $filename;
                if (is_dir($file)) {
                    $file_list[$i]['is_dir'] = true; //是否文件夹
                    $file_list[$i]['has_file'] = (count($this->scandir($file)) > 2); //文件夹是否包含文件
                    $file_list[$i]['filesize'] = 0; //文件大小
                    $file_list[$i]['is_photo'] = false; //是否图片
                    $file_list[$i]['filetype'] = ''; //文件类别，用扩展名判断
                } else {
                    $file_list[$i]['is_dir'] = false;
                    $file_list[$i]['has_file'] = false;
                    $file_list[$i]['filesize'] = filesize($file);
                    $file_list[$i]['dir_path'] = '';
                    $file_ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    $file_list[$i]['is_photo'] = in_array($file_ext, $ext_arr);
                    $file_list[$i]['filetype'] = $file_ext;
                }
                $file_list[$i]['filename'] = $filename; //文件名，包含扩展名
                $file_list[$i]['datetime'] = date('Y-m-d H:i:s', filemtime($file)); //文件最后修改时间
                $i++;
            }
            closedir($handle);
        }

        //排序 内部函数，只调用一次就可以，如果循环调用就会造成循环定义了，就会报错
        function cmp_func($a, $b) {
            global $order;
            if ($a['is_dir'] && !$b['is_dir']) {
                return -1;
            } else if (!$a['is_dir'] && $b['is_dir']) {
                return 1;
            } else {
                if ($order == 'size') {
                    if ($a['filesize'] > $b['filesize']) {
                        return 1;
                    } else if ($a['filesize'] < $b['filesize']) {
                        return -1;
                    } else {
                        return 0;
                    }
                } else if ($order == 'type') {
                    return strcmp($a['filetype'], $b['filetype']);
                } else {
                    return strcmp($a['filename'], $b['filename']);
                }
            }
        }
        usort($file_list, 'cmp_func');

        $result = array();
        //相对于根目录的上一级目录
        $result['moveup_dir_path'] = $moveup_dir_path;
        //相对于根目录的当前目录
        $result['current_dir_path'] = $current_dir_path;
        //当前目录的URL
        $result['current_url'] = $current_url;
        //文件数
        $result['total_count'] = count($file_list);
        //文件列表数组
        $result['file_list'] = $file_list;

        //输出JSON字符串
        header('Content-type: application/json; charset=UTF-8');
        echo json_encode($result);
    }

    /**
     * 一般情况下 scandir 都会被禁用，用以下这个代替
     * 
     * @param mixed $dir
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2017-09-16 17:27
     */
    public function scandir($dir)
    {
        $dirs = array();
        // 用 opendir() 打开目录，失败则中止程序
        $handle = @opendir($dir) or die("Cannot open" . $dir);

        // 用 readdir 读出文件列表
        while($file = readdir($handle))
        {
            if($file != "." && $file != "..") 
            {
                $dirs[] = $file;
            }
        }
        closedir($handle);
        return $dirs;
    }

    public function alert($msg) 
    {
        header('Content-type: text/html; charset=UTF-8');
        echo json_encode(array('error' => 1, 'message' => $msg));
        exit;
    }


}
