<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 商户管理
 *
 * @version $Id$
 */
class ctl_shop
{

	/**
	 * 构造函数
	 * @return void
	 */
	public function __construct()
	{
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("shop", $lang);
		lang::load("bill", $lang);
		lang::load("currency", $lang);
		lang::load("model", $lang);

		mod_shop::$status_list[0] = lang::get('model_normal');
		mod_shop::$status_list[1] = lang::get('model_disabled');

		//self::$card_type_list[1] = lang::get('model_group_registration_number');
		mod_shop::$card_type_list[2] = lang::get('model_business_license');
		mod_shop::$card_type_list[3] = lang::get('model_other');

		mod_shop::$contract_type_list[1] = lang::get('model_signed_contract');
		mod_shop::$contract_type_list[2] = lang::get('model_online_contract');
	}

	//待审核列表
	public function index()
	{
		$this->_list(1);
	}

	//已通过列表
	public function pass_list()
	{
		$this->_list(2);
	}

	//已驳回列表
	public function reject_list()
	{
		$this->_list(3);
	}

	//受理中列表
	public function accepting_list()
	{
		$this->_list(4);
	}

	//已受理列表
	public function accepted_list()
	{
		$this->_list(5);
	}

	//商户列表
	private function _list($type_list)
	{
		$keyword = req::item('keyword', '');

		$where = array();
		if (!empty($keyword))
		{
			$where[] = array ('name', 'like', '%'.$keyword.'%');
		}

		$admin_id = cls_auth::$user->fields['uid'];
		switch ($type_list)
		{
			case 1:

					$where[] = array ('audit_status', '=', 0);
				break;
			case 2:
					$where[] = array ('audit_status', '=', 1);
				break;
			case 3:
					$where[] = array ('audit_status', '=', 2);
				break;
			case 4:

					$where[] = array ('audit_status', '=', 0);
					$where[] = array ('audit_id', '=', $admin_id);
				break;
			case 5:

					$where[] = array ('audit_status', 'in', array (1,2));
					$where[] = array ('audit_id', '=', $admin_id);
				break;
		}

		$count = mod_shop::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_shop::get_list($where,'', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				//商户分类
				$cate_info = mod_shop_category::find($v['catid'], 'name');
				$list[$k]['cate_name'] = empty($cate_info) ? '' : $cate_info['name'];

				//销售中的商品
				$list[$k]['goods_sales_total'] = 0;
				$list[$k]['withdraw_money'] = '0.00';
				if ($v['audit_status'] == 1)
				{
					$goods_count_where = array ();
					$goods_count_where[] = array ('shop_id', '=', $v['id']);
					$goods_count_where[] = array ('status', '=', 1);
					$list[$k]['goods_sales_total'] = mod_goods::get_count($goods_count_where);


					//可提现额度
					$withdraw_money_where = array ();
					$withdraw_money_where[] = array ('shop_id', '=', $v['id']);
					$withdraw_money_where[] = array ('type', '=', 1);
					$withdraw_money_where[] = array ('currency_code', '=', mod_currency_type::get_default_curr());
					$withdraw_money_info = mod_shop_money_bank::get_info($withdraw_money_where, 'money');
					$list[$k]['withdraw_money'] = empty($withdraw_money_info) ? '0.00' : $withdraw_money_info['money'];
				}

				$list[$k]['end_date'] = $v['is_long_date'] == 1 ? lang::get('shop_long') : $v['end_date'];
				$list[$k]['contract_type_name'] = isset(mod_shop::$contract_type_list[$v['contract_type']]) ? mod_shop::$contract_type_list[$v['contract_type']] : '';
				$list[$k]['card_type_name'] = isset(mod_shop::$card_type_list[$v['card_type']]) ? ($v['card_type'] == 2 ? mod_shop::$card_type_list[$v['card_type']] : mod_shop::$card_type_list[$v['card_type']] . ':' . $v['card_name']) : '';
				$list[$k]['status_name'] = mod_shop::$status_list[$v['status']];
				$list[$k]['gutee_money'] = mod_member_info::num_format($v['gutee_money']);
				$list[$k]['apply_date'] = date('Y-m-d Y:i:s', $v['addtime']);
				$list[$k]['interf_all_count'] = mod_shop_interfaces::get_count(array ('shop_id', '=', $v['id']));

				$interfaces_where = array ();
				$interfaces_where[] = array ('shop_id', '=', $v['id']);
				$interfaces_where[] = array ('status', '=', 0);
				$list[$k]['interf_count'] = mod_shop_interfaces::get_count($interfaces_where);
			}
		}

		tpl::assign('list', $list);
		tpl::assign('type_list', $type_list);
		tpl::assign('pages', $pages['show']);
		tpl::display('shop.index.tpl');
	}

	//添加
	public function add()
	{
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$catid = req::item('catid');
			$is_long_date = req::item('is_long_date', '0');
			$card_type = req::item('card_type','1','int');
			$bloc_id = req::item('bloc_id');
			$card_pics = req::item('card_pics');
			req::$forms['payment_days'] = $payment_days = req::item('payment_days', '45', 'int');
			req::$forms['gutee_money'] = $gutee_money = req::item('gutee_money', '0', 'int');
			$contract_pics = req::item('contract_pics');
			$contact_way = req::item('contact_way');
			$contact_num = req::item('contact_num');
			$email = req::item('email');
			$card_name = req::item('card_name');
			$card_num = req::item('card_num');
			$contract_type = req::item('contract_type');
			$contract_num = req::item('contract_num',req::item('online_contract_num'));
			$username = req::item('username');
			$password = req::item('password');
			$repassword = req::item('repassword');

			if(empty($username))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_account'), '-1');
			}

			if(empty($password))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_password'), '-1');
			}

			if($password != $repassword)
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_password_no_same'), '-1');
			}

			if(empty($catid))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_business_type'), '-1');
			}

			if(empty($name))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_shop_search'), '-1');
			}

			$shop_info = mod_shop::get_info(array ('name', '=', $name),'id');
			if(!empty($shop_info))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_existed'), '-1');
			}

			switch ($card_type)
			{
				case 1:
						if(empty($bloc_id))
						{
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_group_reg_number'), '-1');
						}
					break;
				case 2:
						if(empty($card_pics))
						{
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_id_photo_empty'), '-1');
						}

						//移动图片
						$this->_move_file($card_pics);
					break;
				case 3:
					if(empty($card_name))
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_id_name'), '-1');
					}
					if(empty($card_num))
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_id_number'), '-1');
					}
					break;
			}

			if(empty($contact_way) || count($contact_way) != count($contact_num))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_contact_way'), '-1');
			}
			else
			{
				foreach ($contact_way as $wk => $wv)
				{
					$contact_way_list[$wk]['key'] = $wv;
					$contact_way_list[$wk]['val'] = $contact_num[$wk];
				}

				req::$forms['contact_ways'] = json_encode($contact_way_list,JSON_UNESCAPED_UNICODE);
			}

			//合同编号不能为空
			if(empty($contract_num))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_contract_number'), '-1');
			}

			//如果是已签合同，需要上传图片
			if($contract_type == 1)
			{
				//合同照片不能为空
				if(empty($contract_pics))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_contract_photos_empty'), '-1');
				}

				//移动图片
				$this->_move_file($contract_pics);

				req::$forms['contract_pics'] = empty($contract_pics) ? '' : implode(',', $contract_pics);
			}

			req::$forms['contract_num'] = $contract_num;
			req::$forms['card_pics'] = empty($card_pics) ? '' : implode(',', $card_pics);

			//如果选择长期把有效日期设置成空
			if(!empty($is_long_date))
			{
				req::$forms['end_date'] = '';
			}
			else
			{
				$end_date_time = strtotime(req::$forms['end_date']);
				$now_time = time();
				if($end_date_time < $now_time)
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_earlier_current_time'), '-1');
				}
			}

			if(empty($gutee_money))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_security_deposit'), '-1');
			}

			if(empty($email))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_email'), '-1');
			}

			//判断商户账户是否存在
			$shop_account_info = mod_shop_account::get_info(array ('username', '=', $username), 'id');
			if(!empty($shop_account_info))
			{
				cls_msgbox::show(lang::get('common_system_hint'), '该商户账号已存在', '-1');
			}

			db::begin_tran();

			//添加商户
			$shop_add_data = array ();
			$shop_add_data['name'] = req::$forms['name'];
			$shop_add_data['catid'] = req::$forms['catid'];
			$shop_add_data['end_date'] = req::$forms['end_date'];
			$shop_add_data['is_long_date'] = $is_long_date;
			$shop_add_data['card_type'] = req::$forms['card_type'];
			$shop_add_data['card_pics'] = req::$forms['card_pics'];
			$shop_add_data['card_name'] = req::$forms['card_name'];
			$shop_add_data['card_num'] = req::$forms['card_num'];
			$shop_add_data['address'] = req::$forms['address'];
			$shop_add_data['payment_days'] = req::$forms['payment_days'];
			$shop_add_data['gutee_money'] = req::$forms['gutee_money'];
			$shop_add_data['contract_type'] = req::$forms['contract_type'];
			$shop_add_data['contract_num'] = req::$forms['contract_num'];
			$shop_add_data['contract_pics'] = isset(req::$forms['contract_pics']) ? req::$forms['contract_pics'] : '';
			$shop_add_data['contact_per'] = req::$forms['contact_per'];
			$shop_add_data['contact_ways'] = req::$forms['contact_ways'];
			$shop_add_data['email'] = $email;
			$shop_add_data['status'] = 0;
			$shop_add_data['audit_status'] = 0;
			$shop_add_data['audit_id'] = 0;
			$shop_add_data['uptime'] = $shop_add_data['addtime'] = time();
			$shop_id = mod_shop::add_data($shop_add_data);

			if(empty($shop_id))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_add'), '-1');
			}

			//添加商户账户余额
			$bank_data['shop_id'] = $shop_id;
			$bank_data['currency_code'] = mod_currency_type::get_default_curr();
			$bank_data['money'] = 0;
			$band_id = mod_shop_money_bank::add_data($bank_data);

			if(empty($band_id))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_add'), '-1');
			}

			//添加商户账号
			$account_add_data['shop_id'] = $shop_id;
			$account_add_data['role_id'] = 0;
			$account_add_data['name'] = $name;
			$account_add_data['username'] = $username;
			$account_add_data['password'] = util::encrypt_password($password);
			$account_add_data['is_super'] = 1;
			$account_add_data['addtime'] = time();
			$result = mod_shop_account::add_data($account_add_data);
			if(empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_add'), '-1');
			}

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_add')." {$name}");

			db::commit();
			db::autocommit(true);

			$gourl = req::item('gourl', '?ct=shop&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_add'), $gourl);
		}
		else
		{
			$gourl = '?ct=shop&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::assign('year_last_date', mod_shop::get_year_last_date());
			tpl::assign('contact_way_list', mod_shop::$contact_way_list);
			tpl::assign('card_type_list', mod_shop::$card_type_list);
			tpl::assign('cate_options', mod_shop_category::get_options(0));
			tpl::display('shop.add.tpl');
		}
	}

	//查看详情
	public function info()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$info = mod_shop::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}
		$info['card_pics'] = empty($info['card_pics']) ? '' : explode(',',$info['card_pics']);
		$info['contract_pics'] = empty($info['contract_pics']) ? '' : explode(',',$info['contract_pics']);
		$info['contract_pics_status'] = empty($info['contract_pics']) ? 0 : 1;
		$info['contact_ways'] = isset($info['contact_ways']) ? json_decode($info['contact_ways'], true) : array();
		$info['card_type_name'] = isset(mod_shop::$card_type_list[$info['card_type']]) ? mod_shop::$card_type_list[$info['card_type']] : '';
		$info['long_date_name'] = $info['is_long_date'] == 1 ? lang::get('common_true') : lang::get('common_false');
		$info['end_date'] = $info['is_long_date'] == 1 ? lang::get('shop_long') : $info['end_date'];
		$cate_info = mod_shop_category::find($info['catid'],'name');
		$info['cate_name'] = empty($cate_info) ? '' : $cate_info['name'];
		$info['gutee_money'] = mod_member_info::num_format($info['gutee_money']);
		$info['audit_date'] = date('Y-m-d H:i:s',$info['audit_time']);
		$info['contract_type_name'] = $info['contract_type'] == 1 ? lang::get('shop_entry_contract_documents') : lang::get('shop_online_contract');

		//审核结果
		switch ($info['audit_status'])
		{
			case 0:
				$info['audit_status_name'] = '';
				break;
			case 1:
				$info['audit_status_name'] = lang::get('shop_already_agree');
				break;
			case 2:
				$info['audit_status_name'] = lang::get('shop_already_dismiss');
				break;
		}

		if($info['audit_status'] != 0)
		{
			//审核人员
			$audit_info = mod_admin::find($info['audit_id'], 'realname');
			$info['audit_name'] = empty($audit_info) ? '' : $audit_info['realname'];
		}

		//获取返回URL
		$this->_get_gourl();

		tpl::assign('id', $id);
		tpl::assign('admin_id', cls_auth::$user->fields['uid']);
		tpl::assign('info', $info);
		tpl::assign('contact_way_list', mod_shop::$contact_way_list);
		tpl::assign('img_url', URL_UPLOADS.'/image');
		tpl::display('shop.info.tpl');
	}

	//编辑
	public function edit()
	{
		$id = req::item('id');
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$catid = req::item('catid');
			$is_long_date = req::item('is_long_date');
			$card_type = req::item('card_type','1','int');
			$bloc_id = req::item('bloc_id');
			$card_pics = req::item('card_pics');
			req::$forms['payment_days'] = $payment_days = req::item('payment_days', '45', 'int');
			req::$forms['gutee_money'] = $gutee_money = req::item('gutee_money', '0', 'int');
			$contract_pics = req::item('contract_pics');
			$contact_way = req::item('contact_way');
			$contact_num = req::item('contact_num');
			$email = req::item('email');
			$card_name = req::item('card_name');
			$card_num = req::item('card_num');
			$contract_type = req::item('contract_type');
			$online_contract_num = req::item('online_contract_num');
			$contract_num = req::item('contract_num',$online_contract_num);

			if(empty($id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
			}

			$info = mod_shop::find($id);

			if(empty($info))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
			}

			if(empty($catid))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_business_type'), '-1');
			}

			if(empty($name))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_shop_search'), '-1');
			}

			$shop_info_where = array ();
			$shop_info_where[] = array ('name', '=', $name);
			$shop_info_where[] = array ('id', '!=', $id);
			$shop_info = mod_shop::get_info($shop_info_where,'id');

			if(!empty($shop_info))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_existed'), '-1');
			}

			switch ($card_type)
			{
				case 1:
					if(empty($bloc_id))
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_group_reg_number'), '-1');
					}
					break;
				case 2:
					if(empty($card_pics))
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_id_photo_empty'), '-1');
					}

					$this->_move_file($card_pics);

					break;
				case 3:
					if(empty($card_name))
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_id_name'), '-1');
					}
					if(empty($card_num))
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_id_number'), '-1');
					}
					break;
			}

			if(empty($contact_way) || count($contact_way) != count($contact_num))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_contact_information_empty'), '-1');
			}
			else
			{
				foreach ($contact_way as $wk => $wv)
				{
					$contact_way_list[$wk]['key'] = $wv;
					$contact_way_list[$wk]['val'] = $contact_num[$wk];
				}

				req::$forms['contact_ways'] = json_encode($contact_way_list,JSON_UNESCAPED_UNICODE);
				unset(req::$forms['contact_num']);
				unset(req::$forms['contact_way']);
			}

			//合同编号不能为空
			if(empty($contract_num))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_contract_number'), '-1');
			}

			req::$forms['contract_num'] = $contract_num;
			//如果是已签合同，需要上传图片
			if($contract_type == 1)
			{
				//合同照片不能为空
				if(empty($contract_pics))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_contract_photos_empty'), '-1');
				}

				req::$forms['contract_pics'] = is_array($contract_pics) ? implode(',', $contract_pics) : '';

				$this->_move_file($contract_pics);
			}
			else
			{
				req::$forms['contract_pics'] = '';
				req::$forms['contract_num'] = $online_contract_num;
			}

			req::$forms['card_pics'] = is_array($card_pics) ? implode(',', $card_pics) : '';

			//如果选择长期把有效日期设置成空
			if(!empty($is_long_date))
			{
				req::$forms['end_date'] = '';
			}
			else
			{
				$end_date_time = strtotime(req::$forms['end_date']);
				if($end_date_time < time())
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_earlier_current_time'), '-1');
				}

				req::$forms['is_long_date'] = 0;
			}

			if(empty($gutee_money))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_security_deposit'), '-1');
			}

			if(empty($email))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_entry_email'), '-1');
			}


			db::begin_tran();

			//添加担保金额操作记录，当上一次金额变动时与本次金额不一样时添加
			if($gutee_money != $info['gutee_money'])
			{
				$gutee_add_data['admin_id'] = cls_auth::$user->fields['uid'];
				$gutee_add_data['shop_id'] = $id;
				$gutee_add_data['money'] = $info['gutee_money'];
				$gutee_add_data['gutee_money'] = $gutee_money;
				$gutee_add_data['remark'] = '';
				$gutee_add_data['maint_id'] = 0;
				$gutee_add_data['oper_id'] = 0;
				$gutee_add_data['currency_code'] = '';
				$gutee_add_data['addtime'] = time();

				//db::insert('#PB#_shop_gutee_op', $gutee_add_data);
			}

			$shop_edit_data = array ();
			$shop_edit_data['name'] = req::$forms['name'];
			$shop_edit_data['catid'] = req::$forms['catid'];
			$shop_edit_data['end_date'] = req::$forms['end_date'];
			$shop_edit_data['is_long_date'] = req::$forms['is_long_date'];
			$shop_edit_data['card_type'] = req::$forms['card_type'];
			$shop_edit_data['card_pics'] = req::$forms['card_pics'];
			$shop_edit_data['card_name'] = req::$forms['card_name'];
			$shop_edit_data['card_num'] = req::$forms['card_num'];
			$shop_edit_data['address'] = req::$forms['address'];
			$shop_edit_data['payment_days'] = req::$forms['payment_days'];
			$shop_edit_data['gutee_money'] = req::$forms['gutee_money'];
			$shop_edit_data['contract_type'] = req::$forms['contract_type'];
			$shop_edit_data['contract_num'] = req::$forms['contract_num'];
			$shop_edit_data['contract_pics'] = isset(req::$forms['contract_pics']) ? req::$forms['contract_pics'] : '';
			$shop_edit_data['contact_per'] = req::$forms['contact_per'];
			$shop_edit_data['contact_ways'] = req::$forms['contact_ways'];
			$shop_edit_data['email'] = $email;
			$shop_edit_data['uptime'] = time();
			$result = mod_shop::update_data(array ('id', '=', $id), $shop_edit_data);

			//获取所有修改的商店接口
			if(empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
			}

			if($info['name'] != $name)
			{
				$interf_data = array ();
				$interf_data['shop_name'] = $shop_edit_data['name'];
				$interfaces_result = mod_shop_interfaces::update_data(array ('shop_id', '=', $id), $interf_data);
				if(empty($interfaces_result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
				}
			}

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_edit')." {$name}");

			db::commit();
			db::autocommit(true);

			$gourl = req::item('gourl', '?ct=shop&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
		}
		else
		{
			$info = mod_shop::find($id);
			$info['gutee_money'] = intval($info['gutee_money']);
			$info['contact_ways'] = isset($info['contact_ways']) ? json_decode($info['contact_ways'], true) : array();
			$info['card_pics'] = !empty($info['card_pics']) ? explode(',',$info['card_pics']) : array();
			$info['contract_pics'] = !empty($info['contract_pics']) ? explode(',',$info['contract_pics']) : array();
			$year_last_date = $info['is_long_date'] == 1 ? mod_shop::get_year_last_date() : $info['end_date'];

			$gourl = '?ct=shop&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::assign('year_last_date', $year_last_date);
			tpl::assign('info', $info);
			tpl::assign('img_url', URL_UPLOADS.'/image');
			tpl::assign('contact_way_list', mod_shop::$contact_way_list);
			tpl::assign('card_type_list', mod_shop::$card_type_list);
			tpl::assign('cate_options', mod_shop_category::get_options(0, $info['catid']));
			tpl::display('shop.edit.tpl');
		}
	}

	//停用商户
	public function stop()
	{
		$this->_edit_status();
	}

	//启用商户
	public function start()
	{
		$this->_edit_status();
	}

	//停用或者启用接口
	private function _edit_status()
	{
		$id = req::item('id');
		//status为1则停用，为0则启用
		$status = req::item('status');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$update_data['status'] = $status;
		$update_data['uptime'] = time();
		if($status == 1)
		{
			$update_data['deltime'] = time();
		}

		db::begin_tran();

		$result = mod_shop::update_data(array ('id', '=', $id), $update_data);

		$gourl = req::item('gourl', '?ct=shop&ac=index');

		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), $gourl);
		}

		//停用接口
		$result = mod_shop_interfaces::update_data(array ('shop_id', '=', $id), $update_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), $gourl);
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_start_stop_shop')." {$id}");

		db::commit();
		db::autocommit(true);

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
	}

	//商户交易明细
	public function bill()
	{
		$id = req::item('id');
		$start_date = req::item('start_date');
		$end_date = req::item('end_date');
		$type = req::item('type','','int');
		$bill_time = req::item('bill_time','','int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$shop_info = mod_shop::find($id);

		if(empty($shop_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$bill_where = array ();

		if(empty($type))
		{
			$bill_where[] = array ('type', 'in', array (1,2));
		}
		else
		{
			$bill_where[] = array ('type', '=', $type);
		}

		switch ($bill_time)
		{
			case 1:
				$start_time = strtotime(date('Y-m-d').' 00:00:00');
				$end_time = strtotime(date('Y-m-d').' 23:59:59');
				$bill_where[] = array ('addtime', '>=', $start_time);
				$bill_where[] = array ('addtime', '<=', $end_time);
				break;
			case 2:
				$start_time = strtotime(date("Y-m-d H:i:s",mktime(0, 0 , 0,date("m"),date("d")-date("w")+1,date("Y"))));
				$end_time = strtotime(date("Y-m-d H:i:s",mktime(23,59,59,date("m"),date("d")-date("w")+7,date("Y"))));
				$bill_where[] = array ('addtime', '>=', $start_time);
				$bill_where[] = array ('addtime', '<=', $end_time);
				break;
			case 3:
				$start_time = date('Y-m').'-01 00:00:00';
				$start_time = strtotime($start_time.' 00:00:00');
				$end_time = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m', strtotime('+1 month')).'-01')));
				$end_time = strtotime($end_time.' 23:59:59');
				$bill_where[] = array ('addtime', '>=', $start_time);
				$bill_where[] = array ('addtime', '<=', $end_time);
				break;
			case 4:
				if(!empty($start_date))
				{
					$start_time = strtotime($start_date.' 00:00:00');
					$bill_where[] = array ('addtime', '>=', $start_time);
				}
				if(!empty($end_date))
				{
					$end_time = strtotime($end_date.' 23:59:59');
					$bill_where[] = array ('addtime', '<=', $end_time);
				}

				break;
		}
		//查询账单流水
		$bill_where[] = array ('shop_id', '=', $id);


		$count = mod_shop_bill::get_count($bill_where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$bill_list = mod_shop_bill::get_list($bill_where, '', $pages['page_size'], $pages['offset']);
		//货币列表
		$currency_list = mod_currency_type::get_key_val();

		if(!empty($bill_list))
		{
			foreach ($bill_list as $k => $v)
			{
				$bill_list[$k]['add_date'] = date('Y-m-d H:i:s',$v['addtime']);
				$bill_list[$k]['type_name'] = isset(mod_member_bill::$type_list[$v['type']]) ? mod_member_bill::$type_list[$v['type']] : '';
				$bill_list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
			}
		}

		//获取返回URL
		$this->_get_gourl();

		tpl::assign('start_date', $start_date);
		tpl::assign('end_date', $end_date);
		tpl::assign('type', $type);
		tpl::assign('bill_time', $bill_time);
		tpl::assign('info', $shop_info);
		tpl::assign('bill_list', $bill_list);
		tpl::assign('pages', $pages['show']);
		tpl::display('shop.bill.tpl');
	}

	//担保金额操作明细
	public function gutee_op()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$info = mod_shop::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		//查询账单流水
		$where = array ();
		$where[] = array ('shop_id', '=', $id);

		$count = mod_shop_gutee_op::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_shop_gutee_op::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k=>$v)
			{
				$list[$k]['add_date'] = date('Y-m-d',$v['addtime']);
				$admin_info = mod_admin::find($v['admin_id'], 'realname');
				$list[$k]['admin_name'] = empty($admin_info) ? '' : $admin_info['realname'];
			}
		}

		//获取返回URL
		$this->_get_gourl();

		tpl::assign('info', $info);
		tpl::assign('list', $list);
		tpl::display('shop.gutee_op.tpl');
	}

	//查看照片
	public function show_pics()
	{
		$id = req::item('id');
		//1=营业执照，2=合同
		$pic_type = req::item('pic_type','1','int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$info = mod_shop::find($id, 'card_pics, contract_pics');

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$pics = array ();
		switch ($pic_type)
		{
			case 1:
					$pics = empty($info['card_pics']) ? $pics : explode(',', $info['card_pics']);
				break;
			case 2:
					$pics = empty($info['contract_pics']) ? $pics : explode(',', $info['contract_pics']);
				break;
		}

		foreach ($pics as $k => $v)
		{
			$pics[$k] = URL_UPLOADS.'/image/'.$v;
		}
		tpl::assign('pics', $pics);
		tpl::display('modal.pics.view.tpl');
	}

	//同意
	public function agree()
	{
		$id = req::item('id');
		$gourl = req::item('gourl', '?ct=shop&ac=index');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$shop_info = mod_shop::find($id);

		if(empty($shop_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		if($shop_info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		db::begin_tran();

		$update_data = array ();
		$update_data['audit_status'] = 1;
		$update_data['status'] = 0;
		$update_data['audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['audit_time'] = time();
		$update_data['uptime'] = time();

		$result = mod_shop::update_data(array ('id', '=', $id), $update_data);

		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_audit_fail'), $gourl);
		}

		//判断接口是否存在
		$interfaces_where = array ();
		$interfaces_where[] = array ('name', '=', $shop_info['name']);
		$interfaces_where[] = array ('shop_id', '=', $id);
		if( mod_shop_interfaces::is_exist($interfaces_where) )
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_audit_fail'), '-1');
		}

		//添加商户接口
		$interfaces_add_data = array ();
		$interfaces_add_data['name'] = $shop_info['name'];
		$interfaces_add_data['shop_id'] = $id;
		$interfaces_add_data['shop_name'] = $shop_info['name'];
		$interfaces_add_data['key'] = mod_shop_interfaces::make_key();
		$interfaces_add_data['email'] = $shop_info['email'];
		$interfaces_add_data['status'] = 0;
		$interfaces_add_data['addtime'] = time();

		$interfaces_id = mod_shop_interfaces::add_data( $interfaces_add_data);

		if(empty($interfaces_id))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_audit_fail'), '-1');
		}

		//获取默认货币
		$default_currency = mod_currency_type::get_default_curr();

		//添加商户余额账户
		$shop_money_bank_add_data = array ();
		$shop_money_bank_add_data['shop_id'] = $id;
		$shop_money_bank_add_data['currency_code'] = $default_currency;
		$shop_money_bank_add_data['type'] = 1;
		$shop_money_bank_add_data['money'] = 0;

		$result = mod_shop_money_bank::add_data($shop_money_bank_add_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_audit_fail'), '-1');
		}

		//添加商户冻结账户
		$shop_money_bank_add_data = array ();
		$shop_money_bank_add_data['shop_id'] = $id;
		$shop_money_bank_add_data['currency_code'] = $default_currency;
		$shop_money_bank_add_data['type'] = 2;
		$shop_money_bank_add_data['money'] = 0;

		$result = mod_shop_money_bank::add_data($shop_money_bank_add_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_audit_fail'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_audit_pass')." {$id}");

		db::commit();
		db::autocommit(true);

		if(!empty($interfaces_id))
		{
			//发送邮件
			$email_arr = array ();
			$email_arr['email'] = $interfaces_add_data['email'];
			$email_arr['key'] = $interfaces_add_data['key'];
			$email_arr['name'] = $interfaces_add_data['name'];
			$email_arr['end_date'] = $shop_info['is_long_date'] == 1 ? lang::get('shop_long_effective') : lang::get('shop_valid_until').$shop_info['end_date'];
			if(!mod_shop_interfaces::send_mail($email_arr))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_audit_fail'), '-1');
			}
		}

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_audit_success'), $gourl);
	}

	//驳回
	public function reject()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$shop_info = mod_shop::find($id);

		if(empty($shop_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		if($shop_info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		$update_data['audit_status'] = 2;
		$update_data['audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['audit_time'] = time();
		$update_data['uptime'] = time();

		mod_shop::update_data(array ('id', '=', $id), $update_data);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_audit_rejected_business')." {$id}");

		$gourl = req::item('gourl', '?ct=shop&ac=index');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_dismissed_success'), $gourl);
	}

	//异步搜索商户
	public function search()
	{
		header('Content-Type: application/json; Charset=utf-8');

		$keyword = req::item('query', '');
		$id = req::item('id', '');

		$where = array ();
		if (empty($keyword)) {
			exit(json_encode(['suggestions' => []]));
		}
		else
		{
			$where[] = array ('name', 'like', $keyword.'%');
		}

		$where[] = array ('status', '=', 0);
		if(!empty($id))
		{
			$where[] = array ('id', '!=', $id);
		}

		$list = mod_shop::get_list($where, '', 100);
		$format_data = [];
		if($list)
		{
			foreach ($list as $item) {
				$format_data[] = ['data' => $item['id'], 'value' => $item['id'].'-'.$item['name']];
			}
		}
		else
		{
			$format_data[] = ['data' => 0, 'value' => lang::get('shop_search_not_data')];
		}

		exit(json_encode(['suggestions' => $format_data]));
	}

	//查看在线合同
	public function show_electronic_contract()
	{
		$is_sign = req::item('is_sign','0','int');

		tpl::assign("is_sign", $is_sign);
		tpl::display('shop.electronic_contract.tpl');
	}

	// 生成电子合同编号
	public function gen_contract_num()
	{
		util::response_json(200, 'success', 0, ['num' => util::make_bill_id()]);
	}

	//受理
	public function accepte()
	{
		$id = req::item('id');
		$type_list = req::item('type_list','1','int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$info = mod_shop::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
		}

		$update_data['audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		mod_shop::update_data(array ('id', '=', $id) ,$update_data);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_accepte')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_acceptance_success'), "?ct=shop&ac=info&id={$id}&type_list={$type_list}");
	}

	//获取返回URL
	private function _get_gourl()
	{
		$type_list = req::item('type_list','1','int');

		switch ($type_list)
		{
			case 1:
				$gourl = "?ct=shop&ac=index";
				break;
			case 2:
				$gourl = "?ct=shop&ac=pass_list";
				break;
			case 3:
				$gourl = "?ct=shop&ac=reject_list";
				break;
			case 4:
				$gourl = "?ct=shop&ac=accepting_list";
				break;
			case 5:
				$gourl = "?ct=shop&ac=accepted_list";
				break;

		}

		tpl::assign('gourl', $gourl);
		tpl::assign('type_list', $type_list);

		return $gourl;
	}

	//移动文件
	private function _move_file($files)
	{
		if(empty($files))
		{
			return true;
		}

		//没有该目录则创建
		if(!is_dir(PATH_UPLOADS.'/file'))
		{
			if(!mkdir(PATH_UPLOADS.'/file',0777))
			{
				return false;
			}
		}

		//移动文件
		if(is_array($files))
		{
			foreach ($files as $file)
			{
				if(file_exists(PATH_UPLOADS.'/tmp/'.$file))
				{
					if(!rename(PATH_UPLOADS.'/tmp/'.$file, PATH_UPLOADS.'/image/'.$file))
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}

			return true;
		}
		else
		{
			if(file_exists(PATH_UPLOADS.'/tmp/'.$files))
			{
				return rename(PATH_UPLOADS.'/tmp/'.$files, PATH_UPLOADS.'/image/'.$files);
			}
			else
			{
				return false;
			}
		}
	}

}
