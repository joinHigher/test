<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 首页
 *
 * @version $Id$
 */
class ctl_home
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {

	}

    /**
     * 首页
     */
    public function index()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("home", $lang);
		lang::load("member", $lang);
		lang::load("month_bill", $lang);
		lang::load("model", $lang);

		$bill_where = array();

		//查询月账单
		$bill_where[] = array ('status', '=', 2);

		$count = mod_member_bill_month::get_count($bill_where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_member_bill_month::get_list($bill_where, '', $pages['page_size'], $pages['offset']);

		//货币类型
		$currency_list = mod_currency_type::get_key_val();

		//加载语言包
        mod_member_bill_month::$status_list[1] = lang::get('model_closed');
        mod_member_bill_month::$status_list[2] = lang::get('model_open');

		$now_time = time();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
		{
			$member_info = mod_member_info::find($v['member_info_id']);
			$end_time = strtotime($v['end_date'].' 23:59:59');

			$list[$k]['repay_limit'] = mod_member_info::num_format($v['repay_limit']);
			$list[$k]['al_repay_limit'] = mod_member_info::num_format($v['al_repay_limit']);
			$list[$k]['surplus_limit'] = mod_member_info::num_format($v['repay_limit'] - $v['al_repay_limit']);
			$list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
			//$list[$k]['status_name'] = isset(mod_bill_month::$status_list[$v['status']]) ? mod_bill_month::$status_list[$v['status']] : '';
			$list[$k]['member_code_name'] = empty($member_info) ? '' : $member_info['code'].' | '.$member_info['name'];

			//判断是否逾期
			if($now_time > $end_time)
			{
				if($v['al_repay_limit'] == $v['repay_limit']  || $v['repay_limit'] == 0)
				{
					$list[$k]['status_name'] = lang::get('month_bill_has_cleared');
				}
				elseif($v['al_repay_limit'] == 0)
				{
					$list[$k]['status_name'] = lang::get('month_bill_overdue');
				}
				else
				{
					$list[$k]['status_name'] = lang::get('month_bill_overdue_settlement');
				}
			}
			else
			{
				if($v['al_repay_limit'] == 0 && $v['repay_limit'] != 0)
				{
					$list[$k]['status_name'] = lang::get('month_bill_open');
				}
				elseif($v['al_repay_limit'] == $v['repay_limit']  || $v['repay_limit'] == 0)
				{
					$list[$k]['status_name'] = lang::get('month_bill_has_cleared');
				}
				else
				{
					$list[$k]['status_name'] = lang::get('month_bill_not_settled');
				}
			}
		}
		}
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('home.index.tpl');
    }

	//异步获取统计数据
	public function ajax_stati()
	{
		$result = $this->_statistics();
		util::response_json(200, '操作成功', 1, $result);
	}

	//统计数据
	private function _statistics()
	{
		$stati_time = req::item('stati_time','7','int');
		$start_time= strtotime("-{$stati_time} day", time());
		$end_time = time();
		$year = date('Y',time());

		for ($di=$stati_time-1;$di>=0;$di--)
		{
			$time_list[] = date('m-d',strtotime("-{$di} day",time()));
		}

		//资金统计
			//获取汇率列表
			//$cur_code_list = mod_currency_type::get_exg_rate_list();

			//账单金额
			//$sql = "SELECT `date`,`currency_code`,sum(amount) AS `sum` FROM `#PB#_member_bill` WHERE `type`='1' AND `from_type`='2' AND `addtime`>='{$start_time}' AND `addtime`<='{$end_time}' GROUP BY `date`,`currency_code` ORDER BY `date` ASC";
			//$cons_list = db::get_all($sql);
			$cons_list_where = array ();
			$cons_list_where[] = array ('type', '=', 1);
			$cons_list_where[] = array ('from_type', '=', 2);
			$cons_list_where[] = array ('addtime', '>=', $start_time);
			$cons_list_where[] = array ('addtime', '<=', $end_time);
			$cons_list = mod_member_bill::get_list($cons_list_where, 'date,currency_code,sum(amount) AS `sum`', 0, 0, array ('date', 'ASC'), 'date,currency_code');

			//还款金额
			//$sql = "SELECT `date_day`,sum(al_repay_limit) AS `sum` FROM `#PB#_member_bill_repay` WHERE `addtime`>='{$start_time}' AND `addtime`<='{$end_time}' GROUP BY `date_day` ORDER BY `date_day` ASC";
			//$repay_list = db::get_all($sql);
			$repay_list_where = array ();
			$repay_list_where[] = array ('addtime', '>=', $start_time);
			$repay_list_where[] = array ('addtime', '<=', $end_time);
			$repay_list = mod_member_bill_repay::get_list($repay_list_where, 'date_day,sum(al_repay_limit) AS `sum`', 0, 0, array ('date_day', 'ASC'), 'date_day');


		//客户统计
			//下线申请数
			//$sql = "SELECT `date_day`,Count(*) AS `count` FROM `#PB#_member_info` WHERE `addtime`>='{$start_time}' AND `addtime`<='{$end_time}' AND `status`!='0' AND `parentid`!='0' GROUP BY `date_day`";
			//$mem_apply_list = db::get_all($sql);
			$mem_apply_list_where = array ();
			$mem_apply_list_where[] = array ('status', '!=', 0);
			$mem_apply_list_where[] = array ('parentid', '!=', 0);
			$mem_apply_list_where[] = array ('addtime', '>=', $start_time);
			$mem_apply_list_where[] = array ('addtime', '<=', $end_time);
			$mem_apply_list = mod_member_info::get_list($mem_apply_list_where, 'date_day,Count(*) AS `count`', 0, 0, '', 'date_day');

			//新增下线
			//$sql = "SELECT `date_day`,Count(*) AS `count` FROM `#PB#_member_info` WHERE `addtime`>='{$start_time}' AND `addtime`<='{$end_time}' AND `status`='1' AND `parentid`!='0' GROUP BY `date_day`";
			//$mem_add_list = db::get_all($sql);
			$mem_add_list_where = array ();
			$mem_add_list_where[] = array ('status', '=', 1);
			$mem_add_list_where[] = array ('parentid', '!=', 0);
			$mem_add_list_where[] = array ('addtime', '>=', $start_time);
			$mem_add_list_where[] = array ('addtime', '<=', $end_time);
			$mem_add_list = mod_member_info::get_list($mem_apply_list_where, 'date_day,Count(*) AS `count`', 0, 0, '', 'date_day');

		//下线总人数
			//$sql = "SELECT `date_day`,Count(*) AS `count` FROM `#PB#_member_info` WHERE `addtime`>='{$start_time}' AND `addtime`<='{$end_time}' AND `parentid`!='0' GROUP BY `date_day`";
			//$mem_all_list = db::get_all($sql);
			$mem_all_list_where = array ();
			$mem_all_list_where[] = array ('parentid', '!=', 0);
			$mem_all_list_where[] = array ('addtime', '>=', $start_time);
			$mem_all_list_where[] = array ('addtime', '<=', $end_time);
			$mem_all_list = mod_member_info::get_list($mem_apply_list_where, 'date_day,Count(*) AS `count`', 0, 0, '', 'date_day');

		foreach ($time_list as $time)
		{
			$date_day = $year.'-'.$time;
			if(empty($cons_list))
			{
				$new_cons_list[$date_day] = 0;
			}
			else
			{
				foreach ($cons_list as $k => $v)
				{
					if($date_day == $v['date'])
					{
						$sum_money = $sum = isset($v['sum']) ? -$v['sum'] : 0;
						//$sum_money = mod_currency_type::get_exg_money($sum,$v['currency_code']);
						$new_cons_list[$date_day] = empty($new_cons_list[$date_day]) ? floor($sum_money) : floor($new_cons_list[$date_day] + $sum_money);
					}
					else
					{
						if(!isset($new_cons_list[$date_day]))
						{
							$new_cons_list[$date_day] = 0;
						}
					}
				}
			}

			if(empty($repay_list))
			{
				$new_repay_list[] = 0;
			}
			else
			{
				foreach ($repay_list as $k => $v)
				{
					if($date_day == $v['date_day'])
					{
						$new_repay_list[$date_day] = empty($v['sum']) ? 0 : floor($v['sum']);
					}
					else
					{
						if(!isset($new_repay_list[$date_day]))
						{
							$new_repay_list[$date_day] = 0;
						}
					}

				}
			}

			if(empty($mem_apply_list))
			{
				$new_mem_apply_list[$date_day] = 0;
			}
			else
			{
				foreach ($mem_apply_list as $k => $v)
				{
					if($date_day == $v['date_day'])
					{
						$new_mem_apply_list[$date_day] = empty($v['count']) ? 0 : intval($v['count']);
					}
					else
					{
						if(!isset($new_mem_apply_list[$date_day]))
						{
							$new_mem_apply_list[$date_day] = 0;
						}
					}
				}
			}

			if(empty($mem_add_list))
			{
				$new_mem_add_list[$date_day] = 0;
			}
			else
			{
				foreach ($mem_add_list as $k => $v)
				{
					if($date_day == $v['date_day'])
					{
						$new_mem_add_list[$date_day] = empty($v['count']) ? 0 : intval($v['count']);
					}
					else
					{
						if(!isset($new_mem_add_list[$date_day]))
						{
							$new_mem_add_list[$date_day] = 0;
						}
					}
				}
			}

			if(empty($mem_all_list))
			{
				$new_mem_all_list[$date_day] = 0;
			}
			else
			{
				foreach ($mem_all_list as $k => $v)
				{

					if($date_day == $v['date_day'])
					{
						$new_mem_all_list[$date_day] = empty($v['count']) ? 0 : intval($v['count']);
					}
					else
					{
						if(!isset($new_mem_all_list[$date_day]))
						{
							$new_mem_all_list[$date_day] = 0;
						}
					}
				}
			}
		}

		return array (
					'time_list' => $time_list,
					'cons_list' => array_values($new_cons_list),
					'repay_list' => array_values($new_repay_list),
					'mem_apply_list' => array_values($new_mem_apply_list),
					'mem_add_list' => array_values($new_mem_add_list),
					'mem_all_list' => array_values($new_mem_all_list),
				);
	}

}
