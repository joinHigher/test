<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 商户接口管理
 *
 * @version $Id$
 */
class ctl_shop_interfa
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("shop", $lang);
		lang::load("shop_interface", $lang);
		lang::load("model", $lang);

		mod_shop_interfaces::$status_list[0] = lang::get('model_normal');
		mod_shop_interfaces::$status_list[1] = lang::get('model_disabled');

	}

    /**
     * 列表
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $shop_id = req::item('shop_id', '');

        $where = array();
		if(!empty($keyword))
		{
			$where[] = array ('name', 'like', '%'.$keyword.'%');
		}
		if(!empty($shop_id))
		{
			$where[] = array ('shop_id', '=', $shop_id);
		}

		$counnt = mod_shop_interfaces::get_count($where);
		$pages = pub_page::make($counnt, req::item('page_size', '10','int'));
		$list = mod_shop_interfaces::get_list($where, '', $pages['page_size'], $pages['offset']);

        foreach ($list as $k => $v)
		{
			$list[$k]['status_name'] = mod_shop_interfaces::$status_list[$v['status']];
		}
        tpl::assign('shop_id', $shop_id);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
		tpl::assign('ct', req::item('ct'));
        tpl::display('shop_interfa.index.tpl');
    }

	//添加
	public function add()
	{

		$shop_id = req::item('shop_id');
		if(empty($shop_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_select_shop'), '-1');
		}

		if (!empty(req::$posts))
		{
			if(empty($name))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_entry_name_search'), '-1');
			}

			if(empty($email))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_email_empty'), '-1');
			}

			$shop_info = mod_shop::find($shop_id,'name,is_long_date,end_date');

			if(empty($shop_info))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_shop_no_exists'), '-1');
			}

			$name = req::item('name');
			$key = req::item('key');
			$email = req::item('email');

			$interfaces_where = array ();
			$interfaces_where[] = array ('shop_id', '=', $shop_id);
			$interfaces_where[] = array ('name', '=', $name);
			if( mod_shop_interfaces::is_exist($interfaces_where) )
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_already_exists'), '-1');
			}

			if(mod_shop_interfaces::key_exist($key))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_key_exists'), '-1');
			}

			$add_data['name'] = $name;
			$add_data['shop_id'] = $shop_id;
			$add_data['shop_name'] = $shop_info['name'];;
			$add_data['key'] = $key;
			$add_data['email'] = $email;
			$add_data['status'] = 0;
			$add_data['addtime'] = $add_data['uptime'] = time();

			$result = mod_shop_interfaces::add_data($add_data);

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_interface_add')." {$name}");

			if(!empty($result))
			{
				//发送邮件
				$email_arr['email'] = $email;
				$email_arr['key'] = $key;
				$email_arr['name'] = $name;
				$email_arr['end_date'] = $shop_info['is_long_date'] == 1 ? lang::get('shop_interface_long_effective') : lang::get('shop_interface_valid_until').$shop_info['end_date'];
				if(!mod_shop_interfaces::send_mail($email_arr))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_send_email_fail'), '-1');
				}
			}

			$gourl = req::item('gourl', '?ct=shop_interfa&ac=index&shop_id='.$shop_id);
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_add'), $gourl);
		}
		else
		{
			$shop_info = mod_shop::find($shop_id,'name,email');
			$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=shop_interfa&ac=index' : $_SERVER['HTTP_REFERER'];
			tpl::assign('gourl', $gourl);
			tpl::assign('shop_info', $shop_info);
			tpl::assign('key', mod_shop_interfaces::make_key());
			tpl::display('shop_interfa.add.tpl');
		}
	}

	//编辑
	public function edit()
	{
		$id = req::item('id');
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$key = req::item('key');
			$email = req::item('email');

			if(empty($id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_select'), '-1');
			}

			if(empty($name))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_entry_name_search'), '-1');
			}

			if(empty($email))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_email_empty'), '-1');
			}

			$shop_interfa_info = mod_shop_interfaces::find($id);
			if(empty($shop_interfa_info))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_no_exists'), '-1');
			}

			$shop_info = mod_shop::find($shop_interfa_info['shop_id'],'name,is_long_date,end_date');

			if(empty($shop_info))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_shop_no_exists'), '-1');
			}

			$interfaces_where = array ();
			$interfaces_where[] = array ('id', '!=', $id);
			$interfaces_where[] = array ('shop_id', '=', $shop_interfa_info['shop_id']);
			$interfaces_where[] = array ('name', '=', $name);
			if( mod_shop_interfaces::is_exist($interfaces_where) )
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_already_exists'), '-1');
			}

			if(mod_shop_interfaces::key_exist($key,$id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_key_exists'), '-1');
			}

			$edit_data = array ();
			$edit_data['name'] = $name;
			$edit_data['shop_name'] = $shop_info['name'];;
			$edit_data['key'] = $key;
			$edit_data['email'] = $email;
			$edit_data['uptime'] = time();

			$result = mod_shop_interfaces::update_data(array ('id', '=', $id), $edit_data);

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_interface_edit')." {$name}");

			if(!empty($result))
			{
				//发送邮件
				$email_arr['email'] = $email;
				$email_arr['key'] = $key;
				$email_arr['name'] = $name;
				$email_arr['end_date'] = $shop_info['is_long_date'] == 1 ? lang::get('shop_interface_long_effective') : lang::get('shop_interface_valid_until').$shop_info['end_date'];
				if(!mod_shop_interfaces::send_mail($email_arr))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_send_email_fail'), '-1');
				}
			}

			$gourl = req::item('gourl', '?ct=shop_interfa&ac=index&shop_id='.$shop_interfa_info['shop_id']);
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
		}
		else
		{
			$info = mod_shop_interfaces::find($id);
			$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=shop_interfa&ac=index' : $_SERVER['HTTP_REFERER'];
			tpl::assign('info', $info);
			tpl::assign('gourl', $gourl);
			tpl::display('shop_interfa.edit.tpl');
		}
	}

	//停用接口
	public function stop()
	{
		$this->_edit_status(1);
	}

	//启用接口
	public function start()
	{
		$this->_edit_status(0);
	}

	//停用或者启用接口
	public function _edit_status($status)
	{
		$id = req::item('id');
		//status为1则停用，为0则启用
		//$status = req::item('status');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_select'), '-1');
		}

		$shop_interfa_info = mod_shop_interfaces::find($id);
		if(empty($shop_interfa_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_interface_no_exists'), '-1');
		}

		$update_data['status'] = $status;
		$update_data['uptime'] = time();
		if($status == 1)
		{
			$update_data['deltime'] = time();
		}

		mod_shop_interfaces::update_data(array ('id', '=', $id), $update_data);

		$gourl = req::item('gourl', '?ct=shop_interfa&ac=index&shop_id='.$shop_interfa_info['shop_id']);
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
	}

	//生成随机key
	public function make_key()
	{
		$data['key'] = mod_shop_interfaces::make_key();
		util::response_json(200, lang::get('common_operation_success'), 1, $data);
	}
}
