<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 消费账单添加
 *
 * @version $Id$
 */
class ctl_bill_test
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("order", $lang);
		lang::load("model", $lang);
		lang::load("push_message_content", $lang);

		mod_member_bill::$type_list[6] = lang::get('model_thaw');
    }

	public function add()
	{
		$gourl = "?ct=bill_test&ac=add";

		if (!empty(req::$posts))
		{
			$time = strtotime(req::item('time'));
			$shop_id = req::item('shop_id');
			$inter_id = req::item('inter_id');
			$member_info_id = req::item('member_info_id');
			$amount = req::item('amount');
			$currency_code = req::item('currency_code');
			$remark = req::item('remark');
			$date = date('Y-m-d',$time);

			if(empty($shop_id))
			{
				cls_msgbox::show('系统提示', '请选择商户！', '-1');
			}

			if(empty($inter_id))
			{
				cls_msgbox::show('系统提示', '请选择对象！', '-1');
			}

			if(empty($member_info_id))
			{
				cls_msgbox::show('系统提示', '请选择客户！', '-1');
			}

			/********* 判断客户金额是否足够开始 **********/
				//1。判断余额，该步骤暂时不考虑

				//2。判断客户的授信额度,先判断同种货币授信额度是否不足，如果不足再考虑其它货币的授信
				$member_default_money = mod_member_money_credit::get_info("`member_info_id`='{$member_info_id}' AND `currency_code`='{$currency_code}'");

				if(empty($member_default_money))
				{
					cls_msgbox::show('系统提示', '该货币没有授信', '-1');
				}

				//客户可使用金额
				$use_money = $member_default_money['fixed_money'] - $member_default_money['used_money'];
				if($use_money < $amount)
				{
					cls_msgbox::show('系统提示', '固定额度不够！', '-1');
				}
			/********* 判断客户金额是否足够结束 **********/

			//生成订单
			$order_add_data['order_id'] = util::make_bill_id();
			$order_add_data['shop_id'] = $shop_id;
			$order_add_data['interface_id'] = $inter_id;
			$order_add_data['member_info_id'] = $member_info_id;
			$order_add_data['goods_id'] = 2;
			$order_add_data['goods_name'] = '测试商品';
			$order_add_data['payment_type'] = 1;
			$order_add_data['currency_code'] = $currency_code;
			$order_add_data['amount'] = $amount;
			$order_add_data['status'] = 0;
			$order_add_data['pay_status'] = 1;
			$order_add_data['date'] = $date;
			$order_add_data['addtime'] = $time;
			db::insert('#PB#_order',$order_add_data);


			//生成支出账单日志
			$bill_add_data['bill_id'] = util::make_bill_id();
			$bill_add_data['order_id'] = $order_add_data['order_id'];
			$bill_add_data['member_info_id'] = $member_info_id;
			$bill_add_data['type'] = 1;
			$bill_add_data['bank_card_id'] = $member_default_money['id'];
			$bill_add_data['currency_code'] = $currency_code;
			$bill_add_data['amount'] = -$amount;
			$bill_add_data['from_type'] = 2;
			$bill_add_data['remark'] = "购买".$order_add_data['goods_name'];
			$bill_add_data['status'] = 1;
			$bill_add_data['date'] = date('Y-m-d',$time);
			$bill_add_data['addtime'] = $time;
			$bill_add_data['uptime'] = $time;
			db::insert('#PB#_member_bank_log',$bill_add_data);

			/*
			//生成订单与账单流水关联数据
			$bill_order_link_add['order_id'] = $order_add_data['order_id'];
			$bill_order_link_add['bill_id'] = $bill_add_data['bill_id'];
			db::insert('#PB#_member_order_bill_link',$bill_order_link_add);
			*/

			//生成冻结账单日志
			$bill_add_data['bill_id'] = util::make_bill_id();
			$bill_add_data['order_id'] = $order_add_data['order_id'];
			$bill_add_data['member_info_id'] = $member_info_id;
			$bill_add_data['type'] = 3;
			$bill_add_data['bank_card_id'] = $member_default_money['id'];
			$bill_add_data['currency_code'] = $currency_code;
			$bill_add_data['amount'] = $amount;
			$bill_add_data['from_type'] = 2;
			$bill_add_data['remark'] = '冻结';
			$bill_add_data['status'] = 1;
			$bill_add_data['date'] = date('Y-m-d',$time);
			$bill_add_data['addtime'] = $time;
			$bill_add_data['uptime'] = $time;
			db::insert('#PB#_member_bank_log',$bill_add_data);

			/*
			//生成订单与账单流水关联数据
			$bill_order_link_add['order_id'] = $order_add_data['order_id'];
			$bill_order_link_add['bill_id'] = $bill_add_data['bill_id'];
			db::insert('#PB#_member_order_bill_link',$bill_order_link_add);
  			*/

			//添加或者修改冻结金额
			$member_bank_where = "`member_info_id`='{$member_info_id}' AND `currency_code`='{$currency_code}' AND `type`=2";
			$member_bank = mod_member_money_bank::get_info($member_bank_where);
			if(empty($member_bank))
			{
				$member_up_data['member_info_id'] = $member_info_id;
				$member_up_data['type'] = 2;
				$member_up_data['currency_code'] = $currency_code;
				$member_up_data['money'] = $amount;
				db::insert('#PB#_member_money_bank',$member_up_data);
			}
			else
			{
				$member_up_data['money'] = $member_bank['money'] + $amount;
				db::update('#PB#_member_money_bank', $member_up_data, $member_bank_where);
			}

			//扣除客户与上级金额，注意：消费金额先扣除客户账户余额，如果金额不够再扣除授信额度
			$member_info = mod_member_info::get_info("`id`='{$member_info_id}'");

			$ids = empty($member_info['parentpath']) ? $member_info_id : $member_info_id.','.$member_info['parentpath'];
			$sql = "UPDATE #PB#_member_money_credit SET used_money=used_money+{$amount} WHERE member_info_id in({$ids})";
			db::query($sql);

			$gourl = req::item('gourl', '?ct=bill_test&ac=add');
			cls_msgbox::show('系统提示', "添加成功", $gourl);
		}
		else
		{
			$sql = "select id,name from #PB#_shop ";
			$shop_list = db::get_all($sql);
			$n_shop_list = array ();
			foreach ($shop_list as $k=>$v)
			{
				$n_shop_list[$v['id']] = $v['name'];
			}

			$inter_list = array ();
			if(!empty($shop_list))
			{
				$sql = "select id,name from #PB#_shop_interfaces where `status`=0 and `shop_id`='{$shop_list[0]['id']}'";
				$shop_inter_list = db::get_all($sql);
				foreach ($shop_inter_list as $v)
				{
					$inter_list[$v['id']] = $v['name'];
				}
			}
			$sql = "select id,name from #PB#_member_info ";
			$member_list = db::get_all($sql);
			$n_member_list = array ();
			foreach ($member_list as $k=>$v)
			{
				$n_member_list[$v['id']] = $v['name'];
			}
			$currency_list = mod_currency_type::get_key_val();

			tpl::assign('shop_list', $n_shop_list);
			tpl::assign('inter_list', $inter_list);
			tpl::assign('member_list', $n_member_list);
			tpl::assign('currency_list', $currency_list);
			tpl::assign('type_list', mod_member_bill::$type_list);
			tpl::assign('status_list', mod_member_bill::$status_list);
			tpl::assign('gourl',$gourl);
			tpl::assign('currency_code',config::get('transact_curcy'));
			tpl::display('bill_test.add.tpl');
		}

	}

	//异步获取接口
	public function ajax_get_interface()
	{
		$shop_id = req::item('shop_id');
		if(empty($shop_id))
		{
			util::response_json(200, '请选择商户', 0);
		}

		$sql = "SELECT id,name FROM `#PB#_shop_interfaces` WHERE `shop_id`='{$shop_id}' AND `status`=0";
		$list = db::get_all($sql);
		util::response_json(200, '获取成功', 1, $list);
	}

	//手动生成月结账单
	function make_member_month_bill ()
	{
		$gourl = "?ct=bill_test&ac=make_member_month_bill";
		if(req::method() == 'POST')
		{
			$date_sta = req::item('start_time');
			$date_end = req::item('end_time');
			if(empty($date_sta) || empty($date_end))
			{
				cls_msgbox::show('系统提示', "请选择开始与结束时间", $gourl);
			}

			$date_sta = strtotime("{$date_sta} 00:00:00");
			$date_end = strtotime("{$date_end} 23:59:59");

			$start_end_time['start_time'] = $date_sta;
			$start_end_time['end_time'] = $date_end;

			//查询所有的成员
			$all_member_list = db::select('id,bill_monthly')
				->from('#PB#_member_info')
				->where('status', '=', 1)
				->execute();

			if(!empty($all_member_list))
			{
				//默认月结时间
				$bill_end_date = config::get('bill_end_date');
				//结算汇率浮动百分比
				$clear_rate_per = config::get('clear_rate_per');
				//默认货币
				$transact_curcy = mod_currency_type::to_upper(config::get('transact_curcy'));
				//所有的货币汇率
				$rate_list = mod_currency_type::get_exg_rate_list();
				//客户默认货币
				$mem_default_currency_code = mod_member_info::get_default_currency_code();
				//默认货币符号
				$transact_curcy_info = db::select('symbol')
					->from('#PB#_currency_type')
					->where('code_name', '=', $transact_curcy)
					->as_row()
					->execute();

				$transact_curcy_symbol = isset($transact_curcy_info['symbol']) ? $transact_curcy_info['symbol'] : '';

				//到期还款日
				$bill_latest_repay_date = config::get('bill_latest_repay_date');

				foreach ($all_member_list as $mk => $mv)
				{
					$this->member_month_bill($mv,$bill_end_date,$clear_rate_per,$transact_curcy,$rate_list,$mem_default_currency_code,$transact_curcy_symbol,$bill_latest_repay_date,$start_end_time);
				}
			}

			cls_msgbox::show('系统提示', "生成成功", $gourl);

		}
		else
		{
			tpl::assign('gourl',$gourl);
			tpl::display('bill_month_test.add.tpl');
		}
	}

	public function member_month_bill($member_value,$bill_end_date,$clear_rate_per,$transact_curcy,$rate_list,$mem_default_currency_code,$transact_curcy_symbol,$bill_latest_repay_date,$start_end_time = array ())
	{

		$admin_id = 0;

		//还款到期日期
		$bill_monthly = empty($member_value['bill_monthly']) ? $bill_end_date : $member_value['bill_monthly'];

		$member_id = $member_value['id'];

		//获取账单月结开始与结束时间
		$start_end_time = empty($start_end_time) ? mod_member_info::month_start_and_end_time($member_value['bill_monthly']) : $start_end_time;

		/**************  查询账单开始  ************/

		//消费金额（账单包括状态为：0=未确认，1=已确认，2=有疑问）
		$all_bill_where = array ();
		$all_bill_where[] = array ('member_info_id', '=', $member_id);
		$all_bill_where[] = array ('type', '=', 1);
		$all_bill_where[] = array ('addtime', '>=', $start_end_time['start_time']);
		$all_bill_where[] = array ('addtime', '<=', $start_end_time['end_time']);

		$all_bill_list = db::select('currency_code,sum(amount) as `sum`')
			->from('#PB#_member_bill')
			->where($all_bill_where)
			->group_by('currency_code')
			->execute();

		//需还款消费金额
		$repay_bill_where = array ();
		$repay_bill_where[] = array ('member_info_id', '=', $member_id);
		$repay_bill_where[] = array ('type', 'in', array (1,2));
		//$repay_bill_where[] = array ('status', '=', 1);
		$repay_bill_where[] = array ('from_type', '=', 2);
		$repay_bill_where[] = array ('addtime', '>=', $start_end_time['start_time']);
		$repay_bill_where[] = array ('addtime', '<=', $start_end_time['end_time']);

		$repay_bill_list = db::select('currency_code,sum(amount) as `sum`')
			->from('#PB#_member_bill')
			->where($repay_bill_where)
			->group_by('currency_code')
			->execute();

		/**************  查询账单结束  ************/

		/****************** 统计账单金额,根据汇率转换成默认金额开始  ******************/

		//消费金额
		$all_bill_money = 0;
		if(!empty($all_bill_list))
		{
			foreach ($all_bill_list as $ak => $av)
			{
				$all_bill_money += mod_currency_type::get_exg_money(-$av['sum'],$av['currency_code']);
			}
		}

		//需还款消费金额
		$repay_bill_money = 0;
		if(!empty($repay_bill_list))
		{
			foreach ($repay_bill_list as $ak => $av)
			{
				$repay_bill_money += mod_currency_type::get_exg_money(-$av['sum'],$av['currency_code']);
			}
		}

		/****************** 统计账单金额,根据汇率转换成默认金额结束  ******************/

		//客户账户余额
		$bank_where = array ();
		$bank_where[] = array ('member_info_id', '=', $member_id);
		$bank_where[] = array ('type', '=', 1);
		$bank_where[] = array ('currency_code', '=', $mem_default_currency_code);

		$bank_info = db::select('id,money')
			->from('#PB#_member_money_bank')
			->where($bank_where)
			->as_row()
			->execute();

		$member_surplus_money = empty($bank_info) ? 0 : $bank_info['money'];

		//月结年月
		$year = date('Y',$start_end_time['start_time']);
		$month = date('n',$start_end_time['start_time']);

		//判断客户是否已经生成月结账单，有则获取已还款金额
		$month_bill_where = array ();
		$month_bill_where[] = array ('member_info_id', '=', $member_id);
		$month_bill_where[] = array ('year', '=', $year);
		$month_bill_where[] = array ('month', '=', $month);

		$month_bill_info = db::select('id,al_repay_limit')
			->from('#PB#_member_bill_month')
			->where($month_bill_where)
			->as_row()
			->execute();

		//已还款金额
		$al_repay_imit = empty($month_bill_info) ? 0 : $month_bill_info['al_repay_limit'];

		//客户还款之后剩余的钱
		$member_repay_surplus_money = 0;

		//客户本次还款金额
		$member_repay_money = 0;

		//客户需还款剩余金额
		$repay_surplus_money = $repay_bill_money - $al_repay_imit;

		//当需还款金额大于等于客户账户余额时
		if($repay_surplus_money >= $member_surplus_money)
		{
			$al_repay_imit = $al_repay_imit + $member_surplus_money;
			$member_repay_money = $member_surplus_money;
		}
		else
		{
			$al_repay_imit = $repay_bill_money;
			$member_repay_surplus_money = $member_surplus_money - $repay_surplus_money;
			$member_repay_money = $repay_surplus_money;
		}

		//获取客户授信
		$credit_where = array ();
		$credit_where[] = array ('member_info_id', '=', $member_id);
		$credit_where[] = array ('currency_code', '=', $mem_default_currency_code);

		$credit_info = db::select('id,fixed_money,tmp_money,used_money')
			->from('#PB#_member_money_credit')
			->where($credit_where)
			->as_row()
			->execute();

		//开启事务
		db::begin_tran();

		//添加月结账单记录
		$time = time();
		$bill_monthly = $bill_monthly < 10 ? '0'.$bill_monthly : $bill_monthly;
		$add_data = array ();
		$add_data['admin_id'] = $admin_id;
		$add_data['month_bill_id'] = util::make_bill_id();
		$add_data['member_info_id'] = $member_id;
		$add_data['fixed_limit'] = $credit_info['fixed_money'];
		$add_data['tmp_limit'] = $credit_info['tmp_money'];
		$add_data['usage_limit'] = $all_bill_money;
		$add_data['repay_limit'] = $repay_bill_money;
		$add_data['al_repay_limit'] = $al_repay_imit;
		//$add_data['question_limit'] = $question_bill_money;
		$add_data['year'] = $year;
		$add_data['month'] = $month;
		$add_data['start_time'] = $start_end_time['start_time'];
		$add_data['end_time'] = $start_end_time['end_time'];
		$add_data['end_date'] = date('Y-m-d', strtotime("+{$bill_latest_repay_date} day +1 month" , strtotime(date('Y-m',$start_end_time['end_time']).'-'.$bill_monthly)));
		$add_data['currency_code'] = $transact_curcy;
		$add_data['status'] = $repay_bill_money == $al_repay_imit ? 1 : 2;
		$add_data['addtime'] = $time;

		list($month_bill_id, $rows_affected) = db::insert('#PB#_member_bill_month')
			->set($add_data)->execute();

		if(!empty($month_bill_id))
		{
			if(!empty($month_bill_info))
			{
				//删除相同月份的数据
				$result = db::delete('#PB#_member_bill_month')->where('id', '=', $month_bill_info['id'])->execute();
				if(empty($result))
				{
					$html = "客户ID为：{$member_id} 删除相同月结数据失败！";

					//事务回滚
					db::rollback();
					return $html;
				}

				//删除月结汇率兑现记录
				$result = db::delete('#PB#_member_bill_month_curr')->where('bill_month_id', '=', $month_bill_info['id'])->execute();
				if(empty($result))
				{
					$html = "客户ID为：{$member_id} 删除相同月结汇率兑现记录失败！";

					//事务回滚
					db::rollback();
					return $html;
				}
			}

			/*********************   客户还款开始   ***********************/
			//客户还款, 条件：只有客户账户有余额，并且本月有需还款金额时
			if($member_surplus_money > 0 && $repay_bill_money > 0)
			{
				//修改客户账户余额
				$bank_up = array ();
				$bank_up['money'] = $member_repay_surplus_money;

				$bank_result = db::update('#PB#_member_money_bank')
					->set($bank_up)
					->where('id', '=', $bank_info['id'])
					->execute();

				if(empty($bank_result))
				{
					$html = "客户ID为：{$member_id} 修改账户余额失败！";

					//事务回滚
					db::rollback();
					return $html;
				}

				//添加支出账单流水
				$bill_add_data = array ();
				$push_msg_member_bill_id = $bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['member_info_id'] = $member_id;
				$bill_add_data['bank_card_id'] = $bank_info['id'];
				$bill_add_data['type'] = 1;
				$bill_add_data['currency_code'] = $transact_curcy;
				$bill_add_data['amount'] = -$member_repay_money;
				$bill_add_data['from_type'] = 1;
				$bill_add_data['remark'] = '还款：'.$add_data['year'].'年'.$add_data['month'].'月';
				//$bill_add_data['status'] = 1;
				$bill_add_data['date'] = date('Y-m-d',$time);
				$bill_add_data['addtime'] = $time;

				list($member_bill_add_result, $rows_affected) = db::insert('#PB#_member_bill')
					->set($bill_add_data)->execute();

				if(empty($member_bill_add_result))
				{
					$html = "客户ID为：{$member_id} 新增还款账单记录失败！";

					//事务回滚
					db::rollback();
					return $html;
				}

				//添加支出日志
				$bill_add_data = array ();
				$bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['member_info_id'] = $member_id;
				$bill_add_data['bank_card_id'] = $bank_info['id'];
				$bill_add_data['type'] = 1;
				//$bill_add_data['log_type'] = 4;
				$bill_add_data['currency_code'] = $transact_curcy;
				$bill_add_data['amount'] = -$member_repay_money;
				$bill_add_data['from_type'] = 1;
				$bill_add_data['remark'] = '还款：'.$add_data['year'].'年'.$add_data['month'].'月';
				//$bill_add_data['status'] = 1;
				$bill_add_data['date'] = date('Y-m-d',$time);
				$bill_add_data['addtime'] = $time;

				list($bill_add_result, $rows_affected) = db::insert('#PB#_member_bank_log')
					->set($bill_add_data)->execute();

				if(empty($bill_add_result))
				{
					$html = "客户ID为：{$member_id} 新增还款账单日志失败！";

					//事务回滚
					db::rollback();
					return $html;
				}

				//修改客户使用授信
				$credit_up = array ();
				$credit_up['used_money'] = $credit_info['used_money'] - $member_repay_money;
				$credit_result = db::update('#PB#_member_money_credit')
					->set($credit_up)
					->where('id', '=', $credit_info['id'])
					->execute();

				if(empty($credit_result))
				{
					$html = "客户ID为：{$member_id} 修改客户授信失败！";

					//事务回滚
					db::rollback();
					return $html;
				}

				//添加还款记录
				$repay_add_data = array ();
				$repay_add_data['bill_month_id'] = $month_bill_id;
				$repay_add_data['admin_id'] = $admin_id;
				$repay_add_data['member_info_id'] = $member_id;
				$repay_add_data['repay_limit'] = $repay_bill_money;
				$repay_add_data['al_repay_limit'] = $al_repay_imit;
				$repay_add_data['amount'] = $member_repay_money;
				$repay_add_data['remark'] = '还款';
				$repay_add_data['type'] = 1;
				$repay_add_data['repay_type'] = 2;
				$repay_add_data['date_day'] = date('Y-m-d',$time);
				$repay_add_data['currency_code'] = $transact_curcy;
				$repay_add_data['addtime'] = $time;

				list($bill_repay_result, $rows_affected) = db::insert('#PB#_member_bill_repay')
					->set($repay_add_data)->execute();

				if(empty($bill_repay_result))
				{
					$html = "客户ID为：{$member_id} 新增月结还款记录失败！";

					//事务回滚
					db::rollback();
					return $html;
				}

			}

			/*********************   客户还款结束   ***********************/

			//添加消费货币兑换默认货币兑换记录
			$add_result = true;
			if(!empty($repay_bill_list))
			{
				foreach ($repay_bill_list as $rbk => $rbv)
				{
					$curr_add_data = array ();
					$curr_add_data['admin_id'] = $admin_id;
					$curr_add_data['member_info_id'] = $member_id;
					$curr_add_data['bill_month_id'] = $month_bill_id;
					$curr_add_data['repay_money'] = $rbv['sum'];
					$curr_add_data['drift_percen'] = $clear_rate_per;
					$curr_add_data['default_curr_code'] = $transact_curcy;
					$curr_add_data['currency_code'] = mod_currency_type::to_upper($rbv['currency_code']);
					$curr_add_data['exg_rate'] = $rate_list[$rbv['currency_code']];
					$curr_add_data['exg_money'] = mod_currency_type::get_exg_money($rbv['sum'],$rbv['currency_code']);;
					$curr_add_data['addtime'] = $time;

					list($month_curr_result, $rows_affected) = db::insert('#PB#_member_bill_month_curr')
						->set($curr_add_data)->execute();

					if(empty($month_curr_result))
					{
						$add_result = false;
						break;
					}
				}
			}

			if(!$add_result)
			{
				$html = "客户ID为：{$member_id} 新增月结货币记录失败！";

				//事务回滚
				db::rollback();
				return $html;
			}

		}
		else
		{
			$html = "客户ID为：{$member_id} 生产月结账单失败！";

			//事务回滚
			db::rollback();
			return $html;
		}

		//推送月结账单消息
		$bill_money = $transact_curcy_symbol.mod_member_info::num_format($add_data['repay_limit']);
		$title = lang::get('push_message_bill_title');
		$content = str_replace(array ('#year_month#','#bill_money#'),array ($month,$bill_money),lang::get('push_message_bill_money'));

		mod_app_message::create($add_data['member_info_id'], 0, $title, $content, '', 4, 5, $month_bill_id);

		//推送还款消息
		if($member_repay_money > 0)
		{
			$member_repay_money = $transact_curcy_symbol.mod_member_info::num_format($member_repay_money);
			$title = lang::get('push_message_repay_title');
			if($add_data['status'] == 2) //还款未还清
			{
				$content = str_replace(array ('#year_month#', '#repay_money#'),array ($month, $member_repay_money),lang::get('push_message_repay_unfinished'));
			}
			else //还款已还清
			{
				$content = str_replace(array ('#year_month#', '#repay_money#'),array ($month, $member_repay_money),lang::get('push_message_repay_finished'));
			}

			mod_app_message::create($add_data['member_info_id'], 0, $title, $content, '', 7, 6, $push_msg_member_bill_id);

		}

		//提交事务
		db::commit();

		return true;
	}

	//推送逾期订单
	function make_end_month_bill_message()
	{
		//查询所有到期的商户
		$now_date = date('Y-m-d', time());

		$member_bill_month_where = array ();
		$member_bill_month_where[] = array ('status', '=', 2);
		$member_bill_month_where[] = array ('push_msg_status', '=', 0);
		$member_bill_month_where[] = array ('end_date', '<', $now_date);
		$list = db::select('id,month,member_info_id,repay_limit,al_repay_limit')
			->from('#PB#_member_bill_month')
			->where($member_bill_month_where)
			->execute();

		if (!empty($list))
		{
			db::begin_tran();

			foreach ($list as $k => $v)
			{
				if ($v['al_repay_limit'] == 0)
				{
					$content = str_replace('#year_month#', $v['month'], lang::get('push_message_bill_end_data_unfinished'));
				}
				else
				{
					$content = str_replace('#year_month#', $v['month'], lang::get('push_message_bill_end_data_settle'));
				}

				//推送消息
				$title = lang::get('push_message_bill_title');

				$msg_result = mod_app_message::create($v['member_info_id'], 0, $title, $content, '', 4, 5, $v['id']);
				if (empty($msg_result))
				{
					db::rollback();
					continue;
				}

				//修改账单消息推送状态
				$bill_result = db::update('#PB#_member_bill_month')
					->value("push_msg_status", 1)
					->where('id', '=', $v['id'])
					->execute();

				if (empty($bill_result))
				{
					db::rollback();
					continue;
				}

				db::commit();
			}
		}

		echo '推送消息成功';
	}

	//搜索需要确认的订单
	public function search_order_confirm()
	{
		/*
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("order", $lang);
		lang::load("model", $lang);

		mod_member_bill::$type_list[6] = lang::get('model_thaw');
		*/

		//确定订单的限制时间，超过15天未确认的订单
		$confirm_time = strtotime('-15 day 00:00:00',time());
		$confirm_time = strtotime('-9 day 00:00:00',time());
		$confirm_time = strtotime('-1 minute',time());

		//搜索条件：1。已支付，2。未确认，3。超过限定时间
		$order_where = array ();
		$order_where[] = array ('pay_status', '=', 1);
		$order_where[] = array ('pay_time', '<', $confirm_time);
		//$order_where[] = array ('addtime', '<', $confirm_time);
		$order_where[] = array ('status', '=', 0);

		$order_field = 'order_id,goods_name,shop_id,currency_code,amount,member_info_id';
		$order_list = db::select($order_field)
			->from('#PB#_order')
			->where($order_where)
			->execute();
//		var_dump($sql);
//		var_dump($order_list);die;
		if(empty($order_list))
		{
			var_dump('没有需要确认的订单！');
			return false;
		}

		foreach ($order_list as $k => $order_info)
		{
			$this->confirm_order($order_info);
		}

		var_dump('确认订单成功！');
		return true;
	}

	//确认订单
	function confirm_order($order_info)
	{
		$order_id = $order_info['order_id'];

		//获取该订单的冻结账单
		$bill_where = array ();
		$bill_where[] = array ('order_id', '=', $order_id);
		$bill_where[] = array ('type', '=', 1);

		$member_bank_log_field = array (
			'id',
			'bill_id',
			'order_id',
			'member_info_id',
			'type',
			'bank_card_id',
			'currency_code',
			'amount',
			'from_type',
			'remark',
			'date',
			'addtime',
			'uptime',
		);
		$bill_list = db::select($member_bank_log_field)
			->from('#PB#_member_bank_log')
			->where($bill_where)
			->order_by('id')
			->execute();

		db::begin_tran();

		$member_money_bank_field = array (
			'id',
			'member_info_id',
			'type',
			'currency_code',
			'money',
		);

		$shop_money_bank_field = array (
			'id',
			'shop_id',
			'currency_code',
			'type',
			'money',
		);

		foreach ($bill_list as $k => $v)
		{
			//生成解冻账单日志
			$bill_add_data = array ();
			$bill_add_data['bill_id'] = util::make_bill_id();
			$bill_add_data['order_id'] = $v['order_id'];
			$bill_add_data['member_info_id'] = $v['member_info_id'];
			$bill_add_data['type'] = 6;
			$bill_add_data['bank_card_id'] = $v['bank_card_id'];
			$bill_add_data['currency_code'] = $v['currency_code'];
			$bill_add_data['amount'] = $v['amount'];
			$bill_add_data['from_type'] = 2;
			$bill_add_data['remark'] = lang::get('model_thaw');
			//$bill_add_data['status'] = 1;
			$bill_add_data['date'] = date('Y-m-d',time());
			$bill_add_data['addtime'] = time();

			list($bill_insert_id, $rows_affected) = db::insert('#PB#_member_bank_log')
				->set($bill_add_data)->execute();

			if (empty($bill_insert_id))
			{
				db::rollback();
				return false;
			}

			//查询冻结金额
			$member_bank_where = array ();
			$member_bank_where[] = array ('member_info_id', '=', $v['member_info_id']);
			$member_bank_where[] = array ('currency_code', '=', $v['currency_code']);
			$member_bank_where[] = array ('type', '=', 2);

			$member_bank = db::select($member_money_bank_field)
				->from('#PB#_member_money_bank')
				->where($member_bank_where)
				->as_row()
				->execute();

			if(empty($member_bank))
			{
				db::rollback();
				return false;
			}

			//修改冻结金额
			$member_up_data = array ();
			$member_up_data['money'] = $member_bank['money'] + $v['amount'];

			$result = db::update('#PB#_member_money_bank')
				->set($member_up_data)
				->where($member_bank_where)
				->execute();

			if (empty($result))
			{
				db::rollback();
				return false;
			}

			//生成支出账单
			$bill_add_data = array ();
			$bill_add_data['bill_id'] = util::make_bill_id();
			$bill_add_data['member_info_id'] = $v['member_info_id'];
			$bill_add_data['type'] = 1;
			$bill_add_data['bank_card_id'] = $v['bank_card_id'];
			$bill_add_data['currency_code'] = $v['currency_code'];
			$bill_add_data['amount'] = $v['amount'];
			$bill_add_data['from_type'] = $v['from_type'];
			$bill_add_data['remark'] = lang::get('order_buy').$order_info['goods_name'];
			$bill_add_data['date'] = date('Y-m-d',time());
			$bill_add_data['addtime'] = time();
			$bill_add_data['uptime'] = time();

			list($bill_member_bill_id, $rows_affected) = db::insert('#PB#_member_bill')
				->set($bill_add_data)->execute();

			if (empty($bill_member_bill_id))
			{
				db::rollback();
				return false;
			}

			//生成订单与账单流水关联数据
			$bill_order_link_add = array ();
			$bill_order_link_add['order_id'] = $order_id;
			$bill_order_link_add['bill_id'] = $bill_add_data['bill_id'];

			list($_member_order_bill_link_id, $rows_affected) = db::insert('#PB#_member_order_bill_link')
				->set($bill_order_link_add)->execute();

			if (empty($rows_affected))
			{
				db::rollback();
				return false;
			}

		}

		//增加商户余额
		$shop_bank_where = array ();
		$shop_bank_where[] = array ('shop_id', '=', $order_info['shop_id']);
		$shop_bank_where[] = array ('currency_code', '=', $order_info['currency_code']);

		$shop_bank_info = db::select($shop_money_bank_field)
			->from('#PB#_shop_money_bank')
			->where($shop_bank_where)
			->as_row()
			->execute();

		if (empty($shop_bank_info))
		{
			db::rollback();
			return false;
		}

		$shop_bank_updata = array ();
		$shop_bank_updata['money'] = $shop_bank_info['money'] + $order_info['amount'];
		$result = db::update('#PB#_shop_money_bank')
			->set($shop_bank_updata)
			->where($shop_bank_where)
			->execute();

		if (empty($result))
		{
			db::rollback();
			return false;
		}

		//增加商户账单流水
		$shop_bill_add_date = array ();
		$shop_bill_add_date['bill_id'] = util::make_bill_id();
		//$shop_bill_add_date['member_info_id'] = $order_info['member_info_id'];
		$shop_bill_add_date['bank_card_id'] = $shop_bank_info['id'];
		$shop_bill_add_date['shop_id'] = $order_info['shop_id'];
		$shop_bill_add_date['type'] = '2';
		$shop_bill_add_date['currency_code'] = $order_info['currency_code'];
		$shop_bill_add_date['amount'] = $order_info['amount'];
		$shop_bill_add_date['remark'] = lang::get('order_buy_success');
		$shop_bill_add_date['date'] = date('Y-m-d', time());
		$shop_bill_add_date['addtime'] = time();

		list($result, $rows_affected) = db::insert('#PB#_shop_bill')
			->set($shop_bill_add_date)->execute();

		if (empty($result))
		{
			db::rollback();
			return false;
		}

		//订单与账单流水关联数据
		$bill_order_link_add = array ();
		$bill_order_link_add['order_id'] = $order_info['order_id'];
		$bill_order_link_add['bill_id'] = $shop_bill_add_date['bill_id'];
		list($result, $rows_affected) = db::insert('#PB#_shop_order_bill_link')
			->set($bill_order_link_add)->execute();

		if (empty($rows_affected))
		{
			db::rollback();
			return false;
		}

		//修改订单状态
		$up_order_data = array ();
		$up_order_data['status'] = 2;
		$up_order_data['uptime'] = time();

		$result = db::update('#PB#_order')
			->set($up_order_data)
			->where('order_id', '=', $order_id)
			->execute();

		if(empty($result))
		{
			db::rollback();
			return false;
		}

		//推送消息
		$title = lang::get('push_message_order_title');
		$content = lang::get('push_message_confirm_order_success');

		mod_app_message::create($order_info['member_info_id'], 0, $title, $content, '', 3, 4, $v['order_id']);

		db::commit();

		return true;
	}

	//excel导出
	public function export_excel()
	{
		include '../core/library/phpexcel/PHPExcel.php';
		include '../core/library/phpexcel/PHPExcel/Writer/Excel2007.php';
		$objPHPExcel = new PHPExcel();


		$datas = array(
			array('王城', '男', '18', '1997-03-13', '18948348924'),
			array('李飞虹', '男', '21', '1994-06-13', '159481838924'),
			array('王芸', '女', '18', '1997-03-13', '18648313924'),
			array('郭瑞', '男', '17', '1998-04-13', '15543248924'),
			array('李晓霞', '女', '19', '1996-06-13', '18748348924'),
		);

		$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', '名字')
			->setCellValue('B1', '性别')
			->setCellValue('C1', '年龄')
			->setCellValue('D1', '出生日期')
			->setCellValue('E1', '电话号码');

		// Rename worksheet
		$objPHPExcel->getActiveSheet()->setTitle('标题Phpmarker-' . date('Y-m-d'));

		// Set active sheet index to the first sheet, so Excel opens this as the first sheet
		$objPHPExcel->setActiveSheetIndex(0);
		$objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(15);
		$objPHPExcel->getActiveSheet()->freezePane('A2');

		$i = 2;
		foreach($datas as $data){
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $data[0])->getStyle('A'.$i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::VERTICAL_CENTER);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $i, $data[1]);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $i, $data[2]);
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('D'. $i, $data[3],PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->getStyle('D' . $i)->getNumberFormat()->setFormatCode("@");

			// 设置文本格式
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('E'. $i, $data[4],PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->getStyle('E' . $i)->getAlignment()->setWrapText(true);
			$i++;
		}

		//22222
		$objPHPExcel->createSheet();
		$objPHPExcel->setActiveSheetIndex(1)
			->setCellValue('A1', '名字')
			->setCellValue('B1', '性别')
			->setCellValue('C1', '年龄')
			->setCellValue('D1', '出生日期')
			->setCellValue('E1', '电话号码');

		// Rename worksheet
		$objPHPExcel->getActiveSheet()->setTitle('标题Phpmarker-' . date('Y-m-d'));

		// Set active sheet index to the first sheet, so Excel opens this as the first sheet
		$objPHPExcel->setActiveSheetIndex(1);
		$objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(15);
		$objPHPExcel->getActiveSheet()->freezePane('A2');

		$k = 2;
		foreach($datas as $data){
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $k, $data[0])->getStyle('A'.$k)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::VERTICAL_CENTER);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $k, $data[1]);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $k, $data[2]);
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('D'. $k, $data[3],PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->getStyle('D' . $k)->getNumberFormat()->setFormatCode("@");

			// 设置文本格式
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('E'. $k, $data[4],PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->getStyle('E' . $k)->getAlignment()->setWrapText(true);
			$k++;
		}

		$objActSheet = $objPHPExcel->getActiveSheet();

		//设置宽度
		$objActSheet->getColumnDimension('A')->setWidth(18.5);
		$objActSheet->getColumnDimension('B')->setWidth(23.5);
		$objActSheet->getColumnDimension('C')->setWidth(12);
		$objActSheet->getColumnDimension('D')->setWidth(12);
		$objActSheet->getColumnDimension('E')->setWidth(12);

		$filename = '2015030423';
		ob_end_clean();//清除缓冲区,避免乱码
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="'.$filename.'.xls"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');
		// If you're serving to IE over SSL, then the following may be needed
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
		header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header('Pragma: public'); // HTTP/1.0
		$objWriter = new PHPExcel_Writer_Excel5($objPHPExcel);
		$objWriter->save('php://output');
	}

	//测试数据库
	public function test()
	{

		var_dump('success');
	}

}