<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 商品管理
 *
 * @version $Id$
 */
class ctl_goods
{
	//商品状态
	private $goods_status = array(
		0 => '待审核',
		1 => '正常',
		2 => '被驳回',
		3 => '商户下架',
		4 => '管理员下架',
	);

	//是否自动确认
	private $is_auto_confirm = array (
		0 => '否',
		1 => '是',
	);

	//是否自动确认
	private $audit_status = array (
		0 => '待审核',
		1 => '审核通过',
		2 => '审核不通过',
	);

	/**
	 * 构造函数
	 * @return void
	 */
	public function __construct()
	{
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("goods", $lang);
		lang::load("shop", $lang);
		lang::load("model", $lang);

		$this->goods_status[0] = lang::get('goods_audit_pending');
		$this->goods_status[1] = lang::get('goods_normal');
		$this->goods_status[2] = lang::get('goods_audit_no_pass');
		$this->goods_status[3] = lang::get('goods_shop_under');
		$this->goods_status[4] = lang::get('goods_admin_under');

		$this->is_auto_confirm[0] = lang::get('goods_no');
		$this->is_auto_confirm[1] = lang::get('goods_yes');

		$this->audit_status[0] = lang::get('goods_audit_pending');
		$this->audit_status[1] = lang::get('goods_audit_pass');
		$this->audit_status[2] = lang::get('goods_audit_no_pass');
	}

	//待审核列表
	public function index()
	{
		$this->_list(0);
	}

	//销售中列表
	public function pass_list()
	{
		$this->_list(1);
	}

	//已驳回列表
	public function reject_list()
	{
		$this->_list(2);
	}

	//已下架列表
	public function under_list()
	{
		$this->_list(3);
	}

	//受理中列表
	public function accepting_list()
	{
		$this->_list(4);
	}

	//已受理列表
	public function accepted_list()
	{
		$this->_list(5);
	}

	/**
	 * 商品列表
	 *
	 * @param $type_list: 0:待审核，1：销售中，2：已驳回，3：已下架
	 *
	 */
	private function _list($type_list)
	{
		$keyword = req::item('keyword', '');

		$where = array();
		if (!empty($keyword))
		{
			$where[] = array ('name', 'like', '%'.$keyword.'%');
		}

		$admin_id = cls_auth::$user->fields['uid'];
		switch ($type_list)
		{
			case 0:
					$where[] = array ('status', '=', 0);
				break;

			case 1:
					$where[] = array ('status', '=', 1);
				break;

			case 2:
					$where[] = array ('status', '=', 2);
				break;
			case 3:
					$where[] = array ('status', 'in', array (3,4));
				break;
			case 4:
					$where[] = array ('status', '=', 0);
					$where[] = array ('audit_id', '=', $admin_id);
				break;
			case 5:
					$where[] = array ('status', 'in', array (1,2));
					$where[] = array ('audit_id', '=', $admin_id);
				break;
		}

		$count = mod_goods::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_goods::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				//商户信息
				$shop_info = mod_shop::find($v['shop_id'], 'catid,name');
				$list[$k]['shop_name'] = empty($shop_info) ? '' : $shop_info['name'];

				$list[$k]['price'] = mod_member_info::num_format($v['price']);
				$list[$k]['shop_cate_name'] = '';
				if (!empty($shop_info))
				{
					//商户分类
					$shop_cate_info = mod_shop_category::find($shop_info['catid'], 'name');
					$list[$k]['shop_cate_name'] = empty($shop_cate_info) ? '' : $shop_cate_info['name'];
				}

				$list[$k]['add_date'] = date('Y-m-d H:i:s', $v['addtime']);
				$list[$k]['status_name'] = isset($this->goods_status[$v['status']]) ? $this->goods_status[$v['status']] : '';
				$list[$k]['auto_confirm_name'] = isset($this->is_auto_confirm[$v['is_auto_confirm']]) ? $this->is_auto_confirm[$v['is_auto_confirm']] : '';

			}
		}

		tpl::assign('list', $list);
		tpl::assign('type_list', $type_list);
		tpl::assign('pages', $pages['show']);
		tpl::display('goods.index.tpl');
	}

	//查看详情
	public function info()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$info = mod_goods::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		//商户信息
		$shop_info = mod_shop::find($info['shop_id'], 'catid,name');
		$info['shop_name'] = empty($shop_info) ? '' : $shop_info['name'];

		//商品分类
		$cate_info = mod_goods_category::find($info['cateid']);
		$info['cate_name'] = empty($cate_info) ? '' : $cate_info['name'];

		$info['price'] = mod_member_info::num_format($info['price']);
		$info['status_name'] = isset($this->goods_status[$info['status']]) ? $this->goods_status[$info['status']] : '';
		$info['auto_confirm_name'] = isset($this->is_auto_confirm[$info['is_auto_confirm']]) ? $this->is_auto_confirm[$info['is_auto_confirm']] : '';
		//$info['audit_status_name'] = isset($this->audit_status[$info['audit_status']]) ? $this->audit_status[$info['audit_status']] : '';
		$info['add_date'] = date('Y-m-d H:i:s', $info['addtime']);

		//返回URL
		$this->_get_gourl();

		tpl::assign('info', $info);
		tpl::assign('admin_id', cls_auth::$user->fields['uid']);
		tpl::display('goods.info.tpl');
	}

	//上架
	public function goods_up()
	{
		$this->_up_and_down();
	}

	//下架
	public function goods_down()
	{
		$this->_up_and_down();
	}

	//上架与下架
	private function _up_and_down()
	{
		$id = req::item('id');
		//1：上架，2：下架
		$status = req::item('status');
		$type_list = req::item('type_list','0', 'int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$info = mod_goods::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$update_data = array ();
		$update_data['uptime'] = time();
		if($status == 1)
		{
			$update_data['status'] = 1;
			//$update_data['audit_status'] = 1;
		}
		else
		{
			$update_data['status'] = 4;
			//$update_data['audit_status'] = 0;
		}

		$result = mod_goods::update_data(array ('id', '=', $id), $update_data);
		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('goods_up_and_down')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $this->_get_gourl());
	}

	//查看照片
	public function show_pics()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$info = mod_goods::find($id, 'pics');
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$pics = array ();
		$pics = empty($info['pics']) ? $pics : explode(',', $info['pics']);

		foreach ($pics as $k => $v)
		{
			$pics[$k] = URL_UPLOADS.'/image/'.$v;
		}
		tpl::assign('pics', $pics);
		tpl::display('modal.pics.view.tpl');
	}

	//同意
	public function agree()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$info = mod_goods::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		if($info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		$update_data = array ();
		$update_data['status'] = 1;
		$update_data['uptime'] = time();

 		$result = mod_goods::update_data(array ('id', '=', $id), $update_data);
		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('goods_audit_pass')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $this->_get_gourl());
	}

	//驳回
	public function reject()
	{
		$id = req::item('id');
		$audit_fail_reason = req::item('audit_fail_reason');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		if(empty($audit_fail_reason))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_entry_audit_reason'), '-1');
		}

		$info = mod_goods::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		if($info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		$update_data = array ();
		$update_data['status'] = 2;
		$update_data['audit_fail_reason'] = $audit_fail_reason;
		$update_data['uptime'] = time();

		$result = mod_goods::update_data(array ('id', '=', $id), $update_data);
		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('goods_audit_pass')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $this->_get_gourl());
	}

	//获取返回的地址
	private function _get_gourl()
	{
		$type_list = req::item('type_list','0', 'int');

		$gourl = '-1';

		switch ($type_list)
		{
			case 0:
				$gourl = "?ct=goods&ac=index";
				break;
			case 1:
				$gourl = "?ct=goods&ac=pass_list";
				break;
			case 2:
				$gourl = "?ct=goods&ac=reject_list";
				break;
			case 3:
				$gourl = "?ct=goods&ac=under_list";
				break;
			case 4:
				$gourl = "?ct=goods&ac=accepting_list";
				break;
			case 5:
				$gourl = "?ct=goods&ac=accepted_list";
				break;
		}

		tpl::assign('type_list', $type_list);
		tpl::assign('gourl', $gourl);

		return $gourl;
	}

	//受理
	public function accepte()
	{
		$id = req::item('id');
		$type_list = req::item('type_list','0', 'int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$info = mod_goods::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('goods_select_goods'), '-1');
		}

		$update_data = array ();
		$update_data['audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		$result = mod_goods::update_data(array ('id', '=', $id), $update_data);
		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('goods_accepte')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_acceptance_success'), "?ct=goods&ac=info&id={$id}&type_list={$type_list}");
	}
}
