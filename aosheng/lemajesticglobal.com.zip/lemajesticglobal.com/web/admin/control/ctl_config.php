<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 配置管理
 *
 * @version $Id$
 */
class ctl_config
{
    public static $options = array(
        1 => '基本配置',
        2 => '附件设置',
        3 => '文档设置',
		//100=>'平台设置',//这个不不能使用
    );

    //授信模式
	public static $credit_mode_list = array (
		1 => '浮动',
		2 => '固定',
	);

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("config", $lang);
		lang::load("system_setting", $lang);

		self::$options[1] = lang::get('config_basic_settings');
		self::$options[2] = lang::get('config_attachment_settings');
		self::$options[3] = lang::get('config_document_settings');

		self::$credit_mode_list[1] = lang::get('config_float');
		self::$credit_mode_list[2] = lang::get('config_fixed');

        tpl::assign( 'options', self::$options );
        tpl::assign( 'groupid', 1 );
    }

	/**
	 * 管理员帐号管理
	 */
	public function index()
	{
		$keyword = req::item('keyword', '');
		$groupid = req::item('groupid', 1);

		$where = array();
		if (!empty($keyword))
		{
			$where[] = array( 'name', 'like', '%$keyword%' );
		}
		if (!empty($groupid))
		{
			$where[] = array( 'groupid', '=', $groupid );
		}

		$row = db::select('count(*) AS `count`')->from('#PB#_config')->where($where)->as_row()->execute();
		$pages = pub_page::make($row['count'], 10);
		$list = db::select()->from('#PB#_config')->where($where)->order_by('sort', 'asc')->limit($pages['page_size'])->offset($pages['offset'])->execute();

		tpl::assign('groupid', $groupid);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('config.index.tpl');
	}

	public function add()
	{
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$row = db::select('count(*) AS `count`')->from('#PB#_config')->where('name', $name)->as_row()->execute();

			if( $row['count'] )
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('config_var_name_exit'), '-1');
				exit();
			}

			db::insert('#PB#_config')->set(array(
											   'name'    => req::item('name'),
											   'groupid' => req::item('groupid'),
											   'title'   => req::item('title'),
											   'info'    => req::item('info'),
											   'value'   => req::item('value'),
											   'sort'    => req::item('sort'),
										   ))
				->execute();

			config::reload();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('config_add_config')." {$name}");

			$gourl = req::item('gourl', '?ct=config&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_add'), $gourl);
		}
		else
		{
			$gourl = '?ct=config&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::display('config.add.tpl');
		}
	}

	public function edit()
	{
		$name = req::item('name', '');
		if (!empty(req::$posts))
		{
			db::update('#PB#_config')->set(array(
											   'name'    => req::item('name'),
											   'groupid' => req::item('groupid'),
											   'title'   => req::item('title'),
											   'info'    => req::item('info'),
											   'value'   => req::item('value'),
											   'sort'    => req::item('sort'),
										   ))
				->where('name', $name)
				->execute();

			config::reload();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('config_edit_config')." {$name}");

			$gourl = req::item('gourl', '?ct=config&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
		}
		else
		{
			$v = db::select()->from('#PB#_config')->where('name', $name)->as_row()->execute();
			tpl::assign('v', $v);
			$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=config&ac=index' : $_SERVER['HTTP_REFERER'];
			tpl::assign('gourl', $gourl);
			tpl::display('config.edit.tpl');
		}
	}

	public function del()
	{
		$ids = implode(',', req::item('ids', 0));
		db::delete('#PB#_config')->where('sort', 'in', $ids)->execute();

		config::reload();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('config_delete_config')." {$ids}");

		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=config&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_delete'), $gourl);
	}

	public function batch_edit()
	{
		$sorts = req::item('sorts', array());
		$datas = req::item('datas', array());
		foreach ($sorts as $name=>$sort)
		{
			db::update('#PB#_config')->set(array(
											   'sort' => $sort
										   ))->where('name', $name);
		}
		foreach ($datas as $name=>$value)
		{
			db::update('#PB#_config')->set(array(
											   'value' => $value
										   ))->where('name', $name);
		}

		config::reload();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('config_batch_edit_config'));

		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=config&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('config_batch_edit_success'), $gourl);
	}

	//平台配置
	public function platform()
	{
		if (!empty(req::$posts))
		{
			req::$forms['shop_auth_switch'] = req::item('shop_auth_switch',0);
			req::$forms['shop_freeze_switch'] = req::item('shop_freeze_switch',0);
			req::$forms['shop_max_switch'] = req::item('shop_max_switch',0);
			unset(req::$forms['ac']);
			unset(req::$forms['ct']);
			unset(req::$forms['gourl']);

			foreach (req::$forms as $name=>$data)
			{
				db::update('#PB#_config')
					->value("value", $data)
					->where('name', '=', $name)
					->execute();
			}

			config::reload();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('config_platform_config_edit'));

			$gourl = req::item('gourl', '?ct=config&ac=platform');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
		}
		else
		{
			//分配日期
			for($i=1;$i<=28;$i++)
			{
				$month_day_list[$i] = $i;
			}
			$sql = "SELECT `name`,`value` FROM `#PB#_config` WHERE `groupid`=100";
			$rows = db::get_all($sql);
			foreach ($rows as $k=>$v)
			{
				$list[$v['name']] = $v['value'];
			}

			$gourl = '?ct=config&ac=platform';
			tpl::assign('credit_mode_list', self::$credit_mode_list);
			tpl::assign('month_day_list', $month_day_list);
			tpl::assign('info', $list);
			tpl::assign('cucy_list', mod_currency_type::get_key_val());
			tpl::assign('gourl', $gourl);
			tpl::display('config.platform.tpl');
		}

	}
}
