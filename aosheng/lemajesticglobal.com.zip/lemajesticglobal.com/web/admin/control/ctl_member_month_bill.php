<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 客户月结账单管理
 *
 * @version $Id$
 */
class ctl_member_month_bill
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("member", $lang);
		lang::load("month_bill", $lang);
		lang::load("currency", $lang);
		lang::load("bill", $lang);
		lang::load("model", $lang);

        mod_member_bill_month::$status_list[1] = lang::get('model_closed');
        mod_member_bill_month::$status_list[2] = lang::get('model_open');
    }

	//未结清
	public function index()
	{
		$this->_list(2);
	}

	//已结清
	public function settle()
	{
		$this->_list(1);
	}

	//月结账单
	private function _list($status)
	{
		$keyword = req::item('keyword', '');

		$bill_where = array();

		if(!empty($keyword))
		{
			$member_info_where = array ();
			$member_info_where['or'][] = array ('code', 'like', $keyword.'%');
			$member_info_where['or'][] = array ('custom_code', 'like', $keyword.'%');
			$mem_list = mod_member_info::get_list($member_info_where, 'id');
			if(empty($mem_list))
			{
				$bill_where[] = array ('member_info_id', '=', 0);
			}
			else
			{
				foreach ($mem_list as $k => $v)
				{
					$mem_ids[] = $v['id'];
				}
				$bill_where[] = array ('member_info_id', 'in', $mem_ids);
			}
		}

		//查询月账单
		$bill_where[] = array ('status', '=', $status);

		$count = mod_member_bill_month::get_count($bill_where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_member_bill_month::get_list($bill_where, '', $pages['page_size'], $pages['offset']);

		//货币类型
		$currency_list = mod_currency_type::get_key_val();

		$now_time = time();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$member_info = mod_member_info::find($v['member_info_id']);
				$end_time = strtotime($v['end_date'].' 23:59:59');

				$list[$k]['repay_limit'] = mod_member_info::num_format($v['repay_limit']);
				$list[$k]['al_repay_limit'] = mod_member_info::num_format($v['al_repay_limit']);
				$list[$k]['surplus_limit'] = mod_member_info::num_format($v['repay_limit'] - $v['al_repay_limit']);
				$list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
				$list[$k]['member_code'] = empty($member_info) ? '' : $member_info['code'];
				$list[$k]['member_name'] = empty($member_info) ? '' : $member_info['name'];

				//判断是否逾期
				if($now_time > $end_time)
				{
					if($v['al_repay_limit'] == $v['repay_limit']  || $v['repay_limit'] == 0)
					{
						$list[$k]['status_name'] = lang::get('month_bill_has_cleared');
					}
					elseif($v['al_repay_limit'] == 0)
					{
						$list[$k]['status_name'] = lang::get('month_bill_overdue');
					}
					else
					{
						$list[$k]['status_name'] = lang::get('month_bill_overdue_settlement');
					}
				}
				else
				{
					if($v['al_repay_limit'] == 0 && $v['repay_limit'] != 0)
					{
						$list[$k]['status_name'] = lang::get('month_bill_open');
					}
					elseif($v['al_repay_limit'] == $v['repay_limit']  || $v['repay_limit'] == 0)
					{
						$list[$k]['status_name'] = lang::get('month_bill_has_cleared');
					}
					else
					{
						$list[$k]['status_name'] = lang::get('month_bill_not_settled');
					}
				}
			}
		}

		tpl::assign('status', $status);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('member_month_bill.index.tpl');
	}

	//月结账单详情
	public function info()
	{
		$id = req::item('id');

		$info = mod_member_bill_month::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('month_bill_info_no_exist'), '-1');
		}

		//货币类型
		$currency_list = mod_currency_type::get_key_val();

		$info['currency_name'] = isset($currency_list[$info['currency_code']]) ? $currency_list[$info['currency_code']] : '';
		$info['surplus_limit'] = mod_member_info::num_format($info['repay_limit'] - $info['al_repay_limit']);
		$info['repay_limit'] = mod_member_info::num_format($info['repay_limit']);
		$info['al_repay_limit'] = mod_member_info::num_format($info['al_repay_limit']);

		$now_time = time();
		$end_time = strtotime($info['end_date'].' 23:59:59');

		//判断是否逾期
		if($now_time > $end_time)
		{
			if($info['al_repay_limit'] == 0 || $info['repay_limit'] == 0)
			{
				$info['status_name'] = lang::get('month_bill_overdue');
			}
			else
			{
				$info['status_name'] = lang::get('month_bill_overdue_settlement');
			}
		}
		else
		{
			if($info['al_repay_limit'] == 0  && $info['repay_limit'] != 0)
			{
				$info['status_name'] = lang::get('month_bill_open');
			}
			elseif($info['al_repay_limit'] == $info['repay_limit'] || $info['repay_limit'] == 0)
			{
				$info['status_name'] = lang::get('month_bill_has_cleared');
			}
			else
			{
				$info['status_name'] = lang::get('month_bill_not_settled');
			}
		}

		//获取客户信息
		$member_info = mod_member_info::find($info['member_info_id']);
		$member_info['sex_name'] = isset(mod_member_info::$sex_list[$member_info['gender']]) ? mod_member_info::$sex_list[$member_info['gender']] : '';

		tpl::assign('info', $info);
		tpl::assign('member_info', $member_info);
		tpl::assign('gourl', '?ct=member_month_bill&ac=index');
		tpl::display('member_month_bill.info.tpl');
	}

	//月结账单流水
	public function bill_list()
	{
		$id = req::item('id');

		$info = mod_member_bill_month::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('month_bill_info_no_exist'), '-1');
		}

		//获取客户信息
		$member_info = mod_member_info::find($info['member_info_id']);

		//货币类型
		$currency_list = mod_currency_type::get_key_val();

		//需还款消费金额
		$repay_bill_where = array ();
		$repay_bill_where[] = array ('member_info_id', '=', $info['member_info_id']);
		$repay_bill_where[] = array ('from_type', '=', 2);
		$repay_bill_where[] = array ('type', 'in', array (1,2));
		$repay_bill_where[] = array ('addtime', '>=', $info['start_time']);
		$repay_bill_where[] = array ('addtime', '<=', $info['end_time']);

		$count = mod_member_bill::get_count($repay_bill_where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$bill_list = mod_member_bill::get_list($repay_bill_where, '', $pages['page_size'], $pages['offset']);

		foreach ($bill_list as $k => $v)
		{
			$bill_list[$k]['add_date'] = date('Y-m-d H:i:s',$v['addtime']);
			$bill_list[$k]['amount'] = mod_member_info::num_format($v['amount']);
			$bill_list[$k]['type_name'] = isset(mod_member_bill::$type_list[$v['type']]) ? mod_member_bill::$type_list[$v['type']] : '';
			$bill_list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
		}

		tpl::assign('info', $info);
		tpl::assign('member_info', $member_info);
		tpl::assign('pages', $pages['show']);
		tpl::assign('bill_list', $bill_list);
		tpl::assign('gourl', '?ct=member_month_bill&ac=index');
		tpl::display('member_month_bill.bill_list.tpl');
	}
}
