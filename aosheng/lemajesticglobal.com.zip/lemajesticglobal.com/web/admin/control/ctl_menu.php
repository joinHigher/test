<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 栏目管理
 *
 * @version $Id$
 */
class ctl_menu
{
    public static $options = array(0 => '所有分类');
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $rows = db::get_all("Select `id`,`name` From `#PB#_category`");
        foreach ($rows as $row) 
        {
            self::$options[$row['id']] = $row['name'];
        }
        tpl::assign( 'options', self::$options );
        tpl::assign( 'catid', 0 );
    }

    public function index()
    {
        $keyword = req::item('keyword', '');
        $catid   = req::item('catid', 0);

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = "(`name` Like '%{$keyword}%')";
        }
        if (!empty($catid)) 
        {
            $where[] = "`catid`='{$catid}'";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select Count(*) AS count From `#PB#_menu` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count'], 10);
        $sql = "Select * From `#PB#_menu` {$where} Order By `id` Asc Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);
        foreach ($list as $k=>$v) 
        {
            $list[$k]['imageurl'] = URL_UPLOADS."/image/".$v['image'];
        }

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('menu.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $title = req::item('title');
            $row = db::get_one("Select * From `#PB#_menu` Where `title`='{$title}'");
            if( is_array($row) )
            {
                cls_msgbox::show(lang::get('common_system_hint'), '标题已经存在！', '-1');
                exit();
            }

            req::$forms['images'] = empty(req::$forms['images']) ? '' : implode(",", req::$forms['images']);
            req::$forms['uid'] = cls_auth::$user->fields['uid'];
            req::$forms['addtime'] = req::$forms['uptime'] = time();

            $insert_id = db::insert('#PB#_menu', req::$forms);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "栏目添加 {$insert_id}");

            $gourl = req::item('gourl', '?ct=menu&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), "添加成功", $gourl);
        }
        else 
        {
            $gourl = '?ct=menu&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('menu.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
            $title = req::item('title');
            $row = db::get_one("Select * From `#PB#_menu` Where `title`='{$title}' And `id`!='{$id}'");
            if( is_array($row) )
            {
                cls_msgbox::show(lang::get('common_system_hint'), '标题已经存在！', '-1');
                exit();
            }

            req::$forms['images'] = empty(req::$forms['images']) ? '' : implode(",", req::$forms['images']);
            req::$forms['uptime'] = time();

            db::update('#PB#_menu', req::$forms, "`id`='{$id}'");

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "栏目修改 {$id}");

            $gourl = req::item('gourl', '?ct=menu&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), "修改成功", $gourl);
        }
        else 
        {
            $sql = "Select * From `#PB#_menu` Where `id`={$id} Limit 1";
            $v = db::get_one($sql);
            $v['imageurl'] = empty($v['image']) ? 'static/img/addimage.png' : URL_UPLOADS."/image/".$v['image'];
            if (empty($v['images'])) 
            {
                $v['images'] = array();
            }
            else 
            {
                $images = explode(",", $v['images']);
                $image_arr = array();
                foreach ($images as $image) 
                {
                    $image_arr[] = array(
                        'filename' => $image,
                        'filelink' => URL_UPLOADS."/image/".$image,
                    );
                }
                $v['images'] = $image_arr;
            }
            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=menu&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::assign('v', $v);
            tpl::display('menu.edit.tpl');
        }
    }

    public function del()
    {
        $id = req::item('id', 0);
        $sql = "Delete From `#PB#_menu` Where `id`='{$id}'";
        db::query($sql);

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "栏目删除 {$id}");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=menu&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show(lang::get('common_system_hint'), "删除成功", $gourl);
    }

}
