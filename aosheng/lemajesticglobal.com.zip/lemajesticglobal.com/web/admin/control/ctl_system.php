<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 系统管理
 *
 * @version $Id$
 */
class ctl_system
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("config", $lang);
    }

    /**
     * 后台管理菜单
     */
    public function edit_member_menu()
    {
        $this->_edit_hidden_config('admin_menu', lang::get('config_platform_menu_set'), lang::get('config_platform_menu_tips'), lang::get('config_platform_menu_edit'), 'edit_member_menu', 450);
    }

    /**
     *  单项配置修改
     */
    private function _edit_hidden_config($key, $dotitle, $info, $alert_msg, $ac, $area_height=350)
    {
        tpl::assign('dotitle', $dotitle);
        tpl::assign('info', $info);
        tpl::assign('c_ac', $ac);
        tpl::assign('area_height', $area_height);
        if( !isset(req::$forms['new_value']) )
        {
            $value = config::get( $key );
            tpl::assign('value', $value);
            tpl::display( 'system.edit_hidden_config.tpl' );
        }
        else
        {
            config::save($key, req::$forms['new_value']);
            cls_auth::save_admin_log( cls_auth::$user->fields['username'], lang::get('config_platform_system_set')." {$key} ".lang::get('config_platform_project_value'));
            cls_msgbox::show(lang::get('common_system_hint'), $alert_msg, '?ct=system&ac='.$ac);
        }
    }

}
