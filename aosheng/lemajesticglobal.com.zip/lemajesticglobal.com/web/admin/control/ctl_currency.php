<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 汇率管理
 *
 * @version $Id$
 */
class ctl_currency
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("currency", $lang);

		//获取默认汇率
		$transact_curcy = config::get('transact_curcy');
		$curcy_list = mod_currency_type::get_key_val();
		tpl::assign('curcy_name', $curcy_list[$transact_curcy]);
    }

    /**
     * 列表
     */
    public function index()
    {
        $keyword = req::item('keyword', '');

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = array ('name', 'like', '%'.$keyword.'%');
        }

        /*
        $sql = "Select Count(*) AS count From `#PB#_currency_type` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count'], 10);
        $sql = "Select * From `#PB#_currency_type` {$where} Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);
		*/
        $list = mod_currency_type::get_all_list();

        tpl::assign('list', $list);
//        tpl::assign('pages', $pages['show']);
        tpl::display('currency.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts))
		{
			$name = req::item('name');
			$code_name = req::item('code_name');

			$row_where['or'][] = array ('name', '=', $name);
			$row_where['or'][] = array ('code_name', '=', $code_name);
			$row = mod_currency_type::get_info($row_where, 'id');
			if (is_array($row))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('currency_name_already_exists'), '-1');
			}

			$add_data = array ();
			$add_data['name'] = req::$forms['name'];
			$add_data['code_name'] = mod_currency_type::to_upper(req::$forms['code_name']);
			$add_data['symbol'] = req::$forms['symbol'];
			$add_data['exg_rate'] = req::$forms['exg_rate'];
			$add_data['uptime'] = $add_data['addtime'] = time();

			$result = mod_currency_type::add_data($add_data);

			if (!empty($result))
			{
				mod_currency_type::clear_all_cache();
			}

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('currency_add')." {$name}");

            $gourl = req::item('gourl', '?ct=currency&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_add'), $gourl);
        }
        else 
        {
            $gourl = '?ct=currency&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('currency.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item('id', '');

        if (!empty(req::$posts)) 
        {
        	if(empty($id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('currency_select_info'), '-1');
				exit();
			}

			$name = req::item('name');
			$code_name = req::item('code_name');

			$row_where['and'][] = array ('id', '!=', $id);
			$row_where['or'][] = array ('name', '=', $name);
			$row_where['or'][] = array ('code_name', '=', $code_name);
			$row = mod_currency_type::get_info($row_where, 'id');

			if( is_array($row) )
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('currency_name_already_exists'), '-1');
			}

			$edit_data = array ();
			$edit_data['name'] = req::$forms['name'];
			$edit_data['code_name'] = mod_currency_type::to_upper(req::$forms['code_name']);
			$edit_data['symbol'] = req::$forms['symbol'];
			$edit_data['exg_rate'] = req::$forms['exg_rate'];
			$edit_data['uptime'] = time();

			$result = mod_currency_type::update_data(array ('id', $id), $edit_data);

			if (!empty($result))
			{
				mod_currency_type::clear_all_cache();
			}

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('currency_edit')." {$name}");

			$gourl = req::item('gourl', '?ct=currency&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
        }
        else 
        {
            $info = mod_currency_type::find($id);
            tpl::assign('info', $info);
            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=currency&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::display('currency.edit.tpl');
        }
    }

	//批量修改
	public function batch_edit()
	{
		$ids = req::item('id');
		$exg_rates = req::item('exg_rate');
		
		if(!empty($ids))
		{
			foreach ($ids as $k => $id)
			{
				$update_data['exg_rate'] = $exg_rates[$k];

				mod_currency_type::update_data(array ('id', $id), $update_data);
			}

			mod_currency_type::clear_all_cache();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('currency_batch_edit'));

		}

		$gourl = req::item('gourl', '?ct=currency&ac=index');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
	}

}
