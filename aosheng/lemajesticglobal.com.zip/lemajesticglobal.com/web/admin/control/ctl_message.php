<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 消息管理
 *
 * @version $Id$
 */
class ctl_message
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("message", $lang);
    }

    public function index()
	{
        $keyword = req::item('keyword', '');

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = array ('title', 'like', '%'.$keyword.'%');
        }

		$where[] = array ('type', '=', 1);

        $count = mod_push_message::get_count($where);
        $pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_push_message::get_list($where, '', $pages['page_size'], $pages['offset']);

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('message.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $title = req::item('title');
            $content = req::item('content');
            $link = req::item('link');

            if(empty($content) && empty($link))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('message_content_select_one'), '-1');
			}

            $info_where = array ();
            $info_where[] = array ('title', '=', $title);
            $info_where[] = array ('type', '=', 1);
            $row = mod_push_message::get_info($info_where);

            if( is_array($row) )
            {
                cls_msgbox::show(lang::get('common_system_hint'), lang::get('message_title_exist'), '-1');
            }

            req::$forms['addtime'] = req::$forms['uptime'] = time();

			$insert_id = mod_push_message::add_data(req::$forms);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('message_add')." {$insert_id}");

            $gourl = req::item('gourl', '?ct=message&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_add'), $gourl);
        }
        else 
        {
            $gourl = '?ct=message&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('message.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
			$title = req::item('title');
			$content = req::item('content');
			$link = req::item('link');

			if(empty($id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
			}

			if(empty($content) && empty($link))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('message_content_select_one'), '-1');
			}

			$info_where = array ();
			$info_where[] = array ('title', '=', $title);
			$info_where[] = array ('type', '=', 1);
			$info_where[] = array ('id', '!=', $id);
			$row = mod_push_message::get_info($info_where);

            if( is_array($row) )
            {
                cls_msgbox::show(lang::get('common_system_hint'), lang::get('message_title_exist'), '-1');
            }

            req::$forms['uptime'] = time();

			mod_push_message::update_data(array ('id', '=', $id), req::$forms);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('message_edit')." {$id}");

            $gourl = req::item('gourl', '?ct=message&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
        }
        else 
        {

			$info = mod_push_message::find($id);

            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=message&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::assign('info', $info);
            tpl::display('message.edit.tpl');
        }
    }

    public function del()
    {
        $id = req::item('id', 0);

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		mod_push_message::del_data(array ('id', '=', $id));

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('message_delete')." {$id}");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=message&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_delete'), $gourl);
    }

}
