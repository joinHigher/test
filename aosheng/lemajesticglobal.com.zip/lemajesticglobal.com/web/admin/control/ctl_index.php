<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 后台管理控制器
 *
 * @version $Id$
 */
class ctl_index
{
	public function __construct()
	{
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("menu", $lang);
		lang::load("index", $lang);

	}

	/**
	 * 主入口
	 */
	public function index()
	{
		//$t1 = microtime(true);
		//print_r(lang::$language);
		// is_ajax 为 true 能去掉调试信息
		//call::$is_ajax = true;
		//$menus = mod_admin_menu::parse_menu_three();
		//$menus = mod_admin_menu::parse_menu_two();
		mod_admin_menu::$menu_key = "admin_menu";
		$menus = mod_admin_menu::parse_menu();
		$menus = lang::tpl_change($menus);
		tpl::assign('user', cls_auth::$user->fields );
		tpl::assign('menus', $menus);
		tpl::assign('URL_WEBSOCKET', URL_WEBSOCKET);
		tpl::assign('language_list', $this->_language_list());
		tpl::assign('lang_array', json_encode(lang::$language, JSON_UNESCAPED_UNICODE));
		if ($GLOBALS['config']['frame_ui'] == 1)
		{
			tpl::display('index.tpl');
		}
		else
		{
			tpl::display('index2.tpl');
		}
	}

	/**
	 * 用户登录
	 */
	public function login()
	{
		$username = req::item('username', '');
		$password = req::item('password', '');
		$validate = req::item('validate', '');
		$gourl = req::item('gourl', '');
		$rs = 0;
		$errmsg = '';

		if( $username != '' && $password != '' )
		{
			/*
			$vdimg = new cls_securimage();
			if( empty($validate) || !$vdimg->check($validate) )
			{
				$errmsg = '请输入正确的验证码！';
			}
			else
			{*/
			try
			{
				$rs = cls_auth::$user->check_user(req::item('username'), req::item('password'));
			}
			catch ( Exception $e )
			{
				$errmsg = $e->getMessage();
			}
			if( $rs == 1 )
			{
				call::$auth->auth_user( cls_auth::$user->fields );
				$jumpurl = empty($gourl) ? '?ct=index' : $gourl;
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('index_login_success'), $jumpurl);
				exit();
			}
			// }
		}

		tpl::assign('username', $username );
		tpl::assign('password', $password );
		tpl::assign('gourl', $gourl );
		tpl::assign('errmsg', $errmsg );
		tpl::display('login.tpl');
		exit();
	}

	public function xsvalidation()
	{
		$username = req::item('username');
		$password = req::item('password');
		//if( empty($username)  || empty($password) )
		//{
		//exit(json_encode(array(5822,'用户名或密码错误')));
		//}

		static $v_num = 1;
		$ret =  pub_xsverification::check_data(req::item('point'), $_SESSION['XSVer']);
		$v_num +=  $_SESSION["XSVer_VAL_SUM"];
		if( $v_num > 6 )
		{
			$_SESSION["XSVer_SUM"] = null;
			exit(json_encode(array('state'=>4603,'data'=>lang::get('index_code_fail'))));
		}
		else
		{
			$_SESSION["XSVer_VAL_SUM"] = $v_num;
		}

		// 验证通过
		if( $ret['state'] == 0 )
		{
			// 生成一个token
			$_SESSION["XSVer_VAL_SUM"] = 0x111;
			exit(json_encode(array('state'=>0,'data' => $_SESSION['XSVer'])));
		}
		else
		{
			exit(json_encode(array('state'=>603, 'data'=>lang::get('index_error').$v_num)));
		}
	}

	//接收登录数据
	public function get_data()
	{
		// 验证token
		if( $_SESSION["XSVer_VAL_SUM"] !== 0x111 )
		{
			exit(json_encode(array(5821,lang::get('index_code_error'))));
		}
		// 验证通过后要清除一下，不然用户只需要拖动一次然后拿到cookie，就可以不断的提交了
		$_SESSION["XSVer_VAL_SUM"] = null;

		$username = req::item('username');
		$password = req::item('password');
		if( empty($username)  || empty($password) )
		{
			exit(json_encode(array(5822,lang::get('index_login_error'))));
		}
	}

	/**
	 * 生成默认权限系统的数据表
	 * 实际使用中创建好表后应该删除此函数
	 */
	public function db_infos()
	{
		if (DEBUG_MODE === true)
		{
			$type = req::item('type', '');
			mod_make_db_document::show( $type );
		}
		exit();
	}

	/**
	 * 系统消息
	 */
	public function adminmsg()
	{
		$addjob = req::item('addjob', '');
		if($addjob=='del')
		{
			db::update('#PB#_admin_log')->set(array(
												  'isread' => 1
											  ))
				->where('isalert', '=', 1)
				->execute();
			exit('ok');
		}
		else
		{
			$row = db::select("count(*) As count")->from('#PB#_admin_log')
				->where('isalert', '=', 1)
				->and_where('isread', '=', 0)
				->as_row()
				->execute();
			if( is_array($row) && $row['count']>0 )
			{
				exit($row['count']);
			}
			else
			{
				exit('false');
			}
		}
	}


	/**
	 * 退出
	 */
	public function logout()
	{
		call::$auth->logout();
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('index_login_out_success'), './');
		exit();
	}

	/**
	 * 验证码图片
	 */
	public function validate_image()
	{
		//$text_num=4, $im_x = 200, $im_y = 40, $scale = 5, $session_name='securimage_code_value'
		//$vdimg = new cls_securimage(4, 120, 24);
		$vdimg = new cls_securimage(4, 150, 30, 3);
		call::$is_ajax = true;
		$vdimg->show();
	}

	//语言设置
	public function language_change()
	{
		$lang = req::item("lang");

		setcookie("language", $lang);
		$gourl = '?ct=index';
		$lang_list = $this->_language_list();
		$lang_name = isset($lang_list[$lang]) ? $lang_list[$lang] : $lang_list['zh-cn'];

		lang::load("common", $lang);
		lang::load("index", $lang);
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('index_change_language').'  '.$lang_name.'  '.lang::get('index_change_page'), $gourl,3000,$lang);
	}

	//使用语言
	private function _language_list()
	{
		return array (
			'zh-cn' => '简体中文',
			'en' 	=> 'English',
			//'zh-tw' => '繁体中文',
			'km' 	=> 'Combodia',
		);
	}
}
