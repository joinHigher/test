<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 计划任务管理控制器
 *
 * @version $Id$
 */
class ctl_crond
{
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("crond", $lang);

        tpl::assign('ns', time());
    }

	/**
	 * 主入口
	 */
	public function index()
	{
		$keyword = req::item('keyword', '');
		$query = db::select()->from('#PB#_crond');
		if (!empty($keyword))
		{
			$query->where('name', 'like', "%$keyword%");
			$query->or_where('filename', 'like', "%$keyword%");
		}

		$list = $query->order_by('sort', 'asc')->execute();

		tpl::assign('list', $list);
		tpl::display('crond.index.tpl');
		exit();
	}

	public function add()
	{
		if (req::$posts)
		{
			list($insert_id, $rows_affected) = db::insert('#PB#_crond')->set(array(
																				 'name'           => req::item('name'),
																				 'filename'       => req::item('filename'),
																				 'runtime_format' => req::item('runtime_format'),
																				 'status'         => req::item('status'),
																				 'addtime'        => time(),
																			 ))
				->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "计划任务添加 {$insert_id}");

			$this->save();
			$gourl = '?ct=crond&ac=index';
			cls_msgbox::show('系统提示', "添加成功", $gourl);
		}
		else
		{
			$gourl = '?ct=crond&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::display('crond.add.tpl');
		}
	}


	public function edit()
	{
		$id = req::item('id', 0);
		if (req::$posts)
		{
			db::update('#PB#_crond')->set(array(
											  'name'           => req::item('name'),
											  'filename'       => req::item('filename'),
											  'runtime_format' => req::item('runtime_format'),
											  'status'         => req::item('status'),
											  'uptime'         => time(),
										  ))
				->where('id', $id)
				->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "计划任务修改 {$id}");

			$this->save();
			$gourl = '?ct=crond&ac=index';
			cls_msgbox::show('系统提示', "修改成功", $gourl);
		}
		else
		{
			$v = db::select()->from('#PB#_crond')->where('id', $id)->as_row()->execute();
			tpl::assign('v', $v);
			$gourl = '?ct=crond&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::display('crond.edit.tpl');
		}
	}

	public function del()
	{
		$ids = req::item('ids', array());
		db::delete('#PB#_crond')->where('id', 'in', $ids)->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "计划任务删除 ".implode(",", $ids));

		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=crond&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show('系统提示', "删除成功", $gourl);
	}

	public function batch_edit()
	{
		$sorts = req::item('sorts', array());
		foreach ($sorts as $id=>$sort)
		{
			db::update('#PB#_crond')->set(array(
											  'sort' => $sort
										  ))
				->where('id', $id)
				->execute();
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "计划任务排序");

		$this->save();

		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=crond&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show('系统提示', "批量修改成功", $gourl);
	}

	public function status()
	{
		$ids = req::item('ids', array());
		$status = req::item('status', 0);
		$msg = $status ? "启动" : "停止";
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "请选择要修改的任务", -1);
		}

		db::update('#PB#_crond')->set(array(
										  'status' => $status
									  ))
			->where('id', 'in', $ids)
			->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "计划任务{$msg} ".implode(",", $ids));

		$this->save();
		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=crond&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show('系统提示', $msg."成功", $gourl);
	}

	/**
	 * 保存任务管理到文件，以备crondd调用
	 *
	 * @access public
	 * @return void
	 */
	public function save()
	{
		$list = db::select()->from('#PB#_crond')->order_by('sort', 'asc')->execute();
		if ($list)
		{
			$crond_arr = array();
			foreach ($list as $v)
			{
				if (!$v['status'])
				{
					continue;
				}
				$filename = explode("\n", $v['filename']);
				$filename = "'" . implode("','", $filename) . "'";
				$filename = str_replace(array("\n", "\r"), "", $filename);
				$crond_arr[$v['runtime_format']][] = $filename;
			}

			$str = '<?php' . "\n" . '$crond_list = ' . var_export($crond_arr, true) . ';';
			$str = str_replace("\'", "", $str);
			util::put_file(PATH_DATA . '/crond_list.php', $str);
		}
		else
		{
			unlink(PATH_DATA . '/crond_list.php');
		}
	}

}
