<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 授信管理
 *
 * @version $Id$
 */
class ctl_credit_audit
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("member", $lang);
		lang::load("credit_audit", $lang);
		lang::load("model", $lang);
		lang::load("push_message_content", $lang);

		mod_member_info::$type_list[1] = lang::get('model_institutional_user');
		mod_member_info::$type_list[2] = lang::get('model_personal_user');

		mod_credit_audit::$type_list[1] = lang::get('model_fixed_credit');
		mod_credit_audit::$type_list[2] = lang::get('model_tmp_credit');

		mod_credit_audit::$status_list[0] = lang::get('model_pending_review');
		mod_credit_audit::$status_list[1] = lang::get('model_agree');
		mod_credit_audit::$status_list[2] = lang::get('model_reject');

		mod_member_info::$company_type_list[1] = lang::get('model_legal_person');
		mod_member_info::$company_type_list[2] = lang::get('model_institution');
		mod_member_info::$company_type_list[3] = lang::get('model_other_groups');

		mod_member_info::$person_card_type_list[1] = lang::get('model_id_card');
		mod_member_info::$person_card_type_list[2] = lang::get('model_passport');
		mod_member_info::$person_card_type_list[3] = lang::get('model_identity_guarantor');

		mod_member_info::$company_card_type_list[2] = lang::get('model_business_license');
		mod_member_info::$company_card_type_list[3] = lang::get('model_other');

		mod_member_info::$sex_list[1] = lang::get('model_miss');
		mod_member_info::$sex_list[2] = lang::get('model_mr');


	}

    /**
     * 列表
     */
    public function index()
    {
		$keyword = req::item('keyword', '');

		$where = array();

		if(!empty($keyword))
		{
			$where['or'][] = array ('code', 'like', $keyword.'%');
			$where['or'][] = array ('custom_code', 'like', $keyword.'%');
		}

		$where['and'][] = array ('status', '=', 1);

		$count = mod_member_info::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_member_info::get_list($where,'', $pages['page_size'], $pages['offset']);

		//获取授信默认币种
		$default_currency_code = mod_member_info::get_default_currency_code();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				//获取授信
				$credit_where = array ();
				$credit_where[] = array ('member_info_id', '=', $v['id']);
				$credit_where[] = array ('currency_code', '=', $default_currency_code);
				$member_credit_info = mod_member_money_credit::get_info($credit_where);

				$member_credit_info['fixed_money'] = empty($member_credit_info['fixed_money']) ? 0 : $member_credit_info['fixed_money'];
				$member_credit_info['tmp_money'] = empty($member_credit_info['tmp_money']) ? 0 : $member_credit_info['tmp_money'];
				$member_credit_info['used_money'] = empty($member_credit_info['used_money']) ? 0 : $member_credit_info['used_money'];
				$list[$k]['fixed_money'] = empty($member_credit_info) ? '0.00' : mod_member_info::num_format($member_credit_info['fixed_money']);
				$list[$k]['tmp_money'] = empty($member_credit_info) ? '0.00' : mod_member_info::num_format($member_credit_info['tmp_money']);
				$list[$k]['use_money'] = empty($member_credit_info) ? '0.00' : mod_member_info::num_format($member_credit_info['fixed_money'] + $member_credit_info['tmp_money'] - $member_credit_info['used_money']);
				$list[$k]['type_name'] = isset(mod_member_info::$type_list[$v['type']]) ? mod_member_info::$type_list[$v['type']] : mod_member_info::$type_list[$v['type']];
				$list[$k]['usage'] = (empty($member_credit_info) || $member_credit_info['fixed_money'] == 0) ? '0.00%' : mod_member_info::num_format($member_credit_info['used_money'] / $member_credit_info['fixed_money'] * 100) . '%';
			}
		}

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('credit_audit.index.tpl');
    }

	//调整授信
	public function adjust_audit()
	{

		$id = req::item('id');
		$suggest_money = req::item('suggest_money');
		$suggest_money = str_replace(',','',$suggest_money);

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_credit'), '-1');
		}

		if(empty($suggest_money))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_empty'), '-1');
		}

		//获取默认货币
		$default_currency_code = mod_member_info::get_default_currency_code();

		$member_info = mod_member_info::find($id);

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_member_not_exist'), '-1');
		}

		//$suggest_money = $suggest_money*10000;

		//额度不能高于上线
		if(!empty($member_info['parentid']))
		{
			$parent_credit_where = array ();
			$parent_credit_where[] = array ('member_info_id', '=', $member_info['parentid']);
			$parent_credit_where[] = array ('currency_code', '=', $default_currency_code);
			$parent_credit = mod_member_money_credit::get_info($parent_credit_where);

			if($suggest_money > $parent_credit['fixed_money'])
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_line_higher'), '-1');
			}
		}

		//额度不能低于下线
		//$sql = "Select `id` From `#PB#_member_info` WHERE `parentid`='{$member_info['id']}'";
		//$next_list = db::get_all($sql);
		$next_list_where = array ();
		$next_list_where[] = array ('parentid', '=', $member_info['id']);
		$next_list = mod_member_info::get_list($next_list_where, 'id');
		if(!empty($next_list))
		{
			$next_ids = array ();
			foreach ($next_list as $k => $v)
			{
				$next_ids[] = $v['id'];
			}
			//$next_ids = implode(',',$next_ids);
			//$next_info = mod_member_money_credit::get_highest_info("`member_info_id` in($next_ids) and `currency_code`='{$default_currency_code}'");
			$next_info_where = array ();
			$next_info_where[] = array ('member_info_id', 'in', $next_ids);
			$next_info_where[] = array ('currency_code', '=', $default_currency_code);
			$next_info = mod_member_money_credit::get_last_info($next_info_where);
			if($next_info['fixed_money'] > $suggest_money)
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_line_lower'), '-1');
			}
		}

		//调整客户额度
		//$member_credit_where = "`member_info_id`='{$member_info['id']}' AND `currency_code`='{$default_currency_code}'";
		$member_credit_where = array ();
		$member_credit_where[] = array ('member_info_id', '=', $member_info['id']);
		$member_credit_where[] = array ('currency_code', '=', $default_currency_code);
		$member_credit = mod_member_money_credit::get_info($member_credit_where);

		if(empty($member_credit))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_customer_default').mod_member_info::get_default_currency_name().lang::get('credit_audit_not_exist'), '-1');
		}

		db::begin_tran();

		$up_data = array ();
		$up_data['fixed_money'] = $suggest_money;
		$result = mod_member_money_credit::update_data($member_credit_where, $up_data);

		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), -1);
		}

		//添加记录
		$admin_id = cls_auth::$user->fields['uid'];

		$add_data = array ();
		$add_data['admin_id'] = $admin_id;
		$add_data['member_info_id'] = $id;
		$add_data['apply_limit'] = $suggest_money;
		$add_data['current_limit'] = $member_credit['fixed_money'];
		$add_data['uptime'] = $add_data['addtime'] = time();

		$result = mod_credit_audit_admin::add_data($add_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), -1);
		}

		//推送消息
			$transact_curcy_symbol = mod_currency_type::get_symbol();
			$apply_limit = $transact_curcy_symbol.mod_member_info::num_format($suggest_money);
			$title = lang::get('push_message_credit_audit_title');
			$content = str_replace('#adjustment_limit#',$apply_limit,lang::get('push_message_credit_adjustment_limit'));

			mod_app_message::create($id, 0, $title, $content, '', 0, 2, 0);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('credit_audit_adjust_credit_line')." {$id} ");

		db::commit();
		db::autocommit(true);

		$gourl = req::item('gourl', '?ct=credit_audit&ac=index');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
	}

	//获取成员信息
	public function get_member_info()
	{
		$id = req::item('id','0','int');

		$info = array();
		if(empty($id))
		{
			util::response_json(200, lang::get('credit_audit_select_credit'), 0, $info);
		}

		$info = mod_member_info::find($id);

		if(empty($info))
		{
			util::response_json(200, lang::get('credit_audit_select_credit'), 0, $info);
		}

		//获取授信默认币种
		$default_currency_code = mod_member_info::get_default_currency_code();

		//获取授信
		$money_credit_where = array ();
		$money_credit_where[] = array ('member_info_id', '=', $id);
		$money_credit_where[] = array ('currency_code', '=', $default_currency_code);
		$member_credit_info = mod_member_money_credit::get_info($money_credit_where);

		$usage = mod_member_bill::usage($id, 5, $member_credit_info['fixed_money']);

		$info['usage'] = mod_member_info::num_format($usage).'%';
		$info['suggest_money'] = isset($member_credit_info['fixed_money']) ? mod_member_info::num_format($member_credit_info['fixed_money']/0.8, '') : '';

		$info['fixed_limit'] = empty($member_credit_info) ? '0.00' : mod_member_info::num_format($member_credit_info['fixed_money']);
		$info['tmp_limit'] = empty($member_credit_info) ? '0.00' : mod_member_info::num_format($member_credit_info['tmp_money']);

		util::response_json(200, lang::get('common_operation_success'), 1, $info);
	}

	//异步获取
	public function ajax_audit()
	{
		$id = req::item('id','0','int');
		$info = array();
		if(empty($id))
		{
			util::response_json(200, lang::get('credit_audit_select_credit'), 0, $info);
		}

		$audit_info = mod_credit_audit::find($id);
		if(empty($audit_info))
		{
			util::response_json(200, lang::get('credit_audit_not_exist'), 0, $info);
		}

		$info = mod_member_info::find($audit_info['member_info_id']);
		$info['audit_id'] = $id;
		util::response_json(200, lang::get('common_operation_success'), 1, $info);
	}

	//授信审核列表
	public function audit()
	{
		tpl::assign('is_all', 0);
		$this->_audit_list(1);
	}

	//授信已审核列表
	public function al_audit()
	{
		tpl::assign('is_all', 0);
		$this->_audit_list(2);
	}

	//所有授信审核列表
	public function all_audit()
	{
		tpl::assign('is_all', 1);
		$this->_audit_list(3);
	}

	//所有授信已审核列表
	public function all_al_audit()
	{
		tpl::assign('is_all', 1);
		$this->_audit_list(4);
	}

	//受理中列表
	public function accepting_list()
	{
		tpl::assign('is_all', req::item('is_all','0','int'));
		$this->_audit_list(5);
	}

	//已受理列表
	public function accepted_list()
	{
		tpl::assign('is_all', req::item('is_all','0','int'));
		$this->_audit_list(6);
	}

	/**
	 * 审核列表
	 *
	 * @param int $parentid
	 * @param int $audit_status 显示审核信息 0=待审核，1=已审核
	 *
	 */
	private function _audit_list($type_list)
	{
		$where = array();

		$admin_id = cls_auth::$user->fields['uid'];
		$parentid = '';
		switch ($type_list)
		{
			case 1:
				$parentid = 0;
				$where[] = array ('status', '=', 0);
				break;
			case 2:
				$parentid = 0;
				$where[] = array ('status', 'in', array (1,2));
				break;
			case 3:
				$where[] = array ('status', '=', 0);
				break;
			case 4:
				$where[] = array ('status', 'in', array (1,2));
				break;
			case 5:
				$where[] = array ('status', '=', 0);
				$where[] = array ('audit_id', '=', $admin_id);
				break;
			case 6:
				$where[] = array ('status', 'in', array (1,2));
				$where[] = array ('audit_id', '=', $admin_id);
				break;
		}

		//查出所有顶级客户
		if(is_numeric($parentid))
		{
			$mem_list_where = array ();
			$mem_list_where[] = array ('parentid', '=', $parentid);
			$mem_list = mod_member_info::get_list($mem_list_where, 'id');
			if(empty($mem_list))
			{
				$where[] = array ('member_info_id', '=', 0);
			}
			else
			{
				foreach ($mem_list as $mv)
				{
					$mem_ids[] = $mv['id'];
				}

				$where[] = array ('member_info_id', 'in', $mem_ids);
			}
		}

		$count = mod_credit_audit::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));

		$list = mod_credit_audit::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$member_info = mod_member_info::find($v['member_info_id']);
				$list[$k]['member_name'] = empty($member_info['name']) ? '' : $member_info['name'];
				$list[$k]['member_code'] = empty($member_info['code']) ? '' : $member_info['code'];
				$list[$k]['member_type_name'] = isset(mod_member_info::$type_list[$member_info['type']]) ? mod_member_info::$type_list[$member_info['type']] : "";
				$list[$k]['current_limit'] = mod_member_info::num_format($v['current_limit']);
				$list[$k]['apply_limit'] = mod_member_info::num_format($v['apply_limit']);
				$list[$k]['audited_limit'] = $v['status'] == 0 ? '-' : mod_member_info::num_format($v['audited_limit']);
				$list[$k]['type_name'] = mod_credit_audit::$type_list[$v['type']];
				$list[$k]['status_name'] = mod_credit_audit::$status_list[$v['status']];
			}
		}

		tpl::assign('type_list', $type_list);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('credit_audit.audit.tpl');
	}

	//查看审核详情
	public function show()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		$audit_info = mod_credit_audit::find($id);

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		$member_info = mod_member_info::find($audit_info['member_info_id']);
		$audit_info['apply_limit'] = mod_member_info::num_format($audit_info['apply_limit']);
		$audit_info['current_limit'] = mod_member_info::num_format($audit_info['current_limit']);
		$audit_info['audited_limit'] = $audit_info['status'] == 0 ? '-' : mod_member_info::num_format($audit_info['audited_limit']);
		$member_info['member_status'] = $member_info['status'];
		$member_info['member_name'] = $member_info['name'];
		$member_info['card_pic_name'] = empty($member_info['card_pics']) ? lang::get('common_not_uploaded') : lang::get('common_uploaded');
		$member_info['sex_name'] = isset(mod_member_info::$sex_list[$member_info['gender']]) ? mod_member_info::$sex_list[$member_info['gender']] : '';
		$member_info['member_type'] = $member_info['type'];

		//证明人
		$member_info['bondsman_list_name'] = '';
		$member_info['bondsman1_code'] = '';
		$member_info['bondsman1_name'] = '';
		$member_info['bondsman2_code'] = '';
		$member_info['bondsman2_name'] = '';
		if(($member_info['type'] == 1 && $member_info['card_type'] == 3) || ($member_info['type'] == 2 && $member_info['card_type'] == 3))
		{
			if(!empty($member_info['bondsman1_id']))
			{
				$bondsman1_info = mod_member_info::find($member_info['bondsman1_id'], 'code,name');
				if($bondsman1_info)
				{
					$member_info['bondsman1_code'] = $bondsman1_info['code'];
					$member_info['bondsman_list_name'] = $member_info['bondsman1_name'] = $bondsman1_info['name'];
				}
			}

			if(!empty($member_info['bondsman2_id']))
			{
				$bondsman2_info = mod_member_info::find($member_info['bondsman2_id'], 'code,name');
				if($bondsman2_info)
				{
					$member_info['bondsman2_code'] = $bondsman2_info['code'];
					$member_info['bondsman2_name'] = $bondsman2_info['name'];
					$member_info['bondsman_list_name'] = empty($member_info['bondsman_list_name']) ? $member_info['bondsman2_name'] : $member_info['bondsman_list_name'].','.$member_info['bondsman2_name'];
				}
			}
		}

		//证件照片
		$member_info['pic_list'] = array ();
		if(!empty($member_info['card_pics']))
		{
			$pic_list = explode(',',$member_info['card_pics']);
			foreach ($pic_list as $pv)
			{
				$member_info['pic_list'][] = URL_UPLOADS.'/image/'.$pv;
			}
		}

		unset($member_info['id']);
		unset($member_info['name']);
		unset($member_info['type']);
		unset($member_info['addtime']);
		unset($member_info['uptime']);
		unset($member_info['status']);
		unset($member_info['audit_id']);
		unset($member_info['fail_reason']);
		$info = array_merge($audit_info, $member_info);

		//处理返回URL
		$this->_get_gourl();

		tpl::assign('id', $id);
		tpl::assign('admin_id', cls_auth::$user->fields['uid']);
		tpl::assign('info', $info);
		tpl::assign('person_card_type_list', mod_member_info::$person_card_type_list);
		tpl::assign('company_card_type_list', mod_member_info::$company_card_type_list);
		tpl::assign('company_type_list', mod_member_info::$company_type_list);
		tpl::display('credit_audit.show.tpl');
	}

	//授信申请记录
	public function member_credit_op()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		$audit_info = mod_credit_audit::find($id);

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		//成员申请记录
		$mem_where = array();
		$mem_where[] = array ('member_info_id', '=', $audit_info['member_info_id']);

		$count = mod_credit_audit::get_count($mem_where);
		$mem_pages = pub_page::make($count, req::item('page_size', '10','int'));
		$mem_list = mod_credit_audit::get_list($mem_where, '', $mem_pages['page_size'], $mem_pages['offset']);

		if(!empty($mem_list))
		{
			foreach ($mem_list as $k => $v)
			{
				$mem_list[$k]['status_name'] = mod_credit_audit::$status_list[$v['status']];
				$mem_list[$k]['type_name'] = mod_credit_audit::$type_list[$v['type']];
				$mem_list[$k]['current_limit'] = mod_member_info::num_format($v['current_limit']);
				$mem_list[$k]['apply_limit'] = mod_member_info::num_format($v['apply_limit']);
				$mem_list[$k]['audited_limit'] = $v['status'] == 0 ? '' : mod_member_info::num_format($v['audited_limit']);
			}
		}

		//处理URL跳转信息
		$this->_get_gourl();

		tpl::assign('id', $id);
		tpl::assign('mem_list', $mem_list);
		tpl::assign('mem_pages', $mem_pages['show']);
		tpl::display('credit_audit.member_credit_op.tpl');
	}

	//管理端授信调整记录
	public function admin_credit_op()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		$audit_info = mod_credit_audit::find($id);

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		//管理端调整授信记录
		$adm_where = array();
		$adm_where[] = array ('member_info_id', '=', $audit_info['member_info_id']);

		$count = mod_credit_audit_admin::get_count($adm_where);
		$adm_pages = pub_page::make($count, req::item('page_size', '10','int'));
		$adm_list = mod_credit_audit_admin::get_list($adm_where, '', $adm_pages['page_size'], $adm_pages['offset']);

		if(!empty($adm_list))
		{
			foreach ($adm_list as $k => $v)
			{
				$admin_info = mod_admin::find($v['admin_id'], 'realname');
				$adm_list[$k]['admin_name'] = empty($admin_info) ? '' : $admin_info['realname'];
				$adm_list[$k]['current_limit'] = mod_member_info::num_format($v['current_limit']);
				$adm_list[$k]['apply_limit'] = mod_member_info::num_format($v['apply_limit']);
			}
		}
		//处理URL跳转信息
		$this->_get_gourl();

		tpl::assign('id', $id);
		tpl::assign('adm_list', $adm_list);
		tpl::assign('adm_pages', $adm_pages['show']);
		tpl::display('credit_audit.admin_credit_op.tpl');
	}

	//审核同意
	public function consent()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		$credit_info = mod_credit_audit::find($id);

		if(empty($credit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		if($credit_info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		//获取默认货币
		$default_currency_code = mod_member_info::get_default_currency_code();

		//额度不能低于下线
		$next_list_where = array ();
		$next_list_where[] = array ('parentid', '=', $credit_info['member_info_id']);
		$next_list = mod_member_info::get_list($next_list_where, 'id');
		if(!empty($next_list))
		{
			$next_ids = array ();
			foreach ($next_list as $k => $v)
			{
				$next_ids[] = $v['id'];
			}

			$next_info_where = array ();
			$next_info_where[] = array ('member_info_id', 'in', $next_ids);
			$next_info = mod_member_money_credit::get_last_info($next_info_where, 'fixed_money');
			if($credit_info['type'] == 1)
			{
				if($next_info['fixed_money'] > $credit_info['apply_limit'])
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_line_lower'), '-1');
				}
			}
			else
			{
				if($next_info['tmp_money'] > $credit_info['apply_limit'])
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_line_lower'), '-1');
				}
			}
		}

		//查询客户授信
		$member_credit_where = array ();
		$member_credit_where[] = array ('member_info_id', '=', $credit_info['member_info_id']);
		$member_credit_where[] = array ('currency_code', '=', $default_currency_code);
		$member_credit = mod_member_money_credit::get_info($member_credit_where);

		if(empty($member_credit))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_customer_default').mod_member_info::get_default_currency_name().lang::get('credit_audit_not_exist'), '-1');
		}

		db::begin_tran();

		//修改客户授信信息
		$up_data = array ();
		if($credit_info['type'] == 1)
		{
			$up_data['fixed_money'] = $credit_info['apply_limit'];
		}
		else
		{
			$up_data['tmp_money'] = $credit_info['apply_limit'];
			$up_data['tmp_end_date'] = mod_member_info::generate_tmp_end_date();
		}

		$result = mod_member_money_credit::update_data($member_credit_where, $up_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_agree_fail'), '-1');
		}

		//修改审核信息
		$credit_up = array ();
		$credit_up['status'] = 1;
		$credit_up['audited_limit'] = $credit_info['apply_limit'];
		$credit_up['uptime'] = time();

		$up_credit_audit_where = array ();
		$up_credit_audit_where[] = array ('id', '=', $id);
		$result = mod_credit_audit::update_data($up_credit_audit_where, $credit_up);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_agree_fail'), '-1');
		}

		//添加推送消息
		$title = lang::get('push_message_credit_audit_title');
		$content = lang::get('push_message_credit_audit_success');
		mod_app_message::create($credit_info['member_info_id'], $credit_info['member_id'], $title, $content, '', 1, 2, $credit_info['id']);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('credit_audit_members_credit')." {$id}");

		db::commit();
		db::autocommit(true);

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $this->_get_gourl());
	}

	//审核驳回
	public function rejected()
	{
		$id = req::item('id');
		$fail_reason = req::item('fail_reason');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		if(empty($fail_reason))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_reasons_refusal_empty'), '-1');
		}

		$credit_info = mod_credit_audit::find($id);

		if(empty($credit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		if($credit_info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		$updata = array ();
		$updata['status'] = 2;
		$updata['fail_reason'] = $fail_reason;
		$updata['audited_limit'] = $credit_info['current_limit'];
		$updata['uptime'] = time();

		$up_credit_audit_where = array ();
		$up_credit_audit_where[] = array ('id', '=', $id);
		$result = mod_credit_audit::update_data($up_credit_audit_where, $updata);

		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		//添加推送消息
		$title = lang::get('push_message_credit_audit_title');
		$content = lang::get('push_message_credit_audit_fail');
		mod_app_message::create($credit_info['member_info_id'], $credit_info['member_id'], $title, $content, '', 1, 2, $credit_info['id']);


		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('credit_audit_members_credited_rejected')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $this->_get_gourl());

	}

	//受理
	public function accepte()
	{
		$id = req::item('id');
		$type_list = req::item('type_list','1','int');
		$is_all = req::item('is_all','0','int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		$credit_info = mod_credit_audit::find($id);

		if(empty($credit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('credit_audit_select_information'), '-1');
		}

		$update_data = array ();
		$update_data['audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		$up_credit_audit_where = array ();
		$up_credit_audit_where[] = array ('id', '=', $id);

		mod_credit_audit::update_data($up_credit_audit_where, $update_data);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('credit_audit_accepte')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_acceptance_success'), "?ct=credit_audit&ac=show&id={$id}&type_list={$type_list}&is_all={$is_all}");
	}

	//获取调整URL
	private function _get_gourl()
	{
		$type_list = req::item('type_list','1','int');
		$is_all = req::item('is_all','0','int');
		switch ($type_list)
		{
			case 1:
				$gourl = '?ct=credit_audit&ac=audit';
				break;
			case 2:
				$gourl = '?ct=credit_audit&ac=al_audit';
				break;
			case 3:
				$gourl = '?ct=credit_audit&ac=alL_audit';
				break;
			case 4:
				$gourl = '?ct=credit_audit&ac=all_al_audit';
				break;
			case 5:
				$gourl = '?ct=credit_audit&ac=accepting_list';
				break;
			case 6:
				$gourl = '?ct=credit_audit&ac=accepted_list';
				break;
		}

		tpl::assign('is_all', $is_all);
		tpl::assign('type_list', $type_list);
		tpl::assign('gourl', $gourl);

		return $gourl;
	}
}
