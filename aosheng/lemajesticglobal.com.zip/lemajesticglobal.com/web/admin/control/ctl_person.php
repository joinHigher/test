<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 人员管理
 *
 * @version $Id$
 */
class ctl_person
{
    public static $options = array(0 => '所有等级');
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $rows = db::get_all("Select `id`,`name` From `#PB#_level`");
        foreach ($rows as $row) 
        {
            self::$options[$row['id']] = $row['name'];
        }
        tpl::assign( 'options', self::$options );
        tpl::assign( 'level', 0 );
    }

    public function index()
    {
        $keyword = req::item('keyword', '');
        $level   = req::item('level', 0);

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = "(`code` Like '%{$keyword}%')";
        }
        if (!empty($level)) 
        {
            $where[] = "`level`='{$level}'";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select Count(*) AS count From `#PB#_person` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count'], 10);
        $sql = "Select * From `#PB#_person` {$where} Order By `id` Asc Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);
        foreach ($list as $k=>$v) 
        {
            $list[$k]['level'] = self::$options[$v['level']];
            //$list[$k]['imageurl'] = URL_UPLOADS."/image/".$v['image'];
        }

        tpl::assign('level', $level);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('person.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $code = req::item('code');
            $row = db::get_one("Select * From `#PB#_person` Where `code`='{$code}'");
            if( is_array($row) )
            {
                cls_msgbox::show(lang::get('common_system_hint'), '代号已经存在！', '-1');
                exit();
            }

            req::$forms['uid'] = cls_auth::$user->fields['uid'];
            req::$forms['addtime'] = req::$forms['uptime'] = time();

            $insert_id = db::insert('#PB#_person', req::$forms);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "人员添加 {$insert_id}");

            $gourl = req::item('gourl', '?ct=person&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), "添加成功", $gourl);
        }
        else 
        {
            $gourl = '?ct=person&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('person.add.tpl');
        }
    }

    public function show()
    {
        $id = req::item("id", 0);
        $sql = "Select * From `#PB#_person` Where `id`={$id} Limit 1";
        $v = db::get_one($sql);
        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=person&ac=index' : $_SERVER['HTTP_REFERER'];
        tpl::assign('v', $v);
        tpl::assign('gourl', urlencode($gourl));
        tpl::display('person.show.tpl');
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
            $code = req::item('code');
            $row = db::get_one("Select * From `#PB#_person` Where `code`='{$code}' And `id`!='{$id}'");
            if( is_array($row) )
            {
                cls_msgbox::show(lang::get('common_system_hint'), '代号已经存在！', '-1');
                exit();
            }

            req::$forms['uptime'] = time();

            db::update('#PB#_person', req::$forms, "`id`='{$id}'");

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "人员修改 {$id}");

            $gourl = req::item('gourl', '?ct=person&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), "修改成功", $gourl);
        }
        else 
        {
            $sql = "Select * From `#PB#_person` Where `id`={$id} Limit 1";
            $v = db::get_one($sql);
            $gourl = req::item('gourl', '?ct=person&ac=index');
            //$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=person&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::assign('v', $v);
            tpl::display('person.edit.tpl');
        }
    }

    public function del()
    {
        $ids = req::item('ids');
        if (empty($ids)) 
        {
            cls_msgbox::show(lang::get('common_system_hint'), "删除失败，请选择要删除的人员", -1);
            exit;
        }
        $ids = implode(",", $ids);
        //$sql = "Delete From `#PB#_person` Where `id` In({$ids})";
        $sql = "Update `#PB#_person` Set `isdeleted`='1' Where `id` In({$ids})";
        db::query($sql);

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "人员删除 {$ids}");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=person&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show(lang::get('common_system_hint'), "删除成功", $gourl);
    }

}
