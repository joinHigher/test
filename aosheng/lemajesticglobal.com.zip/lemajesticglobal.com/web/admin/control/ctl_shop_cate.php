<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 商户分类管理
 *
 * @version $Id$
 */
class ctl_shop_cate
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("shop_cate", $lang);

		mod_shop_category::$select_information_name = lang::get('common_select');
    }

    /**
     * 列表
     */
    public function index()
    {
        $keyword = req::item('keyword', '');

        $where = array();
        $where[] = array ('is_del', '=', 0);
        if (!empty($keyword))
        {
			$where[] = array ('name', 'like', '%'.$keyword.'%');
        }

        $counnt = mod_shop_category::get_count($where);
        $pages = pub_page::make($counnt, req::item('page_size', '10','int'));
		$list = mod_shop_category::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$parent_info = mod_shop_category::find($v['parentid'], 'name');
				$list[$k]['parent_name'] = empty($parent_info) ? '' : $parent_info['name'];
			}
		}

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('shop_cate.index.tpl');
    }

	//添加
	public function add()
	{
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$parentid = req::item('parentid', 0);

			$row = mod_shop_category::get_info(array('name', '=', $name));
			if(!empty($row) )
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_cate_name_already_exists'), '-1');
			}

			$parent_info = mod_shop_category::find($parentid);
			$add_data['parentpath'] = empty($parent_info) ? $parentid : (empty($parent_info['parentpath']) ? $parentid : $parent_info['parentpath'].','.$parentid);

			$add_data['name'] = $name;
			$add_data['parentid'] = $parentid;
			$add_data['is_del'] = 0;
			$add_data['uptime'] = $add_data['addtime'] = time();

			mod_shop_category::add_data($add_data);

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_cate_add')." {$name}");

			$gourl = req::item('gourl', '?ct=shop_cate&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_add'), $gourl);
		}
		else
		{
			$gourl = '?ct=shop_cate&ac=index';
			tpl::assign('cate_options', mod_shop_category::get_options(1));
			tpl::assign('gourl', $gourl);
			tpl::display('shop_cate.add.tpl');
		}
	}

	//编辑
	public function edit()
	{
		$id = req::item('id');

		if (!empty(req::$posts))
		{
			if(empty($id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_cate_select_cate'), '-1');
				exit();
			}

			$name = req::item('name');
			$parentid = req::item('parentid', 0);

			$category_where = array ();
			$category_where[] = array ('name', '=', $name);
			$category_where[] = array ('id', '!=', $id);
			$row = mod_shop_category::get_info($category_where);
			if(!empty($row))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_cate_name_already_exists'), '-1');
			}

			$parent_info = mod_shop_category::find($parentid);
			$edit_data['parentpath'] = empty($parent_info) ? $parentid : (empty($parent_info['parentpath']) ? $parentid : $parent_info['parentpath'].','.$parentid);

			$edit_data['name'] = $name;
			$edit_data['parentid'] = $parentid;
			$edit_data['is_del'] = 0;
			$edit_data['uptime'] = time();

			mod_shop_category::update_data(array ('id', '=', $id), $edit_data);

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_cate_shop_edit')." {$name}");

			$gourl = req::item('gourl', '?ct=shop_cate&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
		}
		else
		{
			$info = mod_shop_category::find($id);
			$gourl = '?ct=shop_cate&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::assign('info', $info);
			tpl::assign('cate_options', mod_shop_category::get_options(1, $info['parentid'],$info['id']));
			tpl::display('shop_cate.edit.tpl');
		}
	}

	//删除
	public function del()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_cate_select_cate'), '-1');
		}

		$info = mod_shop_category::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_cate_name_not_exists'), '-1');
		}

		$parentinfo = mod_shop_category::get_info(array ('parentid', '=', $id));

		if(!empty($parentinfo))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_cate_sub_not_deleted'), '-1');
		}

		if (mod_shop::cate_exist($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_cate_used_not_deleted'), '-1');
		}

		$del_data['is_del'] = 1;
		$del_data['deltime'] = time();
		mod_shop_category::update_data(array ('id', '=', $id), $del_data);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('shop_cate_deleted')." {$id}");

		$gourl = req::item('gourl', '?ct=shop_cate&ac=index');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_delete'), $gourl);
	}
}
