<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 分类管理
 *
 * @version $Id$
 */
class ctl_category
{
	/**
	 * 构造函数
	 * @return void
	 */
	public function __construct()
	{
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("content", $lang);
	}

	public function index()
	{
		$keyword = req::item('keyword', '');

		$where = array();
		if (!empty($keyword))
		{
			$where[] = array( 'name', 'like', "%$keyword%" );
		}

		//pub_benchmark::mark("操作数据库");

		$row = db::select('count(*) AS `count`')
			->from('#PB#_category')
			->where($where)
			->as_row()
			->execute();

		$pages = pub_page::make($row['count'], 10);

		$list = db::select()->from('#PB#_category')
			->where($where)
			->order_by('sort', 'asc')
			->order_by('id', 'asc')
			->limit($pages['page_size'])
			->offset($pages['offset'])
			->execute();

		//echo pub_benchmark::elapsed_time("操作数据库");

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('category.index.tpl');
	}

	public function add()
	{
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$row = db::select('count(*) AS `count`')
				->from('#PB#_category')
				->where('name', $name)
				->as_row()
				->execute();
			if( $row['count'] )
			{
				cls_msgbox::show('系统提示', '标题已经存在！', '-1');
				exit();
			}

			list($insert_id, $rows_affected) = db::insert('#PB#_category')->set(array(
																					'name'        => $name,
																					'create_user' => cls_auth::$user->fields['uid'],
																					'create_time' => time(),
																				))
				->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "分类添加 {$insert_id}");

			$gourl = req::item('gourl', '?ct=category&ac=index');
			cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_add', '添加成功'), $gourl);
		}
		else
		{
			$gourl = '?ct=category&ac=index';
			tpl::assign('gourl', $gourl);
			tpl::display('category.add.tpl');
		}
	}

	public function edit()
	{
		$id = req::item("id", 0);
		if (!empty(req::$posts))
		{
			$name = req::item('name');
			$row = db::select('count(*) AS `count`')->from('#PB#_category')
				->where('name', $name)
				->where('id', '!=', $id)
				->as_row()
				->execute();
			if( $row['count'] )
			{
				cls_msgbox::show('系统提示', '标题已经存在！', '-1');
				exit();
			}

			db::update('#PB#_category')->set(array(
												 'name'        => $name,
												 'update_user' => cls_auth::$user->fields['uid'],
												 'update_time' => time(),
											 ))
				->where('id', $id)
				->execute();

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], "分类修改 {$id}");

			$gourl = req::item('gourl', '?ct=category&ac=index');
			cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $gourl);
		}
		else
		{
			$v = db::select()->from('#PB#_category')->where('id', $id)->as_row()->execute();
			$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=category&ac=index' : $_SERVER['HTTP_REFERER'];
			tpl::assign('gourl', $gourl);
			tpl::assign('v', $v);
			tpl::display('category.edit.tpl');
		}
	}

	public function edit_batch()
	{
		$ids = req::item('ids', array());
		$sorts = req::item('sorts', array());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "未选中任何数据", -1);
		}
		foreach ($ids as $id)
		{
			$sort = $sorts[$id];
			db::update('#PB#_category')->set(array(
												 'sort' => $sort
											 ))
				->where('id', $id)->execute();
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "分类批量修改 ".implode(",", $ids));

		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=category&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_edit', '修改成功'), $gourl);
	}

	public function del()
	{
		$ids = req::item('ids', array());
		if (empty($ids))
		{
			cls_msgbox::show('系统提示', "删除失败，请选择要删除的分类", $gourl);
		}

		db::delete('#PB#_category')->where('id', 'in', $ids)->execute();

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "分类删除 ".implode(",", $ids));

		$gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=category&ac=index' : $_SERVER['HTTP_REFERER'];
		cls_msgbox::show(lang::get('common_system_hint', '系统提示'), lang::get('common_success_delete', '删除成功'), $gourl);
	}

}
