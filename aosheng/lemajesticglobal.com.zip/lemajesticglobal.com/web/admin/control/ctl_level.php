<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 等级管理
 *
 * @version $Id$
 */
class ctl_level
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
    }

    public function index()
    {
        $keyword = req::item('keyword', '');

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = "(`name` Like '%{$keyword}%')";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select Count(*) AS count From `#PB#_level` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count'], 10);
        $sql = "Select * From `#PB#_level` {$where} Order By `id` Asc Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('level.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            req::$forms['uid'] = cls_auth::$user->fields['uid'];
            req::$forms['addtime'] = req::$forms['uptime'] = time();

            $insert_id = db::insert('#PB#_level', req::$forms);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "等级添加 {$insert_id}");

            $gourl = req::item('gourl', '?ct=level&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), "添加成功", $gourl);
        }
        else 
        {
            $gourl = '?ct=level&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('level.add.tpl');
        }
    }

    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts)) 
        {
            req::$forms['uptime'] = time();

            db::update('#PB#_level', req::$forms, "`id`='{$id}'");

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "等级修改 {$id}");

            $gourl = req::item('gourl', '?ct=level&ac=index');
            cls_msgbox::show(lang::get('common_system_hint'), "修改成功", $gourl);
        }
        else 
        {
            $sql = "Select * From `#PB#_level` Where `id`={$id} Limit 1";
            $v = db::get_one($sql);
            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=level&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::assign('v', $v);
            tpl::display('level.edit.tpl');
        }
    }

    public function del()
    {
        $ids = req::item('ids');
        if (empty($ids)) 
        {
            cls_msgbox::show(lang::get('common_system_hint'), "删除失败，请选择要删除的等级", -1);
            exit;
        }
        $ids = implode(",", $ids);
        //$sql = "Delete From `#PB#_level` Where `id` In({$ids})";
        $sql = "Update `#PB#_level` Set `isdeleted`='1' Where `id` In({$ids})";
        db::query($sql);

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "等级删除 {$ids}");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=level&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show(lang::get('common_system_hint'), "删除成功", $gourl);
    }

}
