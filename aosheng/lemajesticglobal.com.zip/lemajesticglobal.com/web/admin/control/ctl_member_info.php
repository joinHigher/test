<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 客户管理
 *
 * @version $Id$
 */
class ctl_member_info
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("member", $lang);
		lang::load("month_bill", $lang);
		lang::load("bill", $lang);
		lang::load("model", $lang);
		lang::load("member_register", $lang);
		lang::load("push_message_content", $lang);

		mod_member_info::$default_currency['name'] = lang::get('model_rmb');

		mod_member_info::$sex_list[1] = lang::get('model_miss');
		mod_member_info::$sex_list[2] = lang::get('model_mr');

		mod_member_info::$status_map[mod_member_info::STATUS_PENDING] = lang::get('model_pending_review');
		mod_member_info::$status_map[mod_member_info::STATUS_PASS] 	= lang::get('model_examination_passed');
		mod_member_info::$status_map[mod_member_info::STATUS_FAIL] 	= lang::get('model_dismissed');

		mod_member_info::$company_type_list[1] = lang::get('model_legal_person');
		mod_member_info::$company_type_list[2] = lang::get('model_institution');
		mod_member_info::$company_type_list[3] = lang::get('model_other_groups');

		mod_member_info::$person_card_type_list[1] = lang::get('model_id_card');
		mod_member_info::$person_card_type_list[2] = lang::get('model_passport');
		mod_member_info::$person_card_type_list[3] = lang::get('member_identity_guarantor');

		//self::$company_card_type_list[1] = lang::get('model_group_registration_number');
		mod_member_info::$company_card_type_list[2] = lang::get('model_business_license');
		mod_member_info::$company_card_type_list[3] = lang::get('model_other');

		mod_member_info::$type_list[1] = lang::get('model_institutional_user');
		mod_member_info::$type_list[2] = lang::get('model_personal_user');

        mod_member_bill_month::$status_list[1] = lang::get('model_closed');
        mod_member_bill_month::$status_list[2] = lang::get('model_open');

		mod_member_bill::$type_list[1] = lang::get('model_expenditure');
		mod_member_bill::$type_list[2] = lang::get('model_income');
		mod_member_bill::$type_list[3] = lang::get('model_freeze');
		mod_member_bill::$type_list[4] = lang::get('model_doubt');
		mod_member_bill::$type_list[5] = lang::get('model_pre_auth');
		mod_member_bill::$type_list[6] = lang::get('model_thaw');
		mod_member_bill::$type_list[7] = lang::get('model_dispel_doubt');


	}

    /**
     * 客户管理列表
     */
    public function index()
    {
		$keyword = req::item('keyword', '');

		$where = array();
		if (!empty($keyword))
		{
			$where['or'][] = array ('code', 'like', $keyword.'%');
			$where['or'][] = array ('custom_code', 'like', $keyword.'%');
		}

		$where['and'][] = array ('status', '=', 1);

		$count = mod_member_info::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_member_info::get_list($where, '', $pages['page_size'], $pages['offset']);
		//获取默认货币
		$default_currency_code = mod_member_info::get_default_currency_code();

		//默认上线
		$parent_name = mod_member_info::DEFAULT_PARENT_NAME;

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$member_where = array ();
				$member_where[] = array ('member_info_id', '=', $v['id']);
				$member_where[] = array ('butt_type', '=', 0);
				$member_info = mod_member::get_info($member_where);
				$parent_info = mod_member_info::find($v['parentid']);

				//授信固定额度
				$credit_info_where = array ();
				$credit_info_where[] = array ('member_info_id', '=', $v['id']);
				$credit_info_where[] = array ('currency_code', '=', $default_currency_code);
				$credit_info = mod_member_money_credit::get_info($credit_info_where);
				$list[$k]['fixed_limit'] = empty($credit_info) ? '0.00' : mod_member_info::num_format($credit_info['fixed_money'] + $credit_info['tmp_money']);

				$bank_info_where = array ();
				$bank_info_where[] = array ('member_info_id', '=', $v['id']);
				$bank_info_where[] = array ('currency_code', '=', $default_currency_code);
				$bank_info = mod_member_money_bank::get_info($bank_info_where);

				//本期账单金额
				$repay_money_info_where = array ();
				$repay_money_info_where[] = array ('member_info_id', '=', $v['id']);
				$repay_money_info_where[] = array ('status', '=', 2);
				$repay_money_info = mod_member_bill_month::get_info($repay_money_info_where, 'sum(`repay_limit`) as `repay_limit_sum`,sum(`al_repay_limit`) as `al_repay_limit_sum`');
				$list[$k]['repay_amount'] = empty($repay_money_info) ? '0.00' : mod_member_info::num_format($repay_money_info['repay_limit_sum'] - $repay_money_info['al_repay_limit_sum']);

				$list[$k]['account'] = empty($member_info) ? '' : $member_info['username'];
				$list[$k]['type_name'] = isset(mod_member_info::$type_list[$v['type']]) ? mod_member_info::$type_list[$v['type']] : '';
				$list[$k]['balan_money'] = empty($bank_info) ? '0.00' : mod_member_info::num_format($bank_info['money']);
				$list[$k]['parent_name'] = empty($parent_info) ? $parent_name : $parent_info['code'].' | '.$parent_info['name'];
				$list[$k]['usage_money'] = empty($credit_info) ? '0.00' : mod_member_info::num_format($credit_info['fixed_money'] + $credit_info['tmp_money'] - $credit_info['used_money']);
			}
		}

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('member_info.index.tpl');
    }

	//客户审核列表
	public function audit()
	{
		tpl::assign('is_all', 0);
		$this->_audit_list(1);
	}

	//客户已驳回列表
	public function al_reject()
	{
		tpl::assign('is_all', 0);
		$this->_audit_list(2);
	}

	//所有客户审核列表
	public function all_audit()
	{
		tpl::assign('is_all', 1);
		$this->_audit_list(3);
	}

	//所有客户已驳回列表
	public function all_al_reject()
	{
		tpl::assign('is_all', 1);
		$this->_audit_list(4);
	}

	//受理中列表
	public function accepting_list()
	{
		tpl::assign('is_all', req::item('is_all', '0','int'));
		$this->_audit_list( 5);
	}

	//已受理列表
	public function accepted_list()
	{
		tpl::assign('is_all', req::item('is_all', '0','int'));
		$this->_audit_list( 6);
	}

	/**
	 * 客户审核列表
	 *
	 * @param int $list_type 1=审核列表，2=驳回列表，3=所有审核列表，4=所有驳回列表
	 *
	 */
	private function _audit_list($list_type = 1)
	{
		$keyword = req::item('keyword', '');

		$where = array();
		if (!empty($keyword))
		{
			$where['or'][] = array ('code', 'like', $keyword.'%');
			$where['or'][] = array ('custom_code', 'like', $keyword.'%');
		}

		switch ($list_type)
		{
			case 1:
					$where['and'][] = array ('status', '=', 0);
					$where['and'][] = array ('parentid', '=', 0);
				break;
			case 2:
					$where['and'][] = array ('status', '=', 2);
					$where['and'][] = array ('parentid', '=', 0);
				break;
			case 3:
					$where['and'][] = array ('status', '=', 0);
				break;
			case 4:
					$where['and'][] = array ('status', '=', 2);
				break;
			case 5:
					$where['and'][] = array ('status', '=', 0);
					$where['and'][] = array ('parentid', '=', 0);
					$where['and'][] = array ('audit_id', '=', cls_auth::$user->fields['uid']);
				break;
			case 6:
					$where['and'][] = array ('status', 'in', array (1,2));
					$where['and'][] = array ('parentid', '=', 0);
					$where['and'][] = array ('audit_id', '=', cls_auth::$user->fields['uid']);
				break;
		}

		$count = mod_member_info::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_member_info::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$list[$k]['apply_date'] = date('Y-m-d H:i:s', $v['addtime']);
				$list[$k]['status_text'] = mod_member_info::$status_map[$v['status']];
			}
		}

		tpl::assign('list_type', $list_type);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('member_info.audit.tpl');
	}

	//客户审核详情
	public function audit_info()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);

		if ($member_info['type'] == 2 && $member_info['card_type'] == 3) {
			$names = mod_member_info::get_names([$member_info['bondsman1_id'], $member_info['bondsman2_id']]);
			$member_info['bondsmans'] = implode('，', $names);
		}

		$member_info['type_text'] = isset(mod_member_info::$type_list[$member_info['type']]) ? mod_member_info::$type_list[$member_info['type']] : '';
		$member_info['contact_ways_text'] = mod_member_info::contact_ways_text($member_info['contact_ways']);
		$member_info['card_pic_name'] = empty($member_info['card_pics']) ? lang::get('common_not_uploaded') : lang::get('common_uploaded');
		$member_info['currency_name'] = mod_member_info::get_default_currency_name();
		$member_info['sex_name'] = isset(mod_member_info::$sex_list[$member_info['gender']]) ? mod_member_info::$sex_list[$member_info['gender']] : '';

		//获取客户授信
		$default_currency_code = mod_member_info::get_default_currency_code();

		$member_credit_where = array ();
		$member_credit_where[] = array ('member_info_id', '=', $id);
		$member_credit_where[] = array ('currency_code', '=', $default_currency_code);
		$member_credit_info = mod_member_money_credit::get_info($member_credit_where);
		$member_info['fixed_limit'] = mod_member_info::num_format($member_credit_info['fixed_money']);
		$member_info['tmp_limit'] = mod_member_info::num_format($member_credit_info['tmp_money']);

		//获取管理员账号
		$account_info_where = array ();
		$account_info_where[] = array ('member_info_id', '=', $id);
		$account_info_where[] = array ('butt_type', '=', 0);
		$account_info = mod_member::get_info($account_info_where, 'username');
		$member_info['account'] = $account_info['username'];

		//获取上线信息
		$member_info['parent_name'] = empty($member_info['parentname']) ? mod_member_info::DEFAULT_PARENT_NAME : $member_info['parentname'];
		$member_info['parent_account'] = '';
		$member_info['parent_code'] = '';
		if(!empty($member_info['parentid']))
		{
			//$parent_account_info = mod_member::get_info("`member_info_id`='{$member_info['parentid']}' AND `butt_type`=0");
			//$member_info['parent_account'] = $parent_account_info['username'];

			$parent_info = mod_member_info::find($member_info['parentid']);
			$member_info['parent_code'] = $parent_info['code'];
		}

		//获取直属下线总人数
		$member_info['below_total'] = mod_member_info::get_count(array ('parentid', '=', $id));

		//证明人
		$member_info['bondsman_list_name'] = '';
		$member_info['bondsman1_code'] = '';
		$member_info['bondsman1_name'] = '';
		$member_info['bondsman2_code'] = '';
		$member_info['bondsman2_name'] = '';
		if(($member_info['type'] == 1 && $member_info['card_type'] == 3) || ($member_info['type'] == 2 && $member_info['card_type'] == 3))
		{
			if(!empty($member_info['bondsman1_id']))
			{
				$bondsman1_info = mod_member_info::find($member_info['bondsman1_id'], 'code,name');
				if($bondsman1_info)
				{
					$member_info['bondsman1_code'] = $bondsman1_info['code'];
					$member_info['bondsman_list_name'] = $member_info['bondsman1_name'] = $bondsman1_info['name'];
				}
			}

			if(!empty($member_info['bondsman2_id']))
			{
				$bondsman2_info = mod_member_info::find($member_info['bondsman2_id'], 'code,name');
				if($bondsman2_info)
				{
					$member_info['bondsman2_code'] = $bondsman2_info['code'];
					$member_info['bondsman2_name'] = $bondsman2_info['name'];
					$member_info['bondsman_list_name'] = empty($member_info['bondsman_list_name']) ? $member_info['bondsman2_name'] : $member_info['bondsman_list_name'].','.$member_info['bondsman2_name'];
				}
			}
		}

		//权限对接人
		$members = mod_member::get_list(array ('member_info_id', '=', $id), '', 0, 0, array ('butt_type', 'ASC'));
		$members = mod_member::fill_permission_names($members);

		if(!empty($members))
		{
			foreach ($members as $k => $member)
			{
				if ($member['butt_type'] == 0)
				{
					$member['butt_type_text'] = lang::get('member_super_admin');
				}
				else
				{
					$member['butt_type_text'] = $GLOBALS['config']['butt_type'][$member['butt_type']];
				}

				$view_permission_text = implode('、', $member['view_permission_names']);
				$edit_permission_text = implode('、', $member['edit_permission_names']);
				$member['permission_text'] = lang::get('member_page_view') . '：' . $view_permission_text . '<br>' . lang::get('member_page_edit') . '：' . $edit_permission_text;

				$members[$k] = $member;
			}
		}

		//处理返回URL
		$this->_handle_gourl();

		tpl::assign('butt_type_map', $GLOBALS['config']['butt_type']);
		tpl::assign('super_menus', mod_menu::super_menus());
		tpl::assign('member_info', $member_info);
		tpl::assign('members', $members);
		tpl::assign('person_card_type_list', mod_member_info::$person_card_type_list);
		tpl::assign('company_card_type_list', mod_member_info::$company_card_type_list);
		tpl::assign('company_type_list', mod_member_info::$company_type_list);
		tpl::assign('admin_id', cls_auth::$user->fields['uid']);
		tpl::display('member_info.audit_info.tpl');
	}

	//禁止登录
	public function forbid_login()
	{
		$this->_status();
	}

	//恢复登录
	public function allow_login()
	{
		$this->_status();
	}

	//修改客户状态
	private function _status()
	{
		$ids = req::item('ids');
		$status = req::item('status','0','int');

		if(empty($ids))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$up_data = array ();
		$up_data['login_status'] = $status;
		$up_data['uptime'] = time();

		mod_member_info::update_data(array ('id', 'in', $ids), $up_data);

		$ids = implode(',', $ids);
		$msg = $status == 1 ? lang::get('member_prohibited') : lang::get('member_restore');
		cls_auth::save_admin_log(cls_auth::$user->fields['username'], "{$msg}".lang::get('member_user_login')." {$ids}");

		$gourl = req::item('gourl', '?ct=member_info&ac=index');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
	}

	//客户管理查看详情
	public function info()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

        $member_info = mod_member_info::find($id);

        if ($member_info['type'] == 2 && $member_info['card_type'] == 3) {
            $names = mod_member_info::get_names([$member_info['bondsman1_id'], $member_info['bondsman2_id']]);
            $member_info['bondsmans'] = implode('，', $names);
        }

        $member_info['type_text'] = isset(mod_member_info::$type_list[$member_info['type']]) ? mod_member_info::$type_list[$member_info['type']] : '';
        $member_info['contact_ways_text'] = mod_member_info::contact_ways_text($member_info['contact_ways']);
		$member_info['card_pic_name'] = empty($member_info['card_pics']) ? lang::get('common_not_uploaded') : lang::get('common_uploaded');
		$member_info['currency_name'] = mod_member_info::get_default_currency_name();
		$member_info['sex_name'] = isset(mod_member_info::$sex_list[$member_info['gender']]) ? mod_member_info::$sex_list[$member_info['gender']] : '';

		//获取客户授信
		$default_currency_code = mod_member_info::get_default_currency_code();
		$member_credit_where = array();
		$member_credit_where[] = array('member_info_id', '=', $id);
		$member_credit_where[] = array('currency_code', '=', $default_currency_code);
		$member_credit_info = mod_member_money_credit::get_info($member_credit_where);
		$member_info['fixed_limit'] = mod_member_info::num_format($member_credit_info['fixed_money']);
		$member_info['tmp_limit'] = mod_member_info::num_format($member_credit_info['tmp_money']);

		//获取管理员账号
		$account_info_where = array ();
		$account_info_where[] = array ('member_info_id', '=', $id);
		$account_info_where[] = array ('butt_type', '=', 0);
		$account_info = mod_member::get_info($account_info_where);
		$member_info['account'] = $account_info['username'];

		//获取上线信息
		$member_info['parent_name'] = empty($member_info['parentname']) ? mod_member_info::DEFAULT_PARENT_NAME : $member_info['parentname'];
		$member_info['parent_account'] = '';
		$member_info['parent_code'] = '';
		if(!empty($member_info['parentid']))
		{
			//$parent_account_info = mod_member::get_info("`member_info_id`='{$member_info['parentid']}' AND `butt_type`=0");
			//$member_info['parent_account'] = $parent_account_info['username'];

			$parent_info = mod_member_info::find($member_info['parentid']);
			$member_info['parent_code'] = $parent_info['code'];
		}

		//获取直属下线总人数
		$member_info['below_total'] = mod_member_info::get_count(array ('parentid', '=', $id));

		//证明人
		$member_info['bondsman_list_name'] = '';
		$member_info['bondsman1_code'] = '';
		$member_info['bondsman1_name'] = '';
		$member_info['bondsman2_code'] = '';
		$member_info['bondsman2_name'] = '';
		if(($member_info['type'] == 1 && $member_info['card_type'] == 3) || ($member_info['type'] == 2 && $member_info['card_type'] == 3))
		{
			if(!empty($member_info['bondsman1_id']))
			{
				$bondsman1_info = mod_member_info::find($member_info['bondsman1_id'], 'code,name');

				if($bondsman1_info)
				{
					$member_info['bondsman1_code'] = $bondsman1_info['code'];
					$member_info['bondsman1_name'] = $bondsman1_info['name'];
					$member_info['bondsman_list_name'] = $member_info['bondsman1_name'] = $bondsman1_info['name'];
				}
			}

			if(!empty($member_info['bondsman2_id']))
			{
				$bondsman2_info = mod_member_info::find($member_info['bondsman2_id'], 'code,name');

				if($bondsman2_info)
				{
					$member_info['bondsman2_code'] = $bondsman2_info['code'];
					$member_info['bondsman2_name'] = $bondsman2_info['name'];
					$member_info['bondsman_list_name'] = empty($member_info['bondsman_list_name']) ? $member_info['bondsman2_name'] : $member_info['bondsman_list_name'].','.$member_info['bondsman2_name'];
				}
			}
		}

        tpl::assign('butt_type_map', $GLOBALS['config']['butt_type']);
        tpl::assign('super_menus', mod_menu::super_menus());
        tpl::assign('member_info', $member_info);
		tpl::assign('person_card_type_list', mod_member_info::$person_card_type_list);
		tpl::assign('company_card_type_list', mod_member_info::$company_card_type_list);
		tpl::assign('company_type_list', mod_member_info::$company_type_list);
		tpl::assign('gourl', '?ct=member_info&ac=index');
        tpl::display('member_info.info.tpl');
	}

	//业务对接人
	public function abutment_person()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$members = mod_member::get_list(array ('member_info_id', '=', $id), '', 0, 0, array ('butt_type', 'ASC'));
		$members = mod_member::fill_permission_names($members);
		if(!empty($members))
		{
			foreach ($members as $k => $member)
			{
				if ($member['butt_type'] == 0)
				{
					$member['butt_type_text'] = lang::get('member_super_admin');
				}
				else
				{
					//$member['butt_type_text'] = $GLOBALS['config']['butt_type'][$member['butt_type']];
					$member['butt_type_text'] = lang::get('common_butt_type' . $member['butt_type']);
				}

				$view_permission_text = implode('、', $member['view_permission_names']);
				$edit_permission_text = implode('、', $member['edit_permission_names']);
				$member['permission_text'] = lang::get('member_page_view') . '：' . $view_permission_text . '<br>' . lang::get('member_page_edit') . '：' . $edit_permission_text;

				$members[$k] = $member;
			}
		}
		//处理返回URL
		$this->_handle_gourl();

		tpl::assign('butt_type_map', $GLOBALS['config']['butt_type']);
		tpl::assign('super_menus', mod_menu::super_menus());
		tpl::assign('member_info', $member_info);
		tpl::assign('members', $members);
		tpl::display('member_info.abutment_person.tpl');
	}

	// 驳回
	public function reject()
    {
        $id = req::item('id', 0, 'int');
        $fail_reason = req::item('fail_reason');

        if($id <= 0)
        {
            cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
        }

		if(empty($fail_reason))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_entry_rejected_reason'), '-1');
		}

		$member_info = mod_member_info::find($id);
		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		if($member_info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		$up_data = array ();
		$up_data['fail_reason'] = $fail_reason;
		$up_data['status'] = 2;
        $up_data['uptime'] = time();

        $result = mod_member_info::update_data(array ('id', '=', $id), $up_data);

		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('member_dismissed_customer_audit')." {$id}");

        $gourl = req::item('gourl', $this->_handle_gourl());
        cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
    }

    // 同意
    public function agree()
    {
        $id = req::item('id', 0);
        $parentid = req::item('parentid', 0);
        $parent = req::item('parent');

        if($id <= 0 || $parentid < 0)
        {
            cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
        }

		$member_info = mod_member_info::find($id);
		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		if($member_info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		if(!empty($parent))
		{
			$parent_list = explode('-',$parent);
			unset($parent_list[count($parent_list)-1]);
			$code = implode('-',$parent_list);
			//判断提交的客户名称与客户ID是否一致
			$parent_info_where = array ();
			$parent_info_where['or'][] = array ('code', '=', $code);
			$parent_info_where['or'][] = array ('custom_code', '=', $code);
			$parent_info = mod_member_info::get_info($parent_info_where);
			if(empty($parent_info) || (!empty($parent_info) && $parent_info['id'] != $parentid))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_online_users_not_exist'), '-1');
			}
		}

		$up_data = array ();

		if($parentid > 0)
		{
			$parent_member_info = mod_member_info::find($parentid);
			if (! empty($parent_member_info)) {
				$up_data['parentid'] = $parentid;
				$up_data['parentname'] = $parent_member_info['name'];
				$up_data['parentpath'] = empty($parent_member_info['parentpath']) ? $parentid : $parentid . ',' . $parent_member_info['parentpath'];
			}
			else
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_online_users_not_exist'), '-1');
			}

			$up_data['status'] = 0;

		}
		else
		{
			$up_data['status'] = 1;
		}

        $up_data['uptime'] = time();

		$result = mod_member_info::update_data(array ('id', '=', $id), $up_data);

		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}
		else
		{
			if($parentid > 0)
			{
				//推送消息
				$title = lang::get('push_message_downline_audit_title');
				$content = lang::get('push_message_downline_audit');

				mod_app_message::create($parentid, 0, $title, $content, '', 2, 3, $id);
			}
		}

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('member_agree_customer_audit')." {$id}");

        $gourl = req::item('gourl', $this->_handle_gourl());
        cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
    }

	//查询成员
    public function query()
    {
        header('Content-Type: application/json; Charset=utf-8');

        $keyword = req::item('query', '');
        $id = req::item('id', '');

        $where = array ();
        if (empty($keyword) && !is_numeric($keyword)) {
			$format_data[] = ['data' => 0, 'value' => lang::get('member_search_not_users')];
            exit(json_encode(['suggestions' => $format_data]));
        }
		else
		{
			$where['or'][] = array ('code', 'like', $keyword.'%');
			$where['or'][] = array ('custom_code', 'like', $keyword.'%');
		}

		$where['and'][] = array ('status', '=', 1);
		if(!empty($id))
		{
			$where['and'][] = array ('id', '!=', $id);
		}

		$list = mod_member_info::get_list($where, 'id,code,name', 100);
        $format_data = [];
        if($list)
		{
			foreach ($list as $item) {
				$format_data[] = ['data' => $item['id'], 'value' => $item['code'].'-'.$item['name']];
			}
		}
		else
		{
			$format_data[] = ['data' => 0, 'value' => lang::get('member_search_not_users')];
		}

        exit(json_encode(['suggestions' => $format_data]));
    }

	//编辑
	public function edit()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		if(req::method() == "POST")
		{
			$name = req::item('name');
			$type = req::item('type');
			$card_type = req::item('card_type');
			$card_name = req::item('card_name');
			$card_code1 = req::item('card_code1');
			$card_code2 = req::item('card_code2');
			$company_type = req::item('company_type');
			$card_pics = req::item('card_pics');
			$address = req::item('address');
			$bondsman1_name = req::item('bondsman1_name');
			$bondsman1_code = req::item('bondsman1_code');
			$bondsman2_name = req::item('bondsman2_name');
			$bondsman2_code = req::item('bondsman2_code');
			$contact_types = req::item('contact_way');
			$contact_phones = req::item('contact_num');
			$contacts = req::item('contacts');
			$gender = req::item('gender',1);

			$card_code = empty($card_code1) ? $card_code2 : $card_code1;
			$mem_up_data = array ();

			$contact_ways = array ();
			if(!empty($contact_phones))
			{
				foreach ($contact_phones as $k => $contact_phone) {
					if (empty($contact_phone)) {
						util::response_json(409, lang::get('member_entry').' ' . $contact_types[$k] . ' '.lang::get('member_contact_information'), -1);
					}

					$contact_ways[] = $contact_types[$k] . '-' . $contact_phone;
				}
			}

			if(empty($contact_ways))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_enter_contact_information'), '-1');
			}

			//个人用户
			if($type == 2)
			{
				if(empty($name))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_entry_name'), '-1');
				}

				if($card_type != 3)
				{
					if(!empty($card_pics))
					{
						$up_data['card_pics'] = implode(',',$card_pics);
					}
					else
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_empty_photo'), '-1');
					}
				}

				$mem_up_data['name'] = $name;
			}
			else
			{
				if(empty($name))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_enter_institution_name'), '-1');
				}

				//机构用户名称不能重复
				$name_exit_info_where = array ();
				$name_exit_info_where[] = array ('type', '=', 1);
				$name_exit_info_where[] = array ('id', '!=', $id);
				$name_exit_info_where[] = array ('name', '=', $name);
				$name_exit_count = mod_member_info::get_count($name_exit_info_where);
				if($name_exit_count > 0)
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_institution_name_no_repeat'), '-1');
				}

				if($card_type == 2)
				{
					if(!empty($card_pics))
					{
						$up_data['card_pics'] = implode(',',$card_pics);
					}
					else
					{
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_empty_photo'), '-1');
					}
				}

				$mem_up_data['name'] = $up_data['contacts'] = $contacts;
				$up_data['company_type'] = $company_type;
			}

			//证件类型为其他的时候
			if($card_type == 3)
			{
				//证件名与号码不能为空
				if(empty($card_name))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_register_card_name_ph'), '-1');
				}

				if(empty($card_code))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_register_card_num_ph'), '-1');
				}

				//查询担保人
				if(empty($bondsman1_name) || empty($bondsman2_name))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_empty_guarantor'), '-1');
				}

				//证明人不能为同一个人
				if($bondsman1_name == $bondsman2_name)
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_register_prove_cannot_same'), '-1');
				}

				//查询担保人
				if(empty($bondsman1_code) || empty($bondsman2_code))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_register_prove_code_ph'), '-1');
				}

				$bondsman1_info = mod_member_info::get_bondsman_info($bondsman1_code, $bondsman1_name);
				if(empty($bondsman1_info))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_empty_guarantor1'), '-1');
				}

				$bondsman1_info = mod_member_info::get_bondsman_info($bondsman2_code, $bondsman2_name);
				if(empty($bondsman2_info))
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_empty_guarantor2'), '-1');
				}

				if($bondsman1_info['id'] == $bondsman2_info['id'])
				{
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_not_same_guarantor'), '-1');
				}

				$up_data['card_name'] = $card_name;
				$up_data['bondsman1_id'] = $bondsman1_info['id'];
				$up_data['bondsman2_id'] = $bondsman2_info['id'];
			}

			$up_data['card_code'] = $card_code;
			$up_data['card_type'] = $card_type;
			$up_data['name'] = $name;
			$up_data['address'] = $address;
			$up_data['gender'] = $gender;
			$up_data['contact_ways'] = implode(',',$contact_ways);

			db::begin_tran();

			$result = mod_member_info::update_data(array ('id', '=', $id),$up_data);

			if(empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
			}

			//修改账户姓名
			$mem_up_data['contact_ways'] = $up_data['contact_ways'];
			$result = db::update('#PB#_member',$mem_up_data,"`member_info_id`='{$id}' and `butt_type`=0");

			if(empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
			}

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('member_edit_user_information')." {$name}");

			db::commit();
			db::autocommit(true);

			if(!empty($card_pics))
			{
				$this->_move_file($card_pics);
			}

			$gourl = req::item('gourl', '?ct=member_info&ac=index');
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), $gourl);
		}
		else
		{
			$info = mod_member_info::find($id);
			$contact_ways = explode(',',$info['contact_ways']);
			$contact_ways_list = array ();
			foreach ($contact_ways as $cv)
			{
				$cv_arr = explode('-',$cv);
				if(isset($cv_arr[0]) && isset($cv_arr[1]))
				{
					$contact_ways_list[] = array ('key' => $cv_arr[0],'val' => $cv_arr[1]);
				}
			}

			//个人信息
			$info['bondsman1_name'] = '';
			$info['bondsman1_code'] = '';
			$info['bondsman2_name'] = '';
			$info['bondsman2_code'] = '';

			//查询担保人
			if($info['card_type'] == 3)
			{
				if(!empty($info['bondsman1_id']))
				{
					$bondsman1_info = mod_member_info::find($info['bondsman1_id'], 'code, name');
					$info['bondsman1_name'] = $bondsman1_info['name'];
					$info['bondsman1_code'] = $bondsman1_info['code'];
				}

				if(!empty($info['bondsman2_id']))
				{
					$bondsman2_info = mod_member_info::find($info['bondsman2_id'], 'code, name');
					$info['bondsman2_name'] = $bondsman2_info['name'];
					$info['bondsman2_code'] = $bondsman2_info['code'];
				}
			}

			$info['card_pics'] = !empty($info['card_pics']) ? explode(',',$info['card_pics']) : array ();
			$info['contact_ways'] = $contact_ways_list;
			$gourl = req::item('gourl', '?ct=member_info&ac=index');
			tpl::assign('info', $info);
			tpl::assign('img_url', URL_UPLOADS.'/image');
			tpl::assign('person_card_type_list', mod_member_info::$person_card_type_list);
			tpl::assign('company_card_type_list', mod_member_info::$company_card_type_list);
			tpl::assign('contact_way_list', mod_member_info::$contact_way_list);
			tpl::assign('company_type_list', mod_member_info::$company_type_list);
			tpl::assign('sex_list', mod_member_info::$sex_list);
			tpl::assign('gourl', $gourl);
			tpl::display('member_info.edit.tpl');
		}
	}

	//月结账单
	public function month_bill()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);
		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		//查询月账单
		$bill_where = array ();
		$bill_where[] = array ('member_info_id', '=', $id);

		$count = mod_member_bill_month::get_count($bill_where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$month_bill_list =  mod_member_bill_month::get_list($bill_where, '', $pages['page_size'], $pages['offset']);
		//货币类型
		$currency_list = mod_currency_type::get_key_val();

		$now_time = time();

		if(!empty($month_bill_list))
		{
			foreach ($month_bill_list as $k => $v)
			{
				$end_time = strtotime($v['end_date'].' 23:59:59');

				$month_bill_list[$k]['repay_limit'] = mod_member_info::num_format($v['repay_limit']);
				$month_bill_list[$k]['al_repay_limit'] = mod_member_info::num_format($v['al_repay_limit']);
				$month_bill_list[$k]['surplus_limit'] = mod_member_info::num_format($v['repay_limit'] - $v['al_repay_limit']);
				$month_bill_list[$k]['member_code_name'] = $member_info['code'].' | '.$member_info['name'];
				$month_bill_list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
				//$month_bill_list[$k]['status_name'] = isset(mod_bill_month::$status_list[$v['status']]) ? mod_bill_month::$status_list[$v['status']] : '';

				//判断是否逾期
				if($now_time > $end_time)
				{
					if($v['al_repay_limit'] == $v['repay_limit']  || $v['repay_limit'] == 0)
					{
						$month_bill_list[$k]['status_name'] = lang::get('month_bill_has_cleared');
					}
					elseif($v['al_repay_limit'] == 0)
					{
						$month_bill_list[$k]['status_name'] = lang::get('month_bill_overdue');
					}
					else
					{
						$month_bill_list[$k]['status_name'] = lang::get('month_bill_overdue_settlement');
					}
				}
				else
				{
					if($v['al_repay_limit'] == 0 && $v['repay_limit'] != 0)
					{
						$month_bill_list[$k]['status_name'] = lang::get('month_bill_open');
					}
					elseif($v['al_repay_limit'] == $v['repay_limit']  || $v['repay_limit'] == 0)
					{
						$month_bill_list[$k]['status_name'] = lang::get('month_bill_has_cleared');
					}
					else
					{
						$month_bill_list[$k]['status_name'] = lang::get('month_bill_not_settled');
					}
				}
			}
		}

		tpl::assign('member_info', $member_info);
		tpl::assign('month_bill_list', $month_bill_list);
		tpl::assign('pages', $pages['show']);
		tpl::assign('gourl', "?ct=member_info&ac=info&id={$id}");
		tpl::display('member_info.month_bill.tpl');
	}

	//交易明细
	public function bill()
	{
		$id = req::item('id');
		$start_date = req::item('start_date');
		$end_date = req::item('end_date');
		$type = req::item('type','','int');
		$bill_time = req::item('bill_time','','int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$bill_where = array ();

		if(!empty($type))
		{
			$bill_where[] = array ('type', '=', $type);
		}

		switch ($bill_time)
		{
			case 1:
					$start_time = strtotime(date('Y-m-d').' 00:00:00');
					$end_time = strtotime(date('Y-m-d').' 23:59:59');
					$bill_where[] = array ('addtime', '>=', $start_time);
					$bill_where[] = array ('addtime', '<=', $end_time);
				break;
			case 2:
					$start_time = strtotime(date("Y-m-d H:i:s",mktime(0, 0 , 0,date("m"),date("d")-date("w")+1,date("Y"))));
					$end_time = strtotime(date("Y-m-d H:i:s",mktime(23,59,59,date("m"),date("d")-date("w")+7,date("Y"))));
					$bill_where[] = array ('addtime', '>=', $start_time);
					$bill_where[] = array ('addtime', '<=', $end_time);
				break;
			case 3:
					$start_time = date('Y-m').'-01 00:00:00';
					$start_time = strtotime($start_time.' 00:00:00');
					$end_time = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m', strtotime('+1 month')).'-01')));
					$end_time = strtotime($end_time.' 23:59:59');
					$bill_where[] = array ('addtime', '>=', $start_time);
					$bill_where[] = array ('addtime', '<=', $end_time);
				break;
			case 4:
					if(!empty($start_date))
					{
						$start_time = strtotime($start_date.' 00:00:00');
						$bill_where[] = array ('addtime', '>=', $start_time);
					}
					if(!empty($end_date))
					{
						$end_time = strtotime($end_date.' 23:59:59');
						$bill_where[] = array ('addtime', '<=', $end_time);
					}

				break;
		}
		//查询账单流水
		$bill_where[] = array ('member_info_id', '=', $id);

		$count = mod_member_bill::get_count($bill_where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$bill_list = mod_member_bill::get_list($bill_where,'', $pages['page_size'], $pages['offset']);

		//货币列表
		$currency_list = mod_currency_type::get_key_val();
		if(!empty($bill_list))
		{
			foreach ($bill_list as $k => $v)
			{
				$bill_list[$k]['add_date'] = date('Y-m-d H:i:s', $v['addtime']);
				$bill_list[$k]['type_name'] = isset(mod_member_bill::$type_list[$v['type']]) ? mod_member_bill::$type_list[$v['type']] : '';
				$bill_list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
				$bill_list[$k]['amount'] = mod_member_info::num_format($v['amount']);
				/*
					//获取账单信息
					$sql = "SELECT `o`.`interface_id` AS `interface_id` FROM `#PB#_member_bill` AS `mb` JOIN `#PB#_member_order_bill_link` AS `mobl` ON `mb`.`bill_id` = `mobl`.`bill_id` JOIN `#PB#_order` AS `o` ON `o`.`order_id`=`mobl`.`order_id` WHERE `mb`.`bill_id`='{$v['bill_id']}'";
					$order_info = db::get_one($sql);

					//获取接口信息
					$interfaces_name = '';
					if(!empty($order_info))
					{
						$interfaces_info = mod_shop_interfaces::get_info("`id`='{$order_info['interface_id']}'");
						$interfaces_name = empty($interfaces_info) ? '' : $interfaces_info['name'];
					}
					$bill_list[$k]['interfaces_name'] = $interfaces_name;
				*/
			}
		}

		tpl::assign('start_date', $start_date);
		tpl::assign('end_date', $end_date);
		tpl::assign('type', $type);
		tpl::assign('bill_time', $bill_time);
		tpl::assign('member_info', $member_info);
		tpl::assign('bill_list', $bill_list);
		tpl::assign('pages', $pages['show']);
		tpl::assign('gourl', "?ct=member_info&ac=info&id={$id}");
		tpl::display('member_info.bill.tpl');
	}

	//查看照片
	public function show_pics()
	{
		$id = req::item('id');
		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id, 'card_pics');

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$pics = explode(',', $member_info['card_pics']);
		foreach ($pics as $k => $v)
		{
			$pics[$k] = URL_UPLOADS.'/image/'.$v;
		}
		tpl::assign('pics', $pics);
		tpl::display('modal.pics.view.tpl');
	}

	//财务信息
	public function financial_info()
	{
		//获取客户信息
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		//获取客户默认币种
		$default_currency_code = mod_member_info::get_default_currency_code();

		//客户默认货币名称
		$member_info['currency_name'] = mod_member_info::get_default_currency_name();

		//获取系统默认货币
		$platform_currency_code = mod_currency_type::get_default_curr();

		//获取授信信息
		$member_credit_where = array ();
		$member_credit_where[] = array ('member_info_id', '=', $id);
		$member_credit_where[] = array ('currency_code', '=', $default_currency_code);
		$member_credit_info = mod_member_money_credit::get_info($member_credit_where);

		$member_info['fixed_limit'] = mod_member_info::num_format($member_credit_info['fixed_money']);
		$member_info['tmp_limit'] = mod_member_info::num_format($member_credit_info['tmp_money']);
		$member_info['used_money'] = mod_member_info::num_format($member_credit_info['used_money']);
		$member_info['surplus_money'] = mod_member_info::num_format($member_credit_info['fixed_money'] + $member_credit_info['tmp_money'] - $member_credit_info['used_money']);

		//获取钱包信息
		$member_bank_where = array ();
		$member_bank_where[] = array ('member_info_id', '=', $id);
		$member_bank_where[] = array ('currency_code', '=', $default_currency_code);
		$member_bank_info = mod_member_money_bank::get_info($member_bank_where);

		$member_info['money'] = mod_member_info::num_format($member_bank_info['money']);

		//获取客户欠款总额
		$repay_list_where = array ();
		$repay_list_where[] = array ('member_info_id', '=', $id);
		$repay_list_where[] = array ('status', '=', 2);
		$repay_list = mod_member_bill_month::get_list($repay_list_where, 'sum(`repay_limit`) AS `repay_limit_sum`,sum(`al_repay_limit`) AS `al_repay_limit_sum`,`currency_code`', 0, 0, '', 'currency_code');
		$surplus_repay_sum = 0;
		if($repay_list)
		{
			foreach ($repay_list as $k => $v)
			{
				$surplus_repay_sum += mod_currency_type::income_exg_money($v['repay_limit_sum'] - $v['al_repay_limit_sum'],$v['currency_code']);
			}
		}
		$member_info['surplus_repay_sum'] = mod_member_info::num_format($surplus_repay_sum);

		tpl::assign('member_info', $member_info);
		tpl::assign('platform_currency_code', $platform_currency_code);
		tpl::assign('gourl', '?ct=member_info&ac=index');
		tpl::display('member_info.financial_info.tpl');
	}

	//下线管理
	public function offline_manager()
	{
		//获取客户信息
		$id = req::item('id');
		$keyword = req::item('keyword', '');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$where = array();
		if (!empty($keyword))
		{
			$where['or'][] = array ('code', 'like', $keyword.'%');
			$where['or'][] = array ('custom_code', 'like', $keyword.'%');
		}

		$where['and'][] = array ('parentid', '=', $id);
		$where['and'][] = array ('status', '=', 1);

		$count = mod_member_info::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_member_info::get_list($where, '', $pages['page_size'], $pages['offset']);

		//获取默认货币
		$default_currency_code = mod_member_info::get_default_currency_code();

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$member_account_info_where = array ();
				$member_account_info_where[] = array ('member_info_id', '=', $v['id']);
				$member_account_info_where[] = array ('butt_type', '=', 0);
				$member_account_info = mod_member::get_info($member_account_info_where);

				//授信固定额度
				$credit_info_where = array ();
				$credit_info_where[] = array ('member_info_id', '=', $v['id']);
				$credit_info_where[] = array ('currency_code', '=', $default_currency_code);
				$credit_info = mod_member_money_credit::get_info($credit_info_where);
				$list[$k]['fixed_limit'] = empty($credit_info) ? '0.00' : mod_member_info::num_format($credit_info['fixed_money'] + $credit_info['tmp_money']);
				$list[$k]['fixed_money'] = empty($credit_info) ? '0.00' : mod_member_info::num_format($credit_info['fixed_money']);
				$list[$k]['tmp_money'] = empty($credit_info) ? '0.00' : mod_member_info::num_format($credit_info['tmp_money']);

				$bank_info_where = array ();
				$bank_info_where[] = array ('member_info_id', '=', $v['id']);
				$bank_info_where[] = array ('currency_code', '=', $default_currency_code);
				$bank_info = mod_member_money_bank::get_info($bank_info_where);
				//本期账单金额
				$repay_money_info_where = array ();
				$repay_money_info_where[] = array ('member_info_id', '=', $v['id']);
				$repay_money_info_where[] = array ('status', '=', 2);
				$repay_money_info = mod_member_bill_month::get_info($repay_money_info_where, 'sum(`repay_limit`) as `repay_limit_sum`,sum(`al_repay_limit`) as `al_repay_limit_sum`');
				$list[$k]['repay_amount'] = empty($repay_money_info) ? '0.00' : mod_member_info::num_format($repay_money_info['repay_limit_sum'] - $repay_money_info['al_repay_limit_sum']);

				$list[$k]['account'] = empty($member_account_info) ? '' : $member_account_info['username'];
				$list[$k]['add_date'] = empty($member_account_info) ? '' : date('Y-m-d H:i:s',$member_account_info['addtime']);
				$list[$k]['type_name'] = isset(mod_member_info::$type_list[$v['type']]) ? mod_member_info::$type_list[$v['type']] : '';
				$list[$k]['balan_money'] = empty($bank_info) ? '0.00' : mod_member_info::num_format($bank_info['money']);
				$list[$k]['usage_money'] = empty($credit_info) ? '0.00' : mod_member_info::num_format($credit_info['fixed_money'] + $credit_info['tmp_money'] - $credit_info['used_money']);
			}
		}

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);

		tpl::assign('member_info', $member_info);
		tpl::assign('list', $list);
		tpl::assign('gourl', '?ct=member_info&ac=index');
		tpl::display('member_info.offline_manager.tpl');
	}

	//联系方式
	public function contact_info()
	{
		//获取客户信息
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$members = mod_member::get_list(array ('member_info_id', '=', $id), '', 0, 0, array ('butt_type', 'ASC'));
		if(!empty($members))
		{
			foreach ($members as $k => $member)
			{
				if ($member['butt_type'] == 0)
				{
					$member['butt_type_text'] = lang::get('member_super_admin');
				}
				else
				{
					//$member['butt_type_text'] = $GLOBALS['config']['butt_type'][$member['butt_type']];
					$member['butt_type_text'] = lang::get('common_butt_type' . $member['butt_type']);
				}

				$member['contact_ways_list'] = explode(',', $member['contact_ways']);
				$members[$k] = $member;
			}
		}
		//处理返回URL
		$this->_handle_gourl();

		tpl::assign('member_info', $member_info);
		tpl::assign('members', $members);
		tpl::display('member_info.contact_info.tpl');
	}

	//受理
	public function accepte()
	{
		//获取客户信息
		$id = req::item('id');
		$list_type = req::item('list_type','0','int');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$member_info = mod_member_info::find($id);

		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		$update_data = array ();
		$update_data['audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		mod_member_info::update_data(array ('id', '=', $id), $update_data);
		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('member_audit_accepte')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_acceptance_success'), "?ct=member_info&ac=audit_info&id={$id}&list_type={$list_type}");
	}

	//处理返回URL
	private function _handle_gourl()
	{
		$list_type = req::item('list_type','0','int');
		$is_all = req::item('is_all','0','int');

		$all = 0;
		//处理返回URL
		switch ($list_type)
		{
			case 1:
				$gourl = "?ct=member_info&ac=audit&list_type={$list_type}&is_all=0";
				break;
			case 2:
				$gourl = "?ct=member_info&ac=al_reject&list_type={$list_type}&is_all=0";
				break;
			case 3:
				$gourl = "?ct=member_info&ac=all_audit&list_type={$list_type}&is_all=1";
				break;
			case 4:
				$gourl = "?ct=member_info&ac=all_al_reject&list_type={$list_type}&is_all=1";
				break;
			case 5:
				$gourl = "?ct=member_info&ac=accepting_list&list_type={$list_type}&is_all={$is_all}";
				break;
			case 6:
				$gourl = "?ct=member_info&ac=accepted_list&list_type={$list_type}&is_all={$is_all}";
				break;
			default:
				$gourl = "?ct=member_info&ac=index";
				break;
		}

		tpl::assign('is_all', $is_all);
		tpl::assign('list_type', $list_type);
		tpl::assign('gourl', $gourl);

		return $gourl;
	}

	//移动文件
	private function _move_file($files)
	{
		if(empty($files))
		{
			return true;
		}

		//没有该目录则创建
		if(!is_dir(PATH_UPLOADS.'/file'))
		{
			if(!mkdir(PATH_UPLOADS.'/file',0777))
			{
				return false;
			}
		}

		//移动文件
		if(is_array($files))
		{
			foreach ($files as $file)
			{
				if(file_exists(PATH_UPLOADS.'/tmp/'.$file))
				{
					if(!rename(PATH_UPLOADS.'/tmp/'.$file, PATH_UPLOADS.'/image/'.$file))
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}

			return true;
		}
		else
		{
			if(file_exists(PATH_UPLOADS.'/tmp/'.$files))
			{
				return rename(PATH_UPLOADS.'/tmp/'.$files, PATH_UPLOADS.'/image/'.$files);
			}
			else
			{
				return false;
			}
		}
	}
}
