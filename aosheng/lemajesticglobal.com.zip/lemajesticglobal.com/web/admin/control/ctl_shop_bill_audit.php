<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 商户提现与充值审核管理
 *
 * @version $Id$
 */
class ctl_shop_bill_audit
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("shop", $lang);
		lang::load("bill_audit", $lang);
		lang::load("model", $lang);

		mod_shop_bill_audit::$type_list[1] = lang::get('model_recharge');
		mod_shop_bill_audit::$type_list[2] = lang::get('model_withdraw');

		mod_member_bill_audit::$type_list[1] = lang::get('model_recharge');
		mod_member_bill_audit::$type_list[2] = lang::get('model_withdraw');
		mod_member_bill_audit::$status_list[0] = lang::get('model_pending');
		mod_member_bill_audit::$status_list[1] = lang::get('model_customer_confirmed');
		mod_member_bill_audit::$status_list[2] = lang::get('model_customer_dismissed');
		mod_member_bill_audit::$status_list[3] = lang::get('model_financial_confirmation');
		mod_member_bill_audit::$status_list[4] = lang::get('model_financial_dismissed');
    }

    /**
     * 客服待处理列表
     */
    public function index()
    {
    	$this->_list(1);
    }

	//客服已确认
	public function custom_confirm_list()
	{
		$this->_list(2);
	}

	//客服已完成
	public function custom_complete_list()
	{
		$this->_list(3);
	}

	//客服被驳回
	public function custom_reject_list()
	{
		$this->_list(4);
	}

	//财务待处理
	public function finance_list()
	{
		$this->_list(5);
	}

	//财务驳回
	public function finance_reject_list()
	{
		$this->_list(6);
	}

	//财务已完成
	public function finance_complete_list()
	{
		$this->_list(7);
	}

	//客服受理中
	public function custom_accepting()
	{
		$this->_list(8);
	}

	//客服已受理
	public function custom_accepted()
	{
		$this->_list(9);
	}

	//财务受理中
	public function finance_accepting_list()
	{
		$this->_list(10);
	}

	//财务已受理
	public function finance_accepted_list()
	{
		$this->_list(11);
	}

	//获取列表
	private function _list($type_list = 1)
	{
		$start_time = req::item('start_time', '');
		$end_time = req::item('end_time', '');
		$keyword = req::item('keyword', '');
		//$status = req::item('status', '0');

		$where = array();
		$admin_id = cls_auth::$user->fields['uid'];

		$info_handle = "custom_info";
		switch ($type_list)
		{
			case 1:
					$status = 0;
				break;
			case 2:
					$status = 1;
				break;
			case 3:
					$status = 3;
				break;
			case 4:
					$status = array (2,4);
				break;
			case 5:
					$status = 1;
					$info_handle = "finance_info";
				break;
			case 6:
					$status = 4;
					$info_handle = "finance_info";
				break;
			case 7:
					$status = 3;
					$info_handle = "finance_info";
				break;
			case 8:
				$status = 0;
				$where[] = array ('op_id', '=', $admin_id);
				break;
			case 9:
				$status = array (1,2,4);
				$where[] = array ('op_id', '=', $admin_id);
				break;
			case 10:
				$status = 1;
				$where[] = array ('finance_op_id', '=', $admin_id);
				$info_handle = "finance_info";
				break;
			case 11:
				$status = array (3,4);
				$where[] = array ('finance_op_id', '=', $admin_id);
				$info_handle = "finance_info";
				break;
		}

		if(!empty($keyword))
		{
			$mem_list = mod_shop::get_list(array ('name', 'like', $keyword.'%'), 'id');
			if(empty($mem_list))
			{
				$where[] = array ('shop_id', '=', 0);
			}
			else
			{
				$mem_ids = array ();
				foreach ($mem_list as $k => $v)
				{
					$mem_ids[] = $v['id'];
				}
				$where[] = array ('shop_id', 'in', $mem_ids);
			}
		}

		if(!empty($start_time))
		{
			$start_time = strtotime($start_time);
			$where[] = array ('addtime', '>=', $start_time);
		}

		if(!empty($end_time))
		{
			$end_time = strtotime($end_time);
			$where[] = array ('addtime', '<=', $end_time);
		}

		if(is_array($status))
		{
			$where[] = array ('status', 'in', $status);
		}
		else
		{
			$where[] = array ('status', '=', $status);
		}

		$count = mod_shop_bill_audit::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_shop_bill_audit::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k => $v)
			{
				$shop_info = mod_shop::find($v['shop_id']);
				$list[$k]['shop_name'] = empty($shop_info) ? '' : $shop_info['name'];

				$v['audit_money'] = empty($v['audit_money']) ? 0 : $v['audit_money'];
				$v['extra_charge'] = empty($v['extra_charge']) ? 0 : $v['extra_charge'];
				$v['apply_money'] = empty($v['apply_money']) ? 0 : $v['apply_money'];
				$list[$k]['actual_amount'] = $v['status'] == 0 ? '-' : mod_member_info::num_format($v['audit_money'] - $v['extra_charge']);
				$list[$k]['add_date'] = date('Y-m-d H:i:s', $v['addtime']);
				$list[$k]['type_name'] = isset(mod_shop_bill_audit::$type_list[$v['type']]) ? mod_shop_bill_audit::$type_list[$v['type']] : '';
				$list[$k]['apply_money'] = mod_member_info::num_format($v['apply_money']);
				$list[$k]['audit_money'] = $v['status'] == 0 ? '-' : mod_member_info::num_format($v['audit_money']);
				$list[$k]['extra_charge'] = $v['status'] == 0 ? '-' : mod_member_info::num_format($v['extra_charge']);
			}
		}

		tpl::assign('type_list', $type_list);
		tpl::assign('info_handle', $info_handle);
		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::display('shop_bill_audit.index.tpl');
	}

	//客服详情
	public function custom_info()
	{
		$this->_info('shop_bill_audit.custom_info.tpl');
	}

	//财务详情
	public function finance_info()
	{
		$this->_info('shop_bill_audit.finance_info.tpl');
	}

	//详情
	private function _info($display)
	{
		$id = req::item('id', '');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$info = mod_shop_bill_audit::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		//获取货币
		$currency_list = mod_currency_type::get_key_val();

		//获取默认货币
		$default_currency_code = mod_currency_type::get_default_curr();

		//获取商户信息
		$shop_info = mod_shop::find($info['shop_id']);

		//处理联系方式
		$contact_ways = '';
		if(!empty($shop_info['contact_ways']))
		{
			$contact_ways = json_decode($shop_info['contact_ways'], true);
			$new_contact_ways = array ();
			if(is_array($contact_ways))
			{
				foreach ($contact_ways as $k => $v)
				{
					if(isset(mod_shop::$contact_way_list[$v['key']]))
					{
						$new_contact_ways[] = mod_shop::$contact_way_list[$v['key']].'-'.$v['val'];
					}

				}

				$contact_ways = implode(',', $new_contact_ways);
			}
		}

		$info['audit_money'] = empty($info['audit_money']) ? 0 : $info['audit_money'];
		$info['extra_charge'] = empty($info['extra_charge']) ? 0 : $info['extra_charge'];
		$info['shop_name'] = empty($shop_info['name']) ? '' : $shop_info['name'];
		$info['contact_ways'] = $contact_ways;
		$info['add_date'] = date('Y-m-d H:i:s', $info['addtime']);
		$info['type_name'] = isset(mod_shop_bill_audit::$type_list[$info['type']]) ? mod_shop_bill_audit::$type_list[$info['type']] : '';
		$info['currency_name'] = isset($currency_list[$info['currency_code']]) ? $currency_list[$info['currency_code']] : '';
		$info['actual_amount'] = $info['status'] == 0 ? '-' : mod_member_info::num_format($info['audit_money'] - $info['extra_charge']);
		$info['custom_audit_money'] = mod_member_info::num_format($info['apply_money'], '');
		$info['apply_money'] = mod_member_info::num_format($info['apply_money']);
		$info['audit_money'] = $info['status'] == 0 ? '-' : mod_member_info::num_format($info['audit_money']);
		$info['extra_charge'] = $info['status'] == 0 ? '-' : mod_member_info::num_format($info['extra_charge']);

		//获取gourl
		$this->_get_gourl();

		tpl::assign('admin_id', cls_auth::$user->fields['uid']);
		tpl::assign('info', $info);
		tpl::assign('default_currency_code', $default_currency_code);
		tpl::assign('currency_list', $currency_list);
		tpl::display($display);
	}

	//客服审核驳回
	public function custom_rejected()
	{
		$id = req::item('id');
		$reject_reason = req::item('reject_reason');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		if(empty($reject_reason))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_enter_reason_rejection'), '-1');
		}

		$audit_info = mod_shop_bill_audit::find($id);

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		if($audit_info['op_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		if($audit_info['type'] == 2)
		{
			db::begin_tran();
			//提现驳回

				//修改商户冻结余额
				$shop_bank_where = array ();
				$shop_bank_where[] = array ('shop_id', '=', $audit_info['shop_id']);
				$shop_bank_where[] = array ('type', '=', 2);
				$shop_bank_where[] = array ('currency_code', '=', $audit_info['currency_code']);

				$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where);
				if(empty($shop_bank_info))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}

				$member_bank_up = array ();
				$member_bank_up['money'] = $shop_bank_info['money'] - $audit_info['apply_money'];
				$result = mod_shop_money_bank::update_data($shop_bank_where, $member_bank_up);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}

				//生成解冻账单日志
				$bill_add_data = array ();
				$bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['shop_id'] = $audit_info['shop_id'];
				$bill_add_data['bank_card_id'] = $shop_bank_info['id'];
				$bill_add_data['type'] = 6;
				$bill_add_data['currency_code'] = $audit_info['currency_code'];
				$bill_add_data['amount'] = -$audit_info['apply_money'];
				$bill_add_data['from_type'] = 1;
				$bill_add_data['remark'] = lang::get('bill_audit_withdraw');
				$bill_add_data['date'] = date('Y-m-d', time());
				$bill_add_data['addtime'] = time();
				$result = mod_shop_bank_log::add_data($bill_add_data);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
				}

			//增加商户余额
				$shop_bank_where = array ();
				if(empty($audit_info['bank_card_id']))
				{
					$shop_bank_where[] = array ('shop_id', '=', $audit_info['shop_id']);
					$shop_bank_where[] = array ('type', '=', 1);
					$shop_bank_where[] = array ('currency_code', '=', $audit_info['currency_code']);
				}
				else
				{
					$shop_bank_where[] = array ('id', '=', $audit_info['bank_card_id']);
				}

				$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where);
				if(empty($shop_bank_info))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
				}

				$member_bank_up = array ();
				$member_bank_up['money'] = $shop_bank_info['money'] + $audit_info['apply_money'];
				$result = mod_shop_money_bank::update_data($shop_bank_where, $member_bank_up);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
				}
		}

		//修改审核账单状态
		$up_data = array ();
		$up_data['status'] = 2;
		$up_data['reject_reason'] = $reject_reason;
		$up_data['uptime'] = time();
		$result = mod_shop_bill_audit::update_data(array ('audit_id', '=', $id), $up_data);

		if(empty($result))
		{
			if($audit_info['type'] == 2)
			{
				db::rollback();
			}
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('bill_audit_shop_bills_dismissed')." {$id}");

		if($audit_info['type'] == 2)
		{
			db::commit();
			db::autocommit(true);
		}

		$gourl = req::item('gourl', '?ct=shop_bill_audit&ac=index');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_success'), $gourl);
	}

	//客服审核同意
	public function custom_consent()
	{
		$id = req::item('id');
		$audit_money = req::item('audit_money', '0');
		$currency_code = req::item('currency_code');
		$images = req::item('images');
		$op_remark = req::item('op_remark');
		$extra_charge = req::item('extra_charge', '0');
		$extra_currency_code = req::item('extra_currency_code');
		$audit_money = str_replace(',','',$audit_money);

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$audit_info = mod_shop_bill_audit::find($id);

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		if($audit_info['op_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		if($audit_money > $audit_info['apply_money'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_greater_application'), '-1');
		}

		if(empty($images))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_upload_picture_empty'), '-1');
		}

		$images = is_array($images) ? implode(',', $images) : '';

		//只能受理本人操作
		if($audit_info['op_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('Illegal operation'), '-1');
		}

		if($extra_charge > $audit_money)
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_extra_not_than_charge_amount'), '-1');
		}

		//修改账单审核信息
		$audit_up = array ();
		$audit_up['status'] = 1;
		$audit_up['currency_code'] = empty($currency_code) ? $audit_info['currency_code'] : $currency_code;;
		$audit_up['audit_money'] = $audit_money;
		$audit_up['images'] = $images;
		$audit_up['op_remark'] = $op_remark;
		$audit_up['extra_charge'] = $extra_charge;
		$audit_up['extra_currency_code'] = $extra_currency_code;
		$audit_up['uptime'] = time();
		$result = mod_shop_bill_audit::update_data(array ('audit_id', '=', $id), $audit_up);

		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
		}

		$this->_move_file($images);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('bill_audit_shop_bills_confirmed')." {$id}");

		$gourl = req::item('gourl', '?ct=shop_bill_audit&ac=index');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirmed_success'), $gourl);

	}

	//财务审核同意
	public function finance_consent()
	{
		$id = req::item('id');
		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$audit_info = mod_shop_bill_audit::find($id);

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		if($audit_info['finance_op_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		//实际到账金额
		$actual_amount = $audit_info['audit_money'] - $audit_info['extra_charge'];

		db::begin_tran();

		if($audit_info['type'] == 1)
		{
			//充值
				//增加商户余额
				$bank_where = array ();
				$bank_where[] = array ('shop_id', '=', $audit_info['shop_id']);
				$bank_where[] = array ('type', '=', 1);
				$bank_where[] = array ('currency_code', '=', $audit_info['currency_code']);
				$bank_info = mod_shop_money_bank::get_info($bank_where);

				if(empty($bank_info))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_balance_not_exist'), '-1');
				}

				$bank_up = array ();
				$bank_up['money'] = $bank_info['money'] + $actual_amount;
			 	$result = mod_shop_money_bank::update_data($bank_where, $bank_up);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}

				//增加商户收入账单
				$bill_add_data = array ();
				$bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['shop_id'] = $audit_info['shop_id'];
				$bill_add_data['bank_card_id'] = $bank_info['id'];
				$bill_add_data['type'] = 2;
				$bill_add_data['currency_code'] = $audit_info['currency_code'];
				$bill_add_data['amount'] = $actual_amount;
				$bill_add_data['remark'] = lang::get('bill_audit_recharge');
				$bill_add_data['status'] = 1;
				$bill_add_data['date'] = date('Y-m-d', time());
				$bill_add_data['addtime'] = time();
				$result = mod_shop_bill::add_data($bill_add_data);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}

				//增加商户收入账单日志
				$bill_add_data = array ();
				$bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['shop_id'] = $audit_info['shop_id'];
				$bill_add_data['bank_card_id'] = $bank_info['id'];
				$bill_add_data['type'] = 2;
				$bill_add_data['currency_code'] = $audit_info['currency_code'];
				$bill_add_data['amount'] = $actual_amount;
				$bill_add_data['from_type'] = 1;
				$bill_add_data['remark'] = lang::get('bill_audit_recharge');
				$bill_add_data['date'] = date('Y-m-d', time());
				$bill_add_data['addtime'] = time();
				$result = mod_shop_bank_log::add_data($bill_add_data);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}
		}
		else
		{
			//提现

				//如果审核金额与申请金额不一致时，需要返回或者扣除多余的部分
				if($audit_info['apply_money'] >= $audit_info['audit_money']) //申请金额大于等于确认金额时
				{
					//多余的钱
					$shop_sup_money = $audit_info['apply_money'] - $audit_info['audit_money'];

					//查询商户账户余额
					$shop_bank_where = array ();
					$shop_bank_where[] = array ('shop_id', '=', $audit_info['shop_id']);
					$shop_bank_where[] = array ('currency_code', '=', $audit_info['currency_code']);
					$shop_bank_where[] = array ('type', '=', 1);

					$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where);
					if(empty($shop_bank_info))
					{
						db::rollback();
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
					}

					if($shop_sup_money > 0)
					{
						//增加商户账户余额
						$member_bank_up = array ();
						$member_bank_up['money'] = $shop_bank_info['money'] + $shop_sup_money;
						$result = mod_shop_money_bank::update_data($shop_bank_where, $member_bank_up);

						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
						}

						//生成收入账单日志
						$bill_add_data = array ();
						$bill_add_data['bill_id'] = util::make_bill_id();
						$bill_add_data['shop_id'] = $audit_info['shop_id'];
						$bill_add_data['bank_card_id'] = $shop_bank_info['id'];
						$bill_add_data['type'] = 2;
						$bill_add_data['currency_code'] = $audit_info['currency_code'];
						$bill_add_data['amount'] = $shop_sup_money;
						$bill_add_data['from_type'] = 1;
						$bill_add_data['remark'] = lang::get('bill_audit_withdraw_refund');
						$bill_add_data['date'] = date('Y-m-d', time());
						$bill_add_data['addtime'] = time();

						$result = mod_shop_bank_log::add_data($bill_add_data);

						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
						}
					}

					//生成支出账单
					$bill_add_data = array ();
					$bill_add_data['bill_id'] = util::make_bill_id();
					$bill_add_data['shop_id'] = $audit_info['shop_id'];
					$bill_add_data['bank_card_id'] = $shop_bank_info['id'];
					$bill_add_data['type'] = 1;
					$bill_add_data['currency_code'] = $audit_info['currency_code'];
					$bill_add_data['amount'] = -$audit_info['audit_money'];
					$bill_add_data['remark'] = lang::get('bill_audit_withdraw');
					$bill_add_data['status'] = 1;
					$bill_add_data['date'] = date('Y-m-d', time());
					$bill_add_data['addtime'] = time();

					$result = mod_shop_bill::add_data($bill_add_data);

					if(empty($result))
					{
						db::rollback();
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
					}
				}

				//修改商户冻结余额
				$shop_bank_where = array ();
				$shop_bank_where[] = array ('shop_id', '=', $audit_info['shop_id']);
				$shop_bank_where[] = array ('currency_code', '=', $audit_info['currency_code']);
				$shop_bank_where[] = array ('type', '=', 2);

				$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where);
				if(empty($shop_bank_info))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}

				$member_bank_up = array ();
				$member_bank_up['money'] = $shop_bank_info['money'] - $audit_info['apply_money'];
				$result = mod_shop_money_bank::update_data($shop_bank_where, $member_bank_up);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}

				//生成解冻账单日志
				$bill_add_data = array ();
				$bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['shop_id'] = $audit_info['shop_id'];
				$bill_add_data['bank_card_id'] = $shop_bank_info['id'];
				$bill_add_data['type'] = 6;
				$bill_add_data['currency_code'] = $audit_info['currency_code'];
				$bill_add_data['amount'] = -$audit_info['apply_money'];
				$bill_add_data['from_type'] = 1;
				$bill_add_data['remark'] = lang::get('bill_audit_withdraw');
				$bill_add_data['date'] = date('Y-m-d', time());
				$bill_add_data['addtime'] = time();
				$result = mod_shop_bank_log::add_data($bill_add_data);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
				}
		}

		//修改账单审核状态
		$audit_up = array ();
		$audit_up['status'] = 3;
		$audit_up['uptime'] = time();

		$result = mod_shop_bill_audit::update_data(array('audit_id', '=', $id), $audit_up);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('bill_audit_finance_shop_bills_confirmed')." {$id}");

		db::commit();
		db::autocommit(true);

		$gourl = req::item('gourl', '?ct=shop_bill_audit&ac=finance_list');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirmed_success'), $gourl);
	}

	//财务驳回
	public function finance_rejected()
	{
		$id = req::item('id');
		$reject_reason = req::item('reject_reason');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		if(empty($reject_reason))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_enter_reason_rejection'), '-1');
		}

		$audit_info = mod_shop_bill_audit::find($id);

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		if($audit_info['finance_op_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		if($audit_info['type'] == 2)
		{
			db::begin_tran();
			//提现驳回

			//修改商户冻结余额
			$shop_bank_where = array ();
			$shop_bank_where[] = array ('shop_id', '=', $audit_info['shop_id']);
			$shop_bank_where[] = array ('currency_code', '=', $audit_info['currency_code']);
			$shop_bank_where[] = array ('type', '=', 2);

			$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where);
			if(empty($shop_bank_info))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
			}

			$member_bank_up = array ();
			$member_bank_up['money'] = $shop_bank_info['money'] - $audit_info['apply_money'];
			$result = mod_shop_money_bank::update_data($shop_bank_where, $member_bank_up);

			if(empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_confirm_failure'), '-1');
			}

			//生成解冻账单日志
			$bill_add_data = array ();
			$bill_add_data['bill_id'] = util::make_bill_id();
			$bill_add_data['shop_id'] = $audit_info['shop_id'];
			$bill_add_data['bank_card_id'] = $shop_bank_info['id'];
			$bill_add_data['type'] = 6;
			$bill_add_data['currency_code'] = $audit_info['currency_code'];
			$bill_add_data['amount'] = -$audit_info['apply_money'];
			$bill_add_data['from_type'] = 1;
			$bill_add_data['remark'] = lang::get('bill_audit_withdraw');
			$bill_add_data['date'] = date('Y-m-d', time());
			$bill_add_data['addtime'] = time();
			$result = mod_shop_bank_log::add_data($bill_add_data);

			if(empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
			}

			//增加商户余额
				$shop_bank_where = array ();
				if(empty($audit_info['bank_card_id']))
				{
					$shop_bank_where[] = array ('shop_id', '=', $audit_info['shop_id']);
					$shop_bank_where[] = array ('currency_code', '=', $audit_info['currency_code']);
					$shop_bank_where[] = array ('type', '=', 1);
				}
				else
				{
					$shop_bank_where[] = array ('id', '=', $audit_info['bank_card_id']);
				}

				$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where);
				if(empty($shop_bank_info))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
				}
				$member_bank_up['money'] = $shop_bank_info['money'] + $audit_info['apply_money'];
				$result = mod_shop_money_bank::update_data($shop_bank_where, $member_bank_up);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
				}
		}

		//修改审核账单状态
		$up_data = array ();
		$up_data['status'] = 4;
		$up_data['reject_reason'] = $reject_reason;
		$up_data['uptime'] = time();
		$result = mod_shop_bill_audit::update_data(array ('audit_id', '=', $id), $up_data);
		if(empty($result))
		{
			if($audit_info['type'] == 2)
			{
				db::rollback();
			}
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_failed'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('bill_audit_finance_shop_bills_dismissed')." {$id}");

		if($audit_info['type'] == 2)
		{
			db::commit();
			db::autocommit(true);
		}

		$gourl = req::item('gourl', '?ct=shop_bill_audit&ac=finance_list');
		cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_dismissed_success'), $gourl);

	}

	//充值, 客服充值直接到财务审核
	public function recharge()
	{
		if(req::method() == "POST")
		{
			$shop_id = req::item('shop_id');
			$currency_code = req::item('currency_code');
			$audit_money = req::item('audit_money');
			$remark = req::item('remark');
			$images = req::item('images');
			$name = req::item('name');
			$name_list = explode('-',$name);

			if(empty($shop_id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('shop_select_shop'), '-1');
			}
			if(empty($currency_code))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_currency_type'), '-1');
			}
			if(empty($audit_money))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_entry_recharge_amount'), '-1');
			}
			/*
			if(empty($remark))
			{
				cls_msgbox::show(lang::get('common_system_hint'), '请输入备注信息！', '-1');
			}
			*/

			//判断提交的商户名称与商户ID是否一致
			$shop_info = mod_shop::find($name_list[0]);
			if(empty($shop_info) || (!empty($shop_info) && $shop_info['id'] != $shop_id))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_member'), '-1');
			}
			/*
			$images = implode(',', $images);
			if(empty($images))
			{
				cls_msgbox::show(lang::get('common_system_hint'), '请上传凭证图片！', '-1');
			}
			*/

			$add_data = array ();
			$add_data['shop_id'] = $shop_id;
			$add_data['currency_code'] = $currency_code;
			$add_data['apply_money'] = $audit_money;
			$add_data['audit_money'] = $audit_money;
			$add_data['remark'] = $remark;
			$add_data['images'] = $images;
			$add_data['status'] = 0;
			$add_data['type'] = 1;
			$add_data['addtime'] = time();

			$result = mod_shop_bill_audit::add_data($add_data);
			if(empty($result))
			{
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_recharge_failed'), '-1');
			}

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('bill_audit_customer_recharge')."：".$shop_id);

			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_recharge_success'), '?ct=shop_bill_audit&ac=index');

		}
		else
		{

			//获取货币
			$currency_list = mod_currency_type::get_key_val();

			//获取商户默认货币
			$default_currency_code = mod_currency_type::get_default_curr();

			tpl::assign('default_currency_code', $default_currency_code);
			tpl::assign('currency_list', $currency_list);
			tpl::display('shop_bill_audit.recharge.tpl');
		}
	}

	//查看照片
	public function show_pics()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$audit_info = mod_shop_bill_audit::find($id, 'images');

		if(empty($audit_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$pics = explode(',', $audit_info['images']);
		foreach ($pics as $k => $v)
		{
			$pics[$k] = URL_UPLOADS.'/image/'.$v;
		}
		tpl::assign('pics', $pics);
		tpl::display('modal.pics.view.tpl');
	}

	//客服受理
	public function accepte()
	{
		$id = req::item('id');
		$type_list = req::item('type_list');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$info = mod_shop_bill_audit::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$update_data = array ();
		$update_data['op_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		mod_shop_bill_audit::update_data(array ('audit_id', '=', $id), $update_data);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('bill_audit_shop_accepted')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_accepted_success'), "?ct=shop_bill_audit&ac=custom_info&id={$id}&type_list={$type_list}");
	}

	//财务受理
	public function finance_accepte()
	{
		$id = req::item('id');
		$type_list = req::item('type_list');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$info = mod_shop_bill_audit::find($id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_select_info'), '-1');
		}

		$update_data = array ();
		$update_data['finance_op_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		mod_shop_bill_audit::update_data(array ('audit_id', '=', $id),$update_data);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('bill_audit_shop_finance_accepted')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('bill_audit_accepted_success'), "?ct=shop_bill_audit&ac=finance_info&id={$id}&type_list={$type_list}");
	}

	//获取gourl
	private function _get_gourl()
	{
		$type_list = req::item('type_list','1','int');

		switch ($type_list)
		{
			case 1:
				$gourl = "?ct=shop_bill_audit&ac=index";
				break;
			case 2:
				$gourl = "?ct=shop_bill_audit&ac=custom_confirm_list";
				break;
			case 3:
				$gourl = "?ct=shop_bill_audit&ac=custom_complete_list";
				break;
			case 4:
				$gourl = "?ct=shop_bill_audit&ac=custom_reject_list";
				break;
			case 5:
				$gourl = "?ct=shop_bill_audit&ac=finance_list";
				break;
			case 6:
				$gourl = "?ct=shop_bill_audit&ac=finance_reject_list";
				break;
			case 7:
				$gourl = "?ct=shop_bill_audit&ac=finance_complete_list";
				break;
			case 8:
				$gourl = "?ct=shop_bill_audit&ac=custom_accepting";
				break;
			case 9:
				$gourl = "?ct=shop_bill_audit&ac=custom_accepted";
				break;
			case 10:
				$gourl = "?ct=shop_bill_audit&ac=finance_accepting_list";
				break;
			case 11:
				$gourl = "?ct=shop_bill_audit&ac=finance_accepted_list";
				break;
		}

		tpl::assign('gourl', $gourl);
		tpl::assign('type_list', $type_list);

		return $gourl;
	}

	//移动文件
	private function _move_file($files)
	{
		if(empty($files))
		{
			return true;
		}

		//没有该目录则创建
		if(!is_dir(PATH_UPLOADS.'/file'))
		{
			if(!mkdir(PATH_UPLOADS.'/file',0777))
			{
				return false;
			}
		}

		//移动文件
		if(is_array($files))
		{
			foreach ($files as $file)
			{
				if(file_exists(PATH_UPLOADS.'/tmp/'.$file))
				{
					if(!rename(PATH_UPLOADS.'/tmp/'.$file, PATH_UPLOADS.'/image/'.$file))
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}

			return true;
		}
		else
		{
			if(file_exists(PATH_UPLOADS.'/tmp/'.$files))
			{
				return rename(PATH_UPLOADS.'/tmp/'.$files, PATH_UPLOADS.'/image/'.$files);
			}
			else
			{
				return false;
			}
		}
	}
}
