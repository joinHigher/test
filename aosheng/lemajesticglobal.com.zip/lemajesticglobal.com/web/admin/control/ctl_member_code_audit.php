<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 客户户口号审核管理
 *
 * @version $Id$
 */
class ctl_member_code_audit
{
	private $status_list = array (
		0 => '待审核',
		1 => '审核通过',
		2 => '驳回'
	);

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("member", $lang);
		lang::load("model", $lang);
		lang::load("push_message_content", $lang);

		mod_member_info::$type_list[1] = lang::get('model_institutional_user');
		mod_member_info::$type_list[2] = lang::get('model_personal_user');

		$this->status_list[0] = lang::get('member_code_audit_wait');
		$this->status_list[1] = lang::get('member_code_audit_pass');
		$this->status_list[2] = lang::get('member_code_audit_reject');

	}

	//待审核
    public function index()
    {
		$this->_list(1);
    }

	//已审核
	public function pass_list()
	{
		$this->_list(2);
	}

	//已驳回
	public function reject_list()
	{
		$this->_list(3);
	}

	//受理中列表
	public function accepting_list()
	{
		$this->_list(4);
	}

	//已受理列表
	public function accepted_list()
	{
		$this->_list(5);
	}

	/**
	 * 列表
	 *
	 * @param $type_list： 1=待审核，2=已审核，3=已驳回
	 *
	 */
	private function _list($type_list)
	{
		$where = array();

		switch ($type_list)
		{
			case 1:
					$where[] = array ('status', '=', 0);
				break;
			case 2:
					$where[] = array ('status', '=', 1);
				break;
			case 3:
					$where[] = array ('status', '=', 2);
				break;
			case 4:
					$where[] = array ('audit_id', '=', cls_auth::$user->fields['uid']);
					$where[] = array ('status', '=', 0);
				break;
			case 5:
					$where[] = array ('audit_id', '=', cls_auth::$user->fields['uid']);
					$where[] = array ('status', 'in', array (1,2));
				break;
		}

		$count = mod_member_custom_code_audit::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_member_custom_code_audit::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			foreach ($list as $k=>$v)
			{
				$list[$k]['add_date'] = date('Y-m-d H:i:s', $v['addtime']);

				//获取用户信息
				$member_info = mod_member_info::find($v['member_info_id']);
				$list[$k]['member_name'] = empty($member_info) ? '' : $member_info['name'];
				$list[$k]['member_code'] = empty($member_info) ? '' : $member_info['code'];
				$list[$k]['parent_code'] = !empty($member_info) && !empty($member_info['parentcode']) ? $member_info['parentcode'] : '-';
				$list[$k]['parent_name'] = !empty($member_info) && !empty($member_info['parentname']) ? $member_info['parentname'] : '-';

			}
		}

		tpl::assign('list', $list);
		tpl::assign('pages', $pages['show']);
		tpl::assign('type_list', $type_list);
		tpl::display('member_code_audit.index.tpl');
	}

	public function info()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		$info = mod_member_custom_code_audit::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		$info['status_name'] = isset($this->status_list[$info['status']]) ? $this->status_list[$info['status']] : '';
		$info['uptime_date'] = empty($info['uptime']) || $info['status'] == 0  ? '-' : date('Y-m-d H:i:s', $info['uptime']);

		//客户信息
		$member_info = mod_member_info::find($info['member_info_id']);
		$member_info['type_name'] = isset(mod_member_info::$type_list[$member_info['type']]) ? mod_member_info::$type_list[$member_info['type']] : '-';;

		//上线信息
		$parent_info['code'] = '-';
		$parent_info['custom_code'] = '-';
		$parent_info['name'] = '-';
		$parent_info['type_name'] = '-';
		$parent_info['contacts'] = '-';
		$parent_info['contact_ways'] = '-';
		if($member_info && $member_info['parentid'])
		{
			$parent_info = mod_member_info::find($member_info['parentid']);
			$parent_info['type_name'] = isset(mod_member_info::$type_list[$parent_info['type']]) ? mod_member_info::$type_list[$parent_info['type']] : '-';;

		}

		//申请记录
		$op_where = array ();
		$op_where[] = array ('member_info_id', '=', $info['member_info_id']);
		$op_where[] = array ('id', '!=', $id);
		$op_list = mod_member_custom_code_audit::get_list($op_where);
		if(!empty($op_list))
		{
			foreach ($op_list as $k => $v)
			{
				$op_list[$k]['add_date'] = date('Y-m-d H:i:s', $v['addtime']);
				$op_list[$k]['old_custom_code'] = empty($v['old_custom_code']) ? '-' : $v['old_custom_code'];
				$op_list[$k]['status_name'] = isset($this->status_list[$v['status']]) ? $this->status_list[$v['status']] : '-';
			}
		}
		//返回url处理
		$this->_handle_gourl();

		tpl::assign('info', $info);
		tpl::assign('member_info', $member_info);
		tpl::assign('parent_info', $parent_info);
		tpl::assign('list', $op_list);
		tpl::assign('admin_id', cls_auth::$user->fields['uid']);
		tpl::display('member_code_audit.info.tpl');
	}

	//同意
	public function agree()
	{
		$id = req::item('id');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		$info = mod_member_custom_code_audit::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		if($info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		//客户信息
		$member_info = mod_member_info::find($info['member_info_id']);
		if(empty($member_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_select_member'), '-1');
		}

		db::begin_tran();

		$up_data['status'] = 1;
		$up_data['uptime'] = time();

		$result = mod_member_custom_code_audit::update_data(array ('id', '=', $id), $up_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		$member_up_data['custom_code'] = $info['custom_code'];
		$member_up_data['uptime'] = time();

		$result = mod_member_info::update_data(array ('id', '=', $info['member_info_id']), $member_up_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		//添加推送消息
		$title = lang::get('push_message_code_title');
		$content = str_replace('#new_code#',$info['custom_code'],lang::get('push_message_customer_code_edit'));
		mod_app_message::create($info['member_info_id'], 0, $title, $content,'',6, 7, $info['id'], array ('custom_code' => $member_up_data['custom_code']));

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('member_code_audit_pass_log')." {$id}");

		db::commit();
		db::autocommit(true);

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), '?ct=member_code_audit&ac=index');

	}

	//驳回
	public function reject()
	{
		$id = req::item('id');
		$reject_reason = req::item('reject_reason');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		if(empty($reject_reason))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('member_entry_rejected_reason'), '-1');
		}

		$info = mod_member_custom_code_audit::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		if($info['audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		$up_data['status'] = 2;
		$up_data['fail_reason'] = $reject_reason;
		$up_data['uptime'] = time();
		$result = mod_member_custom_code_audit::update_data(array ('id', '=', $id), $up_data);

		if(empty($result))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_fail_edit'), '-1');
		}

		//添加推送消息
		$title = lang::get('push_message_code_title');
		$content = lang::get('push_message_customer_code_fail');
		mod_app_message::create($info['member_info_id'], 0, $title, $content,'',6, 7, $info['id']);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('member_code_audit_reject_log')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_success_edit'), '?ct=member_code_audit&ac=index');

	}

	//受理
	public function accepte()
	{
		$id = req::item('id');
		$type_list = req::item('type_list','1');

		if(empty($id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		$info = mod_member_custom_code_audit::find($id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_select_information'), '-1');
		}

		$update_data = array ();
		$update_data['audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		mod_member_custom_code_audit::update_data(array ('id', '=', $id), $update_data);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('member_code_audit_accepte')." {$id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_acceptance_success'), "?ct=member_code_audit&ac=info&id={$id}&type_list={$type_list}");
	}

	//处理返回URL
	private function _handle_gourl()
	{
		$type_list = req::item('type_list','1');

		switch ($type_list)
		{
			case 1:
					$gourl = "?ct=member_code_audit&ac=index";
				break;
			case 2:
					$gourl = "?ct=member_code_audit&ac=pass_list";
				break;
			case 3:
					$gourl = "?ct=member_code_audit&ac=reject_list";
				break;
			case 4:
					$gourl = "?ct=member_code_audit&ac=accepting_list";
				break;
			case 5:
					$gourl = "?ct=member_code_audit&ac=accepted_list";
				break;
		}

		tpl::assign('gourl', $gourl);
		tpl::assign('type_list', $type_list);

		return $gourl;
	}
}
