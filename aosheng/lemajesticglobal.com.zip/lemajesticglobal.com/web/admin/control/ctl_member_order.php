<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 订单系统
 *
 * @version $Id$
 */
class ctl_member_order
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
		$lang = util::get_language();
		lang::load("common", $lang);
		lang::load("member", $lang);
		lang::load("order", $lang);
		lang::load("goods", $lang);
		lang::load("shop", $lang);
		lang::load("currency", $lang);
		lang::load("bill", $lang);
		lang::load("model", $lang);
		lang::load("push_message_content", $lang);

		mod_order::$status_list[0] = lang::get('model_to_confirmed');
		mod_order::$status_list[1] = lang::get('model_confirm_manually');
		mod_order::$status_list[2] = lang::get('model_automatic_confirmation');
		mod_order::$status_list[3] = lang::get('model_doubt_orders');
		mod_order::$status_list[4] = lang::get('model_abolished');

		mod_member_bill::$type_list[1] = lang::get('model_expenditure');
		mod_member_bill::$type_list[2] = lang::get('model_income');
		mod_member_bill::$type_list[3] = lang::get('model_freeze');
		mod_member_bill::$type_list[4] = lang::get('model_doubt');
		mod_member_bill::$type_list[5] = lang::get('model_pre_auth');
		mod_member_bill::$type_list[6] = lang::get('model_thaw');
		mod_member_bill::$type_list[7] = lang::get('model_dispel_doubt');
    }

	//待确认订单
	public function index()
	{
		$this->_list(0);
	}

	//已确认订单
	public function confirm_list()
	{
		$this->_list(array (1,2));
	}

	//存疑订单
	public function doubt_list()
	{
		$this->_list(3);
	}

	//已作废订单
	public function cancel_list()
	{
		$this->_list(4);
	}

	//列表
	private function _list($status)
	{
		$keyword = req::item('keyword', '');

		$where = array();

		if(!empty($keyword))
		{
			$member_info_where = array ();
			$member_info_where['or'][] = array ('code', 'like', $keyword.'%');
			$member_info_where['or'][] = array ('custom_code', 'like', $keyword.'%');
			$mem_list = mod_member_info::get_list($member_info_where, 'id');
			if(empty($mem_list))
			{
				$where[] = array ('member_info_id', '=', 0);
			}
			else
			{
				foreach ($mem_list as $k => $v)
				{
					$mem_ids[] = $v['id'];
				}
				$where[] = array ('member_info_id', 'in', $mem_ids);
			}
		}

		if(is_array($status))
		{
			$where[] = array ('status', 'in', $status);
		}
		else
		{
			$where[] = array ('status', '=', $status);
		}

		$where[] = array ('pay_status', '=', 1);

		$count = mod_order::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_order::get_list($where, '', $pages['page_size'], $pages['offset']);

		if(!empty($list))
		{
			//货币列表
			$currency_list = mod_currency_type::get_key_val();

			foreach ($list as $k => $v)
			{
				$mem_info = mod_member_info::find($v['member_info_id']);
				$shop_info = mod_shop::find($v['shop_id']);
				$interfaces_info = mod_shop_interfaces::find($v['interface_id']);
				$list[$k]['add_date'] = date('Y-m-d H:i:s', $v['addtime']);
				$list[$k]['amount'] = mod_member_info::num_format($v['amount']);
				$list[$k]['interfaces_name'] = empty($interfaces_info) ? '' : $interfaces_info['name'];
				$list[$k]['shop_name'] = empty($shop_info) ? '' : $shop_info['name'];
				$list[$k]['member_code'] = empty($mem_info) ? '' : $mem_info['code'];
				$list[$k]['member_name'] = empty($mem_info) ? '' : $mem_info['name'];
				$list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
				$list[$k]['status_name'] = isset(mod_order::$status_list[$v['status']]) ? mod_order::$status_list[$v['status']] : '';
			}
		}

		tpl::assign('status', is_array($status) ? implode(',', $status) : $status);
		tpl::assign('list', $list);
		tpl::assign('ac', req::item('ac'));
		tpl::assign('pages', $pages['show']);
		tpl::display('member_order.index.tpl');
	}

	//订单详情
	public function info()
	{
		$order_id = req::item('order_id');
		$status = req::item('status');

		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		$info = mod_order::find($order_id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//货币列表
		$currency_list = mod_currency_type::get_key_val();

		$member_info = mod_member_info::find($info['member_info_id']);
		$shop_info = mod_shop::find($info['shop_id']);
		$info['add_date'] = date('Y-m-d H:i:s', $info['addtime']);
		$info['amount'] = mod_member_info::num_format($info['amount']);
		$info['shop_name'] = empty($shop_info) ? '' : $shop_info['name'];
		$info['currency_name'] = isset($currency_list[$info['currency_code']]) ? $currency_list[$info['currency_code']] : '';
		$info['status_name'] = isset(mod_order::$status_list[$info['status']]) ? mod_order::$status_list[$info['status']] : '';

		$interface_info = mod_shop_interfaces::find($info['interface_id']);
		$info['object_name'] = empty($interface_info) ? '' : $interface_info['name'];

		$bill_list = mod_member_bank_log::get_list(array ('order_id', '=', $order_id));

		foreach ($bill_list as $k => $v)
		{
			$bill_list[$k]['type_name'] = isset(mod_member_bill::$type_list[$v['type']]) ? mod_member_bill::$type_list[$v['type']] : '';
			$bill_list[$k]['currency_name'] = $currency_list[$v['currency_code']];
			$bill_list[$k]['amount'] = mod_member_info::num_format($v['amount']);

			$bill_list[$k]['account_type_name'] = lang::get('order_credit_account');
			if($v['from_type'] == 1 && ($v['type'] == 1 || $v['type'] == 2))
			{
				$bill_list[$k]['account_type_name'] = lang::get('order_balance_account');
			}
			elseif ($v['type'] == 3 || $v['type'] == 6)
			{
				$bill_list[$k]['account_type_name'] = lang::get('order_freeze_account');
			}
			elseif ($v['type'] == 4 || $v['type'] == 7)
			{
				$bill_list[$k]['account_type_name'] = lang::get('order_doubt_account');
			}
		}

		//返回URL处理
		switch ($status)
		{
			case 0:
				  	$gourl = "?ct=member_order&ac=index";
				break;
			case 3:
					$gourl = "?ct=member_order&ac=doubt_list";
				break;
			case 4:
					$gourl = "?ct=member_order&ac=cancel_list";
				break;
			default:
					$gourl = "?ct=member_order&ac=confirm_list";
				break;
		}

		tpl::assign('bill_list', $bill_list);
		tpl::assign('member_info', $member_info);
		tpl::assign('order_info', $info);
		tpl::assign('gourl', $gourl);
		tpl::display('member_order.info.tpl');
	}

	//驳回订单，将钱支付给商家
	public function reject()
	{
		//获取订单
		$order_id = req::item('order_id');
		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//获取订单信息
		$order_info = mod_order::find($order_id);
		if(empty($order_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//获取该订单的冻结账单
		$bill_where = array ();
		$bill_where[] = array ('order_id', '=', $order_id);
		$bill_where[] = array ('type', '=', 1);
		$bill_list = mod_member_bank_log::get_list($bill_where);

		db::begin_tran();

		foreach ($bill_list as $k => $v)
		{
			//客户账户解疑
			$bank_money_info_where = array ();
			$bank_money_info_where[] = array ('member_info_id', '=', $order_info['member_info_id']);
			$bank_money_info_where[] = array ('type', '=', 3);
			$bank_money_info_where[] = array ('currency_code', '=', $v['currency_code']);
			$bank_money_info = mod_member_money_bank::get_info($bank_money_info_where);
			if(empty($bank_money_info))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
			}
			else
			{
				$bank_up_data['money'] = $bank_money_info['money'] + $v['amount'];
				$result = mod_member_money_bank::update_data(array ('id', '=', $bank_money_info['id']), $bank_up_data);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
				}
			}

			//添加客户解疑账单日志
			$bill_add_date = array ();
			$bill_add_date['member_info_id'] = $v['member_info_id'];
			$bill_add_date['order_id'] = $order_id;
			$bill_add_date['bank_card_id'] = $bank_money_info['id'];
			$bill_add_date['currency_code'] = $v['currency_code'];
			$bill_add_date['amount'] = $v['amount'];
			$bill_add_date['from_type'] = $v['from_type'];
			$bill_add_date['bill_id'] = util::make_bill_id();
			$bill_add_date['type'] = '7';
			$bill_add_date['remark'] = lang::get('order_customer_confirm');
			$bill_add_date['date'] = date('Y-m-d', time());
			$bill_add_date['addtime'] = time();

			$result = mod_member_bank_log::add_data($bill_add_date);
			if (empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
			}

			//生成支出账单
			$bill_add_data = array ();
			$bill_add_data['bill_id'] = util::make_bill_id();
			$bill_add_data['member_info_id'] = $v['member_info_id'];
			$bill_add_data['type'] = 1;
			$bill_add_data['bank_card_id'] = $v['bank_card_id'];
			$bill_add_data['currency_code'] = $v['currency_code'];
			$bill_add_data['amount'] = $v['amount'];
			$bill_add_data['from_type'] = $v['from_type'];
			$bill_add_data['remark'] = lang::get('order_buy').$order_info['goods_name'];
			$bill_add_data['date'] = date('Y-m-d',time());
			$bill_add_data['addtime'] = time();
			$bill_add_data['uptime'] = time();

			$result = mod_member_bill::add_data($bill_add_data);
			if (empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
			}

			//生成订单与账单流水关联数据
			$bill_order_link_add = array ();
			$bill_order_link_add['order_id'] = $order_id;
			$bill_order_link_add['bill_id'] = $bill_add_data['bill_id'];
			$result = mod_member_order_bill_link::add_data($bill_order_link_add);
			if (empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
			}

		}

		//增加商户余额
		$shop_bank_where = array ();
		$shop_bank_where[] = array ('shop_id', '=', $order_info['shop_id']);
		$shop_bank_where[] = array ('currency_code', '=', $order_info['currency_code']);
		$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where, 'id,money');

		if (empty($shop_bank_info))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
		}

		$shop_bank_updata = array ();
		$shop_bank_updata['money'] = $shop_bank_info['money'] + $order_info['amount'];
		$result = mod_shop_money_bank::update_data(array ('id', '=', $shop_bank_info['id']), $shop_bank_updata);
		if (empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
		}

		//增加商户账单流水
		$shop_bill_add_date = array ();
		$shop_bill_add_date['bill_id'] = util::make_bill_id();
		$shop_bill_add_date['bank_card_id'] = $shop_bank_info['id'];
		$shop_bill_add_date['shop_id'] = $order_info['shop_id'];
		$shop_bill_add_date['type'] = '2';
		$shop_bill_add_date['currency_code'] = $order_info['currency_code'];
		$shop_bill_add_date['amount'] = $order_info['amount'];
		$shop_bill_add_date['remark'] = lang::get('order_buy_success');
		$shop_bill_add_date['date'] = date('Y-m-d', time());
		$shop_bill_add_date['addtime'] = time();

		$result = mod_shop_bill::add_data($shop_bill_add_date);
		if (empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
		}

		//订单与账单流水关联数据
		$bill_order_link_add = array ();
		$bill_order_link_add['order_id'] = $order_info['order_id'];
		$bill_order_link_add['bill_id'] = $shop_bill_add_date['bill_id'];
		$result = mod_shop_order_bill_link::add_data($bill_order_link_add);
		if (empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
		}

		//修改订单状态
		$up_order_data = array ();
		$up_order_data['status'] = 1;
		$up_order_data['uptime'] = time();
		$result = mod_order::update_data(array ('order_id', '=', $order_id), $up_order_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
		}

		//添加推送消息
		$title = lang::get('push_message_order_title');
		$content = lang::get('push_message_doubtful_order_reject');
		mod_app_message::create($order_info['member_info_id'], 0, $title, $content, '', 3, 4, $order_id);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('order_customer_rejected_order')." {$order_id}");

		db::commit();
		db::autocommit(true);

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_dismiss_order_success'), '?ct=member_order&ac=doubt_list');

	}

	//确认订单，将钱返回给客户
	public function confirm()
	{
		$order_id = req::item('order_id');
		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//获取订单信息
		$order_info = mod_order::find($order_id);
		if(empty($order_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//客户存疑账户解疑
		$money_where = array ();
		$money_where[] = array('member_info_id', '=', $order_info['member_info_id']);
		$money_where[] = array('type', '=', 3);
		$money_where[] = array('currency_code', '=', $order_info['currency_code']);

		$money_info = mod_member_money_bank::get_info($money_where);
		if(empty($money_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
		}

		db::begin_tran();

		$bank_money_up = array ();
		$bank_money_up['money'] = $money_info['money'] - $order_info['amount'];
		$result = mod_member_money_bank::update_data(array ('id', '=', $money_info['id']), $bank_money_up);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
		}

		//添加解疑账单日志
		$bill_add_date = array ();
		$bill_add_date['member_info_id'] = $order_info['member_info_id'];
		$bill_add_date['order_id'] = $order_id;
		$bill_add_date['bank_card_id'] = $money_info['id'];
		$bill_add_date['currency_code'] = $order_info['currency_code'];
		$bill_add_date['amount'] = -$order_info['amount'];
		$bill_add_date['from_type'] = '1';
		$bill_add_date['bill_id'] = util::make_bill_id();
		$bill_add_date['type'] = '7';
		$bill_add_date['remark'] = lang::get('order_cancel_order');
		$bill_add_date['date'] = date('Y-m-d', time());
		$bill_add_date['addtime'] = time();

		$result = mod_member_bank_log::add_data($bill_add_date);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
		}

		//查询客户余额
		$money_where = array ();
		$money_where[] = array ('member_info_id', '=', $order_info['member_info_id']);
		$money_where[] = array ('type', '=', 1);
		$money_where[] = array ('currency_code', '=', $order_info['currency_code']);

		$money_info = mod_member_money_bank::get_info($money_where);
		if(empty($money_info))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
		}

		//获取订单支持日志
		$bill_log_where = array ();
		$bill_log_where[] = array ('order_id', '=', $order_id);
		$bill_log_where[] = array ('type', '=', 1);

		$bill_log_list = mod_member_bank_log::get_list($bill_log_where);

		if(!empty($bill_log_list))
		{
			foreach ($bill_log_list as $bk => $bv)
			{
				//添加支出账单
				$bill_add_date = array ();
				$bill_add_date['member_info_id'] = $order_info['member_info_id'];
				$bill_add_date['bank_card_id'] = $money_info['id'];
				$bill_add_date['currency_code'] = $order_info['currency_code'];
				$bill_add_date['amount'] = -$order_info['amount'];
				$bill_add_date['from_type'] = $bv['from_type'];
				$bill_add_date['bill_id'] = util::make_bill_id();
				$bill_add_date['type'] = '1';
				$bill_add_date['remark'] = lang::get('order_buy').$order_info['goods_name'];
				$bill_add_date['date'] = date('Y-m-d', time());
				$bill_add_date['addtime'] = time();

				$result = mod_member_bill::add_data($bill_add_date);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
				}

				//添加订单关系表
				$bill_order_link_add = array ();
				$bill_order_link_add['order_id'] = $order_id;
				$bill_order_link_add['bill_id'] = $bill_add_date['bill_id'];

				$result = mod_member_order_bill_link::add_data($bill_order_link_add);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
				}

				//添加收入账单
				$bill_add_date = array ();
				$bill_add_date['member_info_id'] = $order_info['member_info_id'];
				$bill_add_date['bank_card_id'] = $money_info['id'];
				$bill_add_date['currency_code'] = $order_info['currency_code'];
				$bill_add_date['amount'] = $order_info['amount'];
				$bill_add_date['from_type'] = 1;
				$bill_add_date['bill_id'] = util::make_bill_id();
				$bill_add_date['type'] = '2';
				$bill_add_date['remark'] = lang::get('order_refund');
				$bill_add_date['date'] = date('Y-m-d', time());
				$bill_add_date['addtime'] = time();

				$result = mod_member_bill::add_data($bill_add_date);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
				}

				//添加订单关系表
				$bill_order_link_add = array ();
				$bill_order_link_add['order_id'] = $order_id;
				$bill_order_link_add['bill_id'] = $bill_add_date['bill_id'];

				$result = mod_member_order_bill_link::add_data($bill_order_link_add);

				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
				}

				//添加收入账单日志
				$bill_add_date = array ();
				$bill_add_date['member_info_id'] = $order_info['member_info_id'];
				$bill_add_date['order_id'] = $order_id;
				$bill_add_date['bank_card_id'] = $money_info['id'];
				$bill_add_date['currency_code'] = $order_info['currency_code'];
				$bill_add_date['amount'] = $order_info['amount'];
				$bill_add_date['from_type'] = 1;
				$bill_add_date['bill_id'] = util::make_bill_id();
				$bill_add_date['type'] = '2';
				$bill_add_date['remark'] = lang::get('order_refund');
				$bill_add_date['date'] = date('Y-m-d', time());
				$bill_add_date['addtime'] = time();

				$result = mod_member_bank_log::add_data($bill_add_date);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
				}

			}
		}

		//获取是否有未还款的月结账单，如果有则先还月结账单，没有则还余额
			//查询月结账单
			$month_where = array ();
			$month_where[] = array ('member_info_id', '=', $order_info['member_info_id']);
			$month_where[] = array ('status', '=', 2);

			$month_list = mod_member_bill_month::get_list($month_where, '', '', '', array ('id', 'ASC'));
			if(empty($month_list))
			{
				//修改客户账户余额
				$bank_money_up = array ();
				$bank_money_up['money'] = $money_info['money'] + $order_info['amount'];
				$result = mod_member_money_bank::update_data($money_where, $bank_money_up);
				if(empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
				}
			}
			else
			{
				$order_amount = $order_info['amount'];

				//还月结账单
				foreach ($month_list as $mk => $mv)
				{
					//剩余还款金额
					$surp_repay_limit = $mv['repay_limit'] - $mv['al_repay_limit'];

					if($order_amount > 0)
					{
						//还款金额
						$repay_money = 0;
						if($surp_repay_limit >= $order_amount)
						{
							$repay_money = $order_amount;
							$order_amount = 0;
						}
						else
						{
							$repay_money = $surp_repay_limit;
							$order_amount = $order_amount - $surp_repay_limit;
						}

						//更新月结账单
						$al_repay_limit = $mv['al_repay_limit'] + $repay_money;

						$month_bill_updata = array ();
						$month_bill_updata['al_repay_limit'] = $al_repay_limit;
						$month_bill_updata['status'] = $al_repay_limit == $mv['repay_limit'] ? 1 : 2;
						$month_bill_updata['uptime'] = time();

						$result = mod_member_bill_month::update_data(array ('id', '=', $mv['id']), $month_bill_updata);
						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
						}

						//添加还款记录
						$repay_op_adddata = array ();
						$repay_op_adddata['bill_month_id'] = $mv['id'];
						$repay_op_adddata['member_info_id'] = $order_info['member_info_id'];
						$repay_op_adddata['repay_limit'] = $mv['repay_limit'];
						$repay_op_adddata['al_repay_limit'] = $mv['al_repay_limit'];
						$repay_op_adddata['amount'] = $repay_money;
						$repay_op_adddata['remark'] = lang::get('order_return_repay');
						$repay_op_adddata['type'] = '5';
						$repay_op_adddata['repay_type'] = '1';
						$repay_op_adddata['date_day'] = date('Y-m-d', time());
						$repay_op_adddata['currency_code'] = $order_info['currency_code'];
						$repay_op_adddata['admin_id'] = cls_auth::$user->fields['uid'];
						$repay_op_adddata['addtime'] = time();

						$result = mod_member_bill_repay::add_data($repay_op_adddata);
						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
						}

						//修改客户授信
						$member_credit_where = array ();
						$member_credit_where[] = array ('member_info_id', '=', $order_info['member_info_id']);
						$member_credit_where[] = array ('currency_code', '=', $order_info['currency_code']);
						$member_credit_info = mod_member_money_credit::get_info($member_credit_where);
						if(empty($member_credit_info))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
						}

						$member_credit_updata = array ();
						$member_credit_updata['used_money'] = $member_credit_info['used_money'] - $repay_money;
						$result = mod_member_money_credit::update_data(array ('id', '=', $member_credit_info['id']), $member_credit_updata);
						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
						}

						//添加还款流水
						$bill_add_date = array ();
						$bill_add_date['member_info_id'] = $order_info['member_info_id'];
						$bill_add_date['bank_card_id'] = $member_credit_info['id'];
						$bill_add_date['currency_code'] = $order_info['currency_code'];
						$bill_add_date['amount'] = -$repay_money;
						$bill_add_date['from_type'] = 1;
						$bill_add_date['bill_id'] = util::make_bill_id();
						$bill_add_date['type'] = 1;
						$bill_add_date['remark'] = lang::get('order_repayment').$mv['year'].'-'.$mv['month'];
						$bill_add_date['date'] = date('Y-m-d', time());
						$bill_add_date['addtime'] = time();

						$result = mod_member_bill::add_data($bill_add_date);
						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
						}

						//添加流水与订单关系表
						$bill_order_link_add = array ();
						$bill_order_link_add['order_id'] = $order_id;
						$bill_order_link_add['bill_id'] = $bill_add_date['bill_id'];

						$result = mod_member_order_bill_link::add_data($bill_order_link_add);
						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
						}

						//添加还款流水日志
						$bill_add_date = array ();
						$bill_add_date['member_info_id'] = $order_info['member_info_id'];
						$bill_add_date['order_id'] = $order_id;
						//$bill_add_date['log_type'] = '1';
						$bill_add_date['bank_card_id'] = $member_credit_info['id'];
						$bill_add_date['currency_code'] = $order_info['currency_code'];
						$bill_add_date['amount'] = -$repay_money;
						$bill_add_date['from_type'] = 1;
						//$bill_add_date['status'] = 1;
						$bill_add_date['bill_id'] = util::make_bill_id();
						$bill_add_date['type'] = 1;
						$bill_add_date['remark'] = lang::get('order_repayment').'：'.$mv['year'].'-'.$mv['month'];
						$bill_add_date['date'] = date('Y-m-d', time());
						$bill_add_date['addtime'] = time();

						$result = mod_member_bank_log::add_data($bill_add_date);
						if(empty($result))
						{
							db::rollback();
							cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
						}

					}
					else
					{
						break;
					}
				}

				//如果还有多余的钱，存入客户余额
				if($order_amount > 0)
				{
					//修改客户账户余额
					$bank_money_up = array ();
					$bank_money_up['money'] = $money_info['money'] + $order_amount;
					$result = mod_member_money_bank::update_data($money_where, $bank_money_up);
					if(empty($result))
					{
						db::rollback();
						cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
					}
				}
			}

			//修改订单状态
			$up_order_data = array ();
			$up_order_data['status'] = 4;
			$up_order_data['uptime'] = time();
			$result = mod_order::update_data(array ('order_id', '=', $order_id), $up_order_data);
			if(empty($result))
			{
				db::rollback();
				cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_failed'), '-1');
			}

			//添加推送消息
			$title = lang::get('push_message_order_title');
			$content = lang::get('push_message_doubtful_order_confirm');
			mod_app_message::create($order_info['member_info_id'], 0, $title, $content, '', 3, 4, $order_id);

			cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('order_customer_confirm_order')." {$order_id}");

			db::commit();
			db::autocommit(true);

			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_success'), '?ct=member_order&ac=doubt_list');

	}

	//客服待操作
	public function customer_not_operated()
	{
		$this->_operated_list(1);
	}

	//客服已操作
	public function customer_operated()
	{
		$this->_operated_list(2);
	}

	//主管待操作
	public function supervisor_not_operated()
	{
		$this->_operated_list(3);
	}

	//主管已操作
	public function supervisor_operated()
	{
		$this->_operated_list(4);
	}

	//主管受理中
	public function customer_accepting_list()
	{
		$this->_operated_list(5);
	}

	//主管已受理
	public function customer_accepted_list()
	{
		$this->_operated_list(6);
	}

	//主管受理中
	public function supervisor_accepting_list()
	{
		$this->_operated_list(7);
	}

	//主管已受理
	public function supervisor_accepted_list()
	{
		$this->_operated_list(8);
	}

	//审核列表
	private function _operated_list($operated_type)
	{
		$keyword = req::item('keyword', '');

		$where = array();

		if(!empty($keyword))
		{
			$mem_list_where = array ();
			$mem_list_where['or'][] = array ('code', 'like', $keyword.'%');
			$mem_list_where['or'][] = array ('custom_code', 'like', $keyword.'%');
			$mem_list = mod_member_info::get_list($mem_list_where, 'id');
			if(empty($mem_list))
			{
				$where[] = array ('member_info_id', '=', 0);
			}
			else
			{
				foreach ($mem_list as $k => $v)
				{
					$mem_ids[] = $v['id'];
				}

				$where[] = array ('member_info_id', 'in', $mem_ids);
			}
		}

		switch ($operated_type)
		{
			case 1:

					$where[] = array ('audit_status', '=', 1);
					$where[] = array ('status', '=', 0);
				break;
			case 2:

					$where[] = array ('audit_status', 'in', array (2,3));
					$where[] = array ('status', '=', 0);
				break;
			case 3:

					$where[] = array ('audit_status', '=', 2);
					$where[] = array ('status', '=', 0);
				break;
			case 4:

					$where[] = array ('audit_status', '=', 3);
					$where[] = array ('status', '=', 1);
				break;
			case 5:

					$where[] = array ('audit_status', '=', 1);
					$where[] = array ('status', '=', 0);
					$where[] = array ('customer_audit_id', '=', cls_auth::$user->fields['uid']);
				break;
			case 6:

					$where[] = array ('audit_status', '=', 2);
					$where[] = array ('status', '=', 0);
					$where[] = array ('customer_audit_id', '=', cls_auth::$user->fields['uid']);
				break;
			case 7:

					$where[] = array ('audit_status', '=', 2);
					$where[] = array ('status', '=', 0);
					$where[] = array ('customer_audit_id', '=', cls_auth::$user->fields['uid']);
				break;
			case 8:

					$where[] = array ('audit_status', '=', 3);
					$where[] = array ('status', '=', 1);
					$where[] = array ('customer_audit_id', '=', cls_auth::$user->fields['uid']);
				break;
		}

		$where[] = array ('pay_status', '=', 1);

		$count = mod_order::get_count($where);
		$pages = pub_page::make($count, req::item('page_size', '10','int'));
		$list = mod_order::get_list($where, '', $pages['page_size'], $pages['offset']);
		if(!empty($list))
		{
			//货币列表
			$currency_list = mod_currency_type::get_key_val();

			foreach ($list as $k => $v)
			{
				$mem_info = mod_member_info::find($v['member_info_id']);
				$shop_info = mod_shop::find($v['shop_id']);
				$interfaces_info = mod_shop_interfaces::find($v['interface_id']);
				$list[$k]['add_date'] = date('Y-m-d H:i:s', $v['addtime']);
				$list[$k]['amount'] = mod_member_info::num_format($v['amount']);
				$list[$k]['interfaces_name'] = empty($interfaces_info) ? '' : $interfaces_info['name'];
				$list[$k]['shop_name'] = empty($shop_info) ? '' : $shop_info['name'];
				$list[$k]['member_code'] = empty($mem_info) ? '' : $mem_info['code'];
				$list[$k]['member_name'] = empty($mem_info) ? '' : $mem_info['name'];
				$list[$k]['currency_name'] = isset($currency_list[$v['currency_code']]) ? $currency_list[$v['currency_code']] : '';
				$list[$k]['status_name'] = isset(mod_order::$status_list[$v['status']]) ? mod_order::$status_list[$v['status']] : '';
			}
		}

		tpl::assign('list', $list);
		tpl::assign('operated_type', $operated_type);
		tpl::assign('pages', $pages['show']);
		tpl::display('member_order.operated_list.tpl');
	}

	//审核订单详情
	public function operated_info()
	{
		$order_id = req::item('order_id');

		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		$info = mod_order::find($order_id);

		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//货币列表
		$currency_list = mod_currency_type::get_key_val();

		$member_info = mod_member_info::find($info['member_info_id']);
		$shop_info = mod_shop::find($info['shop_id']);
		$info['add_date'] = date('Y-m-d H:i:s', $info['addtime']);
		$info['amount'] = mod_member_info::num_format($info['amount']);
		$info['shop_name'] = empty($shop_info) ? '' : $shop_info['name'];
		$info['currency_name'] = isset($currency_list[$info['currency_code']]) ? $currency_list[$info['currency_code']] : '';
		$info['status_name'] = isset(mod_order::$status_list[$info['status']]) ? mod_order::$status_list[$info['status']] : '';

		$interface_info = mod_shop_interfaces::find($info['interface_id']);
		$info['object_name'] = empty($interface_info) ? '' : $interface_info['name'];

		$bill_list = mod_member_bank_log::get_list(array ('order_id', '=', $order_id));
		foreach ($bill_list as $k => $v)
		{
			$bill_list[$k]['type_name'] = isset(mod_member_bill::$type_list[$v['type']]) ? mod_member_bill::$type_list[$v['type']] : '';
			$bill_list[$k]['currency_name'] = $currency_list[$v['currency_code']];
			$bill_list[$k]['amount'] = mod_member_info::num_format($v['amount']);

			$bill_list[$k]['account_type_name'] = lang::get('order_credit_account');
			if($v['from_type'] == 1 && ($v['type'] == 1 || $v['type'] == 2))
			{
				$bill_list[$k]['account_type_name'] = lang::get('order_balance_account');
			}
			elseif ($v['type'] == 3 || $v['type'] == 6)
			{
				$bill_list[$k]['account_type_name'] = lang::get('order_freeze_account');
			}
			elseif ($v['type'] == 4 || $v['type'] == 7)
			{
				$bill_list[$k]['account_type_name'] = lang::get('order_doubt_account');
			}
		}

		//人工审核结果
		$info['customer_number'] = '';
		$info['customer_file'] = '';
		$info['supervisor_number'] = '';
		$info['supervisor_file'] = '';

		$file_list = mod_order_audit_op::get_list(array ('order_id', '=', $order_id), 'id,file,file_number');
		if($file_list)
		{
			$info['customer_number'] = isset($file_list[0]['file_number']) ? $file_list[0]['file_number'] : '';
			$info['customer_file'] = isset($file_list[0]['file']) ? $file_list[0]['file'] : '';
			$info['supervisor_number'] = isset($file_list[1]['file_number']) ? $file_list[1]['file_number'] : '';
			$info['supervisor_file'] = isset($file_list[1]['file']) ? $file_list[1]['file'] : '';
		}

		//返回URL处理
		$this->_get_gourl();

		tpl::assign('bill_list', $bill_list);
		tpl::assign('member_info', $member_info);
		tpl::assign('order_info', $info);
		tpl::assign('admin_id', cls_auth::$user->fields['uid']);
		tpl::display('member_order.operated_info.tpl');
	}

	//客服确认订单，操作未确认的订单，确认之后，主管再确认
	public function customer_confirm()
	{
		$order_id = req::item('order_id');
		$file_number = req::item('number');
		$file = req::item('recording');

		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		if(empty($file_number) && empty($file))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_choose_least_one'), '-1');
		}

		//获取订单
		$info = mod_order::find($order_id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		if($info['customer_audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		//判断订单信息是否未确认
		if($info['status'] != 0 || $info['audit_status'] != 1)
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_type'), '-1');
		}

		db::begin_tran();

		//修改订单状态
		$order_update_data['audit_status'] = 2;
		$order_update_data['uptime'] = time();

		$result = mod_order::update_data(array ('order_id', '=', $order_id), $order_update_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//添加客服信息
		$audit_op_add_data['order_id'] = $order_id;
		$audit_op_add_data['audit_id'] = cls_auth::$user->fields['uid'];
		$audit_op_add_data['file_number'] = $file_number;
		$audit_op_add_data['file'] = is_array($file) ? implode(',', $file) : '';
		$audit_op_add_data['addtime'] = time();

		$result = mod_order_audit_op::add_data($audit_op_add_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//转移文件
		if(!$this->_move_file($file))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('order_customer_confirmed_unconfirmed_orders')." {$order_id}");

		db::commit();
		db::autocommit(true);

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_success'), '?ct=member_order&ac=customer_not_operated');

	}

	//主管确认订单，确认之后将成为真正的订单
	public function supervisor_confirm()
	{
		$order_id = req::item('order_id');
		$file_number = req::item('number');
		$file = req::item('recording');

		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		if(empty($file_number) && empty($file))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_choose_least_one'), '-1');
		}

		//获取订单
		$order_info = mod_order::find($order_id);
		if(empty($order_info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		if($order_info['supervisor_audit_id'] != cls_auth::$user->fields['uid'])
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_illegal_operation'), '-1');
		}

		//判断订单信息是否未确认
		if($order_info['status'] != 0 || $order_info['audit_status'] != 2)
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//获取该订单的冻结账单
		$bill_where = array ();
		$bill_where[] = array ('order_id', '=', $order_id);
		$bill_where[] = array ('type', '=', 1);

		$bill_list = mod_member_bank_log::get_list($bill_where);

		db::begin_tran();

		if(!empty($bill_list))
		{
			foreach ($bill_list as $k => $v)
			{
				//生成解冻账单日志
				$bill_add_data = array ();
				$bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['order_id'] = $v['order_id'];
				$bill_add_data['member_info_id'] = $v['member_info_id'];
				$bill_add_data['type'] = 6;
				$bill_add_data['bank_card_id'] = $v['bank_card_id'];
				$bill_add_data['currency_code'] = $v['currency_code'];
				$bill_add_data['amount'] = $v['amount'];
				$bill_add_data['from_type'] = 2;
				$bill_add_data['remark'] = lang::get('model_thaw');
				//$bill_add_data['status'] = 1;
				$bill_add_data['date'] = date('Y-m-d',time());
				$bill_add_data['addtime'] = time();
				$result = mod_member_bank_log::add_data($bill_add_data);

				if (empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
				}

				//查询冻结金额
				$member_bank_where = array ();
				$member_bank_where[] = array ('member_info_id', '=', $v['member_info_id']);
				$member_bank_where[] = array ('currency_code', '=', $v['currency_code']);
				$member_bank_where[] = array ('type', '=', 2);
				$member_bank = mod_member_money_bank::get_info($member_bank_where);
				if(empty($member_bank))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
				}

				//修改冻结金额
				$member_up_data = array ();
				$member_up_data['money'] = $member_bank['money'] + $v['amount'];

				$result = mod_member_money_bank::update_data($member_bank_where, $member_up_data);

				if (empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
				}

				//生成支出账单
				$bill_add_data = array ();
				$bill_add_data['bill_id'] = util::make_bill_id();
				$bill_add_data['member_info_id'] = $v['member_info_id'];
				$bill_add_data['type'] = 1;
				$bill_add_data['bank_card_id'] = $v['bank_card_id'];
				$bill_add_data['currency_code'] = $v['currency_code'];
				$bill_add_data['amount'] = $v['amount'];
				$bill_add_data['from_type'] = $v['from_type'];
				$bill_add_data['remark'] = lang::get('order_buy').$order_info['goods_name'];
				$bill_add_data['date'] = date('Y-m-d',time());
				$bill_add_data['addtime'] = time();
				$bill_add_data['uptime'] = time();

				$result = mod_member_bill::add_data($bill_add_data);
				if (empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
				}

				//生成订单与账单流水关联数据
				$bill_order_link_add = array ();
				$bill_order_link_add['order_id'] = $order_id;
				$bill_order_link_add['bill_id'] = $bill_add_data['bill_id'];
				$result = mod_member_order_bill_link::add_data($bill_order_link_add);
				if (empty($result))
				{
					db::rollback();
					cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
				}
			}
		}

		//增加商户余额
		$shop_bank_where = array ();
		$shop_bank_where[] = array ('shop_id', '=', $order_info['shop_id']);
		$shop_bank_where[] = array ('currency_code', '=', $order_info['currency_code']);

		$shop_bank_info = mod_shop_money_bank::get_info($shop_bank_where);
		if (empty($shop_bank_info))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_refusal_order_failed'), '-1');
		}

		$shop_bank_updata = array ();
		$shop_bank_updata['money'] = $shop_bank_info['money'] + $order_info['amount'];
		$result = mod_shop_money_bank::update_data($shop_bank_where, $shop_bank_updata);
		if (empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//增加商户账单流水
		$shop_bill_add_date = array ();
		$shop_bill_add_date['bill_id'] = util::make_bill_id();
		$shop_bill_add_date['bank_card_id'] = $shop_bank_info['id'];
		$shop_bill_add_date['shop_id'] = $order_info['shop_id'];
		$shop_bill_add_date['type'] = '2';
		$shop_bill_add_date['currency_code'] = $order_info['currency_code'];
		$shop_bill_add_date['amount'] = $order_info['amount'];
		$shop_bill_add_date['remark'] = lang::get('order_buy_success');
		$shop_bill_add_date['date'] = date('Y-m-d', time());
		$shop_bill_add_date['addtime'] = time();

		$result = mod_shop_bill::add_data($shop_bill_add_date);
		if (empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//订单与账单流水关联数据
		$bill_order_link_add = array ();
		$bill_order_link_add['order_id'] = $order_info['order_id'];
		$bill_order_link_add['bill_id'] = $shop_bill_add_date['bill_id'];
		$result = mod_shop_order_bill_link::add_data($bill_order_link_add);
		if (empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//修改订单状态
		$up_order_data = array ();
		$up_order_data['status'] = 1;
		$up_order_data['audit_status'] = 3;
		$up_order_data['uptime'] = time();
		$result = mod_order::update_data(array ('order_id', '=', $order_id), $up_order_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//添加客服信息
		$audit_op_add_data = array ();
		$audit_op_add_data['order_id'] = $order_id;
		$audit_op_add_data['audit_id'] = cls_auth::$user->fields['uid'];
		$audit_op_add_data['file_number'] = $file_number;
		$audit_op_add_data['file'] = is_array($file) ? implode(',', $file) : '';
		$audit_op_add_data['addtime'] = time();

		$result = mod_order_audit_op::add_data($audit_op_add_data);
		if(empty($result))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//转移文件
		if(!$this->_move_file($file))
		{
			db::rollback();
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_fail'), '-1');
		}

		//添加推送消息
		$title = lang::get('push_message_order_title');
		$content = lang::get('push_message_confirm_order_success');
		mod_app_message::create($order_info['member_info_id'], 0, $title, $content, '', 3, 4, $order_id);

		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('order_supervisor_confirmed_unconfirmed_orders')." {$order_id}");

		db::commit();
		db::autocommit(true);

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_confirm_order_success'), '?ct=member_order&ac=supervisor_not_operated');

	}

	//移动文件
	private function _move_file($files)
	{
		if(empty($files))
		{
			return true;
		}

		//没有该目录则创建
		if(!is_dir(PATH_UPLOADS.'/file'))
		{
			if(!mkdir(PATH_UPLOADS.'/file',0777))
			{
				return false;
			}
		}

		//移动文件
		if(is_array($files))
		{
			foreach ($files as $file)
			{
				if(file_exists(PATH_UPLOADS.'/tmp/'.$file))
				{
					if(!rename(PATH_UPLOADS.'/tmp/'.$file, PATH_UPLOADS.'/file/'.$file))
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}

			return true;
		}
		else
		{
			if(file_exists(PATH_UPLOADS.'/tmp/'.$files))
			{
				return rename(PATH_UPLOADS.'/tmp/'.$files, PATH_UPLOADS.'/file/'.$files);
			}
			else
			{
				return false;
			}
		}
	}

	//下载文件
	public function down_file()
	{
		$file_name = req::item('file_name');
		//$file_name = '1213lsdfsdaf.zip';
		//$file_name = '5a434570449f1.jpg';
		$file_path = PATH_UPLOADS.'/file/';

		//判断文件是否存在
		if(!file_exists($file_path . $file_name))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_download_file_fail'), '-1');
		}

		$ciphertext = file_get_contents($file_path . $file_name);

		header("Content-type: application/octet-stream");
		header('Content-Disposition: attachment; filename="'. $file_name . '"');
		header("Content-Length:".strlen($ciphertext));

		exit($ciphertext);

	}

	//客服受理
	public function customer_accepte()
	{
		$order_id = req::item('order_id');
		$operated_type = req::item('operated_type');

		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//获取订单
		$info = mod_order::find($order_id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		$update_data = array ();
		$update_data['customer_audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		mod_order::update_data(array ('order_id', '=', $order_id), $update_data);
		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('order_customer_audit_accepte')." {$order_id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_acceptance_success'), "?ct=member_order&ac=operated_info&order_id={$order_id}&operated_type={$operated_type}");

	}

	//主管受理
	public function supervisor_accepte()
	{
		$order_id = req::item('order_id');
		$operated_type = req::item('operated_type');

		if(empty($order_id))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		//获取订单
		$info = mod_order::find($order_id);
		if(empty($info))
		{
			cls_msgbox::show(lang::get('common_system_hint'), lang::get('order_select_order'), '-1');
		}

		$update_data = array ();
		$update_data['supervisor_audit_id'] = cls_auth::$user->fields['uid'];
		$update_data['uptime'] = time();

		mod_order::update_data(array ('order_id', '=', $order_id), $update_data);
		cls_auth::save_admin_log(cls_auth::$user->fields['username'], lang::get('order_supervisor_audit_accepte')." {$order_id}");

		cls_msgbox::show(lang::get('common_system_hint'), lang::get('common_acceptance_success'), "?ct=member_order&ac=operated_info&order_id={$order_id}&operated_type={$operated_type}");

	}

	//返回URL处理
	private function _get_gourl()
	{
		$operated_type = req::item('operated_type');

		switch ($operated_type)
		{
			case 1:
					$gourl = "?ct=member_order&ac=customer_not_operated";
				break;
			case 2:
					$gourl = "?ct=member_order&ac=customer_operated";
				break;
			case 3:
					$gourl = "?ct=member_order&ac=supervisor_not_operated";
				break;
			case 4:
					$gourl = "?ct=member_order&ac=supervisor_operated";
				break;
			case 5:
					$gourl = "?ct=member_order&ac=customer_accepting_list";
				break;
			case 6:
					$gourl = "?ct=member_order&ac=customer_accepted_list";
				break;
			case 7:
					$gourl = "?ct=member_order&ac=supervisor_accepting_list";
				break;
			case 8:
					$gourl = "?ct=member_order&ac=supervisor_accepted_list";
				break;
		}

		tpl::assign('gourl', $gourl);
		tpl::assign('operated_type', $operated_type);

		return $gourl;
	}
}
