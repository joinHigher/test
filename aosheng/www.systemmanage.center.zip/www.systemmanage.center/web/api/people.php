<?php
require '../core/call.php';
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 人员API
 */
class people
{
    //数据结构
    //-------------------------------
    private $organization_array =
        [
            'status' => 0,
            'message' => '',
            'data' => [
                'top' => [],
                'sub_org' => [],
                'department' => [],
                'station' => [],
                'member' => [],
            ],
        ];
    private $department_array =
        [
            'status' => 0,
            'message' => '',
            'data' => [
                'department' => [],
                'station' => [],
                'member' => [],
            ],
        ];
    private $station_array =
        [
            'status' => 0,
            'message' => '',
            'data' => [
                'member' => [],
            ],
        ];
    private $people_array =
        [
            'status' => 0,
            'message' => '',
            'data' => [],
        ];
    private $type = 'organization';


    //选择人员列表
    public function make_list()
    {
        $id = req::post('id',0,'int');
        $this->type = req::post('type','organization');

        $result = $this->_get_childs($id);

        pub_mod_common::exit_json($result);
    }

    //根据人员ID取得员工信息
    public function get_one()
    {
        $people_id = req::post('id',0,'int');

        $fields = 'id,realname as name,sn,entry_organization as organization_id,entry_department as department_id';
        $row = db::select($fields)->from(mod_table::people)->where('id','=',$people_id)->as_row()->execute();
        if(empty($row)){
            pub_mod_common::exit_json($this->people_array);
        }

        $data = &$this->people_array['data'];
        $data = $row;
        $data['organization'] = db::select('short_name')->from(mod_table::organization)->where('id','=',$row['organization_id'])->as_field()->execute();
        $data['department'] = db::select('name')->from(mod_table::department)->where('id','=',$row['department_id'])->as_field()->execute();
        $station_id = db::select('station_id')->from(mod_table::job_child)->where('member_id','=',$row['id'])->as_field()->execute();
        if($station_id>0){
            $data['job'] = db::select('name')->from(mod_table::job)->where('id','=',$station_id)->as_field()->execute();
        }

        pub_mod_common::exit_json($this->people_array);
    }

    public function get_peoples()
    {
        $id = req::post('id',0,'int');
        $type = req::post('type','organization');

        $peoples = [];
        if($type=='organization')
        {
            $peoples = db::select('id')->from(mod_table::people)->where('entry_organization','=',$id)->execute();
        } elseif ($type=='department')
        {
            $peoples = db::select('id')->from(mod_table::people)->where('entry_department','=',$id)->execute();
        } elseif ($type=='station')
        {
            $peoples = db::select('member_id as id')->from(mod_table::job_child)->where('station_id','=',$id)->execute();
        }
        if($peoples){
            $this->people_array['data'] = mod_array::one_array($peoples,[0,'id']);
        }

        pub_mod_common::exit_json($this->people_array);
    }

    public function get_peoples_by_mix()
    {
        $organization_ids = req::post('organization_ids');
        $department_ids = req::post('department_ids');
        $station_ids = req::post('station_ids');

        $peoples = [];
        //机构
        if($organization_ids && is_array($organization_ids))
        {
            $peoples_organ = db::select('id')->from(mod_table::people)->where('entry_organization','in',$organization_ids)->execute();
            $peoples_organ && $peoples = array_merge($peoples,$peoples_organ);
        }
        //部门
        if($department_ids && is_array($department_ids))
        {
            $peoples_department = db::select('id')->from(mod_table::people)->where('entry_department','in',$department_ids)->execute();
            $peoples_department && $peoples = array_merge($peoples,$peoples_department);
        }
        //岗位
        if($station_ids && is_array($station_ids))
        {
            $peoples_station = db::select('member_id as id')->from(mod_table::job_child)->where('station_id','in',$station_ids)->execute();
            $peoples_station && $peoples = array_merge($peoples,$peoples_station);
        }


        if($peoples){
            $this->people_array['data'] = mod_array::one_array($peoples,[0,'id']);
        }

        pub_mod_common::exit_json($this->people_array);
    }

    //判断员工是否属于某个部门
    public function validate_department()
    {
        $people_id = req::post('id',0,'int');
        $department_id = req::post('department_id',0,'int');

        $message = null;
        ($people_id==0 && $message = "id is required")  ||  ($department_id==0 && $message = "department_id is required");
        if($message)
        {
            $this->people_array['status'] = 5002;
            $this->people_array['message'] = $message;
            pub_mod_common::exit_json($this->people_array);
        }

        $entry_department = db::select('entry_department')->from(mod_table::people)->where('id','=',$people_id)->as_field()->execute();

        $entry_department!=$department_id && $message = "非该部门的员工";
        if($message)
        {
            $this->people_array['status'] = 5100;
            $this->people_array['message'] = $message;
            pub_mod_common::exit_json($this->people_array);
        }

        pub_mod_common::exit_json($this->people_array);
    }

    /*
     * 取得子集
     * $id 父ID
     */
    private function _get_childs($id)
    {
        $type = $this->type;
        if($type=='organization')
        {
            $data = &$this->organization_array['data'];

            if($id==0)//权力机构
            {
                $row = db::select('id,name')->from(mod_table::organization)->where('superior','=',0)->as_row()->execute();
                if(empty($row)){
                    return $this->organization_array;
                }
                $data['top'] = $row;
                $id = $row['id'];
            }

            $where = [ ['superior','=',$id] ];
            $data['sub_org'] = $this->_get_organizations($where);

            $where = [
                ['organization_id','=',$id],
                ['superior_id','=',0]//部门ID为0
            ];
            $data['department'] = $this->_get_departments($where);

            $where = [
                ['organization_id','=',$id],
                ['department_id','=',0]
            ];
            $data['station'] = $this->_get_stations($where);

            $where = [
                ['entry_organization','=',$id],
                ['entry_department','=',0],
                ['entry_job','=',0]
            ];
            $data['member'] = $this->_get_peoples($where);

            return $this->organization_array;
        }
        elseif ($type=='department')
        {
            $data = &$this->department_array['data'];
            $where = [
                ['superior_id','=',$id]//部门ID
            ];
            $data['department'] = $this->_get_departments($where);

            $where = [
                ['department_id','=',$id]
            ];
            $data['station'] = $this->_get_stations($where);

            $where = [
                ['entry_department','=',$id],
                ['entry_job','=',0]
            ];
            $data['member'] = $this->_get_peoples($where);

            return $this->department_array;
        }
        elseif ($type=='station')
        {
            $data = &$this->station_array['data'];

            $where = [
                ['station_id','=',$id]
            ];
            $data['member'] = $this->_get_peoples($where,'way_two');

            return $this->station_array;
        }

        return $this->organization_array;
    }

    /*
     * 取得机构列表
     * $where WHERE条件
     */
    private function _get_organizations($where)
    {
        $array = db::select('id,short_name as name')->from(mod_table::organization)->where($where)->execute();
        if(empty($array))
        {
            return [];
        }

        foreach ($array as &$item)
        {
            $item['is_sub'] = $this->_count(__FUNCTION__,$item['id']);
        }

        return $array;
    }

    //取得部门列表
    private function _get_departments($where)
    {
        $array = db::select('id,name')->from(mod_table::department)->where($where)->execute();
        if(empty($array))
        {
            return [];
        }

        foreach ($array as &$item)
        {
            $item['is_sub'] = $this->_count(__FUNCTION__,$item['id']);
        }

        return $array;
    }

    //取得岗位列表
    private function _get_stations($where)
    {
        $array = db::select('id,name')->from(mod_table::job)->where($where)->execute();
        if(empty($array))
        {
            return [];
        }

        foreach ($array as &$item)
        {
            $item['is_sub'] = $this->_count(__FUNCTION__,$item['id']);
        }

        return $array;
    }

    /*
     * 取得人员列表
     * $way: way_one 方法一,way_two 方法二
     */
    private function _get_peoples($where,$way='way_one')
    {
        if($way=='way_two')
        {
            $people_ids = db::select('member_id')->from(mod_table::job_child)->where($where)->execute();
            if(!$people_ids)    return [];
            $people_ids = mod_array::one_array($people_ids,[0,'member_id']);
            $array = db::select('id,realname as name,sn')->from(mod_table::people)->where('id','in',$people_ids)->execute();
        }else
        {
            $array = db::select('id,realname as name,sn')->from(mod_table::people)->where($where)->execute();
        }

        if(empty($array))
        {
            return [];
        }

        return $array;
    }

    /**
     * 是否有子集
     * @param $function 来自function
     * @param $id
     * @return int
     */
    private function _count($function,$id)
    {
        if($function=='_get_organizations')
        {
            $where = [ ['superior','=',$id] ];
            $count = db::select('count(*)')->from(mod_table::organization)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            $where = [
                ['organization_id','=',$id],
                ['superior_id','=',0]//部门ID为0
            ];
            $count = db::select('count(*)')->from(mod_table::department)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            $where = [
                ['organization_id','=',$id],
                ['department_id','=',0]
            ];
            $count = db::select('count(*)')->from(mod_table::job)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            $where = [
                ['entry_organization','=',$id],
                ['entry_department','=',0],
                ['entry_job','=',0]
            ];
            $count = db::select('count(*)')->from(mod_table::people)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            return 0;
        }
        elseif ($function=='_get_departments')
        {
            $where = [
                ['superior_id','=',$id]
            ];
            $count = db::select('count(*)')->from(mod_table::department)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            $where = [
                ['department_id','=',$id]
            ];
            $count = db::select('count(*)')->from(mod_table::job)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            $where = [
                ['entry_department','=',$id],
                ['entry_job','=',0]
            ];
            $count = db::select('count(*)')->from(mod_table::people)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            return 0;
        }
        elseif ($function=='_get_stations')
        {
            $where = [
                ['station_id','=',$id]
            ];
            $count = db::select('sum(member_id)')->from(mod_table::job_child)->where($where)->as_field()->execute();
            if($count>0)    return 1;

            return 0;
        }
    }

}

pub_mod_api::api_run(new people());