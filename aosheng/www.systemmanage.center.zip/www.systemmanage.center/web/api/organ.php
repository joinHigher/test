<?php
require '../core/call.php';
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构API
 */
class organ
{
    //数据结构
    //-------------------------------
    private $mix_array =
        [
            'status' => 0,
            'message' => '',
            'data' => [
                'organizations' => [],
                'departments' => [],
                'stations' => [],
                'members' => [],
            ],
        ];


    //选择人员列表
    public function mixing()
    {
        $organization_ids = req::post('organization_ids');
        $department_ids = req::post('department_ids');
        $station_ids = req::post('station_ids');
        $member_ids = req::post('member_ids');

        $data = &$this->mix_array['data'];
        if($organization_ids)
        {
            if(!is_array($organization_ids))
            {
                $this->mix_array['message'] = 'organization_ids must be array';
                pub_mod_common::exit_json($this->mix_array);
            }
            $organizations = db::select('id,short_name as name')->from(mod_table::organization)->where('id','in',$organization_ids)->execute();
            if($organizations)
            {
                $organizations = mod_array::multi_array($organizations,['id',0]);
            }
            $data['organizations'] = $organizations;
        }
        if($department_ids)
        {
            if(!is_array($department_ids))
            {
                $this->mix_array['message'] = 'department_ids must be array';
                pub_mod_common::exit_json($this->mix_array);
            }
            $departments = db::select('id,name')->from(mod_table::department)->where('id','in',$department_ids)->execute();
            if($departments)
            {
                $departments = mod_array::multi_array($departments,['id',0]);
            }
            $data['departments'] = $departments;
        }
        if($station_ids)
        {
            if(!is_array($station_ids))
            {
                $this->mix_array['message'] = 'station_ids must be array';
                pub_mod_common::exit_json($this->mix_array);
            }
            $stations = db::select('id,name')->from(mod_table::job)->where('id','in',$station_ids)->execute();
            if($stations)
            {
                $stations = mod_array::multi_array($stations,['id',0]);
            }
            $data['stations'] = $stations;
        }
        if($member_ids)
        {
            if(!is_array($member_ids))
            {
                $this->mix_array['message'] = 'member_ids must be array';
                pub_mod_common::exit_json($this->mix_array);
            }
            $fields = 'id,entry_department as department_id,realname as name';
            $members = db::select($fields)->from(mod_table::people)->where('id','in',$member_ids)->execute();
            if($members)
            {
                foreach ($members as &$member)
                {
                    $member['department'] = db::select('name')->from(mod_table::department)->where('id','=',$member['department_id'])->as_field()->execute();
                }
                $members = mod_array::multi_array($members,['id',0]);
            }

            $data['members'] = $members;
        }

        pub_mod_common::exit_json($this->mix_array);
    }

}

pub_mod_api::api_run(new organ());