<?php
header('Content-Type: text/html; charset=utf-8');

require '../core/call.php';

$json_data = array('sta'=>0,'msg'=>'','data'=>array());  //通用接口返回格式

$sign = md5("AS".date('Ymdh')); //签名认证
//数据处理
$reqs['member_id'] = (int)request('member_id'); //会员id

$reqs['sign'] = strtolower(_clean_str(request('sign'))); //sign

$where =array();
//签名合法性检查
if($reqs['sign']!=$sign)
{
    //签名不正确
    $json_data['msg'] = 'The signature is incorrect';
    exit(json_encode($json_data));
}

if($reqs['member_id'])
{
    $where[] = array('id',$reqs['member_id']);
}

$arr = mod_member::get_member_info($where);

$arr = !empty($arr)?$arr:'';

$json_data['sta']='1';

$json_data['data'] = $arr;

exit(json_encode($json_data));













function _clean_str($str)
{
    return trim(stripslashes($str));
}


