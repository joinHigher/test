<xml>
    <menu name='机构管理' class='fa fa-user'>
        <menu name='机构列表' ct='organization' ac='index' default='1'  />
        <menu name='添加机构' url='?ct=organization&ac=add'   ct='organization' ac='add' display='none'  />
        <menu name='编辑机构' url='?ct=organization&ac=edit'  ct='organization' ac='edit' display='none'  />
    </menu>
    <menu name='员工管理' class='fa fa-user'>
        <menu name='全部员工' url='?ct=staff&ac=index' ct='staff' ac='index'/>
    </menu>
    <menu name='设置' class='fa fa-th-list'>
        <menu name='机构等级'  ct='mechanism' ac='index'/>
        <menu name='部门岗位等级' url='?ct=dtpost&ac=index' ct='dtpost' ac='index'/>
        <menu name='行政等级' url='?ct=admin_level&ac=index' ct='admin_level' ac='index'/>
        <menu name='地区管理' url='?ct=area&ac=index' ct='area' ac='index'/>
    </menu>
    <!-- //这里的子菜单为隐性项目 -->
    <menu name='常用' class='fa fa-th-list'>
        <menu name='内容管理' class='fa fa-th-list'>
            <menu name='内容列表' ct='content' ac='index' reload='1' />
            <menu name='内容添加' ct='content' ac='add' display='none' />
            <menu name='内容修改' ct='content' ac='edit' display='none' />
            <menu name='内容删除' ct='content' ac='del' display='none' />
            <menu name='{{lang.menu_content_category_manage}}' ct='category' ac='index' />
            <menu name='{{lang.menu_content_category_add}}'    ct='category' ac='add' display='none' />
            <menu name='{{lang.menu_content_category_update}}' ct='category' ac='edit' display='none' />
            <menu name='{{lang.menu_content_category_delete}}' ct='category' ac='del' display='none'  />
        </menu>
    </menu>
    <menu name='系统' class='fa fa-gear'>
        <menu name='用户管理' class='fa fa-user'>
            <menu name='用户组管理' ct='admin_group' ac='index' />
            <menu name='用户组添加' ct='admin_group' ac='add' display='none' />
            <menu name='用户组修改' ct='admin_group' ac='edit' display='none' />
            <menu name='用户组删除' ct='admin_group' ac='del'  display='none' />

            <menu name='用户管理' ct='admin' ac='index' />
            <menu name='用户添加' ct='admin' ac='add' display='none' />
            <menu name='用户修改' ct='admin' ac='edit' display='none' />
            <menu name='用户删除' ct='admin' ac='del' display='none' />

            <menu name='修改密码' ct='admin' ac='editpwd' />
            <menu name='我的权限' ct='admin' ac='mypurview' />
        </menu>
        <menu name='系统管理' class='fa fa-wrench'>
            <menu name='后台菜单配置' ct='system' ac='edit_menu' />

            <menu name='配置管理' ct='config' ac='index' />
            <menu name='配置添加' ct='config' ac='add' display='none'  />
            <menu name='配置修改' ct='config' ac='edit' display='none'  />
            <menu name='配置删除' ct='config' ac='del' display='none'  />

            <menu name='操作日志' ct='admin' ac='oplog' />
            <menu name='登录日志' ct='admin' ac='login_log' />
        </menu>
        <menu name='缓存管理' class='fa fa-cloud'>
            <menu name='缓存管理' ct='cache' ac='index' />
            <menu name='缓存删除' ct='cache' ac='del' display='none' />
            <menu name='缓存清理' ct='cache' ac='clear' display='none' />
            <menu name='Redis键值管理' ct='cache' ac='redis_keys' />
            <menu name='Redis服务器信息' ct='cache' ac='redis_info' />
        </menu>
        <menu name='文件管理' ct='filemanage' ac='index' class='fa fa-file' />
        <menu name='文件新增' ct='filemanage' ac='add' display='none' />
        <menu name='文件修改' ct='filemanage' ac='edit' display='none' />
        <menu name='文件删除' ct='filemanage' ac='del' display='none' />

        <menu name='计划任务管理' ct='crond' ac='index' class='fa fa-tasks' />
        <menu name='计划任务新增' ct='crond' ac='add' display='none'  />
        <menu name='计划任务修改' ct='crond' ac='edit' display='none'  />
        <menu name='计划任务删除' ct='crond' ac='del' display='none'  />
    </menu>
</xml>