<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 系统所有基础类型数据 模型
 *
 * @version $Id$
 */

class mod_base_type
{
    public static $table = '#PB#_base_type_setting'; //表名

    public static $pk = 'id'; //主键

    public static $type = array( // 类型数组
        'certif', 'contri', 'depart', 'business_trip', 'living', 'bussiness_treatment', 'living_treatment','contact'
    );

    public static $fields = array(
        'id','name','type'
    );

    public static  $get_type = array(
           'certif'=>'证件类型',
           'contri'=>'出资方式',
           'depart'=>'部门类型',
           'business_trip'=>'商旅类型',
           'living'=>'生活类型',
           'bussiness_treatment'=>'商旅待遇',
           'living_treatment'=>'生活待遇',
           'contact'=>'联系方式'
       );

    /**
     * 获取生活待遇类型 ，id也可以为数组返回多个类型数据 id不为空时返回单条数据，否则返回所有类型数据
     * @param int array  $id
     * @return array|bool|mixed|null
     */
    public static function get_living_treatment($id = 0,$first_option = '')
    {
        if (!empty($id))
        {
            return self::getdump($id, 'living_treatment');
        }
        else
        {
            return self::getlist('living_treatment',$first_option);
        }
    }

    /**
     * 获取商旅待遇类型 ，id也可以为数组返回多个类型数据，id不为空时返回单条数据，否则返回所有类型数据
     * @param int $id
     * @return array|bool|mixed|null
     */
    public static function get_bussiness_treatment($id = 0,$first_option = '')
    {
        if (!empty($id))
        {
            return self::getdump($id, 'bussiness_treatment');
        }
        else
        {
            return self::getlist('bussiness_treatment',$first_option);
        }
    }



    /**
     * 获取生活类型 ，id也可以为数组返回多个类型数据，id不为空时返回单条数据，否则返回所有类型数据
     * @param int $id
     * @return array|bool|mixed|null
     */
    public static function get_living($id = 0,$first_option = '')
    {
        if (!empty($id))
        {
            return self::getdump($id, 'living');
        }
        else
        {
            return self::getlist('living',$first_option);
        }
    }

    /**
     * 获取出资方式 ，id也可以为数组返回多个类型数据，id不为空时返回单条数据，否则返回所有类型数据
     * @param int $id
     * @return array|bool|mixed|null
     */
    public static function get_contri($id = 0,$first_option = '')
    {
        if(!empty($id))
        {
            return self::getdump($id,'contri');
        }
        else
        {
            return self::getlist('contri',$first_option);
        }
    }

    /**
     * 获取商旅类型 ，id也可以为数组返回多个类型数据，id不为空时返回单条数据，否则返回所有类型数据
     * @param int $id
     * @return array|bool|mixed|null
     */
    public static function get_business($id = 0,$first_option = '')
    {
        if(!empty($id))
        {
            return self::getdump($id,'business_trip');
        }
        else
        {
            return self::getlist('business_trip',$first_option);
        }
    }

    /**
     * 获取联系方式 ，id也可以为数组返回多个类型数据，id不为空时返回单条数据，否则返回所有类型数据
     * @param int $id
     * @return array|bool|mixed|null
     */
    public static function get_contact($id = 0,$first_option = '')
    {
        if(!empty($id))
        {
            return self::getdump($id,'contact');
        }
        else
        {
            return self::getlist('contact',$first_option);
        }
    }

    /**
     * 获取证件类型 ，id也可以为数组返回多个类型数据，id不为空时返回单条数据，否则返回所有类型数据
     * @param int $id
     * @return array|bool|mixed|null
     */
    public static function get_certif($id = 0,$first_option = '')
    {
        if(!empty($id))
        {
            return self::getdump($id,'certif');
        }
        else
        {
            return self::getlist('certif');
        }
    }

    /**
     * 获取部门类型数据 ，id也可以为数组返回多个类型数据，id不为空时返回单条数据，否则返回所有类型数据
     * @param int $id
     * @return array|bool|mixed|null
     */
    public static function get_depart($id = 0,$first_option = '')
    {
        if(!empty($id))
        {
            return self::getdump($id,'depart');
        }
        else
        {
            return self::getlist('depart',$first_option);
        }
    }

    /**
     * 雷特专用
     */
    public static function get_bussiness_treatment_list(){
        $data = db::select(array('id','name'))->from(self::$table)->where('type','=','bussiness_treatment')->execute();
        if(empty($data)) return array();
        $options = array();
        foreach ($data as $v)
        {
            $options[$v['id']] = $v['name'];
        }
        return $options;
    }


    /*******************一下为基础查询，多处使用*******************/
    public static function getlist($type = '',$first_option = ''){
        if(in_array($type,self::$type))
        {
            $options = array(
                '' => $first_option = empty($first_option)? '请选择':$first_option
            );
            $data = db::select(array('id','name'))
                ->from(self::$table)
                ->where('type','=',$type)
                ->and_where('delete_user','=','0')
                ->execute();
            if(empty($data)) return false;
            foreach ($data as $v)
            {
                $options[$v['id']] = $v['name'];
            }
            return $options;
        }
        return false;
    }

    public static function getdump($id = 0,$type = '')
    {
        if(!in_array($type,self::$type) || empty($id))
        {
            return false;
        }
        if(is_array($id))
        {
            return db::select(array('id','name'))
                ->from(self::$table)
                ->where('id','in',$id)
                ->and_where('type','=',$type)
                ->execute();
        }
        if($id > 0 )
        {
            $data = db::select(array('id','name'))
                ->from(self::$table)
                ->where('id','=',$id)
                ->and_where('type','=',$type)
                ->execute();
            return $data[0];
        }
    }


}
