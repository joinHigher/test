<?php
if( !defined('PHPCALL') ) exit('Request Error!');
class mod_user
{
    public static function valid_username($val)
    {
        var_dump($val);
        return false;
    }
}
