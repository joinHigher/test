<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 区域薪酬模块
 *
 * Created by PhpStorm.
 * User: leita
 * Date: 2018/3/17
 * Time: 上午11:26
 * Function: {
 *    exit_ 带有此前缀的执行完本方法都不再往下执行
 *    exit_page_ 展示html页面并exit不再往下执行
 *    display_ 与页面数据展示相关
 *    count_ 与页面需计算的数据相关
 *    outside_ 来自其它模块的数据或外界的数据
 *    array_ 与数组相关的数据
 * }
 */
class mod_payment_area
{
    static $rule = [
        'country_id'=>[ 'required'=>'' ]
    ];

    public static function display_city($row)
    {
        if($row['deep']==1)
        {
            $name = db::select('short_name')->from(mod_table::area)->where('id','=',$row['country_id'])->as_field()->execute();

            return $name;
        }elseif ($row['deep']==2)
        {
            $city_rows = db::select('short_name')->from(mod_table::area)->where('id','in',[$row['country_id'], $row['province_id']])->execute();
            $citys = mod_array::one_array($city_rows,[0,'short_name']);

            return implode(' ',$citys);
        }elseif ($row['deep']==3)
        {
            $city_rows = db::select('short_name')->from(mod_table::area)->where('id','in',[$row['country_id'], $row['province_id'], $row['city_id']])->execute();
            $citys = mod_array::one_array($city_rows,[0,'short_name']);

            return implode(' ',$citys);
        }
    }

}
