<?php

/**
 * Created by PhpStorm.
 * User: leita
 * Date: 2018/3/14
 * Time: 下午3:52
 */

require '../core/library/phpexcel/PHPExcel.php';
//require Yii::getAlias('@common').'/3thlibrary/PHPExcel_1.8.0/Classes/PHPExcel.php';

class mod_excel {

    //excel版本类,目前只需要用到这两个版本，以后有需要再加，而且使用例子中只使用到这两个类别的都没使用到。
    const excel5 = 'Excel5';//用于底版本的excel如95，不过现在的人大部分用2003以上的了，所以默认用2007
    const excel2007 = 'Excel2007';

    private $excel_version,$sheet_titles,$objPHPExcel,$objWriter,$objReader,$objSheet;
    private $letters = [//26个字母
        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    ];
    private $save_dir = PATH_UPLOADS."/tmp/";  //"R:/var/phpexcel_saves/";//默认生成文件目录

    public function __construct( $version = self::excel2007 )
    {
        $this->excel_version = $version;
        $this->objPHPExcel = new \PHPExcel();

        // Set document properties
        $this->objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");
        //$this->objReader = \PHPExcel_IOFactory::createReader($this->objPHPExcel, $this->excel_version);
    }

    //取得PHPExcel对象
    public function getObjPHPExcel()
    {
        return $this->objPHPExcel;
    }

    //取得活动表
    public function getObjActSheet()
    {
        if( empty($this->objSheet) )    $this->objSheet = $this->objPHPExcel->getActiveSheet();
        return $this->objSheet;
    }

    //设置列宽
    private function setWidth( $colname, $width )
    {
        $objSheet = $this->getObjActSheet();
        $objSheet->getColumnDimension($colname)->setWidth($width);
    }

    //多个列设置宽度
    public function setWidthsByTitle( $cols )
    {
        foreach( $cols as $title=>$width ){
            $colname = array_search($title,$this->sheet_titles);
            $this->setWidth($colname,$width);
        }
    }

    //重设标题
    public function setTitle( $name )
    {
        $this->objPHPExcel->getActiveSheet()->setTitle($name);
    }

    //创建行
    public function createRows( $rows )
    {
        if( !is_array($rows) )  return false;

        //收集列字母
        $cols = [];
        $col_count = count($rows[0]);
        for( $i=0; $i<$col_count; $i++ ){
            $this->sheet_titles[ $this->letters[$i] ] = $rows[0][$i];//记录标题
            $cols[] = $this->letters[$i];
        }

        $objActSheet = $this->objPHPExcel->setActiveSheetIndex(0);
        foreach( $rows as $key=>$row )
        {
            $row_num = $key+1;//第几行
            $j = 0;
            foreach($row as $value){//创建一行
                $cell = $cols[$j] . $row_num;//组成如 A1 B1 的列名
                $objActSheet->setCellValue($cell, $value);
                $j++;
            }
        }

        return $this;
    }

    public function read_ignore_title($filename)
    {
        $filename = $this->save_dir.$filename;
        if(!file_exists($filename))
        {
            exit("File $filename was not found.");
        }

        //加载excel
        $reader = \PHPExcel_IOFactory::load($filename);
        //获取要读取的sheet (0开始)
        $sheet = $reader->getSheet(0);
        //取得列的总数 (字母格式)
        $maxColumns = $sheet->getHighestColumn();
        //将字母格式的最大列数转换为数字
        $maxColumns = PHPExcel_Cell::columnIndexFromString($maxColumns);
        //获取最大行数 (数字格式)
        $maxRows    = $sheet->getHighestRow();

        //循环获取表格信息
        //循环规则 先行后列
        //从第2行开始 因为第1行为表头信息
        $data = [];
        for($iR = 2; $iR <= $maxRows; $iR++)
        {
            //内循环获取对应的单元格信息
            //使用函数 : getCellByColumnAndRow(列索引 从0开始, 行索引 从0开始)
            $row = [];
            for($iC = 0; $iC < $maxColumns; $iC++){
                $row[] = $sheet->getCellByColumnAndRow($iC, $iR)->getValue();
            }
            if(array_filter($row))
            {
                $data[] = $row;
            }
        }

        return $data;
    }

    //页面导出excel
    public function download( $filename='demo' )
    {
        // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.$filename.'.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        $this->objWriter = \PHPExcel_IOFactory::createWriter($this->objPHPExcel, $this->excel_version);
        $this->objWriter->save('php://output');
        exit;
    }

    //保存文件到本地
    public function save( $filename )
    {
        $this->objWriter = \PHPExcel_IOFactory::createWriter($this->objPHPExcel, $this->excel_version);
        if( !is_dir($this->save_dir) ){
            mkdir( $this->save_dir );
        }

        $filename = $this->save_dir . $filename . '.xlsx' ;
        $this->objWriter->save( $filename );
    }

}

/*
 * 使用例子:
    $excel = new Excel();
    $excel->createRows([
        [ '姓名', '年龄' , '身高', '学校' ],//第一行 可以算是标题行
        [ 'Lilei', 25, '1.8m', 'sangu' ],//第二行 内容
        [ 'Tom', 23, '1.9m', '2zhong' ],//第三行 内容
    ]);
    $excel->download('tmp111');
*/