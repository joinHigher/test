<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_admin extends mod_base
{

    public static function get_all_fields()
    {
        return "`admin_id`, `username`, `password`, `realname`, `email`, `pools`, `groups`, `regtime`, `regip`, `sta`, `logintime`, `loginip`";
    }


    public static function get_table_name()
    {
        return 'system_admin';
    }

    /**
     * @param array $id_arr  主键id组成的数组.
     */
    public function get_admin_option(array $id_arr = array())
    {
        if (empty($id_arr)) {
            $condition = array('1' => '1');
        } else {
            $condition['admin_id in'] = $id_arr;
        }

        $data = $this->get_list_data($condition, '`admin_id`, `username`');

        return array_column($data, 'username', 'admin_id');
    }

}


