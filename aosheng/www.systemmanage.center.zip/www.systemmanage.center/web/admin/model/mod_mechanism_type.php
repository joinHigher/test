<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构类型model
 *
 * @version $Id$
 */
class mod_mechanism_type extends mod_base
{
    public static function get_all_fields()
    {
        return "`id`, `name`, `short_name`, `num`, `remark`, `create_user`, `create_time`,`update_user`,`update_time`, `delete_user`, `delete_time`";
    }

    public static function get_table_name()
    {
        return 'system_mechanism_type';
    }

    /**
     * @param array $cond
     * @param string $fields
     * @param string $key
     * @param string $limit
     * @param string $order
     * @param string $group
     * @return array
     */
    public function get_list_data(array $cond, $fields = '', $key = '', $limit = '', $order = '', $group = '')
    {
        $cond = array_merge($cond, array('delete_user' => 0, 'delete_time' => 0));
        return parent::get_list_data($cond, $fields, $key, $limit, $order, $group);
    }

    /**
     * 获取该类型下面最大机构数量.
     */
    public function get_org_max_num($id)
    {
        $data = 0;
        if (empty($id)) {
            return $data;
        }

        $cond = array(
            'id' => $id,
            'delete_user' => 0,
            'delete_time' => 0,
        );

        $fields = '`num`';
        $res = $this->get_one_data($cond, $fields);
        if (!empty($res)) {
            $data = $res['num'];
        }

        return $data;
    }

    /**
     * 获取机构类型.
     *
     * @param array $id_arr 类型id.
     *
     * @return array
     */
    public function get_type_options(array $id_arr = array())
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }

        $fields = "`id`, `name`, `short_name`";
        $result = $this->get_list_data($cond, $fields);

        $data = array();
        foreach ($result as $key => $value) {
                $data[$value['id']] = $value['name'].' ('.$value['short_name'].')';
        }

        return $data;
    }


}
