<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 公司模块
 *
 * @version $Id$
 */
class mod_form
{
    private $config;

    static function validate($config)
    {
        $obj = new mod_form();
        $obj->config = $config;
        $obj->main();
    }

    private function main()
    {
        foreach ($this->config as $field=>$rules)
        {
            foreach ($rules as $rule=>$item)
            {
                switch ($rule){
                    case 'required':
                        $this->required($field);
                        break;
                    case 'maxlength':
                        $this->maxlength($field);
                        break;
                }
            }
        }
    }

    private function required($field)
    {
        $message = $this->config[$field][__FUNCTION__];
        empty($message) && $message = "$field is required";

        if(!isset(req::$forms[$field]) || empty(req::$forms[$field]))
        {
            $this->msg($message);
        }
    }

    private function maxlength($field)
    {
        $item = $this->config[$field][__FUNCTION__];
        $message = (isset($item['msg']) && !empty($item['msg'])) ? $item['msg'] : "$field maxlength is {$item['length']}";

        $value = req::$forms[$field];
        if(mb_strlen($value)>$item['length'])//mb_strlen与js的maxlength一至英文或中文都当一个长度。
        {
            $this->msg($message);
        }
    }

    private function msg($msg)
    {
        cls_msgbox::show('系统提示', $msg, '-1');
    }
}

/**
 * $config = //config数据格式
 * [
    'name'=>[
        'required' => "XXX为必填",
        'maxlength' => [ 'length'=>20, 'msg'=>'' ]
    ]
   ]
 * mod_form::validate($config);
 */