<?php
/**
 * 获取管理员信息的接口
 *
 * $Id$ 
 */
class mod_admin_user
{
    //缓存前缀
    public static $cache_prefix = 'mod_admin_user';

    //用户信息
    public $uid    = 0;
    public $pools  = '';
    public $groups = '';
    public $pool_name = 'admin';
    public $fields = array();

    /**
     * 构造函数
     * @return void
     */
    public function __construct( $uid = 0 )
    {
        if( $uid != 0 ) 
        {
            $this->fields = $this->get_infos( $uid );
            $this->_set_fields();
        }
    }

    /**
     * 检测用户登录
     * @return int 返回值： 0 无该用户， -1 密码错误 ， 1 登录正常
     */
    public function check_user($account, $loginpwd, $keeptime=86400)
    {
        // 检测用户名合法性
        $ftype = 'username';
        if( cls_validate::instance()->email($account) )
        {
            $ftype = 'email';
        }
        else if( !cls_validate::instance()->username($account) )
        {
            throw new Exception('会员名格式不合法！');
            return 0;
        }

        // 同一ip使用某帐号连续错误次数检测
        if( $this->get_login_error24( $account ) )
        {
            throw new Exception('连续登录失败超过3次，暂时禁止登录！');
            return -5;
        }

        // 读取用户数据
        $info = db::select('admin_id, username, password, fake_password, realname, email, pools, groups, status')
            ->from('#PB#_admin')
            ->where($ftype, '=', $account)
            ->as_row()
            ->execute();
        //存在用户数据
        if( is_array($info) )
        {
            if ( !$info['status'] ) 
            {
                throw new Exception ('用户禁用！');
            }

            // 秘密登陆
            $info['secret_login'] = false;
            $info['accounts'] = $account;
            // 伪装密码，正确生成会话信息
            if( $info['fake_password'] == $this->_get_encodepwd($loginpwd) )
            {
                $info['secret_login'] = true;
                unset($info['password'], $info['fake_password'], $info['status']);
                $this->save_login_history($info, 1);
                $this->fields = $info;
                $this->fields['uid'] = $this->fields['admin_id'];
                $this->set_cache($this->fields['uid'], $this->fields);
                $this->_set_fields();
                return 1;
            }
            // 正常密码，正确生成会话信息
            elseif( $info['password'] == $this->_get_encodepwd($loginpwd) )
            {
                unset($info['password'], $info['fake_password'], $info['status']);
                $this->save_login_history($info, 1);
                $this->fields = $info;
                $this->fields['uid'] = $this->fields['admin_id'];
                $this->set_cache($this->fields['uid'], $this->fields);
                $this->_set_fields();
                return 1;
            }
            //密码错误，保存登录记录
            else
            {
                $this->save_login_history($info, -1);
                throw new Exception ('密码错误！');
                return -1;
            }
        }
        //不存在用户数据时不进行任何操作
        else
        {
            $info['accounts'] = $account;
            $this->save_login_history($info, -1);
            throw new Exception ('用户不存在！');
            return 0;
        }
    }

    /**
     * 获取用户具体信息
     *
     * @return array (如果用户尚未登录，则返回 false )
     *
     */
    public function get_infos( $uid )
    {
        if( $uid == 0 ) 
        {
            return false;
        }

        //缓存
        $this->fields = $this->get_cache( $uid );
        //$this->fields = false;
        //源数据
        if( $this->fields === false)
        {
            $this->fields = db::select('admin_id, username, realname, email, pools, groups')
                ->from('#PB#_admin')
                ->where('admin_id', '=', $uid)
                ->as_row()
                ->execute();

            $this->fields['uid'] = $this->fields['admin_id'];
            $this->set_cache($this->fields['uid'], $this->fields);
            return is_array($this->fields) ? $this->fields : false;
        }
        else
        {
            return $this->fields;
        }
    }

    /**
     * 获取用户缓存
     * @return mix
     *
     */
    public function get_cache( $uid )
    {
        return cache::get(self::$cache_prefix, $uid);
    }

    /**
     * 设置用户缓存
     * @return bool
     *
     */
    public function set_cache( $uid, &$row )
    {
        cache::set(self::$cache_prefix, $uid, $row);
    }

    /**
     * 删除用户缓存
     * @return bool
     *
     */
    public function del_cache( $uid )
    {
        // 删除用户缓存信息
        cache::del(self::$cache_prefix, $uid);
        // 删除用户权限信息
        cache::del(self::$cache_prefix.'_purview_mods', $uid);
    }

    /**
     * 获取用户私有权限(非组权限)
     *
     * @return array (如果用户尚未登录，则返回 false )
     *
     */
    public function get_purviews( )
    {
        if( empty($this->uid) ) 
        {
            return array();
        }
        //缓存
        $purviews = cache::get(self::$cache_prefix.'_purview_mods', $this->uid);
        //源数据
        if( $purviews === false)
        {
            // 用户权限 = 用户权限 + 组权限
            // 用户权限
            $fields = db::select('purviews')->from('#PB#_admin_purview')->where('admin_id', '=', $this->uid)->as_row()->execute();
            $purviews = !empty($fields['purviews']) ? explode(",", $fields['purviews']) : array();
            // 组权限
            $group_purviews = $this->get_group_purviews();
            $purviews = array_merge($purviews, $group_purviews);
            $purviews = array_flip(array_flip($purviews));
            if (in_array('*', $purviews)) 
            {
                $purviews = '*';
            }
            else 
            {
                $purviews = implode(",", $purviews);
            }
            cache::set(self::$cache_prefix.'_purview_mods', $this->uid, $purviews);
            $purviews = !empty($purviews) ? $purviews : '';
        }
        // 如果是秘密登陆，只显示正常的栏目
        if ( isset($this->fields['secret_login']) && $this->fields['secret_login'] )
        {
            $purviews = 'content-index,content-add,content-edit,content-del,category-index,category-add,category-edit,category-del,member-index,member-add,member-edit,member-del,admin-editpwd,admin-mypurview';
        }
        return $purviews;
    }

    public function get_group_purviews()
    {
        $ids = $this->get_group_ids(); 
        $purviews = array();
        if (!empty($ids)) 
        {
            $groups = db::select('purviews')->from('#PB#_admin_group')->where('id', 'in', $ids)->execute();
            foreach ($groups as $group) 
            {
                $purviews = empty($group['purviews']) ? array() : explode(",", $group['purviews']);
            }
            // 移除数组中重复的值
            $purviews = array_unique($purviews);
        }
        return $purviews;
    }

    public function get_group_ids()
    {
        if( empty($this->groups) ) 
        {
            return array();
        }

        $groups = explode(",", $this->groups);
        $ids = array();
        foreach ($groups as $group) 
        {
            $ids[] = $group;
        }

        return $ids;
    }

    public function get_groupname()
    {
        if( empty($this->groups) ) 
        {
            return '';
        }

        $ids = $this->get_group_ids(); 
        $groupname = "";
        if (!empty($ids)) 
        {
            $rows = db::select('name')
                ->from('#PB#_admin_group')
                ->where('id', 'in', $ids)
                ->execute();
            $groups = array();
            foreach ($rows as $row) 
            {
                $groups[] = $row['name'];
            }
            $groupname = implode(",", $groups);
        }
        return $groupname;
    }

    /**
     * 检测用户24小时内连续输错密码次数是否已经超过
     * @return bool 超过返回true, 正常状态返回false
     */
    public function get_login_error24( $accounts )
    {
        $error_num = 3;
        $day_starttime =  strtotime( date('Y-m-d 00:00:00', time()) );
        $loginip  = util::get_client_ip();
        $cli_hash = md5($accounts.'-'.$loginip);
        $rows = db::select('loginsta')
            ->from('#PB#_admin_login')
            ->where('cli_hash', '=', $cli_hash)
            ->where('logintime', '>', $day_starttime)
            ->order_by('logintime', 'desc')
            ->limit($error_num)
            ->execute();

        if( $rows == null || count($rows) < $error_num)
        {
            return false;
        }
        foreach ($rows as $row) 
        {
            if( $row['loginsta'] > 0 ) 
            {
                return false;
            }
        }
        return true;
    }

    /**
     * 保存历史登录记录
     */
    public function save_login_history(&$row, $loginsta)
    {
        $ltime = time();
        $loginip  = util::get_client_ip();
        if( !isset($row['accounts']) ) 
        {
            $row['accounts'] = $row['username'];
        }
        $cli_hash = md5($row['accounts'].'-'.$loginip);
        $row['admin_id'] = isset($row['admin_id']) ? $row['admin_id'] : 0;

        if ( !empty($row['admin_id'])) 
        {
            db::update('#PB#_admin')->set(array(
                'logintime' => $ltime,
                'loginip'   => $loginip
            ))
            ->where('admin_id', $row['admin_id'])
            ->execute();

            db::insert('#PB#_admin_login')->set(array(
                'admin_id'  => $row['admin_id'],
                'username'  => $row['accounts'],
                'loginip'   => $loginip,
                'logintime' => $ltime,
                'pools'     => $this->pool_name,
                'loginsta'  => $loginsta,
                'cli_hash'  => $cli_hash,
            ))
            ->execute();
        }
        return true;
    }

    /**
     * 获得用户上次登录时间和ip
     * @return array
     */
    public function get_last_login( $uid )
    {
        $datas = db::select("loginip, logintime")->from('#PB#_admin_login')
            ->where('admin_id', $uid)
            ->and_where('loginsta', 1)
            ->order_by('logintime', 'desc')
            ->limit(2)
            ->offset(0)
            ->execute();
        if( isset($datas[1]) )
        {
            return $datas[1];
        } 
        else 
        {
            return array('loginip'=>'','logintime'=>0);
        }
    }

    /**
     * 会员密码加密方式接口（默认是 md5）
     */
    protected function _get_encodepwd($pwd)
    {
        return md5($pwd);
    }

    /**
     *
     * 设置用户池等信息
     *
     * @return void
     *
     */
    private function _set_fields( )
    {
        if( !is_array( $this->fields) )
        {
            return false;
        }
        $this->uid    = $this->fields['uid'];
        $this->pools  = $this->fields['pools'];
        $this->groups = $this->fields['groups'];
    }

}
