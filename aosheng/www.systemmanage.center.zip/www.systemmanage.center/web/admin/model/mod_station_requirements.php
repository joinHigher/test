<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_station_requirements extends mod_base
{

    public static function get_all_fields()
    {
        return "`id`, `station_id`, `mini_level`, `mini_level_id`, `part_time`, `education`, `certificate`, `year`, `secret_degree`, `nation`, `description`, `create_user`, `create_time`, `update_user`,`update_time`";
    }


    public static function get_table_name()
    {
        return 'system_station_requirements';
    }

}


