<?php
if( !defined('PHPCALL') ) exit('Request Error!');

abstract class mod_base extends db
{
    protected static $instance;

    /**
     * Get All Fields.
     *
     * @return string
     */
    abstract static protected function get_all_fields();

    /**
     * Get Table Name.
     *
     * @return string
     */
    abstract static protected function get_table_name();

    /**
     * get a instance
     *
     * @return static
     */
    public static function instance() {
        $class = get_called_class();
        if (!isset(self::$instance[$class])) {
            self::$instance[$class] = new static();
        }
        return self::$instance[$class];
    }

    /**
     * Get Fields.
     *
     * @param string $fields Fields.
     *
     * @return string
     */
    protected function get_select_fields($fields)
    {
        $fields = trim($fields);
        if (empty($fields) || $fields == '*') {
            return $this->get_all_fields();
        } else {
            return $fields;
        }
    }

    /**
     * 判断连接符号并返回值..
     *
     * @param $key
     * @param $value
     *
     * @return array
     */
    private function judge_connect_data($key, $value)
    {
        $data = array();
        $connect = '';
        $maybe_connectors = array('>=', '<=', '<>', '!=', '>', '<', '=', ' NOT BETWEEN', ' BETWEEN', ' NOT LIKE', ' LIKE', ' IS NOT', ' NOT IN', ' IS', ' IN', 'FIND_IN_SET');
        $key = trim($key);
        $key_upper = strtoupper($key);
        foreach ($maybe_connectors as $maybe_connector) {
            $len = strlen($maybe_connector);
            if (substr($key_upper, -$len) == $maybe_connector) {
                $connect = trim($maybe_connector);
                $key = trim(substr($key, 0, -$len));
                break;
            }
        }

        if (empty($connect) && !is_array($value)) {
            $connect = '=';
        }

        if (!empty($connect)) {
            $data = array(
                $key,
                $connect,
                $value,
            );
        }

        return $data;
    }

    /**
     * 构造查询条件.
     *
     * @param array  $condition
     * @param object $reader.
     *
     * @return object
     */
    private function build_condition(array $condition, $reader)
    {
        $data = array(
            'and' => array(),
            'or' => array(),
        );

        if (is_array($condition)) {
            foreach ($condition as $k => $v) {
                if (!is_int($k)) {
                    $k = trim($k);
                    $k_upper = strtoupper($k);
                    if ($k_upper == 'OR') {
                        $tmp = [];
                        foreach ($v as $kk => $vv) {
                            if (is_array($vv) && is_int($kk)) {
                                $result = [];
                                foreach ($vv as $kkk => $vvv) {
                                    $res = $this->judge_connect_data($kkk, $vvv);
                                    if (!empty($res)) {
                                        $result[] = $res;
                                    }
                                }

                                if (!empty($result)) {
                                    $tmp[] = $result;
                                }
                            } else {
                                $res = $this->judge_connect_data($kk, $vv);
                                if (!empty($res)) {
                                    $tmp[] = $res;
                                }
                            }
                        }
                    } else {
                        $tmp = $this->judge_connect_data($k, $v);
                    }

                    if (!empty($tmp) && $k_upper == 'OR') {
                        $data['or'][] = $tmp;
                    } else if (!empty($tmp)) {
                        $data['and'][] = $tmp;
                    }
                }
            }
        }

        foreach ($data as $key => $value) {
            if (!empty($value)) {
                if ($key == 'or') {
                    $reader = $reader->or_where_open();
                    foreach ($value as $k => $v) {
                        if ($k % 2 ==0) {
                            $reader = $reader->where(array($v));
                        } else {
                            $reader = $reader->or_where(array($v));
                        }
                    }
                    $reader = $reader->or_where_close();
                } elseif ($key == 'and') {
                    $reader = $reader->where_open();
                    foreach ($value as $k => $v) {
                        if ($k % 2 ==0) {
                            $reader = $reader->where(array($v));
                        } else {
                            $reader = $reader->and_where(array($v));
                        }

                    }
                    $reader = $reader->where_close();
                }
            }
        }

        return $reader;
    }

    /**
     * Insert.
     *
     * @param array $data 新增数据.
     *
     * @return integer
     */
    public function insert_data(array $data)
    {
        db::insert($this->get_table_name())->set($data)->execute();
        $insert_id = db::insert_id();

        return $insert_id;
    }

    /**
     * 批量插入数据.
     *
     * @param array $fields_arr
     * @param array $data
     *
     * return integer.
     */
    public function bath_insert(array $fields_arr, array $data)
    {
        return db::insert($this->get_table_name())->columns($fields_arr)->values($data)->execute();
    }

    /**
     * 删除数据.
     *
     * @param array $cond 条件.
     *
     * @return integer
     */
    public function delete_data(array $cond)
    {
        $db =  db::delete($this->get_table_name());
        $db = $this->build_condition($cond, $db);

        return $db->execute();
    }

    /**
     * 执行sql语句.
     *
     * @param string  $sql     sql语句.
     * @param boolean $master  是否为主服务器查询.
     *
     * @return  mixed.
     */
    public function execute_sql($sql, $master = false)
    {
        return db::query($sql)->execute($master);
    }

    /**
     * 更新数据.
     *
     * @param array $data  更新数据.
     * @param array $cond  更新条件.
     *
     * @return integer
     */
    public function update_data(array $data, array $cond)
    {
        $db = db::update($this->get_table_name())->set($data);
        $db = $this->build_condition($cond, $db);

        return $db->execute();
    }

    /**
     * 根据条件获取一条记录.
     *
     * @param array   $cond          查询条件.
     * @param string  $fields        查询字段.
     * @param boolean $default_fill  是否默认填充.
     * @param string  $default_value 默认填充值.
     */
    public function get_one_data(array $cond,  $fields = '', $default_fill = false, $default_value = '')
    {
        $reader = db::select($this->get_select_fields($fields))->from($this->get_table_name())->as_row();
        $reader = $this->build_condition($cond, $reader);

        $data = $reader->execute();

        if (empty($data) && !is_array($data)) {
            $data = array();
        }

        if (empty($data) && $default_fill) {
            $fields = $this->get_select_fields($fields);
            $fields = str_replace("`",  '', $fields);
            $fields = str_replace(" ",  '', $fields);
            $fields_arr = explode(',',$fields);
            $data = array_fill_keys($fields_arr, $default_value);
        }

        return $data;
    }

    /**
     * 获取列表, 二维数组..
     *
     * @param array  $cond   Condition.
     * @param string $fields Fields.
     * @param string $key    Key.
     * @param string $limit  Limit.
     * @param string $order  Order.
     * @param string $group  Group.
     *
     * @return array
     */
    public function get_list_data(array $cond,  $fields = '', $key = '', $limit = '', $order = '' , $group = '')
    {
        $reader = db::select($this->get_select_fields($fields))->from($this->get_table_name());
        $reader = $this->build_condition($cond, $reader);
        if (!empty($group)) {
            $group_arr = explode(',', $group);
            $reader->group_by($group_arr);
        }

        if (!empty($order)) {
            $order_arr = explode(',', $order);
            foreach ($order_arr as $value) {
                $tmp_order = trim($value);
                $tmp_order = explode(' ', $tmp_order);
                if (count($tmp_order) > 1) {
                    $reader->order_by($tmp_order[0], $tmp_order[1]);
                }
            }
        }

        if (!empty($limit)) {
            if (is_string($limit)) {
                $limit = explode(',', $limit);
                if (count($limit) > 1) {
                    $reader->offset($limit[0]);
                    $reader->limit($limit[1]);
                } else {
                    $reader->limit($limit[0]);
                }
            } else {
                $reader->limit($limit);
            }
        }

        $data = $reader->execute();
        if (!empty($key) && !empty($data)) {
            $data = array_column($data, null, $key);
        }

        if (empty($data) && !is_array($data)) {
            $data = array();
        }

        return $data;
    }

    /**
     * Get By Cond Column.
     *
     * @param array  $cond  Condition.
     * @param string $field Field(只能一个字段，比如tag_name).
     *
     * @return array
     */
    public function get_column_data(array $cond, $field)
    {
        $data = $this->get_list_data($cond, $field);
        return array_column($data, $field);
    }

    /**
     * Count.
     *
     * @param array $cond Condition.
     *
     * @return integer
     */
    public function count(array $cond)
    {
        $count = 0;
        $reader = db::select('count(*) AS `count`')->from($this->get_table_name())->as_row();
        $data = $this->build_condition($cond, $reader)->execute();

        if (!empty($data)) {
            $count = $data['count'];
        }
        
        return $count;
    }

}

