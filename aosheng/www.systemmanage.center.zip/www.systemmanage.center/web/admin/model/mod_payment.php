<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 薪酬模块
 *
 * Created by PhpStorm.
 * User: leita
 * Date: 2018/3/17
 * Time: 上午11:26
 * Function: {
 *    exit_ 带有此前缀的执行完本方法都不再往下执行
 *    exit_page_ 展示html页面并exit不再往下执行
 *    display_ 与页面数据展示相关
 *    count_ 与页面需计算的数据相关
 *    outside_ 来自其它模块的数据或外界的数据
 *    array_ 与数组相关的数据
 * }
 */
class mod_payment
{
    const tab_payment_level = '#PB#_payment_level';

    public static function all_organs($parent_id=0)
    {
        $rows = db::select('id,short_name as name,superior')->from(mod_table::organization)->where('superior','=',$parent_id)->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                $row['child_num'] = 0;
                $row['child'] = self::all_organs($row['id']);
                $row['child_num'] = count($row['child']);
            }

            return $rows;
        }else{
            return [];
        }
    }

    public static function count_range($business_ids)
    {
        if(empty($business_ids))
        {
            return null;
        }
        is_string($business_ids) && $business_ids = explode(',',$business_ids);
        $fields = 'min(`min`) as t_min, max(`max`) as t_max';
        $row = db::select($fields)->from(mod_table::payment_level)->where('yuewu_id','in',$business_ids)->as_row()->execute();

        return [ $row['t_min'], $row['t_max'] ];
    }


    static function get_creator($user_id=0)
    {
        //创建人
        empty($user_id) && $user_id = cls_auth::$user->fields['uid'];
        $row_creator = db::select('username')->from('#PB#_admin')->where('admin_id','=',$user_id)->as_row()->execute();
        $creator = ( $row_creator ? $row_creator['username'] : "");

        return $creator;
    }

    static function post_levels()
    {
        static $post_levels;
        if(empty($post_levels))
        {
            $where = [
                ['status','=',0],
                ['delete_user','=',0]
            ];
            $post_levels = db::select('level,level_name')->from('system_post_level')->where($where)->order_by('level','desc')->execute();
        }

        return $post_levels;
    }

    //岗位资历
    static function payment_levels($business_ids)
    {
        if(empty($business_ids))
        {
            return [];
        }

        is_string($business_ids) && $business_ids = explode(',',$business_ids);
        $tags = db::select('id,tag_name')->from(mod_table::yuewu)->where('id','in',$business_ids)->execute();
        $post_levels = self::post_levels();
        if(empty($tags))
        {
            return [];
        }

        foreach ($tags as &$tag)
        {
            $tag_levels = $post_levels;
            foreach ($tag_levels as &$post_level)
            {
                $lev_where = [
                    ['level','=',$post_level['level']],
                    ['yuewu_id','=',$tag['id']]
                ];
                $payment = db::select('*')->from(mod_table::payment_level)->where($lev_where)->as_row()->execute();
                $post_level['payment'] = $payment;

                if($post_level['level']==1){

                }

            }
            $tag['post_level'] = $tag_levels;
        }

        return $tags;
    }

    static function validate()
    {
        pub_form_validation::set_rules([]);
    }
}
