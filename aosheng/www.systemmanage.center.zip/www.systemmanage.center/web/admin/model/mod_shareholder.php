<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_shareholder extends mod_base
{

    public static function get_all_fields()
    {
        return "`id`, `type`, `organization_id`, `identity`, `name`, `contact`, `shares`, `contribution`, `amount`, `certificate_type`, `certificate_number`, `certificate_picture`, `create_user`, `create_time`,`update_user`,`update_time`, `delete_user`, `delete_time`";
    }


    public static function get_table_name()
    {
        return 'system_shareholder';
    }

}


