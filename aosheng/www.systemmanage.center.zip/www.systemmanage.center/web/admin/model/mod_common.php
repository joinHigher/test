<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 通用
 * Function: {
 *    exit_ 带有此前缀的执行完本方法都不再往下执行
 *    exit_page_ 展示html页面并exit不再往下执行
 *    display_ 与页面数据展示相关
 *    count_ 与页面需计算的数据相关
 *    outside_ 来自其它模块的数据或外界的数据
 *    array_ 与数组相关的数据
 * }
 */
class mod_common
{
    private static $json_error = ['code'=>-1,'msg'=>''];
    //404页面
    static function exit_page_404()
    {
        cls_msgbox::show('系统提示', '找不到相关数据，请核对再执行', '-1');
    }

    static function exit_json(array $array)
    {
        print json_encode($array);

        if($errorCode = json_last_error())
        {
            switch ($errorCode)
            {
                case JSON_ERROR_NONE:
                    $error = '';
                    break;
                case JSON_ERROR_DEPTH:
                    $error = '到达了最大堆栈深度';
                    break;
                case JSON_ERROR_STATE_MISMATCH:
                    $error = '无效或异常的 JSON';
                    break;
                case JSON_ERROR_CTRL_CHAR:
                    $error = '控制字符错误，可能是编码不对';
                    break;
                case JSON_ERROR_SYNTAX:
                    $error = '语法错误';
                    break;
                case JSON_ERROR_UTF8:
                    $error = '异常的 UTF-8 字符，也许是因为不正确的编码。';
                    break;
                case JSON_ERROR_RECURSION;
                    $error = '被encode的数组存在互相引用的值';
                    break;
                case JSON_ERROR_INF_OR_NAN:
                    $error = '被encode的数组存在NAN或INF的值';
                    break;
                case JSON_ERROR_UNSUPPORTED_TYPE:
                    $error = '所传参数变量类型无法进行encode';
                    break;
            }

            self::$json_error['msg'] = $error;
            exit( json_encode(self::$json_error) );
        }
        exit();
    }

    static function log_line($class_name, $function_name, $content)
    {
        log::write(1,">>>>>>>> ".date('Y-m-d H:i:s')."");
        log::write(1,"-------------------------------------------------------------------------");
        log::write(1,"{$class_name}->{$function_name}:" . $content);
        log::save();
    }

    static function field_creator($user_id)
    {
        $creator = db::select('username')->from('#PB#_admin')->where('admin_id','=',$user_id)->as_field()->execute();
        return $creator;
    }

    //添加并跳转
    static function jump_create($action='make_list')
    {
        $url_tail = req::item('url_tail');
        $gourl = req::item('gourl', '?ct='.__CONTROL__.'&ac='.$action . $url_tail);
        cls_msgbox::show('系统提示', "创建成功", $gourl);
    }

    //修改并跳转
    static function jump_update($action='make_list')
    {
        $url_tail = req::item('url_tail');

        $gourl = req::item('gourl', '?ct='.__CONTROL__.'&ac='.$action . $url_tail);
        cls_msgbox::show('系统提示', "修改成功", $gourl);
    }

    //删除并跳转
    static function jump_delete($action='make_list')
    {
        $url_tail = req::item('url_tail');
        $gourl = req::item('gourl', '?ct='.__CONTROL__.'&ac='.$action . $url_tail);
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

}
