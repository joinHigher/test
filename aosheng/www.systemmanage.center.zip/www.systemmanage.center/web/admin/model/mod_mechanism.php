<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_mechanism
{
    //机构等级表
    protected  static $table = "#PB#_mechanism";
    //条件
    protected  static $where = " where `delete_user` = '0' and `delete_time` = '0' ";

    /**
     * 已存在的等级
     */
    public static function  get_level_exist()
    {
        $sql = "select id,level_name,level from ".self ::$table .self::$where." group by level";
        $arr = db::get_all($sql);
        $arr = array_column($arr, 'level', 'level');
        return $arr;
    }


    /**
     * @ 获取指定条件的数据
     */
    public static function get_list($filed='id, level_name', $condition='')
    {
        $where = self::$where;
        if(!empty($condition))
        {
            $where .= ' and '.$condition;
        }
        $sql = "select ".$filed." from ".self ::$table .$where;
        $arr = db::get_all($sql);
        return $arr;
    }

    /**
     * 获取指定格式化数据
     * $table 表名称
     * $filed array 字段名
     **/
    public static function get_data($field1='id',$filed2='level_name')
    {
        $arr = self::get_list("{$field1},{$filed2}");
        $arr = array_column($arr, $filed2, $field1);
        return $arr;
    }

    /**
     * @desc 获取等级配置
     * @param string $param_name 后台配置参数名称
     * @param int $num 开始数值
     * */
    public static function get_level($param_name,$num=1)
    {
        $level    = config::get($param_name);
        $level  = isset($level) ? $level : 15;
        $arr['']    = "请选择";
        for ($x=$num; $x<=$level; $x++)
        {
            $arr[$x] = $x;
        }
        return  $arr;
    }
}

