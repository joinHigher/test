<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 部门相关
 *
 * Created by PhpStorm.
 * User: leita
 * Date: 2018/3/17
 * Time: 上午11:26
 * Function: {
 *    exit_ 带有此前缀的执行完本方法都不再往下执行
 *    exit_page_ 展示html页面并exit不再往下执行
 *    display_ 与页面数据展示相关
 *    count_ 与页面需计算的数据相关
 *    outside_ 来自其它模块的数据或外界的数据
 *    array_ 与数组相关的数据
 * }
 */
class mod_department extends mod_base
{
    // 部门领导类型.
    const DEPARTMENT_TYPE = 1;
    // 岗位领导类型.
    const STATION_TYPE = 1;
    // 正常状态.
    const STATUS_NORMAL = 1;

    //科室验证规则
    static $rule_room = [
        'name' => [ 'required'=> '', 'maxlength'=>[ 'length'=>20 ] ],
        'organ_id' => [ 'required'=> '' ],
        'department_id' => [ 'required'=> '' ],
        'job_ids' => [ 'required'=> '' ],
        'leader_job_id' => [ 'required'=> '' ],
    ];
    static $rule_committee = [
        'name' => [ 'required'=> '', 'maxlength'=>[ 'length'=>20 ] ],
        'organ_id' => [ 'required'=> '' ],
        'department_id' => [ 'required'=> '' ],
        'job_ids' => [ 'required'=> '' ],
    ];


    public static function get_all_fields()
    {
        return "`id`, `organization_id`, `level`, `level_id`, `business_tag`, `business_leader`, `business_link`,`belong_id`,`belong_type`,`superior_department_type`, `superior_id`, `name`, `external_name`, `type`, `number`, `short_name`, `code`, `highest_station`, `secret_degree`, `status`, `create_user`, `create_time`,`update_user`,`update_time`, `delete_user`, `delete_time`";
    }


    public static function get_table_name()
    {
        return 'system_department';
    }

    public static function room_code($id)
    {
        $no = str_pad("",5-strlen("$id"),'0') . $id;
        return "K{$no}";
    }

    public static function committee_code($id)
    {
        $no = str_pad("",5-strlen("$id"),'0') . $id;
        return "CW{$no}";
    }

    public static function route_path()
    {
        $organization_id = req::get('organization_id',0,'int');
        $department_id = req::get('department_id',0,'int');

        $is_outer = ($organization_id==0 && $department_id==0) ? 1 : 0;
        tpl::assign('is_outer',$is_outer);
        tpl::assign('organization_id',$organization_id);
        tpl::assign('department_id',$department_id);
        tpl::assign('url_tail',"&organization_id=$organization_id&department_id=$department_id");

        if($organization_id && $department_id)
        {
            $one = db::get_one("select id,name from ".mod_table::organization." where id=$organization_id");
            $organization = $one['name'];
            $one1 = db::get_one("select id,name from ".mod_table::department." where id=$department_id");
            $department = $one1['name'];

            return "$organization $department";
        }

        return '';
    }

    static function get_job_room_committee($station_id)
    {
        $rooms = db::select('room_id as id')->distinct(true)->from(mod_table::department_room_people)->where('job_id','=',$station_id)->execute();
        if($rooms)
        {
            foreach ($rooms as &$room){
                $room['room'] = db::select('name')->from(mod_table::department_room)->as_field()->execute();
            }
            $rooms = mod_array::one_array($rooms,['id','room']);
        }else{
            $rooms = [];
        }

        $committees = db::select('room_id as id')->distinct(true)->from(mod_table::department_committee_people)->where('job_id','=',$station_id)->execute();
        if($committees)
        {
            foreach ($committees as &$committee){
                $committee['committee'] = db::select('name')->from(mod_table::department_committee)->as_field()->execute();
            }
            $committees = mod_array::one_array($committees,['id','committee']);
        }else{
            $committees = [];
        }

        $data = [
            'rooms' => $rooms,
            'committees' => $committees
        ];

        return $data;
    }

    static function get_job_room_committees(array $station_ids)
    {
        $data = [];
        foreach ($station_ids as $station_id)
        {
            $data[$station_id] = self::get_job_room_committee($station_id);
        }

        return $data;
    }

    /**
     * 获取正常数据列表, 二维数组..
     *
     * @param array  $cond   Condition.
     * @param string $fields Fields.
     * @param string $key    Key.
     * @param string $limit  Limit.
     * @param string $order  Order.
     * @param string $group  Group.
     *
     * @return array
     */
    public function get_list_normal(array $cond = array(),  $fields = '', $key = '', $limit = '', $order = '' , $group = '')
    {
        $condition = array('delete_user' => 0, 'delete_time' => 0);
        $cond = array_merge($cond, $condition);

        if (empty($fields)) {
            $fields = "`id`, `name`";
        }

        $data = $this->get_list_data($cond, $fields, $key, $limit, $order, $group);

        return $data;
    }

    /**
     * 获取机构下面部门
     *
     * @param array $org_arr
     *
     * @return array
     */
    public function get_list_normal_in_org(array $org_arr)
    {
        $condition = array('organization_id in' => $org_arr);
        $fields = 'id, short_name';

        return $this->get_list_normal($condition, $fields);
    }

    /**
     * 获取部门下面部门
     *
     * @param array $dep_arr
     *
     * @return array
     */
    public function get_list_normal_in_sub(array $dep_arr)
    {
        $condition = array('superior_id in' => $dep_arr, 'superior_department_type' => 1);
        $fields = 'id, short_name';

        return $this->get_list_normal($condition, $fields);
    }

    /**
     * 获取tag.
     *
     * @param array $id_arr  id组成的数组.
     *
     * @return array
     */
    public function get_department_options(array $id_arr = array())
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }

        $data = $this->get_list_data($cond, "`id`, `name`");

        return array_column($data, 'name', 'id');
    }

    /**
     * @param $id
     */
    public function get_department_name($id)
    {
        $data = '';
        if (empty($id)) {
            return $data;
        }

        $result = $this->get_one_data(array('id' => $id), '`id`, `name`');

        !empty($result) ? ($data = $result['name']) : null;

        return $data;
    }

    /**
     * @param $org_id
     */
    public function checkout_is_sub($department_id)
    {
        $condition = array(
            'superior_id' => $department_id,
            // 由部门领导.
            'superior_department_type' => self::DEPARTMENT_TYPE,
            'delete_user' => 0,
            'delete_time' => 0,
        );

        return $this->count($condition);
    }

    /**
     * 获取机构下面的部门.
     *
     * @param array $org_arr
     */
    public function get_department_in_org(array $org_arr)
    {
        if (empty($org_arr)) {
            return [];
        }

        $condition = array(
            'organization_id in' => $org_arr,
            'delete_user' => 0,
            'status' => self::STATUS_NORMAL
        );

        $data = $this->get_list_data($condition, '`id`, `name`');

        return array_column($data, 'name', 'id');
    }

    /**
     * @param $dep_id
     */
    public function checkout_is_sub_belong_id($dep_id)
    {
        $condition = array(
            'belong_id' => $dep_id,
            'belong_type' => self::DEPARTMENT_TYPE,
        );

        return $this->count($condition);
    }

    /**
     * @param $dep_id
     */
    public function checkout_is_sub_superior_id($dep_id)
    {
        $condition = array(
            'superior_id' => $dep_id,
            'superior_department_type' => self::DEPARTMENT_TYPE,
        );

        return $this->count($condition);
    }

    /**
     * 通过行政归属获取下级部门。
     *
     * @param integer $belong_id 机构id.
     *
     * @return array
     */
    public function get_child_by_belong_id($belong_id)
    {
        $condition = array();
        $condition['belong_id'] = $belong_id;
        // 部门领导.
        $condition['belong_type'] = self::DEPARTMENT_TYPE;
        $departments = $this->get_list_data($condition, '`id`, `name`');
        $sub_department = array();

        foreach ($departments as $key => $value) {
            $tmp = array();
            $tmp['id'] = $value['id'];
            $tmp['name'] = $value['name'];
            $tmp['hasChild'] = $this->checkout_is_sub_belong_id($value['id']);
            $sub_department[] = $tmp;
        }

        return $sub_department;
    }

    /**
     * 通过领导归属关系获取下级部门。
     *
     * @param integer $belong_id 机构id.
     *
     * @return array
     */
    public function get_child_by_superior_id($superior_id)
    {
        $condition = array();
        $condition['superior_id'] = $superior_id;
        // 部门领导.
        $condition['superior_department_type'] = self::DEPARTMENT_TYPE;
        $departments = $this->get_list_data($condition, '`id`, `name`');
        $sub_department = array();

        foreach ($departments as $key => $value) {
            $tmp = array();
            $tmp['id'] = $value['id'];
            $tmp['name'] = $value['name'];
            $tmp['hasChild'] = $this->checkout_is_sub_superior_id($value['id']);
            $sub_department[] = $tmp;
        }

        return $sub_department;
    }

}
