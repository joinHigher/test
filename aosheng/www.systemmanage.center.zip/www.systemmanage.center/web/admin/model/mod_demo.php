<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 公司模块
 *
 * @version $Id$
 */
class mod_demo
{
    public static function test()
    {
        echo "admin test\n";
    }
}
