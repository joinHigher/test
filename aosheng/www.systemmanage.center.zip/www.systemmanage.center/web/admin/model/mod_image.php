<?php
if (!defined('PHPCALL')) exit('Request Error!');

class mod_image
{

    public static $image_path = PATH_UPLOADS.DIRECTORY_SEPARATOR.'image'.DIRECTORY_SEPARATOR;
    public static $tmp_path = PATH_UPLOADS.DIRECTORY_SEPARATOR.'tmp'.DIRECTORY_SEPARATOR;

    /**
     * 处理图片.
     *
     * @param array  $image_data 需要处理的图片.
     * @param string $img_path   保存后的图片。
     */
    public static function file_move(array $image_data, $img_path = '')
    {
        $data = array(
            'status' => 0,
            'message' => '',
            'data' => array()
        );

        try {

            if (empty($image_data)) {
                return json_encode($data);
            }

            if (empty($img_path)) {
                $path = self::$image_path;
                $related_path  = '';
            } else {
                $path = self::$image_path.trim($img_path, DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR;
                $related_path = trim($img_path, DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR;
                $result = self::create_dir($path);
                // 检查目录.
                if (!$result) {
                    $data['status'] = 1;
                    $data['message'] = '创建目录失败!';
                    return json_encode($data);
                }
            }

            $encode_key = util::random('unique');
            foreach($image_data as $k=>$v) {
                // 获取临时图片内容
                $content= file_get_contents(self::$tmp_path.$v);
                $crypt_content = cls_crypt::encode($content, $encode_key);
                // 生成加密图片
                file_put_contents($path.$v, $crypt_content);
                //删除临时调用图片
                unlink(self::$tmp_path.$v);
                $data['data'][] = array('file_name'=> $related_path.$v,'key'=>$encode_key, 'old_name'=>$v);
            }

            return $data;
        } catch (\Exception $exception) {
            $data['status'] = 2;
            $data['message'] = $exception->getMessage();

            return $data;
        } catch(\Error $error){
            $data['status'] = 3;
            $data['message'] = $error->getMessage();
            return $data;
        }
    }

    /**
     * 递归创建目录.
     *
     * @param string $dir 目录.
     *
     * @return bool
     */
    public static function create_dir($dir)
    {
        return is_dir($dir) or (self::create_dir(dirname($dir)) and mkdir($dir, 0777));
    }

}
