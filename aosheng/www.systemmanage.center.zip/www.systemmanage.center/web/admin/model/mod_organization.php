<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_organization extends mod_base
{
    // 机构状态.
    public static $status_options = array(
        '1' => '正常',
        '2' => '注销',
        '3' => '暂停',
    );

    const DELETE_TEXT = '删除';
    const NORMAL_STATUS = 1;

    public static  function get_all_fields()
    {
        return "`id`, `name`, `short_name`, `internal_name`, `external_name`, `english_short_name`, `level`, `level_id`, `superior`, `secret_degree`, `number`, `number_id`, `type`, `status`, `create_user`, `create_time`,`update_user`,`update_time`,`delete_user`, `delete_time`";
    }


    public static function get_table_name()
    {
        return 'system_organization';
    }

    /**
     * @param $id
     */
    public function get_organization_name($id)
    {
        $data = '';
        if (empty($id)) {
            return $data;
        }

        $result = $this->get_one_data(array('id' => $id), '`id`, `name`');

        !empty($result) ? ($data = $result['name']) : null;

        return $data;
    }

    /**
     * 获取正常数据列表, 二维数组..
     *
     * @param array  $cond   Condition.
     * @param string $fields Fields.
     * @param string $key    Key.
     * @param string $limit  Limit.
     * @param string $order  Order.
     * @param string $group  Group.
     *
     * @return array
     */
    public function get_list_normal(array $cond = array(), $fields = '', $key = '', $limit = '', $order = '' , $group = '')
    {
        $condition = array('delete_user' => 0, 'delete_time' => 0, 'status' => 1);
        $cond = array_merge($cond, $condition);

        if (empty($fields)) {
            $fields = "`id`, `name`";
        }

        $data = $this->get_list_data($cond, $fields, $key, $limit, $order, $group);

        return $data;
    }

    /**
     * 获取顶级权力机构.
     */
    public function get_top_organization()
    {
        $condition = array(
            'superior' => 0,
        );
        $fields = '`id`, `short_name`';

        return mod_organization::instance()->get_one_data($condition, $fields);
    }

    /**
     * @param array  $data
     * @param string $pre_text   前缀.
     * @param boolean $is_normal 是否返回正常状态.
     *
     * @return string
     */
    public function checkout_org_status(array $data, $pre_text = '', $is_normal = false)
    {
        $result = '未知状态';
        $standard_fields = array('status', 'delete_user');
        $fields = array_keys($data);
        $diff_arr = array_diff($standard_fields, $fields);
        if (!empty($diff_arr)) {
            return $result;
        }
        if (!empty($data['delete_user'])) {
            $result = self::DELETE_TEXT;
        } elseif (isset(self::$status_options[$data['status']])) {
            $result = self::$status_options[$data['status']];
        }

        if (!$is_normal && $data['status'] == self::NORMAL_STATUS) {
            $result = '';
        } else {
            $result  = $pre_text . $result;
        }

        return $result;
    }

    /**
     * @param $org_id
     */
    public function checkout_is_sub($org_id)
    {
        $condition = array(
            'superior' => $org_id,
            'delete_user' => 0,
            'delete_time' => 0,
            'status' => 1
        );

        return $this->count($condition);
    }

    /**
     * @param $org_id
     */
    public function checkout_is_all_sub($org_id)
    {
        $condition = array(
            'superior' => $org_id,
        );

        return $this->count($condition);
    }

    /**
     * 获取下级机构。
     *
     * @param integer $org_id 机构id.
     *
     * @return array
     */
    public function get_child_by_org_id($org_id)
    {
        $condition = array();
        $condition['superior'] = $org_id;
        $organizations = $this->get_list_data($condition, '`id`, `name`, `status`, `delete_user`');
        $sub_organization = array();

        foreach ($organizations as $key => $value) {
            $tmp = array();
            $tmp_status = mod_organization::instance()->checkout_org_status($value, '已');
            $tmp['id'] = $value['id'];
            if (!empty($tmp_status)) {
                $tmp['name'] = '【'.$tmp_status.'】'.$value['name'];
            } else {
                $tmp['name'] = $value['name'];
            }
            $tmp['hasChild'] = $this->checkout_is_all_sub($value['id']);
            $sub_organization[] = $tmp;
        }

        return $sub_organization;
    }

    /**
     * 获取机构及等级.
     */
    public function get_level_and_organization($condition = array())
    {
        if (empty($condition)) {
            $condition = array(
                'status' => 1,
            );
        }

        $data = array();
        $result = $this->get_list_data($condition, '`id`, `name`, `level_id`');
        $level_id_arr = array_column($result, 'level_id');

        $level_data = mod_organize_level::instance()->get_level_options($level_id_arr);

        if (!empty($result)) {
            foreach ($result as $key => $value) {
                $tmp_name = $value['name'];
                if (isset($level_data[$value['level_id']])) {
                    $tmp_name = $level_data[$value['level_id']].'  '.$tmp_name;
                }
                $data[$value['id']] = $tmp_name;
            }
        }

        return $data;
    }

    /**
     * @param array $id_arr
     */
    public function get_sub_org_list(array $id_arr)
    {
        $condition = array(
            'superior in' => $id_arr,
        );

        $fields = '`id`, `short_name`';

        return $this->get_list_normal($condition, $fields);
    }

    /**
     * 获取机构列表.
     *
     * @param
     */
    public function get_organization_options(array $id_arr = array())
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0, 'status' => 1);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }

        $data = $this->get_list_data($cond, "`id`, `name`");
        $data = array_column($data, 'name', 'id');

        return $data;
    }

}


