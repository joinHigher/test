<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_organization_company extends mod_base
{

    public static function get_all_fields()
    {
        return "`id`, `organization_id`, `country`, `social_code`, `name`, `type`, `legal_representative`, `registered_capital`, `currency`, `established_date`, `date_from`, `date_end`, `registration_authority`, `approval_date`, `address`, `business_scope`, `license`, `create_user`, `create_time`,`update_user`,`update_time`";
    }


    public static function get_table_name()
    {
        return 'system_organization_company';
    }

}


