<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_station extends mod_base
{

    public static function get_all_fields()
    {
        return "`id`, `name`, `superior`, `level`, `level_id`, `business_tag`, `business_leader`, `business_link`, `amount`, `organization_id`, `department_id`, `number`, `type`, `form`, `address`, `responsibility`, `caption`, `status`, `create_user`, `create_time`, `update_user`,`update_time`, `delete_user`, `delete_time`";
    }


    public static function get_table_name()
    {
        return 'system_station';
    }

    /**
     * @param $id
     */
    public function get_station_name($id)
    {
        $data = '';
        if (empty($id)) {
            return $data;
        }

        $result = $this->get_one_data(array('id' => $id), '`id`, `name`');

        !empty($result) ? ($data = $result['name']) : null;

        return $data;
    }

    /**
     * 获取正常数据列表, 二维数组..
     *
     * @param array  $cond   Condition.
     * @param string $fields Fields.
     * @param string $key    Key.
     * @param string $limit  Limit.
     * @param string $order  Order.
     * @param string $group  Group.
     *
     * @return array
     */
    public function get_list_normal(array $cond = array(),  $fields = '', $key = '', $limit = '', $order = '' , $group = '')
    {
        $condition = array('delete_user' => 0, 'delete_time' => 0);
        $cond = array_merge($cond, $condition);

        if (empty($fields)) {
            $fields = "`id`, `name`";
        }

        $data = $this->get_list_data($cond, $fields, $key, $limit, $order, $group);

        return $data;
    }


    /**
     * 获取机构下面岗位.
     *
     * @param array $org_arr
     *
     * @return array
     */
    public function get_list_normal_in_org(array $org_arr)
    {
        $condition = array('organization_id in' => $org_arr);
        $fields = 'id, name';

        return $this->get_list_normal($condition, $fields);
    }

    /**
     * 获取部门下面的岗位.
     *
     * @param array $dep_arr
     *
     * @return array
     */
    public function get_list_normal_in_dep(array $dep_arr)
    {
        $condition = array('department_id in' => $dep_arr);
        $fields = 'id, name';

        return $this->get_list_normal($condition, $fields);
    }

    /**
     * 获取岗位下面的岗位.
     *
     * @param array $dep_arr
     *
     * @return array
     */
    public function get_list_normal_in_sub(array $station_arr)
    {
        $condition = array('superior in' => $station_arr);
        $fields = 'id, name';

        return $this->get_list_normal($condition, $fields);
    }

    /**
     * @param $org_id
     */
    public function checkout_is_sub($station_id)
    {
        $condition = array(
            'superior' => $station_id,
            // 由部门领导.
            'delete_user' => 0,
            'delete_time' => 0,
        );

        return $this->count($condition);
    }

    /**
     * 获取岗位列表.
     *
     * @param
     */
    public function get_station_options(array $id_arr = array())
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }

        $data = $this->get_list_data($cond, "`id`, `name`");
        $data = array_column($data, 'name', 'id');

        return $data;
    }

    /**
     * 获取机构下面的岗位.
     *
     * @param array $org_arr
     */
    public function get_station_in_org(array $org_arr, $except_station_id = 0)
    {
        if (empty($org_arr)) {
            return [];
        }

        $condition = array(
            'organization_id in' => $org_arr,
            'delete_user' => 0,
            'status' => 1
        );

        $data = $this->get_list_data($condition, '`id`, `name`');
        $data = array_column($data, 'name', 'id');

        if (!empty($except_station_id)) {
            unset($data[$except_station_id]);
        }

        return $data;
    }

}


