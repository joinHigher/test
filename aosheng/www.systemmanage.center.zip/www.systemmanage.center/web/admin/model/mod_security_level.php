<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_security_level extends mod_base
{

    public static function get_all_fields()
    {
        return "`id`, `level`, `level_name`, `level_short_name`, `create_user`, `create_time`, `update_user`,`update_time`, `delete_user`, `delete_time`";
    }


    public static function get_table_name()
    {
        return 'system_security_level';
    }

    /**
     * @param $id
     */
    public function get_security_level_name($id)
    {
        $data = '';
        if (empty($id)) {
            return $data;
        }

        $result = $this->get_one_data(array('id' => $id), '`id`, `level_name`');

        !empty($result) ? ($data = $result['level_name']) : null;

        return $data;
    }

    /**
     * 获取岗位列表.
     *
     * @param
     */
    public function get_security_level_options(array $id_arr = array())
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }

        $data = $this->get_list_data($cond, "`id`, `level_name`");
        $data = array_column($data, 'level_name', 'id');

        return $data;
    }

}


