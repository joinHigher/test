<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 业务属性model
 *
 * @version $Id$
 */
class mod_operation_tag extends mod_base
{
    protected  static $table = "#PB#_operation_tag";
    protected  static $where = array(
        array('delete_user', '=', '0'),
        array('delete_time', '=', '0')
    );


    public static function get_all_fields()
    {
        return "`id`, `tag_name`, `mec_id`, `create_user`, `create_time`, `update_user`,`update_time`, `delete_user`, `delete_time`";
    }


    public static function get_table_name()
    {
        return 'system_operation_tag';
    }

    /**
     * 获取正常数据列表, 二维数组..
     *
     * @param array  $cond   Condition.
     * @param string $fields Fields.
     * @param string $key    Key.
     * @param string $limit  Limit.
     * @param string $order  Order.
     * @param string $group  Group.
     *
     * @return array
     */
    public function get_list_normal(array $cond = array(),  $fields = '', $key = '', $limit = '', $order = '' , $group = '')
    {
        $condition = array('delete_user' => 0, 'delete_time' => 0);
        $cond = array_merge($cond, $condition);

        if (empty($fields)) {
            $fields = "`id`, `tag_name`";
        }

        $data = $this->get_list_data($cond, $fields, $key, $limit, $order, $group);

        return $data;
    }

    /**
    * @desc 获取指定select样式的数据
     */
    public static function get_list($arr)
    {
        $where = self::$where;
        if(!empty(is_array($arr)))
        {
            $where[] = array('in', 'in', implode(',',$arr));
        }

        $arr = db::select('id,tag_name')->from(self::$table)->where($where)->execute();
        $arr = !empty($arr) ? array_column($arr,'tag_name','id') : [];
        return $arr;
    }

    /**
     * 获取tag.
     *
     * @param array  $id_arr  id组成的数组.
     * @param string $org_id  机构id.
     *
     * @return array
     */
    public function get_tag_options(array $id_arr = array(), $org_id = '')
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }
        if (!empty($org_id)) {
            $cond['mec_id FIND_IN_SET'] = $org_id;
        }

        $data = $this->get_list_data($cond, "`id`, `tag_name`");

        return array_column($data, 'tag_name', 'id');
    }

    /**
     * 获取适用的tag.
     *
     * @param integer $org_id 机构id.
     *
     * @return  array
     */
    public function get_tag_option_in_org($org_id)
    {
        $condition = array(
            'mec_id FIND_IN_SET' => $org_id,
        );

        $fields = '`id`, `tag_name`';
        $data1 = $this->get_list_normal($condition, $fields);

        $condition = array(
            'mec_id' => ''
        );
        $data2 = $this->get_list_normal($condition, $fields);

        $data = array_merge($data1, $data2);
        $data = array_column($data, 'tag_name', 'id');

        return $data;
    }

}
