<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_organize_level extends mod_base
{
    protected  static $table = "#PB#_organize_level";
    protected  static $where = [
        ['delete_user', '=', '0'],
        ['delete_time', '=', '0']
    ];

    public static function get_all_fields()
    {
        return "`id`, `level`, `level_deputy`, `level_name`, `level_short_name`, `h_org_level`, `h_post_level`, `l_post_level`, `l_org_level`, `h_mec_level`, `l_mec_level`, `create_user`, `create_time`, `update_user`,`update_time`, `delete_user`, `delete_time`";
    }

    /**
     * @return string
     */
    public static function get_table_name()
    {
        return 'system_organize_level';
    }

    /**
     * 获取组织等级.
     *
     * @param
     */
    public function get_level_options(array $id_arr = array())
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }
        $level = $this->get_list_data($cond, "`id`, `level_short_name`", '', '', 'level asc');
        $level = array_column($level, 'level_short_name', 'id');

        return $level;
    }

    /**
     * @param $id
     */
    public function get_level_name($id)
    {
        $data = '';
        if (empty($id)) {
            return $data;
        }

        $result = $this->get_one_data(array('id' => $id), '`id`, `level_short_name`');

        !empty($result) ? ($data = $result['level_short_name']) : null;

        return $data;
    }

    /**
     * 获取机构下面的等级对应的下面的下级机构等级范围
     *
     * @param $org_id 机构id.
     *
     * return array
     */
    public function get_org_level_option_in_org($org_id)
    {
        $data = array();
        $org_data = mod_department::instance()->get_one_data(array('id' => $org_id), '`id`, `level_id`');
        if (!empty($org_data)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $org_data['level_id']), '`h_mec_level`, `l_mec_level`');
            $res = mod_organize_level::instance()->get_list_data(
                array(
                    'level <=' => $organize_level_data['l_mec_level'],
                    'level >=' => $organize_level_data['h_mec_level'],
                    'delete_user' => 0,
                ),
                '`id`,`level_short_name`',
                '',
                '',
                'level asc'
            );

            if (!empty($res)) {
                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
     * 获取机构下面的等级对应的部门等级范围
     *
     * @param $org_id 机构id.
     *
     * return array
     */
    public function get_department_level_option_in_org($org_id)
    {
        $data = array();
        $org_data = mod_department::instance()->get_one_data(array('id' => $org_id), '`id`, `level_id`');
        if (!empty($org_data)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $org_data['level_id']), '`h_org_level`, `l_org_level`');
            $res = mod_organize_level::instance()->get_list_data(
                array(
                    'level <=' => $organize_level_data['l_org_level'],
                    'level >=' => $organize_level_data['h_org_level'],
                    'delete_user' => 0,
                ),
                '`id`,`level_short_name`',
                '',
                '',
                'level asc'
            );

            if (!empty($res)) {
                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
     * 获取机构下面的等级对应的岗位等级范围
     *
     * @param $org_id 机构id.
     *
     * return array
     */
    public function get_station_level_option_in_org($org_id)
    {
        $data = array();
        $org_data = mod_organization::instance()->get_one_data(array('id' => $org_id), '`id`, `level_id`');
        if (!empty($org_data)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $org_data['level_id']), '`h_post_level`, `l_post_level`');
            $res = mod_organize_level::instance()->get_list_data(
                array(
                    'level <=' => $organize_level_data['l_post_level'],
                    'level >=' => $organize_level_data['h_post_level'],
                    'delete_user' => 0,
                ),
                '`id`,`level_short_name`',
                '',
                '',
                'level asc'
            );

            if (!empty($res)) {
                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
     * 获取部门下面的等级对应的岗位等级范围
     *
     * @param $org_id 机构id.
     *
     * return array
     */
    public function get_station_level_option_in_dep($dep_id)
    {
        $data = array();
        $department_data = mod_department::instance()->get_one_data(array('id' => $dep_id), '`id`, `level_id`');
        if (!empty($department_data)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $department_data['level_id']), '`h_post_level`, `l_post_level`');
            $res = mod_organize_level::instance()->get_list_data(
                array(
                    'level <=' => $organize_level_data['l_post_level'],
                    'level >=' => $organize_level_data['h_post_level'],
                    'delete_user' => 0,
                ),
                '`id`,`level_short_name`',
                '',
                '',
                'level asc'
            );

            if (!empty($res)) {
                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
     * 获取岗位下面的等级对应的岗位等级范围
     *
     * @param $station_id 岗位id.
     *
     * return array
     */
    public function get_station_level_option_in_station($station_id)
    {
        $data = array();
        $station_data = mod_station::instance()->get_one_data(array('id' => $station_id), '`id`, `level_id`');
        if (!empty($station_data)) {
            $station_level_data = mod_organize_level::instance()->get_one_data(array('id' => $station_data['level_id']), '`level`');
            if (!empty($station_level_data)) {
                $level_id_arr = range($station_level_data['level']+1, 15);
            }

            if (!empty($level_id_arr)) {
                $res = mod_organize_level::instance()->get_list_data(
                    array(
                        'level in' => $level_id_arr,
                        'delete_user' => 0
                    ),
                    '`id`,`level_short_name`',
                    '',
                    '',
                    'level asc'
                );

                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
    * @ 获取指定条件的数据
     */
    public static function get_list($filed='id, level_name', $condition)
    {
        $where = self::$where;
        if(!empty($condition))
        {
            $where[] = $condition;
        }
        $arr = db::select("{$filed}")->from(self::$table)->where($where)->execute();
        return $arr;
    }

    /**
     * 获取指定格式化数据
     * $table 表名称
     * $filed array 字段名
     **/
    public static function get_data($field1='id',$filed2='level_name')
    {
        $arr = db::select("{$field1},{$filed2}")->from(self::$table)->where(self::$where)->execute();
        $arr = array_column($arr, $filed2, $field1);
        return $arr;
    }


    /**
     * 获取指定表的格式化数据
     * $table 表名称
     * $filed array 字段名
     **/
    public static function get_one_level($filed='id, level_name',$id)
    {
        $where = self::$where;
        if(!empty($id))
        {
            $where[] = ['id','=',$id];
        }
        $arr = db::select($filed)->from(self::$table)->where($where)->as_row()->execute();
        return $arr;
    }





    /**
    * 已存在的等级
     */
    public static function get_level()
    {
        $arr = db::select('id,level')->from(self::$table)->where(self::$where)->group_by('level')->execute();

        $arr = !empty($arr) ? array_column($arr, 'level', 'level') : [];
        return $arr;
    }


    /**
     * @desc 获取等级配置
     * @param string $param_name 后台配置参数名称
     * @param int $num 开始数值
     * */
    public static function get_config_level($param_name,$num=1)
    {
        $level    = config::get($param_name);
        $level  = isset($level) ? $level : 15;
        $arr['']    = "请选择";
        for ($x=$num; $x<=$level; $x++)
        {
            $arr[$x] = $x;
        }
        return  $arr;
    }

    /**
     * 通过部门下上级部门或独立岗位获取组织等级范围.
     *
     * @param string $superior 上级部门或独立岗位.
     *
     * @return array
     */
    public function get_department_level_by_superior($superior)
    {
        $data = array();
        $superior_id_arr = explode('_', $superior);
        $id = array_pop($superior_id_arr);
        if (empty($id)) {
            return $data;
        }

        if (in_array('department', $superior_id_arr)) {
            $level_data = mod_department::instance()->get_one_data(array('id' => $id), '`id`, `level_id`, `level`');
        } elseif (in_array('station', $superior_id_arr)) {
            $level_data = mod_station::instance()->get_one_data(array('id' => $id), '`id`, `level_id`, `level`');
        }


        if (!empty($level_data)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $level_data['level_id']), '`level`');
            if (!empty($organize_level_data)) {
                $level_id_arr = range($organize_level_data['level']+1, 15);
            }

            if (!empty($level_id_arr)) {
                $res = mod_organize_level::instance()->get_list_data(
                    array(
                        'level in' => $level_id_arr,
                        'delete_user' => 0
                    ),
                    '`id`,`level_short_name`',
                    '',
                    '',
                    'level asc'
                );

                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
     * 通过部门下的行政归属获取组织等级范围.
     *
     * @param string $belong 行政归属.
     *
     * @return array
     */
    public function get_department_level_by_belong($belong)
    {
        $data = array();
        $belong_id_arr = explode('_', $belong);
        $id = array_pop($belong_id_arr);
        if (empty($id)) {
            return $data;
        }

        if (in_array('department', $belong_id_arr)) {
            $level_data = mod_department::instance()->get_one_data(array('id' => $id), '`id`, `level_id`, `level`');
        } elseif (in_array('station', $belong_id_arr)) {
            $level_data = mod_station::instance()->get_one_data(array('id' => $id), '`id`, `level_id`, `level`');
        }


        if (!empty($level_data)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $level_data['level_id']), '`h_org_level`, `l_org_level`');
            if (!empty($organize_level_data)) {
                $res = mod_organize_level::instance()->get_list_data(
                    array(
                        'level <=' => $organize_level_data['l_org_level'],
                        'level >=' => $organize_level_data['h_org_level'],
                        'delete_user' => 0,
                    ),
                    '`id`,`level_short_name`',
                    '',
                    '',
                    'level asc'
                );
            }

            if (!empty($res)) {
                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
     * 通过部门下的归属机构获取组织等级范围(所属机构对应的权力部门限制的部门等级范围).
     *
     * @param string $belong 行政归属.
     *
     * @return array
     */
    public function get_department_level_by_org($org_id)
    {
        $data = array();
        if (empty($org_id)) {
            return $data;
        }

        // 查询该机构下面的权力部门.
        $top_department = mod_department::instance()->get_one_data(array('organization_id' => $org_id, 'type' => 1, 'delete_user' => 0), '`id`, `level_id`');
        if (!empty($top_department)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $top_department['level_id']), '`h_org_level`, `l_org_level`');
            if (!empty($organize_level_data)) {
                $res = mod_organize_level::instance()->get_list_data(
                    array(
                        'level <=' => $organize_level_data['l_org_level'],
                        'level >=' => $organize_level_data['h_org_level'],
                        'delete_user' => 0,
                    ),
                    '`id`,`level_short_name`',
                    '',
                    '',
                    'level asc'
                );
            }

            if (!empty($res)) {
                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

    /**
     * 通过部门所属的机构获取权力部门的组织等级范围.
     *
     * @param $org_id  部门所属机构id.
     *
     * @return  array
     */
    public function get_top_department_level_by_org($org_id)
    {
        $data = array();
        if (empty($org_id)) {
            return $data;
        }

        $org_data  = mod_organization::instance()->get_one_data(array('id' => $org_id, 'delete_user' => 0), '`level_id`');
        if (!empty($org_data)) {
            $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $org_data['level_id']), '`h_mec_level`, `l_mec_level`');
            if (!empty($organize_level_data)) {
                $res = mod_organize_level::instance()->get_list_data(
                    array(
                        'level <=' => $organize_level_data['l_mec_level'],
                        'level >=' => $organize_level_data['h_mec_level'],
                        'delete_user' => 0,
                    ),
                    '`id`,`level_short_name`',
                    '',
                    '',
                    'level asc'
                );
            }

            if (!empty($res)) {
                $data = array_column($res, 'level_short_name', 'id');
            }
        }

        return $data;
    }

}


