<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 缓存模块
 *
 * @version $Id$
 */
class mod_cache
{
    /**
     * 清除网址导航缓存
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2016-09-06 21:15
     */
    public static function clear_guonei()
    {
        $cache_prefix = "daohang_guonei_";

        // 清除链接模块
        cache::del($cache_prefix, 'link_list');

        // 清除新闻模块
        cache::del($cache_prefix, 'news_list');

        // 清除小说模块
        cache::del($cache_prefix, 'xiaoshuo_list');

        // 清除奇闻模块
        $keyword = $cache_prefix."channel_news_*";
        $keys = pub_redis::keys($keyword);
        $list = array();
        foreach ($keys as $key) 
        {
            $key = str_replace(pub_redis::$prefix.":", "", $key);
            pub_redis::del($key);
        }

        // 清除广告统计模块
        $keyword = $cache_prefix."adcode_list_*";
        $keys = pub_redis::keys($keyword);
        $list = array();
        foreach ($keys as $key) 
        {
            $key = str_replace(pub_redis::$prefix.":", "", $key);
            pub_redis::del($key);
        }

        return true;
    }

    /**
     * 清除网址站群缓存
     * 
     * @return void
     * @author seatle <seatle@foxmail.com> 
     * @created time :2016-09-06 21:15
     */
    public static function clear_site()
    {
        // 小说渠道
        $cache_prefix = "daohang_site_xiaoshuo_";
        // 清除广告统计模块
        $keyword = $cache_prefix."adcode_list_*";
        $keys = pub_redis::keys($keyword);
        $list = array();
        foreach ($keys as $key) 
        {
            $key = str_replace(pub_redis::$prefix.":", "", $key);
            pub_redis::del($key);
        }

        // 小说详情页
        $cache_prefix = "daohang_site_xiaoshuo_detail_";
        // 清除小说详情
        $keyword = $cache_prefix."detail_info_*";
        $keys = pub_redis::keys($keyword);
        $list = array();
        foreach ($keys as $key) 
        {
            $key = str_replace(pub_redis::$prefix.":", "", $key);
            pub_redis::del($key);
        }
        // 清除广告统计模块
        $keyword = $cache_prefix."adcode_list_*";
        $keys = pub_redis::keys($keyword);
        $list = array();
        foreach ($keys as $key) 
        {
            $key = str_replace(pub_redis::$prefix.":", "", $key);
            pub_redis::del($key);
        }

        return true;
    }
}
