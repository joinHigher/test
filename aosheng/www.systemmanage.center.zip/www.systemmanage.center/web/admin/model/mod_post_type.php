<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_post_type extends mod_base
{

    /**
     * 表字段.
     *
     * @return string
     */
    public static function get_all_fields()
    {
        return "`id`, `name`, `org_level_region`, `mec_level_region`, `create_user`, `create_time`, `update_user`,`update_time`, `delete_user`, `delete_time`";
    }

    /**
     * 表名.
     *
     * @return string
     */
    public static function get_table_name()
    {
        return 'system_post_type';
    }

    /**
     * 获取岗位列表.
     *
     * @param
     */
    public function get_type_options(array $id_arr = array())
    {
        $cond = array('delete_user' => 0, 'delete_time' => 0);
        if (!empty($id_arr)) {
            $cond['id in'] = $id_arr;
        }

        $data = $this->get_list_data($cond, "`id`, `name`");
        $data = array_column($data, 'name', 'id');

        return $data;
    }

    /**
     * @param $id
     */
    public function get_type_name($id)
    {
        $data = '';
        if (empty($id)) {
            return $data;
        }

        $result = $this->get_one_data(array('id' => $id), '`id`, `name`');

        !empty($result) ? ($data = $result['name']) : null;

        return $data;
    }

    /**
     * 获取正常数据列表, 二维数组..
     *
     * @param array  $cond   Condition.
     * @param string $fields Fields.
     * @param string $key    Key.
     * @param string $limit  Limit.
     * @param string $order  Order.
     * @param string $group  Group.
     *
     * @return array
     */
    public function get_list_normal(array $cond = array(),  $fields = '', $key = '', $limit = '', $order = '' , $group = '')
    {
        $condition = array('delete_user' => 0, 'delete_time' => 0);
        $cond = array_merge($cond, $condition);

        if (empty($fields)) {
            $fields = "`id`, `name`";
        }

        $data = $this->get_list_data($cond, $fields, $key, $limit, $order, $group);

        return $data;
    }

    /**
     * 获取适用的岗位类型.
     *
     * @param integer $org_id 机构id.
     *
     * @return  array
     */
    public function get_type_option_in_org($org_id)
    {
        $condition = array(
            'mec_level_region FIND_IN_SET' => $org_id,
        );

        $fields = '`id`, `name`';
        $data1 = $this->get_list_normal($condition, $fields);

        $condition = array(
            'mec_level_region' => ''
        );
        $data2 = $this->get_list_normal($condition, $fields);

        $data = array_merge($data1, $data2);
        $data = array_column($data, 'name', 'id');

        return $data;
    }

    /**
     * @param $org_id   机构id.
     * @param $type_id  岗位类型id.
     *
     * @return  array
     */
    public function get_level_range_in_type_org($org_id, $type_id)
    {
        $data = array();
        if (empty($org_id) || empty($type_id)) {
            return $data;
        }

        $org_data = mod_organization::instance()->get_one_data(array('id' => $org_id), '`id`, `level`');
        if (empty($org_data)) {
            return $data;
        }
        $level = $org_data['level'];

        $condition = array(
            'id' => $type_id,
            'delete_user' => 0,
        );

        $level_id_arr = array();
        $type_data = $this->get_one_data($condition, '`id`, `org_level_region`');
        if (!empty($type_data)) {
            $type_data['org_level_region'] = !empty($type_data['org_level_region']) ? json_decode($type_data['org_level_region'], true) : array();
            if (isset($type_data['org_level_region'][$level])) {
                $level_id_arr = explode(',', $type_data['org_level_region'][$level]);
            } elseif(empty($type_data['org_level_region'])) {
                // 为空全部适用.
                $level_id_arr = range(1, 15);
            }
        }

        if (!empty($level_id_arr)) {
            $res = mod_organize_level::instance()->get_list_data(
                array(
                    'level in' => $level_id_arr,
                    'delete_user' => 0
                ),
                '`id`,`level_short_name`'
            );

            $data = array_column($res, 'level_short_name', 'id');
        }

        return $data;
    }

}


