<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构设置模块
 *
 * @version $Id$
 */
class mod_station_list extends mod_base
{

    public static function get_all_fields()
    {
        return "`id`, `code`, `organization_id`, `department_id`, `station_id`, `external_name`, `member_id`, `assigned_organization_id`, `assigned_department_id`, `assigned_station_id`, `arrival_time`, `description`, `create_user`, `create_time`, `update_user`,`update_time`";
    }


    public static function get_table_name()
    {
        return 'system_station_list';
    }

}


