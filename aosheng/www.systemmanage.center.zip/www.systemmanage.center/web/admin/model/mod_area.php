<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 *  地址，地区，模型
 *
 * @version $Id$
 */
class mod_area
{
    public static $table = '#PB#_area';

    public static $pk = 'id';

    public static $cache_time = 72000;

    public static $fields = array(
        'id','name','short_name','level','parent_id','path','child_num'
    );

    public static $level_intro = array(
        '-1'=>'国家级',
        '1'=>'州省级',
        '2'=>'市级',
        '3'=>'区县级',
        '4'=>'街道级',
    );

    /********************************* 其他模块 使用接口  start*****************************************/
    //根据parent_id获取 下级地址的 id=>short_name 的数组结构
    public static function get_level_area($parent_id = 0)
    {
        $where[] = array('delete_user','=','0');
        if(empty($parent_id))
        {
            $where[] = array('level','=','-1');
        }
        elseif($parent_id > 0)
        {
            $where[] = array('parent_id','=',$parent_id);
        }
        $data = self::getlist('id,short_name',$where);
        if(is_array($data) && !empty($data))
        {
            $result = array();
            foreach ($data as $v)
            {
                $result[$v['id']] = $v['short_name'];
            }
            return $result;
        }
        return $data;
    }

    //根据id 获取简称
    public static function get_area_name($id)
    {
        if($id > 0)
        {
            $res = self::getdump('short_name',array('id','=',$id));
            return empty($res)?false:$res['short_name'];
        }
        return false;
    }

    /********************************* 其他模块 使用接口  end*****************************************/

    /**
     *
     * 默认获取国家级别的地址，根据parent_id 获取 下级地址数据列表
     * @param string $parent_id
     * @return array|bool|mixed
     */
    public static function get_api_name($parent_id = '0')
    {
        $where[] = array('delete_user','=','0');
        if(empty($parent_id))
        {
            $where[] = array('level','=','-1');
        }
        elseif($parent_id > 0)
        {
            $where[] = array('parent_id','=',$parent_id);
        }
        return self::getlist('id,short_name,parent_id,child_num,level',$where);
    }


    /**
     * 根据主键id 修改下级数量，child——num
     * @param $id
     * @param string $num
     * @return bool|mysqli_result|null|resource|void
     */
    public static function set_child_num($id = 0,$num = '1')
    {
        if(is_numeric($num) && $id > 0)
        {
            $type = $num > 0?'+':'-';
            $num = abs($num);
            return db::query("UPDATE `".self::$table."` SET `child_num` = (`child_num`{$type}{$num}) WHERE `id` = '{$id}'")->execute();
        }
        return false;
    }

    /**
     * 根据主键或区相应的字段下 的值
     * @param int $id  主键
     * @param string $field  字段名称
     */
    public static function get_arae_val($id = 0,$fields = '')
    {
        if(empty($id)) return false;
        $fields = empty($fields)?array('id','short_name','parent_id'):$fields;
        $data = db::select($fields)->from(self::$table)->where('id','in',$id)->execute();
        if(is_array($data) && !empty($data))
        {
            $result = array();
            foreach ($data as $value)
            {
                $result[$value['id']] = $value;
            }
            return $result;
        }
        return false;
    }


    /**
     * 根据 id 或者 单条数据 组织地址上级联动
     * @param array $data
     */
    public static function get_path_area($param = '')
    {
        if(is_numeric($param) && $param > 0)
        {
            $list = self::getdump(self::$fields,array('id','=',$param));
        }
        else
        {
            $list = $param;
        }
        if(empty($list['level']))
        {
            return false;
        }
        $list['one_short'] = $list['two_short'] = $list['thr_short'] = $list['fou_short'] = $list['fiv_short'] = '-';
        $list['one'] = $list['two'] = $list['thr'] = $list['fou'] = $list['fiv'] = '-';
        $list['one_id'] = $list['two_id'] = $list['thr_id'] = $list['fou_id'] = $list['fiv_id'] = '0';
        $list['path'] = substr($list['path'],2);

        switch ($list['level'])
        {
            case '-1':
                $list['zero'] = $list['name'];
                $list['zero_id'] = $list['id'];
                $list['zero_short'] = $list['short_name'];
                break;
            case '1':
                $all_data = self::getdump('name,short_name',array('id','=',$list['parent_id']));
                $list['zero_short'] = $all_data['short_name'];
                $list['zero'] = $all_data['name'];
                $list['zero_id'] = $list['parent_id'];
                $list['one'] = $list['name'];
                $list['one_short'] = $list['short_name'];
                $list['short'] = $list['name'];
                $list['one_id'] = $list['id'];
                break;
            case '2':
                $parent_ids = explode('-',$list['path']);
                $all_data = self::get_arae_val($parent_ids,array('id','name','short_name','parent_id'));

                $list['zero_short'] = $all_data[$parent_ids[0]]['short_name'];
                $list['zero'] = $all_data[$parent_ids[0]]['name'];
                $list['one_short'] = $all_data[$list['parent_id']]['short_name'];
                $list['one'] = $all_data[$list['parent_id']]['name'];

                $list['two_short'] = $list['short_name'];
                $list['two'] = $list['name'];
                $list['zero_id'] = $parent_ids[0];
                $list['one_id'] = $list['parent_id'];
                $list['two_id'] = $list['id'];
                break;
            case '3':
                $parent_ids = explode('-',$list['path']);
                $all_data = self::get_arae_val($parent_ids,array('id','name','short_name','parent_id'));

                $list['zero_short'] = $all_data[$parent_ids[0]]['short_name'];
                $list['zero'] = $all_data[$parent_ids[0]]['name'];
                $list['one_short'] = $all_data[$parent_ids[1]]['short_name'];
                $list['one'] = $all_data[$parent_ids[1]]['name'];
                $list['two_short'] = $all_data[$list['parent_id']]['short_name'];
                $list['two'] = $all_data[$list['parent_id']]['name'];

                $list['thr_short'] = $list['short_name'];
                $list['thr'] = $list['name'];
                $list['zero_id'] = $parent_ids[0];
                $list['one_id'] = $parent_ids[1];
                $list['two_id'] = $list['parent_id'];
                $list['thr_id'] = $list['id'];
                break;
            case '4':
                $parent_ids = explode('-',$list['path']);
                $all_data = self::get_arae_val($parent_ids,array('id','name','short_name','parent_id'));

                $list['zero_short'] = $all_data[$parent_ids[0]]['short_name'];
                $list['zero'] = $all_data[$parent_ids[0]]['name'];
                $list['one_short'] = $all_data[$parent_ids[1]]['short_name'];
                $list['two_short'] = $all_data[$parent_ids[2]]['short_name'];
                $list['two'] = $all_data[$parent_ids[2]]['name'];
                $list['thr_short'] = $all_data[$list['parent_id']]['short_name'];
                $list['thr'] = $all_data[$list['parent_id']]['name'];
                $list['fou_short'] = $list['short_name'];
                $list['fou'] = $list['name'];
                $list['zero_id'] = $parent_ids[0];
                $list['one_id'] = $parent_ids[1];
                $list['two_id'] = $parent_ids[2];
                $list['thr_id'] = $list['parent_id'];
                $list['fou_id'] = $list['id'];
                break;
            default:
                return false;
        }
        //var_dump($list);
        return $list;

    }



    /**
     * 记录所有缓存的key ，方便准确clear
     * @param string $key
     */
    public static function log_cache_key($key = '')
    {
        if(empty($key)) return false;
        $data = empty(cache::get(self::$table,'log_array_key'))?array():cache::get(self::$table,'log_array_key');
        $data = array_merge($data,array($key));
        cache::set(self::$table,'log_array_key',$data,self::$cache_time);
    }
    /**
     * 清楚该表是的所有缓存
     */
    public static function celar_cache()
    {
        $data = cache::get(self::$table,'log_array_key');
        if(empty($data))
        {
            return false;
        }
        foreach ($data as $v)
        {
            cache::del(self::$table,$v);
        }
        cache::del(self::$table,'log_array_key');
    }

    public static function save()
    {

        db::update(self::$table)->value()->where()->execute();
    }

    /**
     * 获取 单条数据
     */
    public static function getdump($field = '',$where = '')
    {
        $field = empty($field)?self::$fields:$field;
        if(is_array($where) && !is_array($where[0]))
        {
            $where = array($where);
        }
        if(!is_array($field) && strpos($field,','))
        {
            $field = explode(',',$field);
        }
        $data = db::select($field)
            ->from(self::$table)
            ->where($where)
            ->execute();
            //->compile();
        return empty($data)?$data:$data[0];
    }

    /**
     * 根据 where 条件获取 地址列表
     * @param string $where 自带 where 关键字
     * @param string $field
     * @param string $order 自带 order by 关键字
     * @param string $limit 自带 limit 关键字
     */
    public static function getlist($field = '',$where = '',$order = '',$limit = 0,$offset = 0){
        $field = empty($field)?self::$fields:$field;
        $where_md5 = '';
        foreach ($where as $value){
            $where_md5 .= is_array($value)?implode('@',$value):$value;
        }
        $key = md5($where_md5.$order.$limit.$offset.$field);
        $data = cache::get(self::$table,$key);
        if(empty($data)){
            if(!is_array($field) && strpos($field,',')){
                $field = explode(',',$field);
            }
            if(is_array($where) && !is_array($where[0])){
                $where = array($where);
            }
            $query = db::select($field)->from(self::$table)->where($where);
            if($limit > 0){
                $query->limit($limit);
                $query->offset($offset);
            }
            if(!empty($order)){
                $query->order_by($order[0],$order[1]);
            }
            $data = $query->execute();
            //$data = $query->compile();
            cache::set(self::$table,$key,$data,self::$cache_time);
            self::log_cache_key($key);
        }
        return $data;
    }

}
