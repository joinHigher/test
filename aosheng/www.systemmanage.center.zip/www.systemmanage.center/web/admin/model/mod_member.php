<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 *  员工管理
 *
 * @version $Id$
 */
class mod_member extends mod_base
{
    protected  static $admin_table = "#PB#_admin"; //系统用户表

    protected static $table = "#PB#_member";

    protected static $dtpost_table = "#PB#_dtpost"; //部门岗位等级

    protected static $admin_level = "#PB#_admin_level"; //行政等级

    protected  static $organization = "#PB#_organization"; //机构表

    protected static $department = "#PB#_department";  //部门表

    protected static $station = "#PB#_station";  //岗位表

    protected static  $tmp_path = PATH_UPLOADS.'/tmp'; //未加密文件存放处

    protected static  $file_path = PATH_UPLOADS.'/file'; //加密文件存放


    public static function get_all_fields()
    {
        return "`id`, `sn`,`member_pass`,`realname`, `nickname`, `nationality`, `job`, `job_sta`, `nation`, `account_sta`, `birth`, `prove`, `prove2`, 
        `province`, `city`, `town`, `address`, `email`, `contact_type`, `contact`, `ug_contact_type`, `ug_contact_name`,`ug_contact_rate`, 
        `ug_contact`, `id_type`, `image_data`, `university`, `edu_high`, `edu_date`, `edu_major`, `admin_level`, `sta`, `id_code`, 
        `entry_department`, `entry_organization`, `entry_job`, `job_num`, `job_qf`, `come_job_date`, `become_job_date`, `sex`, `create_time`, 
        `create_user`, `update_time`, `update_user`, `del_time`, `del_user`, `security`, `security2`, `working_num`, `job_file`, `job_code_id`";
    }
    //入职记录
    public static function get_job_log_field()
    {
        return "`id`,`create_user`,`create_time`, `update_time`, `update_user`, `del_time`, `job_time`, `job_why`, `job_first`, `job_last`
        , `organization_first_level`, `organization_last_level`, `organization_first`, `organization_last`, `department_first`
        ,`department_last`, `log_val`, `mid`, `working_num`, `job_file`,`type`";
    }
    //离职记录
    public static function get_quit_log_field()
    {
        return "`id`,`create_user`,`create_time`, `update_time`, `update_user`, `del_time`, `quit_time`, `quit_why`, `quit_val`,`mid`
        ,`handover_object`,`handover_file`,`contact_type`,`contact`";
    }

    public static function get_table_name()
    {
        return 'system_member';
    }

    /**
     * @param $id
     */
    public function get_member_name($id)
    {
        $data = '';
        if (empty($id)) {
            return $data;
        }

        $result = $this->get_one_data(array('id' => $id), '`id`, `realname`');

        !empty($result) ? ($data = $result['realname']) : null;

        return $data;
    }

    /**
     * 获取正常数据列表, 二维数组..
     *
     * @param array  $cond   Condition.
     * @param string $fields Fields.
     * @param string $key    Key.
     * @param string $limit  Limit.
     * @param string $order  Order.
     * @param string $group  Group.
     *
     * @return array
     */
    public function get_list_normal(array $cond = array(),  $fields = '', $key = '', $limit = '', $order = '' , $group = '')
    {
        $condition = array('del_user' => 0, 'del_time' => 0);
        $cond = array_merge($cond, $condition);

        if (empty($fields)) {
            $fields = "`id`, `name`";
        }

        $data = $this->get_list_data($cond, $fields, $key, $limit, $order, $group);

        return $data;
    }

    /**
     * 获取机构下面的员工.
     *
     * @param array $org_arr
     *
     * @return array
     */
    public function get_list_normal_in_org(array $org_arr)
    {
        $condition = array('entry_organization in' => $org_arr, 'entry_department' => 0, 'entry_job' => 0);
        $fields = '`id`, `realname`, `sn`, `nickname`';

        $res = $this->get_list_normal($condition, $fields);

        $data = array();
        foreach ($res as $key => $value) {
            $tmp = array();
            $tmp['id'] = $value['id'];
            $tmp['name'] = !empty($value['realname']) ? $value['realname'] : $value['nickname'];
            $tmp['sn'] = $value['sn'];
            $data[] = $tmp;
        }
        
        return $data;
    }

    /**
     * 获取部门下面的员工.
     *
     * @param array $dep_arr
     *
     * @return array
     */
    public function get_list_normal_in_dep(array $dep_arr)
    {
        $condition = array('entry_department in' => $dep_arr, 'entry_job' => 0);
        $fields = '`id`, `realname`, `sn`, `nickname`';

        $res =  $this->get_list_normal($condition, $fields);

        $data = array();
        foreach ($res as $key => $value) {
            $tmp = array();
            $tmp['id'] = $value['id'];
            $tmp['name'] = !empty($value['realname']) ? $value['realname'] : $value['nickname'];
            $tmp['sn'] = $value['sn'];
            $data[] = $tmp;
        }

        return $data;
    }

    /**
     * 获取岗位下面的员工.
     *
     * @param array $station_arr
     *
     * @return array
     */
    public function get_list_normal_in_station(array $station_arr)
    {
        $condition = array('entry_job in' => $station_arr);
        $fields = '`id`, `realname`, `sn`, `nickname`';

        $res =  $this->get_list_normal($condition, $fields);

        $data = array();
        foreach ($res as $key => $value) {
            $tmp = array();
            $tmp['id'] = $value['id'];
            $tmp['name'] = !empty($value['realname']) ? $value['realname'] : $value['nickname'];
            $tmp['sn'] = $value['sn'];
            $data[] = $tmp;
        }

        return $data;
    }

    /*
    * 相当于语言包，统一管理select的option值方便维护
    * $key 返回对应option数组
    * return array()
    **/
    public static function set_option_arr($key = '')
    {
        return array(
            'contact_type' => //联系方式与紧急联系方式一样
                array(
                    '1' => 'whatsapp',
                    '2' => 'Tel',
                    '3' => 'Telegram',
                    '4' => 'Wechat',
                    '5' => 'QQ',
                    '6' => 'Potato'
                ),
            'ug_contact_rate' =>//紧急联系人与当事人关系
                array(
                    '1' => '妻子',
                    '2' => '朋友',
                    '3' => '兄弟姐妹',
                    '4' => '配偶',
                    '5' => '其他'
                ),

            'id_type' => //证件类型
                array(
                    '1' => '身份证',
                    '2' => '护照',
                    '3' => '身份担保人'
                ),
            'edu_high' => //最高学历
                array(
                    '1' => '初中',
                    '2' => '高中',
                    '3' => '中专',
                    '4' => '大专',
                    '5' => '本科'
                ),
            'sta' => //账号状态
                array(
                    '0' =>'未激活', //未任职不生成账号密码为未激活
                    '1' => '正常',
                    '2' => '禁止'
                ),
            'job_sta'=>//工作状态
                array(
                    '0'=>'未任职',
                    '1'=>'在职',
                    '2'=>'离职',
                    '3'=>'免职'
                ),
            'sex'=>
                array(
                    '1'=>'男',
                    '2'=>'女'
                ),
            'admin_level'=>self::get_admin_level_data(),            //所有行政等级
            'organize_level'=>mod_organize_level::get_data('id','level_name'),            //所有组织等级
            'dtpost' => self::get_dtpost_data(),                    //部门岗位等级
            'entry_organization' => self::get_data(self::$organization),  //所有机构
            'entry_department' => self::get_data(self::$department),   //所有部门
            'entry_job'=> self::get_data(self::$station),              //所有岗位
            'entry_job_num'=>self::get_hr_job_num(),                   //所有岗位编号
            'nationality'=>self::get_area_data('-1'),         //国籍

            //任职操作原因
            'log_val'=>array(
                '1'=>'入职任免',
                '2'=>'升职任免',
                '3'=>'降职任免',
            ),
            //离职原因
            'quit'=>array(
                '1'=>'个人',
                '2'=>'公司辞退',
                '3'=>'调整机构',
                '4'=>'其他'
            ),



        );
    }

    /**
     * $id 数据库返回的索引id
     * $pre id生成的前缀（机构简称 例如AY）不存在则默认为DF
     * $mechanism 机构
     * 生成唯一id编号
     **/
    public static function get_user_sn($id,$mechanism)
    {

        $sn = 10000; //规定id从10000起
        $sn = $sn + $id;
        if(empty($mechanism))
        {
            $pre = 'DF';
        }else{
            $pre = self::get_machanism_pre($mechanism);
        }
        return $pre.$sn;
    }

    /**
     * 生成岗位编号
     * $mpre 机构前缀
     * $dpre 部门前缀
     * $id   唯一索引id
     */
    public static function set_hr_job_num($mpre,$dpre,$id)
    {
        if(empty($mpre) && empty($dpre))  //机构/岗位都为空
        {
            $sn = 'MN-DN-'.$id;
        }elseif(empty($mpre) && !empty($dpre))
        {
            $sn = 'MN-'.$dpre.'-'.$id;
        }elseif(!empty($mpre) && empty($dpre)){
            $sn = $mpre.'-'.'DN-'.$id;
        }else{
            $sn = $mpre.''.$dpre.'-'.$id;
        }
        return $sn;

    }

    /**
     * 获取机构前缀(机构英文简称)
     * $id 机构id 构造岗位编号
     */
    public static function get_machanism_pre($id){
        //$row = db::get_one("select `english_short_name` from ".self::$organization." where `id`='{$id}'");
        $row = db::select("english_short_name")->from(self::$organization)->where('id',$id)->as_row()->execute();
        return $row['english_short_name'];
    }
    /**
     * 获取部门前缀(部门简称字段)
     * $id 部门id 构造部门编号
     */
    public static function get_department_pre($id){
        //$row = db::get_one("select `short_name` from ".self::$organization."where `id`='{$id}'");
        $row = db::select("short_name")->from(self::$organization)->where('id',$id)->as_row()->execute();
        return $row['short_name'];
    }


    /**
     * 获取指定表的格式化数据
     * $table 表名称
     * $filed array 字段名
     **/
    public static function get_data($table,$filed=null,$condition='')
    {
        //$condition = 'where `isdeleted`!=0';
        $data = array();
        if(empty($filed))
        {
            $filed=array('id','name');

        }
        $condition = !empty($condition)?$condition:array(['delete_user','=','']);
        $filed = join(',',$filed);
       // $sql = "select ".$filed." from ".$table .$condition;
       // $arr = db::get_all($sql);
        $arr = db::select($filed)->from($table)->where($condition)->execute();
        if($arr)
        {
            foreach($arr as $k=>$v){
                $data[$v['id']]=$v['name'];
            }
        }

        return $data;

    }
    /**
     * 单一获取岗位编号
     */
    public static function get_hr_job_num()
    {

        //$arr = db::get_all("select `id`,`number` from `#PB#_station`");
        $arr = db::select("id,number")->from('#PB#_station')->execute();
        $data = array();
        if($arr)
        {
            foreach($arr as $k=>$v)
            {
                $data[$v['id']]=$v['number'];
            }
        }
        return $data;

    }

    /**
     * 多图片加密处理
     * $image_data array 多图片数组
     * $tmp_path string 存放图片的临时文件夹
     * $image_path string 存放加密图片的文件夹
     * return array $arr 图片加密后的信息
     */
    public static function file_crypt($image_data, $tmp_path, $img_path)
    {
        $info = array();
        //生成key
        $key = util::random('unique');

        foreach ($image_data as $k => $v) {
            if(file_exists($tmp_path . '/' . $v))
            {
                $plaintext = file_get_contents($tmp_path . '/' . $v);
                $value = cls_crypt::encode($plaintext, $key);
                //unlink($tmp_path . '/' . $v);  //此处如果删除  修改图片找不到源文件会有问题
                //生成加密图片
                file_put_contents($img_path . '/' . $v, $value);
                $info[] = array('file_name' => $v, 'key' => $key);
            }
        }
        return json_encode($info);
    }

    /**
     * 获取行政级别
     */
    public static function get_admin_level_data()
    {

        $arr = db::select("level,level_name")->from(self::$admin_level)->where('delete_user','=','')->execute();
        $admin_level = array();
        foreach($arr as $k=>$v){

            $admin_level[$v['level']]=$v['level_name'];
        }
        return $admin_level;
    }

    /**
     * 获取部门岗位等级表数据
     */
    public static function get_dtpost_data()
    {
        $arr = db::select("level,level_name")->from(self::$dtpost_table)->where('delete_user','=','')->execute();
        $dtpot_arr = array();
        $dtpot_arr['0']='岗位资历';
        if($arr)
        {
            foreach($arr as $k=>$v){
                $dtpot_arr[$v['level']]=$v['level_name'];
            }
        }

        return $dtpot_arr;
    }

    /**
     * 格式化联系人与联系方式
     * return array()
     **/
    public static function format_contact($type,$contact)
    {
        $arr =array();
        if(!empty($type))
        {
            foreach($type as $k=>$v)
            {
                $arr[$k]['contact_type']=!empty($v)?$v:'';
                $arr[$k]['contact']=!empty($contact[$k])?$contact[$k]:'';

            }
        }
        return $arr;
    }

    /**
     * 格式化紧急联系人数组
     * $ug_contact_type 紧急联系方式类型
     * $ug_contact_name 紧急联系人姓名
     * $ug_contact_rate 紧急联系人与当事人关系
     * $ug_contact  紧急联系方式
     * return array()
     */
    public  static function format_ug_contact($ug_contact_type,$ug_contact_name,$ug_contact_rate,$ug_contact)
    {
        $arr = array();
        foreach($ug_contact_type as $k=>$v)
        {
            $arr[$k]['ug_contact_type']=$v;
            $arr[$k]['ug_contact_name']=$ug_contact_name[$k];
            $arr[$k]['ug_contact_rate']=$ug_contact_rate[$k];
            $arr[$k]['ug_contact']=$ug_contact[$k];
        }
        return $arr;
    }

    /**
     * 根据carete_user（id）获取用户名
     */
    public static function get_username($admin_id)
    {
        //$row = db::get_one("select `username` from ".self::$admin_table." where `admin_id`='{$admin_id}'");
        $row = db::select("username")->from(self::$admin_table)->where('admin_id','=',$admin_id)->as_row()->execute();
        return $row['username'];
    }


    /**
     *获取地区对应的父级地区id
     * id 父id
     */
    public static function get_area($id=0)
    {
        $id = !empty($id)?$id:0;
        $where = array(
            array('parent_id','=',$id),
            array('delete_user','=','')
        );
        $arr = db::select("id,short_name")->from('#PB#_area')->where($where)->execute();
        $data = array();
        if(!empty($arr))
        {
            foreach($arr as $k=>$v)
            {
                $data[$v['id']]=$v['short_name'];
            }

            return $data;
        }
    }
    /**
     * 获取对应级别的行政地域
     * $level 行政级别  等级 -1=国籍，1=省/直辖市,2=地级市,3=区县,4=镇/街道
     * */
    public static function get_area_data($level)
    {
//         $sql = "select `id`,`name` from `#PB#_area` where `level`='{$level}' and `delete_user`=''";
//         $arr = db::get_all($sql);
        $where = array(
            array('level','=',$level),
            array('delete_user','=','')
        );
        $arr = db::select("id,short_name")->from('#PB#_area')->where($where)->execute();
         $data = array();

         if(!empty($arr))
         {
             foreach($arr as $k=>$v)
             {
                 $data[$v['id']]=$v['short_name'];
             }

             return $data;
         }
    }

    //任职加密文件处理

    /**
     * 获取文件加密后的信息
     * $filename 文件名称
     * return 加密信息数组 array();
     */
    public static function get_file_crypt($filename)
    {
            //生成key
            $key = util::random('unique');
            //文件执行压缩
            $name = explode('.',$filename);
            pub_zip::add(self::$tmp_path.'/zip_dir');
            pub_zip::add(self::$tmp_path.'/'.$filename);
            $new_zip_name = self::$tmp_path . '/' . $name['0'].'.zip';  //压缩跟之前一样的名字
            pub_zip::zip($new_zip_name);
            pub_zip::close();
            // 获取ZIP内容
            $plaintext = file_get_contents(self::$tmp_path . '/' . $filename);
            $value = cls_crypt::encode($plaintext, $key);
            // 生成加密的压缩文件
            file_put_contents(self::$file_path . '/' . $filename, $value);
            //删除临时调用文件
            unlink(self::$tmp_path . '/' . $filename);
            $info = array('file_name' => $filename, 'key' => $key);
            return $info;
    }

    /**
     * 获取对应的组织等级
     * $table 对应岗位/部门表
     * $id 对应岗位/部门id
     * return int
     */

    public static function get_organization_level($table,$id)
    {


        //$arr = db::get_one("select `id` from `$table` where `id`='{$id}'");
        $arr = db::select("id")->from($table)->where('id',$id)->as_row()->execute();
        if($arr)
        {
            return $arr['id'];
        }else
        {
            return '';
        }

    }

    /**
     * 获取员工任免记录
     * $id 指定记录的id
     * return $data array
     */
    public static function get_job_log($id)
    {
       // $sql = "Select * from `#PB#_job_log` where `mid`='{$id}' ";
        //$res = db::query($sql);

        //$data = db::fetch_all($res);
        $data = db::select(self::get_job_log_field())->from('#PB#_job_log')->where('mid',$id)->execute();
        return $data;
    }

    /**
     * 获取指定员工信息
     * $str 指定员工字符串
     */
    public static function get_handover_object($str)
    {
//        $sql = "select * from ".self::$table." where `id` in ($str)";
//
//        $data = db::get_all($sql);
        $arr = [$str];
        $data = db::select(self::get_all_fields())->from(self::$table)->where('id','in',$arr)->execute();
        if(!empty($data))
        {
            return $data;
        }else{
            exit("error:数据不存在");
        }

    }

    //获取所有员工
    public static function get_member_info($where)
    {
        if(!empty($where) && is_array($where))
        {
            $where = $where;
        }else
        {
            $where[] = array('1','=','1');
        }
        $data = db::select(self::get_all_fields())->from(self::$table)->where($where)->execute();
        $data = !empty($data)?$data:'';
    }

    //针对member表的表单验证
    public static function check_form($arr)
    {
        if(!is_array($arr))
        {
            exit('传递的参数必须为数组');
        }

        if(self::check_two($arr['realname'],$arr['nickname'])!=true)
        {
            cls_msgbox::show('系统提示', "员工姓名或员工代号必须填一个", '-1');
        }

        if(!empty($arr['realname']) && mb_strlen($arr['realname'])>30)
        {
            cls_msgbox::show('系统提示', "员工姓名最多30字", '-1');
        }

        if(!empty($arr['nickname']) && mb_strlen($arr['realname'])>30)
        {
            cls_msgbox::show('系统提示', "员工代号最多30字", '-1');
        }

        if(self::check_required($arr['prove'])!=true)
        {
            cls_msgbox::show('系统提示', "证明人1不能为空", '-1');
        }

        if(self::check_required($arr['prove2'])!=true)
        {
            cls_msgbox::show('系统提示', "证明人2不能为空", '-1');
        }

        if(self::check_required($arr['email'])!=true)
        {
            cls_msgbox::show('系统提示', "邮箱地址不能为空", '-1');
        }


        if(self::check_or_required($arr['contact'],$arr['contact_type'])!=true)
        {

            cls_msgbox::show('系统提示', "联系方式不能为空", '-1');
        }


        if(self::check_or_required($arr['ug_contact_rate'],$arr['ug_contact'])!=true)
        {
            cls_msgbox::show('系统提示', "紧急联系人不能为空", '-1');
        }



    }

    //二选一
    public static function check_two($name,$name2,$msg='')
    {
        if(empty($name) && empty($name2))
        {
            return $msg;
        }else{
            return true;
        }
    }

    //必填
    public static function check_required($data,$msg='')
    {
        if(empty($data))
        {
            return $msg;
        }else{
            return true;
        }
    }

    //or必填
    public static function check_or_required($name,$name2,$msg='')
    {

        if(self::check_empty_array($name)==false || self::check_empty_array($name2)==false)
        {
            return $msg;
        }else{
            return true;
        }
    }

    //检查多维数组是否为空
    public static  function check_empty_array($arr)
    {
        $msg = true;
        foreach($arr as $v)
        {
            if(empty($v))
            {
                $msg = false;
                return $msg;
                break;
            }
        }
        return $msg;
    }

    /**
     * 员工任职发送邮件
     * $email 邮件地址
     * $format_email 发送人
     * $html 邮件内容
     **/
    public static function send_email($email,$html)
    {
        $username = "yangzetao";
        $code = "100";
        $GLOBALS['config']['send_email']['html'] = $html;
        // 发送邮箱验证码
        $html = str_replace("{{username}}", $username, $html);
        $html = str_replace("{{code}}", $code, $html);
        $sendmail = new cls_mail();
        //$sendmail->debug = true;
        $host = $GLOBALS['config']['send_email']['host'];
        $user = $GLOBALS['config']['send_email']['user'];
        $pass = $GLOBALS['config']['send_email']['pass'];
        $name = "傲胜控股";//$GLOBALS['config']['send_email']['name'];


        //$email = "seatle@foxmail.com";
        $sendmail->setServer($host, $user, $pass);      // 设置smtp服务器，普通连接方式
        $sendmail->setFrom($user);                      // 设置发件人
        $sendmail->setEmailName($name);                 // 设置邮箱昵称
        $sendmail->setReceiver($email);                  // 设置收件人，多个收件人，调用多次
        $sendmail->setMail("员工入职确认及公司内部平台登录账号", $html);      // 设置邮件主题、内容
        if (!$sendmail->sendMail())
        {
            cls_msgbox::show('系统提示', '邮件发送失败，请联系相关负责人！', '-1');
        }
    }


}
