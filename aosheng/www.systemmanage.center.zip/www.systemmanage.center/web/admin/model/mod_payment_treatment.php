<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 待遇模块
 *
 * Created by PhpStorm.
 * User: leita
 * Date: 2018/3/17
 * Time: 上午11:26
 * Function: {
 *    exit_ 带有此前缀的执行完本方法都不再往下执行
 *    exit_page_ 展示html页面并exit不再往下执行
 *    display_ 与页面数据展示相关
 *    count_ 与页面需计算的数据相关
 *    outside_ 来自其它模块的数据或外界的数据
 *    array_ 与数组相关的数据
 * }
 */
class mod_payment_treatment
{
    static $travel_types = [ 1=>'商旅交通', 2=>'商旅住宿', -1=>'其他' ];
    static $rule_travel = [
        'name'=>[ 'required'=>'', 'maxlength'=>[ 'length'=>20 ] ],
        'type'=>[ 'required'=>'' ],
    ];
    static $rule_life = [
        'name'=>[ 'required'=>'', 'maxlength'=>[ 'length'=>20 ] ],
        'type'=>[ 'required'=>'' ],
    ];

    public static function outside_treat_types($is_all=false)
    {
        static $types;
        if(empty($types))
        {
            if($is_all){
                $types = mod_base_type::get_bussiness_treatment_list();
            }else{
                $types = mod_base_type::get_bussiness_treatment();
            }
        }

        return $types;
    }

    public static function outside_life_types()
    {
        static $types;
        if(empty($types))
        {
            $types = mod_base_type::get_living_treatment();
        }

        return $types;
    }

    //等级修改相关
    public static function outside_levels()
    {
        static $levels;
        if(empty($levels))
        {
            $xing_levels = db::select('id,level,level_name,level_short_name')->from(mod_table::xing)->where('delete_user','=',0)->execute();
            $zu_levels = db::select('id,level,level_name,level_short_name')->from(mod_table::zuzi)->where('delete_user','=',0)->execute();
            $levels = [
                'xing'=>$xing_levels,
                'zuzi'=>$zu_levels
            ];
        }

        return $levels;
    }

    public static function array_levels()
    {
        $levels = self::outside_levels();
        $xing_levels = $zu_levels = [];

        foreach ($levels as $key=>$child_level)
        {
            foreach ($child_level as $level)
            {
                if($key=='xing')
                {
                    $xing_levels[] = [
                        'id'=>$level['id'],
                        'name'=>$level['level_name']
                    ];
                }elseif($key=='zuzi')
                {
                    $zu_levels[] = [
                        'id'=>$level['id'],
                        'name'=>$level['level_short_name']
                    ];
                }
            }

        }

        return [$xing_levels,$zu_levels];
    }

    public static function display_travel_type($row)
    {
        if($row['type']==-1)
        {
            return $row['type_other'];
        }else{
            $travel_types = self::$travel_types;
            $type_display = isset($travel_types[$row['type']]) ? $travel_types[$row['type']] : '';

            return $type_display;
        }
    }

    public static function display_travel_items($travel_id,$return_array=false)
    {
        $item_display = '';
        $desc_array = [];
        $result_array = [];
        $treat_types = self::outside_treat_types();

        $items = db::select('desc,type_id')->from(mod_table::treatment_travel_item)->where('travel_id','=',$travel_id)->execute();
        if($items)
        {
            foreach ($items as $item)
            {
                $type = isset($treat_types[$item['type_id']]) ? $treat_types[$item['type_id']] : '未知';
                $desc_array[] = "{$type}: {$item['desc']}";
                $result_array[] = [
                    'type_id'=>$item['type_id'],
                    'type'=>$type,
                    'desc'=>$item['desc']
                ];
            }
        }

        if($return_array){
            return $result_array;
        }
        !empty($desc_array) && $item_display = implode('<br>',$desc_array);

        return $item_display;
    }

    public static function display_travel_levels($travel_id,$return_array=false)
    {
        $level_display = '';
        $desc_array = [
            'xing' => [],
            'zu' => [],
            'xing_vals' =>'',
            'zu_vals' =>'',
        ];
        $fields = 'id,level_id,level_type';
        $levels = db::select($fields)->from(mod_table::treatment_travel_level)->where('travel_id','=',$travel_id)->execute();

        if($levels)
        {
            foreach ($levels as $level)
            {
                if ($level['level_type'] == 0) {
                    $one = db::select('id,level,level_name')->from(mod_table::xing)->where('id','=',$level['level_id'])->as_row()->execute();
                    $desc_array['xing'][] = $one['level_name'];
                    $desc_array['xing_vals'] .= ($desc_array['xing_vals']=='' ? '' : ',') . $one['id'];
                } else {
                    $one = db::select('id,level,level_name')->from(mod_table::zuzi)->where('id','=',$level['level_id'])->as_row()->execute();
                    $desc_array['zu'][] = $one['level_name'];
                    $desc_array['zu_vals'] .= ($desc_array['zu_vals']=='' ? '' : ',') . $one['id'];
                }
            }
        }


        if ($return_array) {//返回数组
            return $desc_array;
        }

        if (!empty($desc_array)) {
            !empty($desc_array['xing']) && $level_display .= '行政等级：' . implode("，", $desc_array['xing']);
            !empty($desc_array['zu']) && $level_display .= ($level_display ? '<br>' : '') . '组织等级：' . implode("，", $desc_array['zu']);
        }

        return $level_display;
    }


    public static function display_life_items($life_id,$return_array=false)
    {
        $item_display = '';
        $desc_array = [];
        $result_array = [];
        $treat_types = self::outside_life_types();

        $items = db::select('desc,type_id')->from(mod_table::treatment_life_item)->where('life_id','=',$life_id)->execute();
        if($items)
        {
            foreach ($items as $item)
            {
                $type = isset($treat_types[$item['type_id']]) ? $treat_types[$item['type_id']] : '未知';
                $desc_array[] = "{$type}: {$item['desc']}";
                $result_array[] = [
                    'type_id'=>$item['type_id'],
                    'type'=>$type,
                    'desc'=>$item['desc']
                ];
            }
        }


        if($return_array){
            return $result_array;
        }
        !empty($desc_array) && $item_display = implode('<br>',$desc_array);

        return $item_display;
    }

    public static function display_life_levels($life_id,$return_array=false)
    {
        $level_display = '';
        $desc_array = [
            'xing' => [],
            'zu' => [],
            'xing_vals' => '',
            'zu_vals' => ''
        ];
        $levels = db::select('id,level_id,level_type')->from(mod_table::treatment_life_level)->where('life_id','=',$life_id)->execute();

        if($levels)
        {
            foreach ($levels as $level) {
                if ($level['level_type'] == 0) {
                    $one = db::select('id,level,level_name')->from(mod_table::xing)->where('id','=',$level['level_id'])->as_row()->execute();
                    $desc_array['xing'][] = $one['level_name'];
                    $desc_array['xing_vals'] .= ($desc_array['xing_vals']=='' ? '' : ',') . $one['id'];
                } else {
                    $one = db::select('id,level,level_name')->from(mod_table::zuzi)->where('id','=',$level['level_id'])->as_row()->execute();
                    $desc_array['zu'][] = $one['level_name'];
                    $desc_array['zu_vals'] .= ($desc_array['zu_vals']=='' ? '' : ',') . $one['id'];
                }
            }
        }



        if ($return_array) {//返回数组
            return $desc_array;
        }

        if (!empty($desc_array)) {
            !empty($desc_array['xing']) && $level_display .= '行政等级：' . implode("，", $desc_array['xing']);
            !empty($desc_array['zu']) && $level_display .= ($level_display ? '<br>' : '') . '组织等级：' . implode("，", $desc_array['zu']);
        }

        return $level_display;
    }
}
