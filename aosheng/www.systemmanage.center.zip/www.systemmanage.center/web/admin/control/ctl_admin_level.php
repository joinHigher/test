<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 行政等级管理
 *
 * @version $Id$
 */
class ctl_admin_level
{


    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $this->table = '#PB#_admin_level';
        $this->baseUrl = '?ct=admin_level&ac=index';
        $this->level = mod_organize_level::get_config_level('admin_level');
        $this->where = [
            ['delete_user', '=', '0'],
            ['delete_time', '=', '0']
        ];
        tpl::assign('level', $this->level);
    }

    /**
    *
     * @desc 列表页
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 20);
        $even = req::item('even', 'add');

        if(!empty($keyword))
        {
            $this->where[] = array('level_name', 'like', "%{$keyword}%");
        }
        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();

        $pages = pub_page::make($row['count'], $page_size);
        $list  = db::select("id,level,level_name,level_short_name")->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('id','asc')->execute();

        tpl::assign('even', $even);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('admin_level.index.tpl');
    }

    /**
     * 增加等级
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;

            if (empty($data['level'])) cls_msgbox::show('系统提示', '请选择行政等级','-1');
            if (empty($data['level_name'])) cls_msgbox::show('系统提示', '请填写等级名称','-1');
            $this->where[] = array('level_name', '=', $data['level_name']);
            $row  = db::select('id')->from($this->table)->where($this->where)->as_row()->execute();

            if (!empty($row))
            {
                cls_msgbox::show('系统提示', '等级名称已存在，请修改','-1');
            }

            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['create_time'] = time();
            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加了行政等级 ID 为{$insert_id}的记录");
            $gourl = req::item('gourl', "?ct=admin_level&ac=add");
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }else
        {
            tpl::display('admin_level.add.tpl');
        }

    }

    /**
     * 编辑等级
     **/
    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            $this->where[] = ['level_name', '=', $data['level_name']];
            $this->where[] = ['id','!=',$id];

            $post_info  = db::select('id')->from($this->table)->where($this->where)->as_row()->execute();
            if (!empty($post_info)) cls_msgbox::show('系统提示', "级别名称已经存在,请换别的名称！", '-1');

            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();

            db::update($this->table)
                ->set($data)
                ->where('id', '=', $id)
                ->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了行政级别ID为{$id}的数据");
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }else
        {
            $this->where[] = ['id','=',$id];
            $row = db::select('id,level,level_name,level_short_name')->from($this->table)->where($this->where)->as_row()->execute();
            tpl::assign('row', $row);
            tpl::display('admin_level.edit.tpl');
        }
    }
    /**
     * @desc 删除等级
     */
    public function del()
    {
        $id = req::item('id', 0);
        $delete_arr = array
        (
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );
        db::update($this->table, $delete_arr, "`id` = '{$id}' ");
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "行政级别ID为{$id}被删除");
        $gourl =$this->baseUrl;
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

}
