<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 区域薪酬管理
 *
 * @version $Id$
 */
class ctl_payment_area
{
    public $page_size = 10;
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $area_tops = mod_area::get_api_name();
        if(empty($area_tops))
        {
            mod_common::log_line(__CLASS__,__FUNCTION__,'$area_tops is empty');
        }
        $area_tops = mod_array::one_array($area_tops,['id','short_name']);
        tpl::assign('area_tops',$area_tops);

        tpl::assign('creator',mod_payment::get_creator());
        tpl::assign('create_time',time());
    }

    //列表
    public function make_list()
    {
        $country = req::get('country');

        $where = [
            ["delete_user", '=', 0]
        ];
        if($country)
        {
            $country_id = db::select('id')->from(mod_table::area)->where('short_name','like',"$country%")->as_field()->execute();
            !empty($country_id) && $where[] = ["country_id",'=', $country_id];
        }

        $count = db::select('count(*)')->from(mod_table::payment_area)->where($where)->as_field()->execute();
        $pages = pub_page::make($count, $this->page_size);
        $fields = 'id,country_id,organ_ids,create_user,create_time';
        $rows = db::select($fields)->from(mod_table::payment_area)->where($where)->order_by('id','asc')->limit($pages['page_size'])->offset($pages['offset'])->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                $row_area = db::select('name,short_name')->from(mod_table::area)->where('id','=',$row['country_id'])->as_row()->execute();
                $row['country'] = $row_area['short_name'];

                //机构
                $row['organ_display'] = '';
                if($row['organ_ids'])
                {
                    $organ_ids = explode(',',$row['organ_ids']);
                    $organ_rows = db::select('name')->from(mod_table::organization)->where('id','in',$organ_ids)->execute();
                    if($organ_rows)
                    {
                        $organ_names = mod_array::one_array($organ_rows,[0,'name']);
                        $row['organ_display'] = mod_array::implode_cut('、', $organ_names, 3, '等{count}个机构');
                    }
                }

                //区域
                $row['city_display'] = '';
                $city_rows = db::select('country_id')->from(mod_table::payment_area_pay)->where('area_id','=',$row['id'])
                    ->group_by('country_id')->execute();

                if($city_rows)
                {
                    $city_ids = mod_array::one_array($city_rows,[0,'country_id']);
                    $citys = db::select('short_name')->from(mod_table::area)->where('id','in',$city_ids)->execute();
                    $citys = mod_array::one_array($citys,[0,'short_name']);
                    $row['city_display'] = mod_array::implode_cut('、', $citys, 3, '等{count}个国家的区域');
                }
            }
        }


        tpl::assign('country',$country);
        tpl::assign('rows', $rows);
        tpl::assign('pages', $pages['show']);
        tpl::display('payment_area.'.__FUNCTION__.'.tpl');
    }

    //区域薪酬详情
    public function detail()
    {
        $id = req::get('id',0,'int');

        $fields = 'id,country_id,organ_ids,create_user,create_time';
        $row = db::select($fields)->from(mod_table::payment_area)->where('id','=',$id)->as_row()->execute();
        if(empty($row))
        {
            mod_common::exit_page_404();
        }

        $row['country'] = db::select('short_name')->from(mod_table::area)->where('id','=',$row['country_id'])->as_field()->execute();

        //机构
        $row['organ_display'] = '';
        if($row['organ_ids'])
        {
            $organ_ids = explode(',',$row['organ_ids']);
            $organ_rows = db::select('name')->from(mod_table::organization)->where('id','in',$organ_ids)->execute();
            if($organ_rows){
                $organ_names = mod_array::one_array($organ_rows,[0,'name']);
                $row['organ_display'] = implode(' ', $organ_names);
            }
        }

        //区域薪酬表格
        $fields = 'country_id,province_id,city_id,deep,payment_percent';
        $area_pays = db::select($fields)->from(mod_table::payment_area_pay)->where('area_id','=',$id)->execute();
        if($area_pays){
            foreach ($area_pays as &$area_pay)
            {
                $area_pay['display_city'] = mod_payment_area::display_city($area_pay);
            }
        }

        $row['create_time'] = date('Y-m-d H:i:s',$row['create_time']);

        tpl::assign('row',$row);
        tpl::assign('area_pays',$area_pays);
        tpl::display('payment_area.'.__FUNCTION__.'.tpl');
    }

    //删除区域薪酬
    public function delete()
    {
        $id = req::get('id',0,'int');

        db::update(mod_table::payment_area)->set([
            'delete_user'=>cls_auth::$user->fields['uid'],
            'delete_time'=>time()
        ])->where("id",'=',$id)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除区域薪酬 ID={$id}");

        $gourl = req::item('gourl', '?ct=payment_area&ac=make_list');
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    //添加区域薪酬
    public function create()
    {
        if (!empty(req::$posts))
        {
            $data = [
                'country_id' => req::post('country_id'),
                'organ_ids' => req::post('organ_ids'),
                'create_user' => cls_auth::$user->fields['uid'],
                'create_time' => time()
            ];

            mod_form::validate(mod_payment_area::$rule);

            db::begin_tran();
            list($area_id, ) = db::insert(mod_table::payment_area)->set($data)->execute();

            //区域薪酬信息
            $items = isset(req::$posts['payment']) ? req::$posts['payment'] : [];
            if($items)
            {
                foreach ($items as &$item)
                {
                    //country_id,province_id,city_id 已有
                    empty($item['province_id']) && $item['province_id'] = 0;
                    empty($item['city_id']) && $item['city_id'] = 0;
                    $item['area_id'] = $area_id;
                    $item['create_user'] = cls_auth::$user->fields['uid'];
                    $item['create_time'] = time();

                    $item = array_values($item);
                }

                $columns = ['country_id','province_id','city_id','deep','payment_percent','area_id','create_user','create_time'];
                db::insert(mod_table::payment_area_pay)->columns($columns)->values($items)->execute();
            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加区域薪酬 ID={$area_id}");

            db::commit();


            $gourl = req::item('gourl', '?ct=payment_area&ac=make_list');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else
        {

            tpl::display('payment_area.'.__FUNCTION__.'.tpl');
        }
    }

    //修改区域薪酬
    public function edit()
    {
        if (!empty(req::$posts))
        {
            $id = req::post('id',0,'int');
            if(empty($id))
            {
                cls_msgbox::show('系统提示', '找不到相关数据，请核对再执行', '-1');
            }

            db::begin_tran();

            $data = [
                'country_id' => req::post('country_id',0,'int'),
                'organ_ids' => req::post('organ_ids'),
                'update_user' => cls_auth::$user->fields['uid'],
                'update_time' => time()
            ];

            db::update(mod_table::payment_area)->set($data)->where("id",'=',$id)->execute();

            //区域薪酬信息
            $items = isset(req::$posts['payment']) ? req::$posts['payment'] : [];
            if($items)
            {
                foreach ($items as &$item)
                {
                    $item['area_id'] = $id;
                    $item['create_user'] = cls_auth::$user->fields['uid'];
                    $item['create_time'] = time();
                }

                db::delete(mod_table::payment_area_pay)->where('area_id','=',$id)->execute();
                $columns = array_keys(current($items));
                db::insert(mod_table::payment_area_pay)->columns($columns)->values($items)->execute();
            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改区域薪酬 ID={$id}");

            db::commit();


            $gourl = req::item('gourl', '?ct=payment_area&ac=make_list');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else
        {
            $id = req::get('id',0,'int');

            $fields = 'id,country_id,organ_ids,create_user,create_time';
            $row = db::select($fields)->from(mod_table::payment_area)->where('id','=',$id)->as_row()->execute();
            if (empty($row))
            {
                mod_common::exit_page_404();
            }

            //区域薪酬表格
            $fields = 'country_id,province_id,city_id,deep,payment_percent';
            $area_pays = db::select($fields)->from(mod_table::payment_area_pay)->where('area_id','=',$id)->execute();
            if($area_pays)
            {
                foreach ($area_pays as &$area_pay)
                {
                    $area_pay['display_city'] = mod_payment_area::display_city($area_pay);
                    $id_array = array_filter([$area_pay['country_id'], $area_pay['province_id'], $area_pay['city_id']]);
                    $area_pay['id_bunch'] = implode('_',$id_array);
                }
            }


            $row['organ_items'] = [];
            if($row['organ_ids']) {
                $organ_ids = explode(',',$row['organ_ids']);
                $row['organ_items'] = db::select('id,name')->from(mod_table::organization)->where('id','in',$organ_ids)->execute();
            }

            tpl::assign('area_index',count($area_pays));
            tpl::assign('row',$row);
            tpl::assign('area_pays',$area_pays);
            tpl::display('payment_area.'.__FUNCTION__.'.tpl');
        }
    }

    //批量添加区域薪酬
    public function create_batch()
    {
        if(req::$posts)
        {
            mod_form::validate(mod_payment_area::$rule);

            db::begin_tran();

            $data = [
                'country_id' =>req::post('country_id'),
                'organ_ids'  =>req::post('organ_ids'),
                'create_user'=>cls_auth::$user->fields['uid'],
                'create_time'=>time()
            ];
            list($area_id,) = db::insert(mod_table::payment_area)->set($data)->execute();

            db::commit();


            db::begin_tran();
            //原先cloud生成的json数组
            $json_area_data = isset(req::$posts['json_area_data']) ? req::$posts['json_area_data'] : [];
            $json_areas = json_decode($json_area_data);

            //读取excel文件并生成薪酬数据
            $file_info = isset(req::$posts['fileinfo']) ? req::$posts['fileinfo'] : [];
            if($file_info && $json_area_data)//在有选择办公区域和上传文件时才执行
            {
                $sheet_file = $file_info[0];
                $excel = new mod_excel();
                //这里读取时乎略了标题直接往下取
                $excel_data = $excel->read_ignore_title($sheet_file);

                $result_data = [];
                foreach ($json_areas as $key=>$json_area)
                {
                    $result_data[] = [
                        'area_id' => $area_id,
                        'country_id' => $json_area[0],
                        'province_id' => $json_area[1],
                        'city_id' => $json_area[2],
                        'payment_percent' => ($excel_data[$key][4] * 100),//根据键索引取得相关比例值
                        'deep' => count(array_filter($json_area)),
                        'create_user' => cls_auth::$user->fields['uid'],
                        'create_time' => time()
                    ];
                }

                $columns = array_keys(current($result_data));
                db::insert(mod_table::payment_area_pay)->columns($columns)->values($result_data)->execute();

                cls_auth::save_admin_log(cls_auth::$user->fields['username'], "批量添加区域薪酬 ID={$area_id}");

                db::commit();
            }else{
                //没上传文件则回滚
                db::rollback();
            }

            $gourl = req::item('gourl', '?ct=payment_area&ac=make_list');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }


        tpl::display('payment_area.'.__FUNCTION__.'.tpl');
    }

    public function ajax_save_excel()
    {
        $id = req::post('id',0,'int');
        $region_data = isset(req::$posts['region']) ? req::$posts['region'] : [];

        //保存未有比例值区域excel文件
        //这里由json组成正确格式的数组，所以这里不用做处理可直接生成excel表格
        if($region_data)
        {
            $write_data = [
                [ '序号', '国家' , '省份', '城市', '比例' ]
            ];
            foreach ($region_data as $region)
            {
                $fiter_region = array_filter($region);
                $num_id = count($fiter_region)==1 ? $region[0] : ( count($fiter_region)==2 ? $region[1] : $region[2] );

                $region_ids = implode(',',$region);
                $sql = "select id,short_name from ".mod_table::area." where id IN($region_ids)";
                $regions = db::get_all($sql);
                $region = mod_array::one_array($regions,[0,'short_name']);
                $region = array_merge([$num_id], array_pad($region,4,''));

                $write_data[] = $region;
            }


            $excel_file = 'excel_'.date('Ymd-His');
            $excel = new mod_excel();
            $excel->createRows($write_data);
            $excel->save($excel_file);

            exit(json_encode(['excel_file'=>'/uploads/tmp/'.$excel_file.'.xlsx']));
            /*$excel->createRows([
                [ '序号', '国家' , '省份', '城市', '比例' ],//第一行 可以算是标题行
                [ '122356', '中国', '广东', '深圳' ''],//第二行 内容
                [ '245879', '中国', '广东', '广州' ''],//第三行 内容
            ]);
            $excel->save('tmp111');*/
        }

    }

}
