<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构管理.
 *
 * @version $Id$
 */
class ctl_station
{
    public static $station_prefix = 'P';
    /**
     * 岗位状态.
     */
    public static $status_options = array(
        '' => '请选择',
        '1' => '正常',
        '2' => '删除',
    );

    /**
     * 岗位类型.
     */
    public static $type_options = array(
        '' => '请选择',
        '1' => '员工岗',
        '2' => '委员岗',
        '3' => '兼职岗',
        '4' => '实际岗',
    );

    /**
     * 岗位等级
     */
    public static $nation_options;

    /**
     * 学历类型.
     */
    public static $education_options = array(
        '1' => '高中',
        '2' => '中专',
        '3' => '大专',
        '4' => '本科',
        '5' => '硕士',
        '6' => '博士',
    );

    /**
     * 部门状态.
     */
    public static $station_status_options = array(
        '1' => '正常',
        '2' => '删除',
    );

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $nation_options = $this->get_nation_options();
        self::$nation_options = $nation_options;
        tpl::assign( 'type_options', self::$type_options);
        tpl::assign( 'education_options', self::$education_options);
        tpl::assign( 'nation_options', self::$nation_options);
    }

    /**
     * 获取组织等级.
     */
    private function get_level_options()
    {
        return mod_organize_level::instance()->get_level_options();
    }

    /**
     * 获取国家数据.
     */
    private function get_nation_options()
    {
        return mod_area::get_level_area();
    }

    /**
     * 获取业务属性.
     */
    private function get_tag_options($org_id = 0)
    {
        return mod_operation_tag::instance()->get_tag_options(array(), $org_id);
    }

    /**
     * 岗位列表.
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $organization_id = req::item('organization_id', 0, 'int');
        $power = req::item('power', 0, 'int');
        $type = req::item('type', '', 'string');
        $page_size = req::item('page_size', 10);

        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = '%'.$keyword.'%';
        }

        if (!empty($organization_id)) {
            $condition['organization_id'] = $organization_id;
        }

        if ($type=='delete') {
            $condition['delete_user >'] = 0;
        } else {
            $condition['delete_user'] = 0;
        }

        $count = mod_station::instance()->count($condition);
        $pages = pub_page::make($count, $page_size);
        $list = mod_station::instance()->get_list_data($condition, '', 'id', "{$pages['offset']}, {$pages['page_size']}", 'id desc');
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `name`');

        // 所属室\会.
        $station_id_arr = array_keys($list);
        $committee_data = mod_department::get_job_room_committees($station_id_arr);

        if (!empty($list)) {
            $department_id_arr = array_column($list, 'department_id');
            $user_id_arr = array_column($list, 'create_user');
        }

        // 组织等级.
        $level_data = array();
        $level_id_arr = array_column($list, 'level_id');
        if (!empty($level_id_arr)) {
            $level_id_arr = array_unique($level_id_arr);
            $level_data = mod_organize_level::instance()->get_level_options($level_id_arr);
        }

        // 所属部门.
        $department_data = array();
        if (!empty($department_id_arr)) {
            $department_id_arr = array_unique($department_id_arr);
            $department_data = mod_department::instance()->get_department_options($department_id_arr);
        }

        // 数据写入作者.
        $admin_options = array();
        if (!empty($user_id_arr)) {
            $user_id_arr = array_unique($user_id_arr);
            $admin_options = mod_admin::instance()->get_admin_option($user_id_arr);
        }
        // 获取任务领取人名称.
        foreach ($list as $key=>$value) {
            $list[$key]['creator'] = isset($admin_options[$value['create_user']]) ? $admin_options[$value['create_user']] : '';
            $list[$key]['type'] = isset(self::$type_options[$value['type']]) ? self::$type_options[$value['type']] : '';
            $list[$key]['department_id'] = isset($department_data[$value['department_id']]) ? $department_data[$value['department_id']] : '';
            $list[$key]['level_id'] = isset($level_data[$value['level_id']]) ? $level_data[$value['level_id']] : '';
            $list[$key]['is_delete'] = ($value['delete_user'] == 0)? self::$station_status_options[1] : self::$station_status_options[2];
            $list[$key]['on_duty_num'] = mod_station_list::instance()->count(array('station_id' => $value['id'], 'delete_user' => 0, 'member_id >' => 0));
            $committee_tmp = array_merge($committee_data[$key]['committees'], $committee_data[$key]['rooms']);
            $list[$key]['committee_string'] = implode(',', $committee_tmp);
        }

        tpl::assign('index', 'org_station');
        tpl::assign('list', $list);
        tpl::assign('type', $type);
        tpl::assign('power', $power);
        tpl::assign('organizations', $organizations);
        tpl::assign('keyword', $keyword);
        tpl::assign('pages', $pages['show']);
        tpl::assign('organization_id', $organization_id);
        if (empty($type)) {
            tpl::display('station.index.tpl');
        } else {
            tpl::display('station.index.all.tpl');
        }

    }

    /**
     * 岗位详情.
     */
    public function detail()
    {
        $id = req::item('id', 0, 'int');
        $type = req::item('type', '', 'string');
        // 是否从部门岗位过来.
        $from_department_id = req::item('from_department_id', 0, 'int');
        $page_size = req::item('page_size', 10);
        $page_no = req::item('page_no', 0, 'int');
        if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 岗位数据.
        $station = mod_station::instance()->get_one_data(array('id' => $id));
        if (empty($station)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 业务属性.
        if (!empty($station['business_tag'])) {
            $tag_arr = explode(',', $station['business_tag']);
            $tag_data = mod_operation_tag::instance()->get_tag_options($tag_arr);
            $station['business_tag'] = implode(',', $tag_data);
        }
        if (!empty($station['business_leader'])) {
            $station['business_leader'] = json_decode($station['business_leader'], true);
        }
        if (!empty($station['business_link'])) {
            $station['business_link'] = json_decode($station['business_link'], true);
        }

        // 上级岗位.
        if (!empty($station['superior'])) {
            $super_data_tmp = mod_station::instance()->get_one_data(array('id' => $station['superior']), '`id`,`name`');
            $station['superior'] = $super_data_tmp['name'];
        } else {
            $station['superior'] = '';
        }

        // 所属室\会.
        $committee_data = mod_department::get_job_room_committee(array($id));
        $committee_tmp = array_merge($committee_data['committees'], $committee_data['rooms']);
        $station['committee_string'] = implode(',', $committee_tmp);

        // 组织等级
        $station['level_id'] = mod_organize_level::instance()->get_level_name($station['level_id']);

        $form_options = mod_post_type::instance()->get_type_options();
        // 岗位类型.
        isset($form_options[$station['form']]) ? ($station['form'] = $form_options[$station['form']]) : ($station['form'] = '');
        // 机构数据.
        $organization = mod_organization::instance()->get_one_data(array('id' => $station['organization_id']), '`id`, `name`');
        $station['organization_name'] = !empty($organization) ? $organization['name'] : '';
        // 部门数据.
        $department = mod_department::instance()->get_one_data(array('id' => $station['department_id']), '`id`, `name`');
        $station['department_name'] = !empty($department) ? $department['name'] : '';
        $station['type'] = isset(self::$type_options[$station['type']]) ? self::$type_options[$station['type']] : '';
        // 在职人员统计.
        $station_list_data = mod_station_list::instance()->count(
            array(
                'station_id' => $station['id'],
                'delete_user' => 0,
                'member_id >' => 0,
            )
        );

        //任职要求.
        $requirements = mod_station_requirements::instance()->get_one_data(array('station_id' => $station['id']), '', true);
        if (!empty($requirements)) {
            $nationArr = array();
            $nation_name = array();
            if (!empty($requirements['nation'])) {
                $nationArr = explode(',', $requirements['nation']);
            }
            foreach ($nationArr as $key => $value) {
                $nation_name[] = isset(self::$nation_options[$value]) ? self::$nation_options[$value] : '';
            }
            $nation_name = array_filter($nation_name);
            $requirements['education'] = isset(self::$education_options[$requirements['education']]) ? self::$education_options[$requirements['education']] : '';
            $requirements['secret_degree'] = mod_security_level::instance()->get_security_level_name($requirements['secret_degree']);
            $requirements['nation'] = implode(',', $nation_name);
            $requirements['part_time_name'] = '';
            if (!empty($requirements['part_time'])) {
                $part_time_arr = explode(',', $requirements['part_time']);
                $tmp = mod_station::instance()->get_list_data(array('id in' => $part_time_arr), '`id`,`name`');
                if (!empty($tmp)) {
                    $requirements['part_time_name'] = array_column($tmp, 'name');
                    $requirements['part_time_name'] = implode(',', $requirements['part_time_name']);
                }
            }
        }

        // 在岗人数.
        $station['num'] = mod_station_list::instance()->count(array('station_id' => $id, 'delete_user' => 0, 'member_id >' => 0));
        // 获取station_list数据.
        $num = mod_station_list::instance()->count(array('station_id' => $id, 'delete_user' => 0));
        $pages = pub_page::make($num, $page_size);
        $fields = "`id`, `code`, `external_name`, `member_id`, `station_id`";
        $station_list = mod_station_list::instance()->get_list_data(array('station_id' => $id, 'delete_user' => 0), $fields, '',"{$pages['offset']}, {$pages['page_size']}", 'id desc');
        $staff_ids = array();
        $station_ids = array();
        if (!empty($station_list)) {
            $staff_ids = array_column($station_list, 'member_id');
            $staff_ids = array_unique(array_filter($staff_ids));

            $station_ids = array_column($station_list, 'station_id');
            $station_ids = array_unique(array_filter($station_ids));
        }

        // 获取员工姓名数据.
        $staff_data = array();
        if (!empty($staff_ids)) {
            $staff_data = mod_member::instance()->get_list_data(array('id in' => $staff_ids), '`id`, `realname`', 'id');
        }

        // 岗位名称.
        $station_name_data = array();
        if (!empty($station_ids)) {
            $station_name_data = mod_station::instance()->get_list_data(array('id in' => $station_ids), '`id`, `name`', 'id');
        }

        // 组装员工姓名数据.
        array_walk(
            $station_list,
            function (&$value, $key) use($staff_data, $station_name_data) {
                isset($staff_data[$value['member_id']]) ? ($value['member_id'] = $staff_data[$value['member_id']]['realname']) : ($value['member_id'] = '');
                isset($station_name_data[$value['station_id']]) ? ($value['station_id'] = $station_name_data[$value['station_id']]['name']) : ($value['station_id'] = '');
            }
        );

        // 最低行政等级.
        $requirements['mini_level_id'] = mod_admin_level::instance()->get_admin_level_name($requirements['mini_level_id']);
        if (!empty($requirements['description'])) {
            $requirements['description'] = json_decode($requirements['description'], true);
        }

        $return_url = '?ct=station&ac=index&organization_id='.$station['organization_id'];
        if (!empty($type)) {
            $return_url = '?ct=station&ac=index&type='.$type;
        }
        // 从部门岗位列表过来.
        if (!empty($from_department_id)) {
            $return_url = "?ct=organization_company&ac=department_station&organization_id=".$station['organization_id']."&id={$from_department_id}&type={$type}";
        }

        tpl::assign('return_url', $return_url);
        tpl::assign('organization_id', $station['organization_id']);
        tpl::assign('station', $station);
        tpl::assign('delete_user', $station['delete_user']);
        tpl::assign('station_list_data', $station_list_data);
        tpl::assign('requirements', $requirements);
        tpl::assign('station_list', $station_list);
        tpl::assign('from_department_id', $from_department_id);
        tpl::assign('pages', $pages['show']);
        tpl::assign('page_no', $page_no);
        tpl::display('station.detail.tpl');
    }

    /**
     * 新建岗位.
     */
    public function add()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        // 部门岗位下面点击添加岗位,会传递过来.
        $href_department_id = req::item('href_department_id', 0, 'int');
        $type = req::item('type', '', 'string');
        // 是否是部门岗位下点击添加按钮.
        $department_add_type = req::item('department_add_type', '', 'string');
        if (!empty(req::$posts))
        {
            $description = array();
            $cache_text = array();
            foreach (req::$posts as $key => $value) {
                if (strpos($key,'-')) {
                    $pos = strpos($key, 'text-');
                    if ($pos !== false) {
                        $tmp = array();
                        $tt = explode('-', $key);
                        $tmp['name'] = array_pop($tt);
                        $tmp['value'] = $value;
                        $description[] = $tmp;
                        $cache_text[$tmp['name']] = $value;
                    }
                }
            }

            $station = array();
            $requirements = array();
            $time = time();
            $station_name = req::item('station_name', '', 'string');
            // 岗位名重复性检查.
            $count = mod_station::instance()->count(array('name' => $station_name));
            if (!empty($count)) {
                if (!empty($cache_text)) {
                    setcookie("require_text", json_encode($cache_text), time() + 3600);
                }
                cls_msgbox::show('系统提示', '该岗位名已存在', '-1');
                exit();
            }
            $select_organization_id = req::item('station_organization_id', 0, 'int');
            $station_business_tag = req::item('station_business_tag', array());
            $station_business_tag = array_unique($station_business_tag);
            $station_business_leader = req::item('station_business_leader', '{}', 'string');
            $station_business_link = req::item('station_business_link', '{}', 'string');
            // 岗位数据.
            $station['level_id'] = req::item('station_level', 0, 'int');
            $station['organization_id'] = empty($select_organization_id) ? $organization_id : $select_organization_id;
            $station['amount'] = req::item('station_amount', 0, 'int');
            $station['department_id'] = req::item('station_department_id', 0, 'int');
            $station['superior'] = req::item('superior', 0, 'int');
            $station['type'] = req::item('station_type', 0, 'int');
            $station['form'] = req::item('station_form', 0, 'int');
            $station['number'] = $this->get_station_number();
            $station['name'] = $station_name;
            $station['address'] = req::item('station_address', '', 'string');
            $station['caption'] = req::item('station_caption', '', 'string');
            $station['responsibility'] = req::item('station_responsibility', '', 'string');
            $station['business_tag'] = implode(',', $station_business_tag);
            $station['business_leader'] = $station_business_leader;
            $station['business_link'] = $station_business_link;
            $station['status'] = 1;
            $station['create_user'] = cls_auth::$user->fields['admin_id'];
            $station['update_user'] = cls_auth::$user->fields['admin_id'];
            $station['create_time'] = $time;
            $station['update_time'] = $time;
            if (!empty($station['level_id'])) {
                $station_level_data = mod_organize_level::instance()->get_one_data(array('id' => $station['level_id']), '`id`, `level`');
                $station['level'] = $station_level_data['level'];
            }

            $station_id = mod_station::instance()->insert_data($station);
            $url = req::item('gourl', '?ct=station&ac=index&organization_id='.$organization_id);
            if (empty($station_id)) {
                if (!empty($cache_text)) {
                    setcookie("require_text", json_encode($cache_text), time() + 3600);
                }
                cls_msgbox::show('系统提示', "添加失败", -1);
                exit();
            }

            // 生成岗位列表数据.
            if (!empty($station['amount']) && !empty($station['number'])) {
                $field_arr = array('code', 'organization_id', 'department_id', 'station_id', 'create_user', 'update_user', 'create_time', 'update_time');
                $insert_data = array();
                for ($i = 1; $i<=$station['amount'];  $i++) {
                    $tmp = [];
                    $tmp_number = $station['number'].'-'.'1'.str_pad($i, 4, "0", STR_PAD_LEFT);
                    $tmp[] = $tmp_number;
                    $tmp[] = $station['organization_id'];
                    $tmp[] = $station['department_id'];
                    $tmp[] = $station_id;
                    $tmp[] = cls_auth::$user->fields['admin_id'];
                    $tmp[] = cls_auth::$user->fields['admin_id'];
                    $tmp[] = $time;
                    $tmp[] = $time;
                    $insert_data[] = $tmp;
                }

                $result = mod_station_list::instance()->bath_insert($field_arr, $insert_data);
                if ($result == false) {
                    mod_station::instance()->delete_data(array('id' => $station_id));
                    if (!empty($cache_text)) {
                        setcookie("require_text", json_encode($cache_text), time() + 3600);
                    }
                    cls_msgbox::show('系统提示', "添加失败", -1);
                    exit();
                }
            }

            // 任职要求数据.
            $requirements_part_time = req::item('requirements_part_time', '');
            if (!empty($requirements_part_time)) {
                $requirements_part_time = json_decode($requirements_part_time, true);
                $requirements_part_time = array_column($requirements_part_time, 'id');
                $requirements_part_time = array_unique($requirements_part_time);
            }
            $requirements_nation = req::item('requirements_nation', '');
            $requirements['station_id'] = $station_id;
            $requirements['mini_level_id'] = req::item('requirements_mini_level', 0, 'int');
            $requirements['education'] = req::item('requirements_education', 0, 'int');
            $requirements['year'] = req::item('requirements_year', 0, 'int');
            $requirements['secret_degree'] = req::item('requirements_secret_degree', 0, 'int');
            $requirements['nation'] = !empty($requirements_nation) ? implode(',', $requirements_nation) : '';
            $requirements['certificate'] = req::item('requirements_certificate', '', 'string');
            $requirements['description'] = json_encode($description, JSON_UNESCAPED_UNICODE);
            $requirements['create_user'] = cls_auth::$user->fields['admin_id'];
            $requirements['update_user'] = cls_auth::$user->fields['admin_id'];
            $requirements['create_time'] = $time;
            $requirements['update_time'] = $time;
            if (!empty($requirements_part_time)) {
                $requirements['part_time'] = implode(',', $requirements_part_time);
            }
            // 最低行政等级.
            if (!empty($requirements['mini_level_id'])) {
                $level_data = mod_admin_level::instance()->get_one_data(array('id' => $requirements['mini_level_id']), '`id`, `level`');
                $requirements['mini_level'] = $level_data['level'];
            }
            $require_id = mod_station_requirements::instance()->insert_data($requirements);
            if (empty($require_id)) {
                mod_station::instance()->delete_data(array('id' => $station_id));
                if (!empty($cache_text)) {
                    setcookie("require_text", json_encode($cache_text), time() + 3600);
                }
                cls_msgbox::show('系统提示', "添加失败", -1);
                exit();
            }

            if (!empty($type)) {
                // 返回到创建操作动作页面.
                $url = '?ct=station&ac=add&type=all';
            }
            // 部门下添加岗位.
            if (!empty($department_add_type) && !empty($station['department_id'])) {
                // 返回部门下岗位列表.
                $url = "?ct=organization_company&ac=department_station&organization_id={$organization_id}&id={$station['department_id']}&type={$type}";
            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户添加岗位信息 {$station_id}");
            if (!empty($cache_text)) {
                setcookie("require_text", json_encode($cache_text), time() - 1);
            }
            cls_msgbox::show('系统提示', "添加成功", $url);
        }
        else
        {
            // 岗位编号.
            $number = $this->get_station_number();
            // 岗位类型.
            $form_options = mod_post_type::instance()->get_type_options();
            // 业务属性.
            $tags = $this->get_tag_options();
            // 归属部门
            $department = mod_department::instance()->get_department_options();
            if (!empty($organization_id)) {
                $department = mod_department::instance()->get_department_in_org(array($organization_id));
                $level_options = mod_organize_level::instance()->get_station_level_option_in_org($organization_id);
                $form_options = mod_post_type::instance()->get_type_option_in_org($organization_id);
                $tags = mod_operation_tag::instance()->get_tag_option_in_org($organization_id);
            }

            // 最低行政级别.
            $mini_level_data = mod_admin_level::instance()->get_admin_level_options();
            $superior_data = array();
            if (empty($type)) {
                $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`,`name`, `level`');
                $organization_name = !empty($organizations['name']) ? $organizations['name'] : '';
                // 上级岗位.
                $res = mod_station::instance()->get_list_data(array('organization_id' => $organization_id), '`id`,`name`');
                $superior_data = array_column($res, 'name', 'id');
                tpl::assign('organization_name', $organization_name);
            } else {
                $organization_options = mod_organization::instance()->get_list_data(array('status' => '1'), '`id`,`name`');
                $organization_options = array_column($organization_options, 'name', 'id');
                tpl::assign('organization_options', $organization_options);
            }

            // 选了部门, 组织等级不受机构的限制.
            $level_options = $this->get_level_options();
            // 没有选部门组织等级要受机构影响.
            if (empty($href_department_id)) {
                $res = $this->get_org_level($organization_id, $href_department_id);
                if ($res['status'] == 0) {
                    $level_options = $res['data'];
                }
            }
            $secret_degree_options = mod_security_level::instance()->get_security_level_options();

            tpl::assign( 'secret_degree_options', $secret_degree_options);
            tpl::assign( 'form_options', $form_options);
            tpl::assign('organization_id', $organization_id);
            tpl::assign('department', $department);
            tpl::assign('superior_data', $superior_data);
            tpl::assign('tags', $tags);
            tpl::assign('level_options', $level_options);
            tpl::assign('number', $number);
            tpl::assign('mini_level_data', $mini_level_data);
            tpl::assign('type', $type);
            tpl::assign( 'department_add_type', $department_add_type);
            tpl::assign('href_department_id', $href_department_id);
            tpl::display('station.add.tpl');
        }

    }

    /**
     * 获取岗位编号.
     */
    private function get_station_number()
    {
        // 岗位编号.
        $data = mod_station::instance()->get_list_data(array('1' => '1'), '`id`,`number`', '', 1, 'id desc');
        if (empty($data)) {
            $id = 1;
        } else {
            $data = $data[0];
            $number = substr($data['number'], 2, 5);
            $number = (int) $number;
            $id = $data['id'] + 1;
            if ($number >= $id) {
                $id = $number + 1;
            }
        }

        $number = self::$station_prefix.str_pad($id, 5, "0", STR_PAD_LEFT);

        return $number;
    }

    /**
     * 编辑岗位.
     */
    public function edit()
    {
        $station_id = req::item('id', 0, 'int');
        $organization_id = req::item('organization_id', 0, 'int');
        // 是否是部门岗位下点击添加按钮.
        $department_add_type = req::item('department_add_type', '', 'string');
        $type = req::item('type', '', 'string');
        if (empty($station_id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 岗位数据.
        $station_data = mod_station::instance()->get_one_data(array('id' => $station_id, 'delete_user' => 0), '', true);
        if (empty($station_data)) {
            cls_msgbox::show('系统提示', '未找到数据！', '-1');
            exit();
        }

        if (!empty($station_data['delete_user'])) {
            cls_msgbox::show('系统提示', '已删除的岗位不能被编辑！', '-1');
            exit();
        }

        if (!empty(req::$posts)) {
            $description = array();
            $cache_text = array();
            foreach (req::$posts as $key => $value) {
                if (strpos($key,'-')) {
                    $pos = strpos($key, 'text-');
                    if ($pos !== false) {
                        $tmp = array();
                        $tt = explode('-', $key);
                        $tmp['name'] = array_pop($tt);
                        $tmp['value'] = $value;
                        $description[] = $tmp;
                        $cache_text[$tmp['name']] = $value;
                    }
                }
            }

            $station = array();
            $requirements = array();
            $time = time();
            $station_name = req::item('station_name', '', 'string');
            // 岗位名重复性检查.
            $tmp = mod_station::instance()->get_one_data(array('name' => $station_name), 'id');
            if (!empty($tmp) && ($tmp['id'] != $station_id)) {
                if (!empty($cache_text)) {
                    setcookie("require_text", json_encode($cache_text), time() + 3600);
                }
                cls_msgbox::show('系统提示', '该岗位名已存在', '-1');
                exit();
            }
            $select_organization_id = req::item('station_organization_id', 0, 'int');
            $station_business_tag = req::item('station_business_tag', array());
            $station_business_tag = array_unique($station_business_tag);
            $station_business_leader = req::item('station_business_leader', '{}', 'string');
            $station_business_link = req::item('station_business_link', '{}', 'string');
            // 岗位数据.
            $station['level_id'] = req::item('station_level', 0, 'int');
            $station['organization_id'] = empty($select_organization_id) ? $organization_id : $select_organization_id;
            $station['amount'] = req::item('station_amount', 0, 'int');
            $station['department_id'] = req::item('station_department_id', 0, 'int');
            $station['superior'] = req::item('superior', 0, 'int');
            $station['type'] = req::item('station_type', 0, 'int');
            $station['form'] = req::item('station_form', 0, 'int');
            $station['name'] = $station_name;
            $station['address'] = req::item('station_address', '', 'string');
            $station['responsibility'] = req::item('station_responsibility', '', 'string');
            $station['business_tag'] = implode(',', $station_business_tag);
            $station['business_leader'] = $station_business_leader;
            $station['business_link'] = $station_business_link;
            $station['caption'] = req::item('station_caption', '', 'string');
            $station['status'] = 1;
            $station['update_user'] = cls_auth::$user->fields['admin_id'];
            $station['update_time'] = $time;
            if (!empty($station['level_id'])) {
                $station_level_data = mod_organize_level::instance()->get_one_data(array('id' => $station['level_id']), '`id`, `level`');;
                $station['level'] = $station_level_data['level'];
            }

            $result = mod_station::instance()->update_data($station, array('id' => $station_id));
            $url = req::item('gourl', '?ct=station&ac=detail&id='.$station_id.'&organization_id='.$organization_id);
            if ($result === false) {
                if (!empty($cache_text)) {
                    setcookie("require_text", json_encode($cache_text), time() + 3600);
                }
                cls_msgbox::show('系统提示', "更新岗位数据失败", -1);
                exit();
            }

            // 新增子岗位.
            if ($station['amount'] > $station_data['amount']) {
                $list_data = mod_station_list::instance()->get_list_data(array('station_id' => $station_id), '`id`,`code`', '', 1, 'id desc');
                $list_data = $list_data[0];
                $code = substr($list_data['code'],strpos($list_data['code'], '-')+2, strlen($list_data['code']));
                $code = (int) $code;

                $field_arr = array('code', 'organization_id', 'department_id', 'station_id', 'create_user', 'update_user', 'create_time', 'update_time');
                $increase_number = $station['amount'] - $station_data['amount'];
                $insert_data = array();
                $base_code = $this->get_station_number();
                for ($i = 1; $i<=$increase_number;  $i++) {
                    $tmp = [];
                    $base_number = $code + $i;
                    $tmp_number = $base_code.'-'.'1'.str_pad($base_number, 4, "0", STR_PAD_LEFT);
                    $tmp[] = $tmp_number;
                    $tmp[] = $station['organization_id'];
                    $tmp[] = $station['department_id'];
                    $tmp[] = $station_id;
                    $tmp[] = cls_auth::$user->fields['admin_id'];
                    $tmp[] = cls_auth::$user->fields['admin_id'];
                    $tmp[] = $time;
                    $tmp[] = $time;
                    $insert_data[] = $tmp;
                }

                $result = mod_station_list::instance()->bath_insert($field_arr, $insert_data);
                if ($result == false) {
                    if (!empty($cache_text)) {
                        setcookie("require_text", json_encode($cache_text), time() + 3600);
                    }
                    cls_msgbox::show('系统提示', "新增子岗位数据失败.", -1);
                    exit();
                }

            // 裁减子岗位数据, 需求更改, 不删除多余的岗位.
            } elseif (false && $station['amount'] < $station_data['amount']) {
                // 查看有人在岗的数据.
                $row_count = mod_station_list::instance()->count(array('station_id' => $station_id, 'member_id >' => 0));
                $deal_with_number = $row_count - $station['amount'];
                // 需要裁减自岗位数据.
                if ($deal_with_number > 0) {
                    // 按顺序裁减.
                    $deal_with_data = mod_station_list::instance()->get_list_data(array('station_id' => $station_id), 'id', '', $deal_with_number, 'id asc');
                    $id_arr = array_column($deal_with_data, 'id');
                    $update_data = array(
                        'delete_user' => cls_auth::$user->fields['admin_id'],
                        'delete_time' => time(),
                    );
                    $result = mod_station_list::instance()->update_data($update_data, array('id in' => $id_arr));
                    if ($result === false) {
                        if (!empty($cache_text)) {
                            setcookie("require_text", json_encode($cache_text), time() + 3600);
                        }
                        cls_msgbox::show('系统提示', "裁减子岗位数据失败", -1);
                        exit();
                    }
                }
            }

            // 改子岗位列表机构，部门属性.
            $update_station_list = array();
            $update_station_list['organization_id'] = $station['organization_id'];
            $update_station_list['department_id'] = $station['department_id'];
            mod_station_list::instance()->update_data($update_station_list, array('station_id' => $station_id));

            // 任职要求数据.
            $requirements_part_time = req::item('requirements_part_time', '');
            $requirements_part_time = json_decode($requirements_part_time, true);
            $requirements_part_time = array_column($requirements_part_time, 'id');
            $requirements_part_time = array_unique($requirements_part_time);
            $requirements_nation = req::item('requirements_nation', '');
            $requirements['station_id'] = $station_id;
            $requirements['mini_level_id'] = req::item('requirements_mini_level', 0, 'int');
            $requirements['education'] = req::item('requirements_education', 0, 'int');
            $requirements['year'] = req::item('requirements_year', 0, 'int');
            $requirements['secret_degree'] = req::item('requirements_secret_degree', 0, 'int');
            $requirements['nation'] = !empty($requirements_nation) ? implode(',', $requirements_nation) : '';
            $requirements['certificate'] = req::item('requirements_certificate', '', 'string');
            $requirements['description'] = json_encode($description, JSON_UNESCAPED_UNICODE);
            $requirements['update_user'] = cls_auth::$user->fields['admin_id'];
            $requirements['update_time'] = $time;
            if (!empty($requirements_part_time)) {
                $requirements['part_time'] = implode(',', $requirements_part_time);
            }

            // 最低行政等级.
            if (!empty($requirements['mini_level_id'])) {
                $level_data = mod_admin_level::instance()->get_one_data(array('id' => $requirements['mini_level_id']), '`id`, `level`');
                $requirements['mini_level'] = $level_data['level'];
            }
            $result = mod_station_requirements::instance()->update_data($requirements, array('station_id'=>$station_id));
            if ($result === false) {
                if (!empty($cache_text)) {
                    setcookie("require_text", json_encode($cache_text), time() + 3600);
                }
                cls_msgbox::show('系统提示', "更新岗位任职要求数据失败", -1);
                exit();
            }

            // 部门下添加岗位.
            if (!empty($department_add_type)) {
                // 返回部门下岗位列表.
                $url = "?ct=organization_company&ac=department_station&organization_id={$organization_id}&id={$station_data['department_id']}&type={$type}";
            }
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户更新岗位信息 {$station_id}");
            if (!empty($cache_text)) {
                setcookie("require_text", json_encode($cache_text), time() -1);
            }
            cls_msgbox::show('系统提示', "修改成功", $url);
        } else {
            // 归属部门
            $department = mod_department::instance()->get_department_options();
            if (!empty($organization_id)) {
                $department = mod_department::instance()->get_department_in_org(array($organization_id));
            }
            // 最低行政级别.
            $mini_level_data = mod_admin_level::instance()->get_admin_level_options();

            // 任职要求.
            $requirements_data = mod_station_requirements::instance()->get_one_data(array('station_id' => $station_data['id']), '', true);
            !empty($requirements_data['nation']) ? ($requirements_data['nation'] = explode(',', $requirements_data['nation'])) : null;
            $requirements_data['description'] = json_decode($requirements_data['description'], true);
            $requirements_data['part_time_name'] = array();
            if (!empty($requirements_data['part_time'])) {
                $requirements_data['part_time'] = explode(',', $requirements_data['part_time']);
                $tmp = mod_station::instance()->get_list_data(array('id in' => $requirements_data['part_time']), '`id`,`name`');
                $requirements_data['part_time_name'] = $tmp;
            }
            $requirements_data['part_time_name'] = json_encode($requirements_data['part_time_name']);

            // 业务属性.
            $tags = mod_operation_tag::instance()->get_tag_option_in_org($organization_id);
            if (!empty($station_data['business_tag'])) {
                $station_data['business_tag'] = explode(',', $station_data['business_tag']);
            }

            // 岗位类型.
            $form_options = mod_post_type::instance()->get_type_option_in_org($organization_id);
            // 上级岗位.
            $superior_data = mod_station::instance()->get_station_in_org(array($organization_id), $station_id);
            // 保密级别.
            $secret_degree_options = mod_security_level::instance()->get_security_level_options();
            // 组织等级.
            $level_options = array();
            $res = $this->get_org_level($organization_id, $station_data['department_id'], $station_data['superior'], $station_data['form']);
            if ($res['status'] == 0) {
                $level_options = $res['data'];
            }
            tpl::assign( 'secret_degree_options', $secret_degree_options);
            tpl::assign( 'station_id', $station_id);
            tpl::assign( 'department_add_type', $department_add_type);
            tpl::assign('mini_level_data', $mini_level_data);
            tpl::assign('level_options', $level_options);
            tpl::assign('tags', $tags);
            tpl::assign('form_options', $form_options);
            tpl::assign('department', $department);
            tpl::assign('station_data', $station_data);
            tpl::assign('superior_data', $superior_data);
            tpl::assign('requirements_data', $requirements_data);
            tpl::assign('organization_id', $organization_id);
            tpl::display('station.edit.tpl');
        }
    }


    /**
     * 子岗位详情.
     */
    public function station_list_detail()
    {
        $id = req::item('id', 0, 'int');
        $organization_id = req::item('organization_id', 0, 'int');
        if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 子岗位数据.
        $data = mod_station_list::instance()->get_one_data(array('id' => $id));
        if (empty($data)) {
            cls_msgbox::show('系统提示', '未找到数据！', '-1');
            exit();
        }
        $data['member_id'] = mod_member::instance()->get_member_name($data['member_id']);

        // 岗位名称.
        $data['station_name'] = mod_station::instance()->get_station_name($data['station_id']);

        // 分管机构.
        if (!empty($data['assigned_organization_id'])) {
            $data['assigned_organization_id'] = explode(',', $data['assigned_organization_id']);
            $organization = mod_organization::instance()->get_organization_options($data['assigned_organization_id']);
            $data['assigned_organization_id'] = implode(',', $organization);
        }

        // 分管部门.
        if (!empty($data['assigned_department_id'])) {
            $data['assigned_department_id'] = explode(',', $data['assigned_department_id']);
            $department = mod_department::instance()->get_department_options($data['assigned_department_id']);
            $data['assigned_department_id'] = implode(',', $department);
        }

        // 分管岗位.
        if (!empty($data['assigned_station_id'])) {
            $data['assigned_station_id'] = explode(',', $data['assigned_station_id']);
            $station = mod_station::instance()->get_station_options($data['assigned_station_id']);
            $data['assigned_station_id'] = implode(',', $station);
        }

        tpl::assign('organization_id', $organization_id);
        tpl::assign('data', $data);
        tpl::display('station_list.detail.tpl');
    }
    
    /**
     * 编辑子岗位.
     */
    public function edit_station_list()
    {
        $id = req::item('id', 0, 'int');
        $organization_id = req::item('organization_id', 0, 'int');
        if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 子岗位数据.
        $data = mod_station_list::instance()->get_one_data(array('id' => $id));
        if (empty($data)) {
            cls_msgbox::show('系统提示', '未找到数据！', '-1');
            exit();
        }
        if (!empty(req::$posts)) {
            $data = array();
            $time = time();
            $assigned_org_id = array_unique(req::item('assigned_org_id', array()));
            $assigned_department_id = array_unique(req::item('assigned_department_id', array()));
            $assigned_station_id = array_unique(req::item('assigned_station_id', array()));
            $data['arrival_time'] = strtotime(req::item('arrival_time', '', 'string'));
            $data['external_name'] = req::item('external_name', '', 'string');
            $data['description'] = req::item('description', '', 'string');
            $data['assigned_organization_id'] = implode(',', $assigned_org_id);
            $data['assigned_department_id'] = implode(',', $assigned_department_id);
            $data['assigned_station_id'] = implode(',', $assigned_station_id);
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = $time;

            $gourl = req::item('gourl', '?ct=station&ac=station_list_detail&id='.$id.'&organization_id='.$organization_id);
            $result = mod_station_list::instance()->update_data($data, array('id' => $id));
            if (empty($result) && ($result !== false)) {
                cls_msgbox::show('系统提示', "修改失败", $gourl);
                exit();
            }

            cls_msgbox::show('系统提示', "修改成功", $gourl);
        } else {
            // 员工名称.
            $data['member_id'] = mod_member::instance()->get_member_name($data['member_id']);

            // 岗位名称.
            $data['station_name'] = mod_station::instance()->get_station_name($data['station_id']);

            // 归属机构
            $organizations = mod_organization::instance()->get_organization_options();

            $department = array();
            $station = array();

            if (!empty($data['assigned_organization_id'])) {
                $data['assigned_organization_id'] = explode(',', $data['assigned_organization_id']);
            }
            if (!empty($data['assigned_department_id'])) {
                $data['assigned_department_id'] = explode(',', $data['assigned_department_id']);
                $department = mod_department::instance()->get_department_options($data['assigned_department_id']);
            }
            if (!empty($data['assigned_station_id'])) {
                $data['assigned_station_id'] = explode(',', $data['assigned_station_id']);
                $station = mod_station::instance()->get_station_options($data['assigned_station_id']);
            }

            
            tpl::assign('organization_id', $organization_id);
            tpl::assign('data', $data);
            tpl::assign('organizations', $organizations);
            tpl::assign('department', $department);
            tpl::assign('station', $station);
            tpl::display('station_list.edit.tpl');
        }

    }

    /**
     * 编辑子岗位时候,获取归属部门，岗位数据.
     */
    public function get_station_list_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'department' => array(),
            'station' => array(),
        );

        $org_id = req::item('org_id');
        if (empty($org_id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }
        $org_id = array_unique($org_id);

        // 归属部门
        $department = mod_department::instance()->get_department_in_org($org_id);

        // 归属岗位.
        $station = mod_station::instance()->get_station_in_org($org_id);

        $result['department'] = $department;
        $result['station'] = $station;

        echo json_encode($result);
    }

    /**
     * 删除子岗位.
     */
    public function delete_station_list()
    {
        $result = array(
            'status' => 0,
            'message' => '操作成功.',
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');
        $station_id = req::item('station_id', 0, 'int');

        if (empty($organization_id) || empty($id) || empty($station_id)) {
            $result['status'] = 2;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $station_list = mod_station_list::instance()->get_one_data(
            array(
                'id' => $id,
                'station_id' => $station_id,
                'organization_id' => $organization_id,
            ),
            '`id`, `member_id`'
        );
        if (empty($station_list)) {
            $result['status'] = 2;
            $result['message'] = '数据不存在';
            echo json_encode($result);
            exit();
        } elseif (!empty($station_list['member_id'])) {
            $result['status'] = 3;
            $result['message'] = '子岗位下存在工作人员, 不能删除.';
            echo json_encode($result);
            exit();
        }

        $data['delete_user'] = cls_auth::$user->fields['admin_id'];
        $data['delete_time'] = time();
        $res = mod_station_list::instance()->update_data($data, array('id' => $id, 'organization_id' => $organization_id));
        if ($res === false) {
            $result['status'] = 4;
            $result['message'] = '操作失败.';
            echo json_encode($result);
            exit();
        }

        echo json_encode($result);
    }

    /**
     * 删除岗位操作.
     */
    public function delete_station()
    {
        $result = array(
            'status' => 0,
            'message' => '更新成功.',
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');

        if (empty($organization_id) || empty($id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $count = mod_station_list::instance()->count(
            array(
                'station_id'  => $id,
                'delete_user' => 0,
                'member_id >' => 0
            )
        );
        if (!empty($count)) {
            $result['status'] = 2;
            $result['message'] = '该岗位包含正在使用的人员不能删除!';
            echo json_encode($result);
            exit();
        }

        $data['delete_user'] = cls_auth::$user->fields['admin_id'];
        $data['delete_time'] = time();
        $res = mod_station::instance()->update_data($data, array('id' => $id, 'organization_id' => $organization_id));
        if ($res === false) {
            $result['status'] = '2';
            $result['message'] = '更改失败.';
        }

        echo json_encode($result);
    }

    /**
     * 恢复岗位.
     */
    public function recover_station()
    {
        $result = array(
            'status' => 0,
            'message' => '恢复成功.',
        );
        
        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');

        if (empty($organization_id) || empty($id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');

        $data['delete_user'] = 0;
        $data['delete_time'] = 0;
        $res = mod_station::instance()->update_data($data, array('id' => $id, 'organization_id' => $organization_id));
        if ($res === false) {
            $result['status'] = '2';
            $result['message'] = '恢复失败.';
        }

        echo json_encode($result);
    }

    /**
     * 获取供兼职岗位选择的数据.
     */
    public function get_station_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'departments' => array(),
            'stations' => array(),
            'nav' => array(),
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $department_id = req::item('department_id', 0, 'int');
        if (empty($organization_id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }


        if (empty($department_id)) {
            // 第一次点击进来的.
            // 获取部门数据.
            $departments = mod_department::instance()->get_list_data(
                array(
                    'organization_id' => $organization_id,
                    'superior_id' => 0,
                    'delete_user' => 0,
                ),
                '`id`, `name`'
            );
            // 获取独立岗位数据.
            $stations = mod_station::instance()->get_list_data(
                array(
                    'organization_id' => $organization_id,
                    'department_id' => 0,
                    'delete_user' => 0,
                ),
                '`id`, `name`'
            );
        } else {
            // 点击部门获取这个部门下的子部门或者岗位.
            $nav = array();
            $departments = mod_department::instance()->get_list_data(
                array(
                    'organization_id' => $organization_id,
                    'superior_department_type' => 1,
                    'superior_id' => $department_id,
                    'delete_user' => 0,
                ),
                '`id`, `name`'
            );
            $stations = mod_station::instance()->get_list_data(
                array(
                    'organization_id' => $organization_id,
                    'department_id' => $department_id,
                    'delete_user' => 0
                ),
                '`id`, `name`'
            );

            $data = mod_department::instance()->get_one_data(array('id' => $department_id), '`id`, `name`, `superior_id`');
            if (!empty($data)) {
                $nav[] = array(
                    'id' => $data['id'],
                    'name' => $data['name'],
                );

                // 有上级.
                if (!empty($data['superior_id'])) {
                    $superior_id = $data['superior_id'];
                    do {
                        $tmp = mod_department::instance()->get_one_data(array('id' => $superior_id), '`id`, `name`, `superior_id`');
                        if (!empty($tmp))  {
                            $nav[] = array(
                                'id' => $tmp['id'],
                                'name' => $tmp['name'],
                            );

                            $superior_id = $tmp['superior_id'];
                        } else {
                            $superior_id = 0;
                        }

                    } while($superior_id > 0);
                }

                // 排序.
                if (!empty($nav)) {
                    $nav[] = array(
                        'id' => 0,
                        'name' => '首页',
                    );

                    $tmp_keys = array_keys($nav);
                    array_multisort($nav, $tmp_keys, SORT_DESC);
                }

                $result['nav'] = $nav;
            }

        }

        if (!empty($departments)) {
            $result['departments'] = $departments;
        }
        if (!empty($stations)) {
            $result['stations'] = $stations;
        }

        if (empty($nav)) {
            $result['nav'][] = array(
                'id' => 0,
                'name' => '首页',
            );
        }

        echo json_encode($result);
    }

    /**
     * 获取业务领导数据.
     */
    public function get_business_leader_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'departments' => array(),
            'stations' => array(),
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $except_station_id = req::item('except_station_id', 0, 'int');
        $tags = req::item('tags', array());
        if (empty($organization_id) && empty($tags)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        // 本机构.
        $superiors = array($organization_id);
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `superior`');
        // 直属上级机构.
        $superior_id = $organizations['superior'];
        do {
            $tmp = mod_organization::instance()->get_one_data(array('id' => $superior_id), '`id`, `superior`');
            if (!empty($tmp)) {
                $superior_id = $tmp['superior'];
                $superiors[] = $tmp['id'];
            } else {
                $superior_id = 0;
            }

        } while($superior_id > 0);

        $superiors = array_filter($superiors);
        $superiors_str = implode(',', $superiors);
        // 找部门.
        $departments = mod_department::instance()->get_list_data(array('organization_id in' => $superiors), '`id`, `name`, `business_tag`');
        if (!empty($departments)) {
            foreach ($departments as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    $result['stations'][] = array(
                        'id' => $value['id'].'_department',
                        'name' => $value['name'],
                    );
                }
            }
        }

        // 找独立岗位.
        $stations = mod_station::instance()->get_list_data(array('organization_id in' => $superiors, 'department_id' => 0), '`id`, `name`, `business_tag`');
        if (!empty($stations)) {
            foreach ($stations as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    // 编辑的时候排除自己.
                    if (!empty($except_station_id) && $value['id'] == $except_station_id) {
                        continue;
                    }
                    $result['stations'][] = array(
                        'id' => $value['id'].'_station',
                        'name' => $value['name'],
                    );
                }
            }
        }

        echo json_encode($result);
    }

    /**
     * 获取业务对接数据.
     */
    public function get_business_link_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'departments' => array(),
            'stations' => array(),
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $except_station_id = req::item('except_station_id', 0, 'int');
        $tags = req::item('tags', array());
        if (empty($organization_id) && empty($tags)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $superiors = array();
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `superior`');
        // 直属上级机构.
        $superior_id = $organizations['superior'];
        do {
            $tmp = mod_organization::instance()->get_one_data(array('id' => $superior_id), '`id`, `superior`');
            if (!empty($tmp)) {
                $superior_id = $tmp['superior'];
                $superiors[] = $tmp['id'];
            } else {
                $superior_id = 0;
            }

        } while($superior_id > 0);

        // 找部门.
        $departments = mod_department::instance()->get_list_data(array('organization_id in' => $superiors), '`id`, `name`, `business_tag`');
        if (!empty($departments)) {
            foreach ($departments as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    $result['stations'][] = array(
                        'id' => $value['id'].'_department',
                        'name' => $value['name'],
                    );
                }
            }
        }

        // 找独立岗位.
        $stations = mod_station::instance()->get_list_data(array('organization_id in' => $superiors, 'department_id' => 0), '`id`, `name`, `business_tag`');
        if (!empty($stations)) {
            foreach ($stations as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    // 编辑的时候排除自己.
                    if (!empty($except_station_id) && $value['id'] == $except_station_id) {
                        continue;
                    }
                    $result['stations'][] = array(
                        'id' => $value['id'].'_station',
                        'name' => $value['name'],
                    );
                }
            }
        }

        echo json_encode($result);
    }

    /**
     * 获取上级岗位.
     */
    public function get_superior_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'data' => array(
                'station' => array(),
                'station_type' => array(),
                'department' => array(),
                'tags' => array(),
                'level' => array(),
            ),
        );

        $organization_id = req::item('idd', 0, 'int');
        if (empty($organization_id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        // 上级岗位.
        $result['data']['station'] = mod_station::instance()->get_station_in_org(array($organization_id));
        // 岗位类型.
        $result['data']['station_type'] = mod_post_type::instance()->get_type_option_in_org($organization_id);
        // 所属部门.
        $result['data']['department'] = mod_department::instance()->get_department_in_org(array($organization_id));
        $result['data']['tags'] = mod_operation_tag::instance()->get_tag_option_in_org($organization_id);
        $result['data']['level'] = mod_organize_level::instance()->get_station_level_option_in_org($organization_id);

        echo json_encode($result, true);
    }

    /**
     * 获取组织等级数据.
     */
    public function get_org_level($organization_id = 0, $department = 0, $superior_id = 0, $station_type = 0)
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'data' => array(),
        );

        $org_id = req::item('org_id', 0, 'int');
        $department_id = req::item('station_department', 0, 'int');
        $type_id = req::item('station_type', 0, 'int');
        $station_id = req::item('superior', 0, 'int');
        $ajax = req::item('ajax', 0, 'int');

        $org_id = empty($org_id) ? $organization_id : $org_id;
        $department_id = empty($department_id) ? $department : $department_id;
        $station_id = empty($station_id) ? $superior_id : $station_id;
        $type_id = empty($type_id) ? $station_type : $type_id;

        if (empty($org_id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        $data = $this->get_level_options();
        // 没有归属部门的时候, 岗位所属机构对应限制独立岗位等级范围起作用.
        if (empty($department_id)) {
            $org_data = mod_organize_level::instance()->get_station_level_option_in_org($org_id);
            $data = array_intersect_key($data, $org_data);
        }

        // 岗位下面的等级.
        if (!empty($station_id)) {
            $station_data = mod_organize_level::instance()->get_station_level_option_in_station($station_id);
            $data = array_intersect_key($data, $station_data);
        }

        if (!empty($type_id)) {
            $type_level_data = mod_post_type::instance()->get_level_range_in_type_org($org_id, $type_id);
            $data = array_intersect_key($data, $type_level_data);
        }

        $result['data'] = $data;
        if (!empty($ajax)) {
            echo json_encode($result);
            exit();
        } else {
            return $result;
        }

    }

}
