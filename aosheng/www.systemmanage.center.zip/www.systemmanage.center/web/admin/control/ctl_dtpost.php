<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 部门岗位等级管理
 *
 * @version $Id$
 */
class ctl_dtpost
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $this->table = '#PB#_dtpost';
        $this->baseUrl = '?ct=dtpost&ac=index';
        $this->level = mod_member::get_def_level();
        tpl::assign('level', $this->level);
    }

    public function index()
    {
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 20);
        $even = req::item('even', 'add');
        $where = array();
        $where[] = "`isdeleted` = '0'";
        if (!empty($keyword)) {
            $where[] = "(`level_name` Like '%{$keyword}%')";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);

        $sql = "Select Count(*) AS count From `$this->table` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count'], $page_size);
        $sql = "Select * From `$this->table` {$where} Order By `id` Asc Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);
        tpl::assign('even', $even);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('dtpost.index.tpl');
    }

    /**
     * 增加级别
     */
    public function add()
    {

        if (!empty(req::$posts)) {
            $data = req::$posts;

            if (empty($data['level'])) cls_msgbox::show('系统提示', '请选择行政等级');
            if (empty($data['level_name'])) cls_msgbox::show('系统提示', '请填写等级名称');
            if (empty($data['pay'])) cls_msgbox::show('系统提示', '请填写基本薪酬');
            $level_name = db::get_one("select `level_name` from `$this->table` where `level_name`='{$data['level_name']}' and `isdeleted`!='1' ");
            if (!empty($level_name)) {
                cls_msgbox::show('系统提示', '等级名称已存在，请换别的名称');
            }
            //$level = db::get_one("select `level` from `$this->table` where `level`='{$data['level']}' and `isdeleted`!='1' ");
            //if (!empty($level)) {
            //  cls_msgbox::show('系统提示', '等级已存在，请换别的等级');
            // }
            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['create_time'] = time();
            db::insert($this->table, $data);
            $insert_id = db::insert_id();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加了行政等级 为{$insert_id}的记录");
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }

    }

    /**
     * 编辑级别
     **/
    public function edit()
    {
       $id = req::item("id", 0);
//        $sql = "Select * From `$this->table` Where `id`={$id} Limit 1";
//        $rows = db::get_one($sql);
        if (!empty(req::$posts)) {
            $data = req::$posts;
            $level_name = req::item('level_name');
            $row = db::get_one("Select * From `$this->table` Where `level_name`='{$level_name}' And `id`!='{$id}'");
            if (!empty($row)) {
                cls_msgbox::show('系统提示', '级别名称已经存在,请换别的名称！', '-1');
                exit();
            }
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();
            db::update($this->table, $data, "`id`='{$id}'");
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了行政级别id为{$id}的数据");
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
//        $gourl = $this->baseUrl;
//        tpl::assign('gourl', $gourl);
//        tpl::assign('rows', $rows);
//        tpl::display('admin_level.edit.tpl');
    }
    /**
     * 删除级别
     */
    public function del()
    {
        $id = req::item('id', 0);
        $delete_arr = array(
            'isdeleted'=>1,
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );
        db::update($this->table, $delete_arr, "`id` = '{$id}' ");
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "行政级别{$id}被删除");
        $gourl =$this->baseUrl;
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

}
