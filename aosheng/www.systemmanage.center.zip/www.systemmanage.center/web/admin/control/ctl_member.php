<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 员工管理
 *
 * @version $Id$
 */
class ctl_member
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $this->field = mod_member::get_all_fields(); //所有员工字段

        $this->job_log_field = mod_member::get_job_log_field();//所有任职记录字段

        $this->quit_log_field = mod_member::get_quit_log_field();//所有离职记录字段

        $this->def_where = array(['del_user','=','']);

        $this->userinfo =  cls_auth::$user->fields;

        $this->option_organization= mod_member::get_data("#PB#_organization");

        $this->organization = "#PB#_organization";

        $this->department = "#PB#_department";

        $this->station = "#PB#_station";

        $this->station_list = "#PB#_station_list";

        $this->job_log = "#PB#_job_log";

        $this->base_info = mod_member::set_option_arr(); //基础数据

//        $this->option_department=array(0=>'请选择部门','1'=>'部门1');
//
//        $this->option_job=array(0=>'选择岗位','1'=>'岗位1');
        //临时图片上传未知
        $this->tmp_path = PATH_UPLOADS.'/tmp';
        //实际图片存放未知
        $this->image_path = PATH_UPLOADS.'/image';
        //加密文件存放
        $this->file_path = PATH_UPLOADS.'/file';

        $this->sta=array('1'=>'正常','2'=>'禁止');

        $this->area = "#PB#_area";

        $this->station_list = "#PB#_station_list";

        $this->table="#PB#_member";

        $this->job_log  = "#PB#_job_log";  //任职记录日志

        $this->quit_log = "#PB#_quit_log"; //离职记录表

        $this->baseUrl = '?ct=member&ac=index';

        $this->p = mod_member::get_area_data('1');
        //获得各行政区域
        tpl::assign('nation',mod_member::get_area_data('-1'));

        tpl::assign('province',mod_member::get_area_data('1'));

        tpl::assign('city',mod_member::get_area_data('2'));

        tpl::assign('town',mod_member::get_area_data('3'));

        //获得option数组
        tpl::assign('option_val',mod_member::set_option_arr());

        //定义当前日期
        tpl::assign('date',date('Y-m-d'));

        tpl::assign('option_organization',$this->option_organization);

//        tpl::assign('option_department',$this->option_department);
//
//        tpl::assign('option_job',$this->option_department);

        tpl::assign('sta',$this->sta);

    }

    /**
     * 员工管理列表
     */
    public function index()
    {

        $power = req::item('power', 0, 'int');
        $reqs['entry_organization']  = req::item('entry_organization');
        $reqs['entry_department'] = req::item('entry_department');
        $reqs['entry_job']        = req::item('entry_job');
        $reqs['sta']           = req::item('sta');
        $reqs['nickname']      =req::item('nickname');
        $reqs['type']          = req::item('type','all');  //根据列表类型返回对于状态数据
        $organization_id = req::item('entry_organization',''); //本机构传递过来的id
        $title = req::item('title','所有员工');
        //是否顶部的分类nav搜索
        $nav = req::item('nav','');
        $where = array();
        $order_field = 'id';
        $sort = 'desc';
        //对应的机构员工
        if(!empty($organization_id))
        {
            //$where[] = "(`entry_organization` = '{$organization_id}' )";
            $where[] = array('entry_organization','=',$organization_id);

        }
        if (!empty($reqs['nickname']))
        {
            //$where[] = "(`nickname` Like '%{$reqs['nickname']}%')";
            $where[] = array('nickname','like',"%{$reqs['nickname']}%");
        }

        if($reqs['type']=='not_post')
        {
            //无岗位员工
            //$where[] = "(`entry_job` = '')";
            $where[] = array('entry_job','=','');
            $title = '无岗位员工';
        }elseif($reqs['type']=='yes_post')
        {
            //在岗员工
           // $where[] = "(`entry_job` != '' && `job_sta`!='2')";
            $where[] = array('entry_job','!=','');
            $where[] = array('job_sta','!=','2');
            $title = '在岗员工';
        }elseif($reqs['type']=='quit'){
            //离职员工
            //$where[] = "(`job_sta` = '2')";
            $where[] = array('job_sta','=','2');
            $title = '离职员工';
        }elseif($reqs['type']=='quit2'){
            //员工免职
            $title = '员工免职';
            //$where[] = "(`job_sta` != '2')";
            $where[] = array('job_sta','!=','2');
        }elseif($reqs['type']=='working'){
            $title = '员工任职';
        }elseif($reqs['type']=='quit_sta'){
            $title = '员工离职';
            $where[] = array('sta','!=','2');
        }
        $department_option = '';
        $job_option = '';
        //按机构搜索
        if(!empty($reqs['entry_organization']))
        {
            //$where[] = "(`entry_organization` = '{$reqs['entry_organization']}')";
            $where[] = array('entry_organization','=',$reqs['entry_organization']);
            $pid = $reqs['entry_organization'];
            //返回机构下所有的部门
            //$sql  = "select `id`,`name` from `#PB#_department` where `organization_id`='{$pid}'";
            //$arr = db::get_all($sql);
            $arr = db::select("id,name")->from('#PB#_department')->where('organization_id',$pid)->execute();
            if(!empty($arr))
            {
                foreach($arr as $k=>$v)
                {
                    if(!empty($reqs['entry_department']) && $reqs['entry_department']==$v['id'])
                    {
                        $department_option.="<option selected value=$v[id] >$v[name]</option>";
                    }else{
                        $department_option.="<option value=$v[id] >$v[name]</option>";
                    }

                }
            }
            //返回机构下所有的岗位
            //$sql  = "select `id`,`name` from `#PB#_station` where `organization_id`='{$pid}'";
            //$arr = db::get_all($sql);
            $arr = db::select("id,name")->from('#PB#_station')->where('organization_id',$pid)->execute();
            if(!empty($arr))
            {
                foreach($arr as $k=>$v)
                {
                    if(!empty( $reqs['entry_job']) &&  $reqs['entry_job']==$v['id'])
                    {
                        $job_option.="<option selected value=$v[id] >$v[name]</option>";
                    }else{
                        $job_option.="<option value=$v[id] >$v[name]</option>";
                    }

                }
            }


        }


        tpl::assign('department_option',$department_option);
        tpl::assign('job_option',$job_option);
        //按部门搜索
        if(!empty($reqs['entry_department']))
        {
            //$where[] = "(`entry_department` = '{$reqs['entry_department']}')";
            $where[] = array('entry_department','=',$reqs['entry_department']);
        }
        //按岗位搜索
        if(!empty($reqs['entry_job']))
        {
            //$where[] = "(`entry_job` = '{$reqs['entry_job']}')";
            $where[] = array('entry_job','=',$reqs['entry_job']);
        }
        //按账号状态搜索
        if(!empty($reqs['sta']))
        {
            //$where[] = "(`sta` = '{$reqs['sta']}')";
            $where[] = array('sta','=',$reqs['sta']);
        }

        //$where = empty($where) ? '' : 'Where ' . implode(' And ', $where);
        //$sql = "Select Count(*) AS count From `$this->table` {$where}";
        //$row = db::get_one($sql);
        $row = db::select('count(*) AS `count`')
            ->from($this->table)
            ->where($where)
            ->as_row()
            ->execute();
        $pages = pub_page::make($row['count'], 20);
        //$sql = "Select * From `$this->table` {$where} Order By `id` desc Limit {$pages['offset']}, {$pages['page_size']}";
        //$list = db::get_all($sql);
        $list = db::select($this->field)
            ->from($this->table)
            ->where($where)
            ->order_by($order_field,$sort)
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();
        tpl::assign('list', $list);
        tpl::assign('title', $title);
        tpl::assign('organization_id', $organization_id);
        tpl::assign('nav', $nav);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::assign('reqs',$reqs);
        tpl::assign('power',$power);
        tpl::assign('index','org_member');
        tpl::display('member.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $data = req::$posts;
            //后台表单验证
            mod_member::check_form($data);
            $data['nation'] = !empty($data['nation'])?$data['nation']:'';
            $data['contact_type']=json_encode($data['contact_type']);
            $data['contact']=json_encode($data['contact']);
            $data['ug_contact_rate']=json_encode($data['ug_contact_rate']);
            $data['ug_contact_name'] = json_encode($data['ug_contact_name'],JSON_UNESCAPED_UNICODE);
            $data['ug_contact_type']=json_encode($data['ug_contact_type']);
            $data['ug_contact']=json_encode($data['ug_contact']);
            $data['birth'] = strtotime($data['birth']);
            $data['member_pass'] = substr(md5(time()),2,8);

            //证件照片加密处理
            if(!empty($data['image_data']))
            {
                $data['image_data'] = mod_member::file_crypt($data['image_data'],$this->tmp_path,$this->image_path);
            }
            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['create_time'] = time();

            $row_email = db::select("email")->from($this->table)->where("email","=",$data['email'])->as_row()->execute();

            //不允许添加已经存在的邮件
            if(!empty($row_email))
            {
                cls_msgbox::show('系统提示', "邮箱已存在，请换其他邮箱", '-1');
            }
            //证明人验证
            if($data['prove']==$data['prove2'])
            {
                cls_msgbox::show('系统提示', "两个证明人不允许相同", '-1');
            }
            //$prove1 = db::get_one("select `sn` from `$this->table` where `sn`='{$data['prove']}'");
            $prove1 = db::select("sn")->from($this->table)->where('sn',$data['prove'])->as_row()->execute();

            if(empty($prove1))
            {
                cls_msgbox::show('系统提示', "证明人1不在系统内，请查询后再填写", '-1');
            }

            //$prove2 = db::get_one("select `sn` from `$this->table` where `sn`='{$data['prove2']}'");
            $prove2 = db::select("sn")->from($this->table)->where('sn',$data['prove2'])->as_row()->execute();

            if(empty($prove2))
            {
                cls_msgbox::show('系统提示', "证明人2不在系统内，请查询后再填写", '-1');
            }
            if($data['id_type']=='3')
            {
                if(empty($data['security']))  cls_msgbox::show('系统提示', "身份担保人1不能为空", '-1');

                if(empty($data['security2']))  cls_msgbox::show('系统提示', "身份担保人2不能为空", '-1');
                //身份担保人
                if(!empty($data['security']) && !empty($data['security2']))
                {
                    if($data['security']==$data['security2'])
                    {
                        cls_msgbox::show('系统提示', "两个身份担保人不允许相同", '-1');
                    }

                    //$security1 = db::get_one("select `sn` from `$this->table` where `sn`='{$data['security']}'");
                    $security1 = db::select("sn")->from($this->table)->where('sn',$data['security'])->as_row()->execute();
                    if(empty($security1))
                    {
                        cls_msgbox::show('系统提示', "身份担保人1不在系统内，请查询后再填写", '-1');
                    }
                    //$security2 = db::get_one("select `sn` from `$this->table` where `sn`='{$data['security2']}'");
                    $security2 = db::select("sn")->from($this->table)->where('sn',$data['security2'])->as_row()->execute();
                    if(empty($security2))
                    {
                        cls_msgbox::show('系统提示', "身份担保人2不在系统内，请查询后再填写", '-1');
                    }
                }
            }


            unset($data['gourl']);
            unset($data['ct']);
            unset($data['ac']);
            unset($data['file']);
            list($insert_id, $rows_affected) = db::insert($this->table)->set($data) ->execute();

           // db::insert($this->table,$data);
            //$insert_id = db::insert_id();
            //生成员工编号
            $sn = mod_member::get_user_sn($insert_id,$data['entry_organization']);
            if($sn)
            {
                //$sql_sn = "update `$this->table` set `sn`='{$sn}' where `id`='{$insert_id}'";
                //db::query($sql_sn);
                $res = db::update($this->table)->set(array('sn'=>$sn))->where('id', $insert_id)->execute();
            }
            //回溯station表绑定star_id
            if(!empty($data['entry_job']))
            {
                //$sql = "update `$this->station_list` set `member_id`='{$insert_id}' where `station_id`='{$data['entry_job']}'";
                //db::query($sql);
                $res = db::update($this->station_list)->set(array('member_id'=>$insert_id))->where('station_id', $data['entry_job'])->execute();
            }
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加了id为{$insert_id}的员工信息记录");
            $gourl= "?ct=member&ac=add";
            cls_msgbox::show('系统提示', "员工资料添加成功", $gourl);

        }
        else 
        {
            $even = req::item('even','basic');
            $area_init =  mod_member::get_area();  //初始化地区数据
            $gourl = '?ct=member&ac=index';
            tpl::assign('area_init', $area_init);
            tpl::assign('even', $even);
            tpl::assign('gourl', $gourl);
            tpl::display('member.add.tpl');
        }
    }
    /**
     * 查看员工信息
     */
    public function show()
    {
        $type = req::item('type','');
        $id = req::item('id',0);
        $order_field = 'create_time';
        $sort = 'desc';
        if(empty($id))
        {
            cls_msgbox::show('系统提示', "请选择要查看的员工", -1,3000);
        }
        //$rows = db::get_one("select * from `$this->table` where `id`='{$id}' and `del_user`='' ");
        $int_where = array(
            array('id','=',$id),
            array('del_user','=','')
        );
        $rows = db::select($this->field)->from($this->table)->where($int_where)->as_row()->execute();
        if(empty($rows))
        {
            cls_msgbox::show('系统提示', "你选择的员工不存在", -1,3000);
        }
        //员工子岗位信息
        $job_chird_info = db::select(mod_station_list::get_all_fields())->from($this->station_list)->where('id',$rows['job_code_id'])->as_row()->execute();
        //$where = " where `mid`='{$id}' ";
        $where[] = array('mid','=',$id);
        $creart_time = db::select(' min(`create_time`) as c_time')->from($this->job_log)->where($where)->as_row()->execute();

        $row = db::select('count(*) AS `count`')
            ->from($this->job_log)
            ->where($where)
            ->as_row()
            ->execute();
        $pages = pub_page::make($row['count'], 10);
        $list = db::select($this->job_log_field)
            ->from($this->job_log)
            ->where($where)
            ->order_by($order_field,$sort)
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();
        $contact_arr = mod_member::format_contact(json_decode($rows['contact_type']),json_decode($rows['contact']));
        $ug_contact_type = mod_member::format_ug_contact(json_decode($rows['ug_contact_type']),json_decode($rows['ug_contact_name']),json_decode($rows['ug_contact_rate']),json_decode($rows['ug_contact']));  //获取紧急联系人
        $image_data = json_decode($rows['image_data']);
        if(!empty($type))
        {
            $reback_url ="?ct=member&ac=index&type=$type";
        }else{
            $reback_url ="?ct=member&ac=index";
        }
        tpl::assign('pages', $pages['show']);
        tpl::assign('reback_url', $reback_url);
        tpl::assign('list', $list);
        tpl::assign('first_time', $creart_time['c_time']);
        tpl::assign('image_data',$image_data);
        tpl::assign('contact_arr',$contact_arr);
        tpl::assign('ug_contact_type',$ug_contact_type);
        tpl::assign('rows',$rows);
        tpl::assign('job_chird_info',$job_chird_info);
        tpl::display('member.show.tpl');
    }



    public function edit()
    {
        $id = req::item('id', 0, 'int');
        if (!empty(req::$posts)) 
        {
            $data = req::$posts;
            //后台表单验证
            mod_member::check_form($data);
            $data['nation'] = !empty($data['nation'])?$data['nation']:''; //测试用数据
            $data['contact_type']=json_encode($data['contact_type']);
            $data['contact']=json_encode($data['contact']);
            $data['ug_contact_rate']=json_encode($data['ug_contact_rate']);
            $data['ug_contact_name'] = json_encode($data['ug_contact_name'],JSON_UNESCAPED_UNICODE);
            $data['ug_contact_type']=json_encode($data['ug_contact_type']);
            $data['ug_contact']=json_encode($data['ug_contact']);
            $data['birth'] = strtotime($data['birth']);
            $row_email_where = array(['email','=',$data['email']],['id','!=',$id]);
            $row_email = db::select("email")->from($this->table)->where($row_email_where)->as_row()->execute();

            //不允许添加已经存在的邮件
            if(!empty($row_email))
            {
                cls_msgbox::show('系统提示', "邮箱已存在，请换其他邮箱", '-1');
            }
            if(!empty($data['image_data']))
            {
                //证件照片加密处理
                $data['image_data'] = mod_member::file_crypt($data['image_data'],$this->tmp_path,$this->image_path);
            }
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();
            //$data['sn'] = mod_member::get_user_sn($id,$data['entry_organization']);  //先注释，员工编号在任职时会重新生成（2018）
            unset($data['gourl']);
            unset($data['ct']);
            unset($data['ac']);
            unset($data['file']);
            //db::update($this->table, $data, "`id`=" . $id);
            db::update($this->table)->set($data)->where('id', $id)->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户修改 {$id}的员工数据");
            $gourl = "?ct=member&ac=show&id=$id";
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else 
        {
//            $sql = "Select * From `$this->table` Where `id`={$id} Limit 1";
//            $rows = db::get_one($sql);
            $rows = db::select($this->field)->from($this->table)->where('id','=',$id)->as_row()->execute();
            //联系方式数据
            $contact_arr = mod_member::format_contact(json_decode($rows['contact_type']),json_decode($rows['contact']));
            //获取紧急联系人数据
            $ug_contact_type = mod_member::format_ug_contact(json_decode($rows['ug_contact_type']),json_decode($rows['ug_contact_name']),json_decode($rows['ug_contact_rate']),json_decode($rows['ug_contact']));
            if(!empty($rows['image_data']))
            {
                //证件图片数据
                $image_data = json_decode($rows['image_data']);
                //解释出来二级为对象 强行转化为数组方便前台处理
                foreach($image_data as $k=>$val)
                {
                    $image_data[$k] = (array)$val;
                }

            }else{
                $image_data='';
            }
            tpl::assign('image_data',$image_data);
            //初始化地区获得国家级数据
            $area_init =  mod_member::get_area();  //初始化地区数据
            $province = '';
            $city = '';
            $town = '';
            if($rows['nation'])
            {
                $province = db::select("id,name")->from('#PB#_area')->where('parent_id','=',$rows['nation'])->execute();

            }

            //获得当前province下的所有city
            if(!empty($province)){

                $city = db::select("id,name")->from('#PB#_area')->where('parent_id','=',$rows['province'])->execute();
            }

            //获得当前所有city下的town
            if(!empty($city)){
                $town = db::select("id,name")->from('#PB#_area')->where('parent_id','=',$rows['city'])->execute();

            }
            //print_r()
            tpl::assign('area_init',$area_init);
            tpl::assign('province', $province);
            tpl::assign('city', $city);
            tpl::assign('town', $town);
            tpl::assign('contact_arr',$contact_arr);
            tpl::assign('ug_contact_type',$ug_contact_type);
            $gourl = '?ct=member&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::assign('rows', $rows);
            tpl::display('member.edit.tpl');
        }
    }

//    public function del()
//    {
//        $ids = implode(',', req::item('ids', 0));
//        $sql = "Delete From `#PB#_admin` Where `admin_id` IN ({$ids})";
//        db::query($sql);
//
//        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户删除 {$ids}");
//
//        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=member&ac=index' : $_SERVER['HTTP_REFERER'];
//        cls_msgbox::show('系统提示', "删除成功", $gourl);
//    }

    /**
     * 设置用户禁止登陆
     */
    public function set_sta()
    {
        $sta = req::item('sta');
        $id = req::item('id');
        //禁止登陆状态禁止登陆员工工作状态为离职
        if($sta=='2')
        {
//            $sql = "update `$this->table` set `sta`='{$sta}',`job_sta`='2' where `id`='{$id}'";
//            $res = db::query($sql);
            $data['sta'] = $sta;
            $data['job_sta'] = '2';
            $res = db::update($this->table)->set($data)->where('id',$id)->execute();
        }else{
            //$sql = "update `$this->table` set `sta`='{$sta}',`job_sta`='1' where `id`='{$id}'";
            $data['sta'] = $sta;
            $data['job_sta'] = '1';
            $res = db::update($this->table)->set($data)->where('id',$id)->execute();
        }

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户登陆状态已更改 {$id}");
        cls_msgbox::show('系统提示', '登陆状态已更改', '?ct=member&ac=show&id='.$id);
    }



    /**
     * 人事任职
     **/
    public function member_working()
    {
        $data = req::$posts;
        $id = req::item('id', 0);
        if ($data) {
            //数据录入前处理
            if(empty($data['entry_organization']))  cls_msgbox::show('系统提示', "机构不能为空", -1, 3000);

            if(empty($data['log_val']))  cls_msgbox::show('系统提示', "您好，请选择要操作的记录", -1, 3000);

            if(mb_strlen($data['job_why'])>140)  cls_msgbox::show('系统提示', "您好，操作记录不能超过140字", -1, 3000);
            //图片加密处理
            $data['fileinfo'] = !empty($data['fileinfo']) ? $data['fileinfo'] : '';
            $chird_job = $data['entry_job']; //子岗位编制id
            $data['job_code_id'] = $chird_job;
            //获取父岗位信息
            //$p_station = db::get_one("select `station_id` from `$this->station_list` where `id`='{$data['job_code_id']}' ");
            if(!empty($data['job_code_id']))
            {
                $p_station = db::select("station_id")->from($this->station_list)->where('id','=',$data['job_code_id'])->as_row()->execute();
                $data['entry_job'] = $p_station['station_id']; //子岗位的父级岗位id
            }

            $data['job_sta'] = '1'; //修改在职状态为在职
            $arr = array();
            if(!empty($data['fileinfo'])){
                //加密多文件处理
                foreach($data['fileinfo'] as $k=>$v)
                {
                    //$fileinfo = json_decode(str_replace('\"','"',$v));
                    $filename = $this->tmp_path.'/'.$v;
                    if(file_exists($filename))
                    {
                        $arr[] = mod_member::get_file_crypt($v);
                    }
                }
                $data['job_file'] = json_encode($arr);
            }else{
                $data['job_file'] = '';
            }
            $data['come_job_date'] = !empty($data['come_job_date'])?strtotime($data['come_job_date']):'';  //入职时间
            $data['become_job_date'] = !empty($data['become_job_date'])?strtotime($data['become_job_date']):''; //转正时间
            //任免前职位等级
            $first_level = !empty($data['organization_first_level'])?$data['organization_first_level']:'';
            //获取组织当前等级
           // $station_level = db::get_one("select `level_id` from `#PB#_station` where `id`='{$data['entry_job']}'");
            $station_level = db::select("level_id")->from($this->station)->where('id','=',$data['entry_job'])->as_row()->execute();
            $last_level = mod_member::get_organization_level('#PB#_organize_level',$station_level['level_id']);
            //更改在职状态为在职，账号状态为正常
            db::update($this->table)->set(array('job_sta'=>'1','sta'=>'1'))->where('id','=',$id)->execute();

            //一个萝卜一个坑 更新子岗位绑定的人员id 先清除再绑定
            db::query("update `$this->station_list` set `member_id`='0' where `member_id`='{$id}' ")->execute();
            db::query("update `$this->station_list` set `member_id`='{$id}' where `id`='{$chird_job}' ")->execute();

            //db::update($this->table, $data, "`id`='{$id}'");
            $log_data = array(
                'create_time'=>time(),                                  //当前记录时间
                'create_user'=>$this->userinfo['admin_id'],             //操作人
                'job_time'=>$data['come_job_date'],          //当前记录时间
                'log_val' => $data['log_val'],                          //任免记录
                'job_why' =>$data['job_why'],                           //任免原因
                'department_first' =>$data['department_first'],         //任免前部门
                'department_last' =>$data['entry_department'],          //任免后部门
                'organization_first' =>$data['organization_first'],     //任免前机构
                'organization_last' =>$data['entry_organization'],      //任免后机构
                'job_first' =>$data['job_first'],                       //任免前职位
                'job_last' =>!empty($data['entry_job'])?$data['entry_job']:'',                        //任免后职位
                'organization_first_level' => !empty($first_level)?$first_level:'',                       //任免前职位等级
                'organization_last_level' => !empty($last_level)?$last_level:'',       //任免后职位等级
                'working_num'=>$data['working_num'],                              //任职文件编号
                'job_file'=>$data['job_file'],                              //任职文件记录
                'mid'=>$id,                                         //member关联id

            );

            //更改member的入职数据
            $work_data['entry_organization'] =$data['entry_organization'];
            $work_data['entry_department']   =!empty($data['entry_department'])?$data['entry_department']:'';
            $work_data['entry_job']          =$data['entry_job'];
            $work_data['job_code_id']        =$data['job_code_id'];
            $work_data['come_job_date']      =$data['come_job_date']; //到岗时间
            $work_data['become_job_date']    =$data['become_job_date']; //转正时间
            $work_data['sn']                 =mod_member::get_user_sn($id,$data['entry_organization']);       //任职需要更新员工编号


            //记录日志
            list($insert_id, $rows_affected) = db::insert($this->job_log)->set($log_data) ->execute();
            db::update($this->table)->set($work_data)->where('id',$id)->execute();

            if($data['log_val']=='1')
            {
                //发送成功任职邮件,只有任职时发送
                $member_pass = db::select("member_pass,email")->from($this->table)->where('id','=',$id)->as_row()->execute();
                //获取收件人邮箱
                $email = $member_pass['email'];
                //防止有密码为空的情况
                if(empty($member_pass['member_pass']))
                {
                    $member_pass = substr(md5(time()),2,8);
                    $pass['member_pass'] = $member_pass;
                    db::update($this->table)->set($pass)->where('id',$id)->execute();
                }else{
                    $member_pass = $member_pass['member_pass'];
                }
                $organization_name = $this->base_info['entry_organization'][$data['entry_organization']];
                $department_name = !empty($data['entry_department'])?$this->base_info['entry_department'][$data['entry_department']]:'无'; //无任职部门的需要判断一下
                $job_name = $this->base_info['entry_job'][$data['entry_job']];
                $sn = $work_data['sn'];
                $email_html = "
                <p>您好:</p>
                <p>您已成功办理入职手续，</p>
                <p>入职机构：【 $organization_name 】</p>
                <p>入职部门：【 $department_name 】</p>
                <p>入职岗位：【 $job_name 】</p>
                <p>员工编号：【 $sn 】</p>
                <p>公司内部各平台登录账号：".$sn.",登录密码：".$member_pass."</p> 
                ";
                mod_member::send_email($email,$email_html);
            }

            //任职记录
            if($insert_id)
            {
                cls_msgbox::show('系统提示', "员工任职成功", "?ct=member&ac=show&id=$id&type=working", 3000);
            }

        } else {
            if (empty($id)) {
                cls_msgbox::show('系统提示', "请选择要查看的员工", -1, 3000);
            }
            //$rows = db::get_one("select * from `$this->table` where `id`='{$id}' and `del_user`='' ");
            $df_where = array(
                array('id','=',$id),
                array('del_user','=','')
            );
            $rows = db::select($this->field)->from($this->table)->where($df_where)->as_row()->execute();
            if (empty($rows)) {
                cls_msgbox::show('系统提示', "你选择的员工不存在", -1, 3000);
            }
            $organization_level = '';
            //获取组织当前等级
            $station_level = db::select("level_id")->from($this->station)->where('id',$rows['entry_job'])->as_row()->execute();
            if(!empty($rows['entry_job'])){
                $organization_level = mod_member::get_organization_level('#PB#_organize_level',$station_level['level_id']);
            }

            $rows['organization_first_level'] = $organization_level;
            $contact_arr = mod_member::format_contact(json_decode($rows['contact_type']), json_decode($rows['contact']));
            $ug_contact_type = mod_member::format_ug_contact(json_decode($rows['ug_contact_type']), json_decode($rows['ug_contact_name']), json_decode($rows['ug_contact_rate']), json_decode($rows['ug_contact']));  //获取紧急联系人
            $image_data = json_decode($rows['image_data']);
            tpl::assign('image_data', $image_data);
            tpl::assign('organization_first_level', $organization_level);
            tpl::assign('contact_arr', $contact_arr);
            tpl::assign('ug_contact_type', $ug_contact_type);
            tpl::assign('rows', $rows);
            tpl::display('member.working.tpl');
        }
    }

    /**
     * 任免记录列表
     */
    public function member_working_list()
    {
        $id = req::item('id');
        $df_where = array(
            array('id','=',$id),
            array('del_user','=','')
        );
        $order_field = 'create_time';
        $sort = 'desc';
        if (empty($id)) {
            cls_msgbox::show('系统提示', "请选择要查看的员工", -1, 3000);
        }
        //$rows = db::get_one("select * from `$this->table` where `id`='{$id}' and `del_user`='' ");
        $rows = db::select($this->field)->from($this->table)->where($df_where)->as_row()->execute();
        if (empty($rows)) {
            cls_msgbox::show('系统提示', "你选择的员工不存在", -1, 3000);
        }
          $where[] = array('mid','=',$id);  //" where `mid`='{$id}' ";

        $creart_time = db::select(" min(create_time) as `c_time`")->from($this->job_log)->where($where)->as_row()->execute();
//        $sql = "Select Count(*) AS count From `$this->job_log` {$where}";
//        $row = db::get_one($sql);
        $row = db::select('count(*) AS `count`')
            ->from($this->job_log)
            ->where($where)
            ->as_row()
            ->execute();
        $pages = pub_page::make($row['count'], 10);
//        $sql = "Select * From `$this->job_log` {$where}  Order By `create_time` desc Limit {$pages['offset']}, {$pages['page_size']}";
//        $list = db::get_all($sql);
        $list = db::select($this->job_log_field)
            ->from($this->job_log)
            ->where($where)
            ->order_by($order_field,$sort)
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();

        tpl::assign('list', $list);
        tpl::assign('first_time', $creart_time['c_time']);
        tpl::assign('rows', $rows);
        tpl::assign('count', $row['count']);
        tpl::assign('pages', $pages['show']);
        tpl::display('member.working.list.tpl');
    }
    /**
     * 任免记录详情
     **/
    public  function member_working_show()
    {
            $id = req::item('id');

            //$log_rows = db::get_one("select * from `#PB#_job_log` where `id`='{$id}'");  //当前记录
            $log_rows = db::select($this->job_log_field)->from($this->job_log)->where('id',$id)->as_row()->execute();  //当前记录

            //$rows = db::get_one("select * from `$this->table` where `id`='{$log_rows['mid']}'");  //员工基本信息
            $rows = db::select($this->field)->from($this->table)->where('id',$log_rows['mid'])->as_row()->execute();

            tpl::assign('log_rows', $log_rows);

            tpl::assign('rows', $rows);

            tpl::display('member.working.show.tpl');

    }
    /**
     * 员工离职管理
     */
    public function member_quit()
    {
        $data = req::$posts;
        $id = req::item('id', 0);
        $quit_sta = req::item('quit_sta',''); //用于区分免职与离职
        if ($data) {
            //数据录入前处理
            if(empty($data['quit_val']))  cls_msgbox::show('系统提示', "请选择离职原因", -1, 3000);

            if(empty($data['quit_time']))  cls_msgbox::show('系统提示', "离职日期不能为空", -1, 3000);
            //免职前数据
            $rows = db::select("job_code_id,entry_department,entry_organization,entry_job")->from($this->table)->where('id',$id)->as_row()->execute();

            $organization_level = '';
            //子岗位id
            $chird_job = $rows['job_code_id'];
            if(mb_strlen($data['quit_why'])>300)  cls_msgbox::show('系统提示', "您好，离职原因不能超过300字", -1, 3000);
            $data['contact_type']= !empty($data['contact_type'])?json_encode($data['contact_type']):'';  //存储联系方式类型
            $data['contact']=  !empty($data['contact'])?json_encode($data['contact']):'';//json_encode($data['contact']);            //存储联系方式
            //图片加密处理
            $data['fileinfo'] = !empty($data['fileinfo']) ? $data['fileinfo'] : '';
            $arr = array();
            //加密多文件处理
            if(!empty($data['fileinfo'])){
                foreach($data['fileinfo'] as $k=>$v)
                {
                    //$fileinfo = json_decode(str_replace('\"','"',$v));
                    $filename = $this->tmp_path.'/'.$v;
                    if(file_exists($filename))
                    {
                        $arr[] = mod_member::get_file_crypt($v);
                    }
                }
                $data['handover_file'] = json_encode($arr);
            }else{
                $data['handover_file'] = '';
            }

            //免职/离职资料
            $log_data = array(
                'create_time'=>time(),                                  //当前记录时间
                'create_user'=>$this->userinfo['admin_id'],             //操作人
                'quit_val' =>$data['quit_val'],                         //离职原因
                'quit_why' =>$data['quit_why'],                         //原因说明
                'handover_object'=>$data['handover_object'],            //工作交接对象
                'handover_file'=>$data['handover_file'],                //任职文件记录
                'quit_time'    =>strtotime($data['quit_time']),         //离职时间
                'contact_type'    =>$data['contact_type'],   //离职后联系方式类型
                'contact'    =>$data['contact'],             //离职后联系方式
                'mid'=>$id                                     //member关联id
            );

            //$insert_id = db::insert($this->quit_log,$log_data);
            list($insert_id, $rows_affected) = db::insert($this->quit_log)->set($log_data) ->execute();

            //获取免职前岗位数据

            //清除当前子岗位编号
            db::query("update `$this->station_list` set `member_id`='0' where `member_id`='{$id}' ")->execute();
            if(!empty($quit_sta) && $quit_sta=='1')
            {
                //离职更改状态并清除必要数据
                $quit_info = array
                 (
                    'job_sta'=>'2',
                    'sta'=>'2',
                    'entry_organization'=>'',
                    'entry_department'=>'',
                    'entry_job'=>'',
                    'job_code_id'=>'',
                    'member_pass'=>'',
                 );
                $msg = '员工离职成功';
                db::update($this->table)->set($quit_info)->where('id','=',$id)->execute();
            }else{
                //获取组织当前等级
                //$station_level = db::get_one("select `level_id` from `#PB#_station` where `id`='{$rows['entry_job']}'");
                $station_level = db::select("level_id")->from($this->station)->where('id',$rows['entry_job'])->as_row()->execute();
                if(!empty($rows['entry_job'])){
                    $organization_level = mod_member::get_organization_level('#PB#_organize_level',$station_level['level_id']);
                }
                //免职记录
                $log_data = array(
                    'create_time'=>time(),                                  //当前记录时间
                    'create_user'=>$this->userinfo['admin_id'],             //操作人
                    'job_time'=>time(),                                     //当前记录时间
                    'log_val' => $data['quit_val'],                         //任免记录
                    'job_why' =>$data['quit_why'],                          //任免原因
                    'department_first' =>$rows['entry_department'],         //任免前部门
                    'department_last' =>'',                                 //任免后部门
                    'organization_first' =>$rows['entry_organization'],     //任免前机构
                    'organization_last' =>'',                               //任免后机构
                    'job_first' =>$rows['entry_job'],                       //任免前职位
                    'job_last' =>'',                                        //任免后职位
                    'organization_first_level' => !empty($organization_level)?$organization_level:'',                     //任免前组织等级
                    'organization_last_level' => '',                        //任免后职位等级
                    'working_num'=>'',                                      //任职文件编号
                    'job_file'=>'',                                         //任职文件记录
                    'mid'=>$id,                                             //member关联id
                    'type'=>'2'                                             //任职记录类型1任职，2免职
                );

                //插入免职记录
                list($insert_id, $rows_affected) = db::insert($this->job_log)->set($log_data) ->execute();
                $quit_info = array
                (
                    'job_sta'=>'3',
                    'entry_job'=>'',
                );
                $msg = '员工免职成功';
                //更改在职状态为免职
                db::update($this->table)->set($quit_info)->where('id','=',$id)->execute();
            }

            //重置子岗位列表状态
            db::query("update `$this->station_list` set `member_id`='0' where `id`='{$chird_job}' ")->execute();
            if($insert_id)
            {
                cls_msgbox::show('系统提示', $msg, "?ct=member&ac=show&id=$id&type=quit", 3000);
            }

        } else {
            if (empty($id)) {
                cls_msgbox::show('系统提示', "请选择要查看的员工", -1, 3000);
            }
            //$rows = db::get_one("select * from `$this->table` where `id`='{$id}' and `del_user`='' ");
            $rows = db::select($this->field)->from($this->table)->where(array(['id','=',$id],['del_user','=','']))->as_row()->execute();
            if (empty($rows)) {
                cls_msgbox::show('系统提示', "你选择的员工不存在", -1, 3000);
            }
            $organization_level = '';
            //获取组织等级
            if (!empty($rows['entry_job'])) {
                $organization_level = mod_member::get_organization_level('#PB#_station', $rows['entry_job']);

            }
            $label_name = '';
            if(!empty($quit_sta))
            {
                $label_name = '离职';
                $label_date_name = '解除/终止劳动合同日期';
            }else
            {
                $label_name = '免职';
                $label_date_name  = '免职日期';
            }
            $m_where = array(['entry_organization','=',$rows['entry_organization']],['id','!=',$rows['id']]);
            $member_data = db::select($this->field)->from($this->table)->where($m_where)->execute();
            $rows['organization_first_level'] = $organization_level;
            $contact_arr = mod_member::format_contact(json_decode($rows['contact_type']), json_decode($rows['contact']));
            $ug_contact_type = mod_member::format_ug_contact(json_decode($rows['ug_contact_type']), json_decode($rows['ug_contact_name']), json_decode($rows['ug_contact_rate']), json_decode($rows['ug_contact']));  //获取紧急联系人
            $image_data = json_decode($rows['image_data']);
            tpl::assign('image_data', $image_data);
            tpl::assign('label_name', $label_name);
            tpl::assign('label_date_name', $label_date_name);
            tpl::assign('member_data', $member_data);
            tpl::assign('organization_first_level', $organization_level);
            tpl::assign('contact_arr', $contact_arr);
            tpl::assign('ug_contact_type', $ug_contact_type);
            tpl::assign('rows', $rows);
            tpl::assign('quit_sta', $quit_sta);
            //tpl::assign('pages', $pages['show']);
            tpl::display('member.quit.tpl');
        }


    }

    /**
     * 员工离职详情
     **/
    public function member_quit_show()
    {
        $id = req::item('id');
        $type = req::item('type','');
        //$rows = db::get_one("select * from `$this->table` where `id`='{$id}' and `del_user`='' ");
        $rows = db::select($this->field)->from($this->table)->where(array(['id','=',$id],['del_user','=','']))->as_row()->execute();
        if (empty($rows)) {
            cls_msgbox::show('系统提示', "你选择的员工不存在", -1, 3000);
        }

        if(!empty($type) && $type=='2')
        {
            $title = '免职';
        }else
        {
            $title = '离职';
        }

        //$quit_data = db::get_one("select * from `$this->quit_log` where `mid`='{$rows['id']}'");
        $quit_data = db::select($this->quit_log_field)->from($this->quit_log)->where('mid',$rows['id'])->as_row()->execute();
        $contact_arr = mod_member::format_contact(json_decode($quit_data['contact_type']), json_decode($quit_data['contact']));

        $contact_arr = !empty($contact_arr) ? $contact_arr : '';

        $file_data = json_decode($quit_data['handover_file']);
        $handover_object = '';
        if($quit_data['handover_object'])
        {
            $handover_object = mod_member::get_handover_object($quit_data['handover_object']);
        }

        tpl::assign('file_data', $file_data);

        tpl::assign('title', $title);

        tpl::assign('member_data', $handover_object);

        tpl::assign('contact_arr', $contact_arr);

        tpl::assign('quit_data', $quit_data);

        tpl::assign('rows', $rows);

        tpl::display('member.quit.show.tpl');

    }

    /**
     * 部门下员工.
     */
    public function department_staff()
    {

        $keyword = req::item('keyword', '');
        $department_id = req::item('id', 0, 'int');
        $organization_id = req::item('organization_id', 0, 'int');
        $page_size = req::item('page_size', 10);
        $department_add_type = req::item('department_add_type','');
        $type = req::item('type', '', 'string');
        if (empty($organization_id) || empty($department_id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }


        $condition = array();
        if (!empty($keyword)) {
            $condition['realname like'] = "%".$keyword."%";
        }

        if (!empty($organization_id)) {
            $condition['entry_organization'] = $organization_id;
        }
        if (!empty($department_id)) {
            $condition['entry_department'] = $department_id;
        }
        $condition['del_user'] = 0;
        $count = mod_member::instance()->count($condition);
        $pages = pub_page::make($count, $page_size);
        $list = mod_member::instance()->get_list_data($condition, '', '', "{$pages['offset']}, {$pages['page_size']}", 'id desc');

        // 机构数据.
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `name`');
        // 部门数据.
        $department_data = mod_department::instance()->get_one_data(array('id' => $department_id), '`id`,`name`, `delete_user`');

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::assign('department_add_type',$department_add_type);
        tpl::assign('department_data', $department_data);
        tpl::assign('organization_id', $organization_id);
        tpl::assign('is_depart_deleted', $department_data['delete_user']);
        tpl::assign('department_id', $department_id);
        tpl::assign('organizations', $organizations);
        tpl::assign('type', $type);
        tpl::assign('index', 'department_member');
        tpl::display('organization_company.department_staff.tpl');
    }


//    /**
//     * 岗位tpl
//     */
//    public function member_job_menu_tpl()
//    {
//        $sql = "select * from  `#PB#_organization` where `delete_user`=''";
//        $organization = db::get_all($sql);
//        tpl::assign('organization',$organization);
//        tpl::display('member_job_menu_tpl.tpl');
//    }
    /**
     * 根据机构id返回机构下所有部门
     */
    public function ajax_get_demp()
    {
        $id = request('id');
//        $sql = "select `id`,`name` from `#PB#_department` where `organization_id`='{$id}'";
//        $data = db::get_all($sql);
        $data = db::select("id,name")->from('#PB#_department')->where('organization_id','=',$id)->execute();
        if($data){
            echo  json_encode($data);
        }


    }

    /**
     * 根据部门id返回部门下所有岗位
     */
    public function ajax_get_demp_job()
    {
        $id = request('id');
//        $sql = "select `id`,`name` from `#PB#_station` where `department_id`='{$id}'";
//
//        $data = db::get_all($sql);
        $data = db::select("id,name")->from('#PB#_station')->where('department_id','=',$id)->execute();
        if($data){
            echo  json_encode($data);
        }
    }
    /**
     *  根据机构id返回部门下所有岗位
     */
    public function ajax_get_org_job()
    {
        $id = request('id');
        //$sql = "select `id`,`name` from `#PB#_station` where `organization_id`='{$id}'";
        $data = db::select("id,name")->from('#PB#_station')->where('organization_id','=',$id)->execute();
        if($data){
            echo  json_encode($data);
        }
    }

    /**
     * 证件图片显示
     */
    public function img_show()
    {
                $id = request('id','0');
                $k = request('k');
                //$image_data = db::get_one("select `image_data` from `$this->table` where `id`='{$id}'");
                $image_data = db::select('image_data')->from($this->table)->where('id','=',$id)->as_row()->execute();
                if(empty($image_data))
                {
                    exit('error:图片数据不存在');
                }
                $info = json_decode($image_data['image_data']);

                //$key=substr($info[$k]->key,0,16);
                $key = $info[$k]->key;
                //$iv=substr($info[$k]->iv,0,16);
                //读取图片

                $ciphertext = file_get_contents(PATH_UPLOADS."/image/{$info[$k]->file_name}");
                //解密
                $plaintext = cls_crypt::decode($ciphertext, $key);
                echo $plaintext;
                exit;
//                $plaintext = file_put_contents(PATH_UPLOADS."/image/{$info[$k]->file_name}", $plaintext);
//                header("Content-type: application/octet-stream");
//                header('Content-Disposition: attachment; filename="'.basename($info[$k]->file_name) . '"');
//                header("Content-Length:".strlen($plaintext));
//                echo $plaintext;
//                exit();
    }
    /**
     * 证件大图显示
     * **/
    public function img_show_big()
    {
        $id = request('id','0');
        $rows['id'] = $id;
        $k = request('k');
        $image_data = db::select('image_data')->from($this->table)->where('id','=',$id)->as_row()->execute();
        if(empty($image_data))
        {
            exit('error:图片数据不存在');
        }
        $image_data = json_decode($image_data['image_data']);
        tpl::assign('image_data',$image_data);
        tpl::assign('rows',$rows);
        tpl::display('img_show_big.tpl');
    }


    /**
     * 任职文件下载
     */
    public function download()
    {
        $id = req::item('id');

        //$row = db::get_one($sql);
        $row = db::select('job_file')->from($this->job_log)->where('id',$id)->as_row()->execute();
        if(empty($row))
        {
            exit('error:文件数据不存在');
        }
       //创建临时文件
        pub_zip::add($this->tmp_path . '/zip_dir');
        if ($row['job_file']) {
            $arr = json_decode($row['job_file']);
            //批量解密压缩
            foreach ($arr as $k => $obj) {
                    // 读取加密ZIP内容
                    $ciphertext = file_get_contents($this->file_path . '/' . $obj->file_name);

                    //解密
                    $value = cls_crypt::decode($ciphertext, $obj->key);


                    $tmp_name = $this->tmp_path . '/' . $obj->file_name;

                    // 生成解密文件
                    file_put_contents($tmp_name, $value);

                    pub_zip::add($tmp_name);
                }

            //pub_zip::zip($this->tmp_path . '/down.zip');
            pub_zip::zip($this->tmp_path . $obj->file_name);
            pub_zip::close();
            $down_file_name = $this->tmp_path.$obj->file_name;
            $filename = $obj->file_name;
            util::down($down_file_name, $filename);
        }
    }

    /**
     * 离职文件下载
     */
    public function quit_download()
    {
        $id = req::item('id');
        $kk = req::item('k');
        $row = db::select('handover_file')->from($this->quit_log)->where('id',$id)->as_row()->execute();

        if(empty($row))
        {
            exit('error:文件数据不存在');
        }

        //创建临时文件
        pub_zip::add($this->tmp_path . '/zip_dir');
        if ($row['handover_file']) {
            $arr = json_decode($row['handover_file']);
            //指定key的文件名称
            $filename = $arr[$kk]->file_name;
            $key = $arr[$kk]->key;
            // 读取加密ZIP内容
            $ciphertext = file_get_contents($this->file_path . '/' . $filename);
            // 解密
            $plaintext = cls_crypt::decode($ciphertext, $key);
            $tmp_name = $this->tmp_path . '/' . $filename;
            // 生成解密文件
            file_put_contents($tmp_name, $plaintext);
            pub_zip::add($tmp_name);
            pub_zip::zip($this->tmp_path . '/down.zip');
            pub_zip::close();
            $down_file_name = $this->tmp_path.'/down.zip';
            $filename = "down.zip";
            util::down($down_file_name, $filename);
        }else
        {
            exit('error:文件不存在');
        }
    }


    //单一的ajax返回下级部门
    public function ajax_chird_data()
    {
        $id =req::item('cid');
        $table ="#PB#_".req::item('table','');
        $field = req::item('field','organization_id');  //数字库关联字段
        $where[] = array('delete_user','=','');
        $where[] = array($field,'=',$id);
        $data = mod_member::get_data($table,array('id','name'),$where);
        $option = "<option value=''>请选择部门</option>";
        if($data)
        {
            //查找父级下的所有子级元素
            foreach($data as $k=>$v)
            {
                $option .= "<option value='$k'>$v</option>\n";
            }

        }
        echo  $option;

    }
    //ajax当部门为无的时候返回机构对应的岗位
    public function ajax_mechan_job()
    {
        $pid = req::item('pid');
        //$condition = " where `organization_id`='{$pid}' ";
        //$data = db::get_all("select * from `$this->station` ".$condition);
        $s_where[] = array('organization_id','=',$pid);
        $s_where[] = array('delete_user','=','');
        $data = db::select(mod_station::get_all_fields())->from($this->station)->where($s_where)->execute();
        $job_arr = array();
        if($data)
        {
            //需要返回是否有子岗位chirend_id
            foreach($data as $k=>$v)
            {
                //$station = db::get_one("select `id` from $this->station_list where `station_id`='{$v['id']}'");
                //$list_where[] = array('station_id','=',$v['id']);
                $list_where = array(
                    array('station_id','=',$v['id']),
                    array('member_id','=',''),
                    array('delete_user','=',''),
                );
                $station = db::select("id")->from($this->station_list)->where($list_where)->as_row()->execute();

                if(!empty($station))
                {
                    $job_arr[$k]['chirend_id'] = '1';
                    $job_arr[$k]['id'] = $v['id'];
                    $job_arr[$k]['name'] = $v['name'];
                }else{
                    $job_arr[$k]['chirend_id'] = '0';
                }
            }
        }

        echo json_encode($job_arr);
    }

    //ajax返回岗位编制
    public function ajax_station_list()
    {
        $id = req::item('id');
        $where = array(['station_id','=',$id],['member_id','=',0],['delete_user','=','']);
        $data = db::select("id,code,external_name as name")->from($this->station_list)->where($where)->execute();
        echo json_encode($data);
    }

    //ajax返回上级部门对应岗位
    public function ajax_entry_job()
    {

        $pid = req::item('pid');
        //$condition = " where `department_id`='{$pid}' ";
        $job_arr = array();
        $where[] = array('department_id','=',$pid);
        $where[] = array('delete_user','=','');
        //$data = db::get_all("select * from `$this->station` ".$condition);
        $data = db::select(mod_station::get_all_fields())->from($this->station)->where($where)->execute();

        if(!empty($data))
        {

            //需要返回是否有下级岗位
            foreach($data as $k=>$v)
            {
                $list_where = array(
                    array('station_id','=',$v['id']),
                    array('member_id','=',''),
                );
                $station = db::select("id")->from($this->station_list)->where($list_where)->as_row()->execute();
                if(!empty($station))
                {
                    $job_arr[$k]['chirend_id'] = '1';
                    $job_arr[$k]['id'] = $v['id'];
                    $job_arr[$k]['name'] = $v['name'];
                }else{
                    $job_arr[$k]['chirend_id'] = '0';
                }
            }
        }
        exit(json_encode($job_arr));
    }

//    //ajax获取对应岗位的员工编号
//    public function ajax_get_entry_job_num()
//    {
//        $entry_job = req::item('entry_job');  //根据员工岗位获取员工编号
//        //$condition = " where `id`='{$entry_job}'";
//        $where[] = array('id','=',$entry_job);
//        //$data = db::get_all("select `id`,`number` from `#PB#_station` $condition");
//        $data = db::select("id,number")->from($this->station)->where($where)->execute();
//        $option = "<option value=''>请选择员工编号</option>";
//        if($data)
//        {
//            foreach($data as $k=>$v)
//            {
//                $option .= "<option value=".$v['id'].">".$v['number']."</option>\n";
//            }
//        }
//        echo $option;
//    }


    //aiaj返回下级地区
    public function ajax_get_chird_area()
    {
        $pid = req::item('pid');
        //$sql  = "select `id`,`name` from `#PB#_area` where `parent_id`='{$pid}'";
        //$arr = db::get_all($sql);
        $arr = db::select("id,name")->from('#PB#_area')->where('parent_id','=',$pid)->execute();
        $option = "<option value='' >请选择</option>";
        if(!empty($arr))
        {
            foreach($arr as $k=>$v)
            {
                $option.="<option value=$v[id]>$v[name]</option>";
            }
        }
        echo $option;
    }










}
