<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * Created by PhpStorm.
 * User: nengliu
 * Date: 2018/3/31
 * Time: 下午7:48
 */
class ctl_organization_api
{

    /**
     * 获取机构列表.
     */
    public function get_organization_list()
    {
        $data = array(
            'status' => 0,
            'message' => '',
            'data' => array(
                'top' => array(),
                'sub_org' => array(),
                'department' => array(),
                'station' => array(),
                'member' => array()
            ),
        );

        try{
            $org_id = req::item('org_id', 0, 'int');
            if (empty($org_id)) {
                $top = mod_organization::instance()->get_top_organization();
                $data['data']['top'] = $top;
                $org_id = $top['id'];
            }

            if (empty($org_id)) {
                $data['status'] = 1;
                $data['message'] = '参数错误!';
                echo json_encode($data);
            }

            // 下级机构.
            $sub_org = mod_organization::instance()->get_sub_org_list(array($org_id));
            // 机构下部门.
            $department = mod_department::instance()->get_list_normal_in_org(array($org_id));
            // 机构下岗位.
            $station = mod_station::instance()->get_list_normal_in_org(array($org_id));
            foreach ($sub_org as $key => $value) {
                $count = mod_organization::instance()->checkout_is_sub($value['id']);
                $sub_org[$key]['is_sub'] = $count;
            }

            foreach ($department as $key => $value) {
                $count = mod_department::instance()->checkout_is_sub($value['id']);
                $department[$key]['is_sub'] = $count;
            }

            foreach ($station as $key => $value) {
                $count = mod_station::instance()->checkout_is_sub($value['id']);
                $station[$key]['is_sub'] = $count;
            }

            $data['data']['sub_org'] = $sub_org;
            $data['data']['department'] = $department;
            $data['data']['station'] = $station;
            // 机构下员工.
            $data['data']['member'] = mod_member::instance()->get_list_normal_in_org(array($org_id));
        }catch (\Exception $e) {
            $data['status'] = '404';
            $data['message'] = $e->getMessage();
        }

        echo json_encode($data);
    }

    /**
     * 获取下级部门,下岗位及员工.
     */
    public function get_department_list()
    {
        $data = array(
            'status' => 0,
            'message' => '',
            'data' => array(
                'department' => array(),
                'station' => array(),
                'member' => array(),
            ),
        );

        try{
            $dep_id = req::item('dep_id', 0, 'int');
            if (empty($dep_id)) {
                $data['status'] = 1;
                $data['message'] = '参数错误!';
                echo json_encode($data);
            }

            // 下级部门.
            $sub_department = mod_department::instance()->get_list_normal_in_sub(array($dep_id));
            // 部门下岗位.
            $station = mod_station::instance()->get_list_normal_in_dep(array($dep_id));

            foreach ($sub_department as $key => $value) {
                $count = mod_department::instance()->checkout_is_sub($value['id']);
                $sub_department[$key]['is_sub'] = $count;
            }

            foreach ($station as $key => $value) {
                $count = mod_station::instance()->checkout_is_sub($value['id']);
                $station[$key]['is_sub'] = $count;
            }

            $data['data']['department'] = $sub_department;
            $data['data']['station'] = $station;
            $data['data']['member'] = mod_member::instance()->get_list_normal_in_dep(array($dep_id));
        }catch (\Exception $e) {
            $data['status'] = '404';
            $data['message'] = $e->getMessage();
        }

        echo json_encode($data);
    }

    /**
     * 获取部门下岗位及员工.
     */
    public function get_station_list()
    {
        $data = array(
            'status' => 0,
            'message' => '',
            'data' => array(
                'station' => array(),
                'member' => array(),
            ),
        );

        try{
            $station_id = req::item('station_id', 0, 'int');
            if (empty($station_id)) {
                $data['status'] = 1;
                $data['message'] = '参数错误!';
                echo json_encode($data);
            }

            // 下级岗位.
            $sub_station = mod_station::instance()->get_list_normal_in_sub(array($station_id));

            foreach ($sub_station as $key => $value) {
                $count = mod_station::instance()->checkout_is_sub($value['id']);
                $sub_station[$key]['is_sub'] = $count;
            }

            $data['data']['station'] = $sub_station;
            $data['data']['member'] = mod_member::instance()->get_list_normal_in_station(array($station_id));
        }catch (\Exception $e) {
            $data['status'] = '404';
            $data['message'] = $e->getMessage();
        }

        echo json_encode($data);
    }

}