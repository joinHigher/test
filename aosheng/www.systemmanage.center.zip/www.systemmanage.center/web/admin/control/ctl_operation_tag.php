<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 业务属性管理
 *
 * @version $Id$
 */
class ctl_operation_tag
{

    protected  $org_table = '#PB#_organization';

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $this->table = '#PB#_operation_tag';
        $this->baseUrl = '?ct=operation_tag&ac=index';
        $this->where = [
            ['delete_user', '=', '0'],
            ['delete_time', '=', '0']
        ];
    }

    /**
    * @desc 列表页
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 20);


        if(!empty($keyword))
        {
            $this->where[] = array('tag_name', 'like', "%{$keyword}%");
        }
        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();

        $pages = pub_page::make($row['count'], $page_size);
        $arr  = db::select("id,tag_name,mec_id")->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('id','asc')->execute();

        $arr = $this->get_organization_data($arr);

        tpl::assign('list', $arr);
        tpl::assign('pages', $pages['show']);
        tpl::display('operation_tag.index.tpl');
    }

    /**
     * @desc 增加业务属性
     */
    public function add()
    {

        if (!empty(req::$posts))
        {
            $data = req::$posts;

            if (empty($data['tag_name'])) cls_msgbox::show('系统提示', '请填写名称','-1');
            $this->where[] = ['tag_name','=',$data['tag_name']];
            $row = db::select('tag_name')->from($this->table)->where($this->where)->as_row()->execute();
            if (!empty($row))
            {
                cls_msgbox::show('系统提示', '名称已存在，请修正','-1');
            }

            if($data['mec_id'] == "all")
            {
                $mec_data = db::select('id')->from('#PB#_organization')->where('delete_user','0')->and_where('delete_time','0')->execute();
                $data['mec_id'] = is_array($mec_data) ? implode(',',array_column($mec_data,'id')) : '';
           }

            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['create_time'] = time();

            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加业务属性，id为{$insert_id}的记录");
            $gourl = req::item('gourl', '?ct=operation_tag&ac=add');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }else
        {
            $org_data = self::org_data();
            tpl::assign('org_data', $org_data);
            tpl::display('operation_tag.add.tpl');
        }

    }

    /**
     * @desc 编辑业务属性
     **/
    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts))
        {
            $data = req::$posts;

            if (empty($data['tag_name'])) cls_msgbox::show('系统提示', '请填写名称','-1');

            $row  = db::select('tag_name')->from($this->table)->where('tag_name',$data['tag_name'])->and_where('id','!=',$id)->and_where($this->where)->as_row()->execute();

            if (!empty($row))
            {
                cls_msgbox::show('系统提示', '名称已存在，请修正','-1');
            }

            if($data['mec_id'] == "all")
            {
                $mec_data = db::select('id')->from('#PB#_organization')->where($this->where)->execute();
                $data['mec_id'] = is_array($mec_data) ? implode(',',array_column($mec_data,'id')) : '';

            }

            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();
            db::update($this->table)
                ->set($data)
                ->where('id', '=', $id)
                ->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改业务属性ID为{$id}的数据");
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }else
        {
            $row  = db::select('id,tag_name,mec_id')->from($this->table)->where('id',$id)->and_where($this->where)->as_row()->execute();
            $row['region'] = $this-> get_org_date_one($row['mec_id']);

            $org_data = self::org_data();
            tpl::assign('org_data', $org_data);
            tpl::assign('data', $row);
            tpl::display('operation_tag.edit.tpl');
        }
    }
    /**
     * @desc 删除业务属性
     */
    public function del()
    {
        $id = req::item('id', 0,'int');
        if(!$id)
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');exit;
        }
        $delete_arr = array
        (
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );

        db::update($this->table)
            ->set($delete_arr)
            ->where('id', '=', $id)
            ->execute();
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除业务属性ID为：{$id}的数据");
        $gourl =$this->baseUrl;
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    /**
    * @desc 获取机构名称
     */
    private function get_organization_data($arr)
    {
        if(!empty($arr))
        {
            foreach ($arr as $key => $value)
            {
                $arr[$key]['region'] = $this -> get_org_date_one($value['mec_id']);

            }
        }

        return $arr;
    }



    private  function get_org_date_one($mec_id)
    {
        $region = "";
        if($mec_id)
        {
            $mec_id = explode(',',$mec_id);
            $row = db::select('name')->from($this->org_table)->where('id','in',$mec_id)->and_where('delete_user','0')->and_where('delete_time','0')->execute();
            if(!empty($row))
            {
                $org = is_array($row) && isset($row[1]) ? $row[0]['name'].'、'.$row[1]['name'] : $row[0]['name'];
                $region = $org . '等'.count($row).'个机构可用';
            }else{
                $region = "<span style='color: #881b1b'>暂无可用机构</span>";
            }

        }else{
            $region = "全部机构可用";
        }
        return $region;
    }


    /*public function ajax_org_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'departments' => array(),
            'stations' => array(),
            'organization' => array(),
        );
        $organization_id = req::item('organization_id', 0, 'int');

        if (empty($organization_id))
        {
            $result = array(
                'status' => 1,
                'message' => '数据有误'
            );
            echo json_encode($result);exit;
        }
        // 点击部门岗位下的部门与机构
        $departments = db::get_all("Select `id`, `name` From `#PB#_department` WHERE `organization_id` ='{$organization_id}' AND `delete_user` ='0' AND `delete_time` ='0'");
        $stations = db::get_all("Select `id`, `name` From `#PB#_station` WHERE `organization_id` ='{$organization_id}' AND `delete_user` ='0' AND `delete_time` ='0'");

        if (!empty($departments))
        {
            $result['departments'] = $departments;
        }
        if (!empty($stations))
        {
            $result['stations'] = $stations;
        }
        echo json_encode($result);exit;
    }*/



    private static  function  org_data()
    {
        $list = db::select('id,name')->from('#PB#_organization')->where('delete_user','0')->and_where('delete_time','0')->execute();
        return $list;
    }




}
