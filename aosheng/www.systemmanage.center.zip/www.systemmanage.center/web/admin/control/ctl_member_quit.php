<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 员工离职管理
 *
 * @version $Id$
 */
class ctl_member_quit
{

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        //离职员工资料表
        $this->table = "#PB#_member_quit";
    }

    /**
     * 员工离职列表
    */
    public function index()
    {
        echo '员工离职列表';
    }

    /**
     * 添加离职员工
     */
    public  function add()
    {
        echo "提交离职资料";
    }











}
