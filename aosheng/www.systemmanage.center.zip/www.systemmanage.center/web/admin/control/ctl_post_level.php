<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 岗位等级管理
 *
 * @version $Id$
 */
class ctl_post_level
{
    public function __construct()
    {
        $this->level = mod_organize_level::get_config_level('post_level');
        $this->table = '#PB#_post_level';
        $this->where = [
            ['delete_user', '=', '0'],
            ['delete_time', '=', '0']
        ];
        tpl::assign('level', $this->level);
    }

    /**
    * @desc 列表
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 20);

        if(!empty($keyword))
        {
            //$where[] = "`title` Like '%{$title}%'";
            $this->where[] = array('level_name', 'like', "%{$keyword}%");
        }

        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();
        $pages = pub_page::make($row['count'], $page_size);
        $list  = db::select('id,level,level_name,status')->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('id','asc')->execute();

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('post_level.index.tpl');
    }


    /**
    * @desc 添加
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            if (empty($data['level'])) cls_msgbox::show('系统提示', '请选择等级','-1');
            if (empty($data['level_name'])) cls_msgbox::show('系统提示', '请填写等级名称','-1');

            $post_info  = db::select('id')->from($this->table)->where('level',$data['level'])->and_where($this->where)->as_row()->execute();

            if(!empty($post_info))   cls_msgbox::show('系统提示', "等级已存在，请重新选择", '-1');

            $data['create_user'] = cls_auth::$user->fields['uid'];
            $data['create_time'] = time();

            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增岗位资历 ID为{$insert_id}的数据");

            $gourl = req::item('gourl', '?ct=post_level&ac=add');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else
        {
            $gourl = '?ct=post_level&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('post_level.add.tpl');
        }
    }



    /**
     * @desc 编辑
     */
    public function edit()
    {
        $id = req::item('id', 0, 'int');
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            if (empty($data['level'])) cls_msgbox::show('系统提示', '请选择岗位资历');
            if (empty($data['level_name'])) cls_msgbox::show('系统提示', '请填写等级名称');

            $post_info = db::select('level')->from($this->table)->where('level',$data['level'])->and_where('id','!=',$id)->and_where($this->where)->as_row()->execute();
            if (!empty($post_info)) cls_msgbox::show('系统提示', "等级已存在，请重新选择", '-1');

            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();
            db::update($this->table)
                ->set($data)
                ->where('id', '=', $id)
                ->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了岗位资历ID为{$id}的数据");
            $gourl = req::item('gourl', "?ct=post_level&ac=index");
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }else{
            $post_info = db::select('id,level,level_name,status')->from($this->table)->where('id',$id)->and_where($this->where)->as_row()->execute();
            $gourl = '?ct=post_level&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::assign('post_info', $post_info);
            tpl::display('post_level.edit.tpl');
        }
    }

}
