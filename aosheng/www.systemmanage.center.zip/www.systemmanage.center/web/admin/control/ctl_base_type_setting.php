<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 机构，部门，待遇，联系方式，等等一些基础数据 属性或者类型的 相关操作
 *
 * @version $Id$
 */
class ctl_base_type_setting
{
    //数据表名称
    public $table = '#PB#_base_type_setting';

    public $html = '';

//----------------------------证件类型------------------------------------------
    //证件类型列表
    public function certif_index()
    {
        $this->set_html(array( //设置html tab页面
                'ac' => 'contri_index',
                'if' => '',
                'name' => '股东出资方式'
            ),array(
                'ac' => 'certif_index',
                'if' => 'active',
                'name' => '证件类型'
        ));
        $this->index(
            '#PB#_certif_type',
            'certif',
            '证件类型',
            '?ct=base_type_setting&ac=certif_save',
            '?ct=base_type_setting&ac=certif_del'
            );
    }
    //证件类型保存
    public function certif_save()
    {
        $this->save(
            '#PB#_certif_type',
            'certif',
            '证件类型',
            '?ct=base_type_setting&ac=certif_index'
        );

    }
    //证件类型删除
    public function certif_del()
    {
        $this->del(
            '#PB#_certif_type',
            'certif',
            '?ct=base_type_setting&ac=certif_index'
        );
    }
//------------------------------出资方式----------------------------------
    //出资方式列表
    public function contri_index()
    {
        $this->set_html(array( //设置html tab页面
            'ac' => 'contri_index',
            'if' => 'active',
            'name' => '股东出资方式'
        ),array(
            'ac' => 'certif_index',
            'if' => '',
            'name' => '证件类型'
        ));
        $this->index(
            '#PB#_contribution_type',
            'contri',
            '出资方式',
            '?ct=base_type_setting&ac=contri_save',
            '?ct=base_type_setting&ac=contri_del'
        );
    }
    //出资方式类型保存
    public function contri_save()
    {
        $this->save(
            '#PB#_contribution_type',
            'contri',
            '出资方式',
            '?ct=base_type_setting&ac=contri_index'
        );
    }
    //出资方式删除操作
    public function contri_del()
    {
        $this->del(
            '#PB#_contribution_type',
            'contri',
            '?ct=base_type_setting&ac=contri_index'
        );
    }
//-------------------------------部门类型------------------------------------
    //部门类型列表
    public function depart_index()
    {
        $this->index(
            '#PB#_department_type',
            'depart',
            '部门类型',
            '?ct=base_type_setting&ac=depart_save',
            '?ct=base_type_setting&ac=depart_del'
        );
    }
    //部门类型数据保存
    public function depart_save()
    {
        $this->save(
            '#PB#_department_type',
            'depart',
            '部门类型',
            '?ct=base_type_setting&ac=depart_index'
        );
    }
    //部门类型删除
    public function depart_del()
    {
        $this->del(
            '#PB#_department_type',
            'depart',
            '?ct=base_type_setting&ac=depart_index'
        );
    }
//----------------------------商旅类型------------------------------------------
    //商旅类型列表
    public function business_trip_index()
    {
        $this->set_html(array( //设置html tab页面
            'ac' => 'business_trip_index',
            'if' => 'active',
            'name' => '商旅类型'
        ),array(
            'ac' => 'bussiness_treatment_index',
            'if' => '',
            'name' => '待遇类型'
        ));
        $this->index(
            '#PB#_business_type',
            'business_trip',
            '商旅类型',
            '?ct=base_type_setting&ac=business_trip_save',
            '?ct=base_type_setting&ac=business_trip_del'
        );
    }
    //商旅类型数据保存
    public function business_trip_save()
    {
        $this->save(
            '#PB#_business_type',
            'business_trip',
            '商旅类型',
            '?ct=base_type_setting&ac=business_trip_index'
        );
    }
    //商旅类型删除
    public function business_trip_del()
    {
        $this->del(
            '#PB#_business_type',
            'business_trip',
            '?ct=base_type_setting&ac=business_trip_index'
        );
    }
//----------------------------商旅待遇类型------------------------------------------
    //商旅待遇类型列表
    public function bussiness_treatment_index()
    {
        $this->set_html(array( //设置html tab页面
            'ac' => 'business_trip_index',
            'if' => '',
            'name' => '商旅类型'
        ),array(
            'ac' => 'bussiness_treatment_index',
            'if' => 'active',
            'name' => '待遇类型'
        ));
        $this->index(
            '#PB#_bussiness_treatment_type',
            'bussiness_treatment',
            '待遇类型',
            '?ct=base_type_setting&ac=bussiness_treatment_save',
            '?ct=base_type_setting&ac=bussiness_treatment_del'
        );
    }
    //商旅待遇类型数据保存
    public function bussiness_treatment_save()
    {
        $this->save(
            '#PB#_bussiness_treatment_type',
            'bussiness_treatment',
            '待遇类型',
            '?ct=base_type_setting&ac=bussiness_treatment_index'
        );
    }
    //商旅待遇类型删除
    public function bussiness_treatment_del()
    {
        $this->del(
            '#PB#_bussiness_treatment_type',
            'bussiness_treatment',
            '?ct=base_type_setting&ac=bussiness_treatment_index'
        );
    }
//----------------------------生活类型------------------------------------------
    //生活类型列表
    public function living_index()
    {
        $this->set_html(array( //设置html tab页面
            'ac' => 'living_index',
            'if' => 'active',
            'name' => '生活类型'
        ),array(
            'ac' => 'living_treatment_index',
            'if' => '',
            'name' => '待遇类型'
        ));
        $this->index(
            '#PB#_living_type',
            'living',
            '生活类型',
            '?ct=base_type_setting&ac=living_save',
            '?ct=base_type_setting&ac=living_del'
        );
    }
    //生活类型数据保存
    public function living_save()
    {
        $this->save(
            '#PB#_living_type',
            'living',
            '生活待遇',
            '?ct=base_type_setting&ac=living_index'
        );
    }
    //生活类型删除
    public function living_del()
    {
        $this->del(
            '#PB#_living_type',
            'living',
            '?ct=base_type_setting&ac=living_index'
        );
    }
//----------------------------生活待遇类型------------------------------------------
    //生活待遇类型列表
    public function living_treatment_index()
    {
        $this->set_html(array( //设置html tab页面
            'ac' => 'living_index',
            'if' => '',
            'name' => '生活类型'
        ),array(
            'ac' => 'living_treatment_index',
            'if' => 'active',
            'name' => '待遇类型'
        ));
        $this->index(
            '#PB#_living_treatment_type',
            'living_treatment',
            '生活待遇',
            '?ct=base_type_setting&ac=living_treatment_save',
            '?ct=base_type_setting&ac=living_treatment_del'
        );
    }
    //生活待遇类型数据保存
    public function living_treatment_save()
    {
        $this->save(
            '#PB#_living_treatment_type',
            'living_treatment',
            '生活待遇',
            '?ct=base_type_setting&ac=living_treatment_index'
        );
    }
    //生活待遇类型删除
    public function living_treatment_del()
    {
        $this->del(
            '#PB#_living_treatment_type',
            'living_treatment',
            '?ct=base_type_setting&ac=living_treatment_index'
        );
    }
//----------------------------联系方式------------------------------------------
    //联系方式列表
    public function contact_index()
    {
        $this->index(
            '#PB#_living_treatment_type',
            'contact',
            '联系方式',
            '?ct=base_type_setting&ac=contact_save',
            '?ct=base_type_setting&ac=contact_del'
        );
    }
    //联系方式数据保存
    public function contact_save()
    {
        $this->save(
            '#PB#_living_treatment_type',
            'contact',
            '联系方式',
            '?ct=base_type_setting&ac=contact_index'
        );
    }
    //联系方式 删除
    public function contact_del()
    {
        $this->del(
            '#PB#_living_treatment_type',
            'contact',
            '?ct=base_type_setting&ac=contact_index'
        );
    }

    //公共的列表操作，搜索
    private function index($table = '',$type = '',$page_title,$save_url,$del_url)
    {
        $keyword = req::item('keyword', '');
        $where = array();
        $where[] = array('delete_user','=','0');
        $where[] = array('type','=',$type);
        if (!empty($keyword))
        {
            $where[] = array('name','Like',"%{$keyword}%");
        }

        $row = db::select('count(id) AS `count`')->from($this->table)->where($where)->execute();

        $pages = pub_page::make($row[0]['count'], 10);

        $list = db::select(array('id','name'))->from($this->table)->where($where)->limit($pages['page_size'])->offset($pages['offset'])->execute();

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);


        tpl::assign('page_title',$page_title);
        tpl::assign('save_url',$save_url);
        tpl::assign('del_url',$del_url);

        tpl::assign('change_html',$this->html);
        tpl::display('base_type_setting.index.tpl');
    }

    //公共的数据保存操作 包括添加和编辑的保存
    private function save($table = '',$type='',$page_title,$url)
    {
        if(empty($type) || empty($url)) return false;
        $id  = req::item('id',0);
        $save['name'] = req::item('name','');
        $save['update_time'] = time();
        $save['update_user'] = cls_auth::$user->fields['admin_id'];
        //验证数据合法性
        if(empty($save['name']) || mb_strlen($save['name']) > 10 )
        {
            cls_msgbox::show('系统提示', $page_title."名称不合法，请重新输入",$url);
        }

        $data_one = db::select('id')->from($this->table)->where(array(
            array('type','=',$type),
            array('delete_user','=','0'),
            array('name','=',$save["name"])
        ))->execute();
        if($data_one[0]['id'] > 0 && $data_one[0]['id'] != $id)
        {//过滤同名类型
            cls_msgbox::show('系统提示', "【 {$save['name']} 】{$page_title}名称已经存在，请重新输入",$url);
        }

        if($id > 0)
        {
            //判断为编辑操作
            $res = db::update($this->table)
                ->value('name',$save['name'])
                ->value('update_user',$save['update_time'])
                ->value('update_time',$save['update_user'])
                ->where('id','=',$id)->and_where('type','=',$type)->execute();
            $op = '编辑';
        }
        else
        {   //判定为添加操纵

            $save['create_time'] = time();
            $save['type'] = $type;
            $save['create_user'] = cls_auth::$user->fields['admin_id'];
            list($res, $rows_affected) = db::insert($this->table)->set($save)->execute();
            $op = '新增';
        }
        if($res)
        {
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], $op.$page_title.'ID：'.$res);
            cls_msgbox::show('系统提示', "{$page_title}{$op}成功", $url);
        }
        else
        {
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], $op.$page_title.'DATA:'.var_export($save,1));
            cls_msgbox::show('系统提示', "{$page_title}{$op}失败", $url);
        }
    }
    //公共删除操作
    private function del($table = '', $type = '',$url)
    {
        if(empty($type)) return false;
        $id = req::item('id',0);
        if($id == '1'){
            cls_msgbox::show('系统提示', "权利部门不允许删除", $url);
        }
        if($id > 0)
        {
            $data = array(
                'update_time'=>time(),
                'update_user'=>cls_auth::$user->fields['admin_id'],
                'delete_time'=>time(),
                'delete_user'=>cls_auth::$user->fields['admin_id']
            );
            if(db::update($this->table)->set($data)->where('id','=',$id)->and_where('type','=',$type)->execute() > 0){
                cls_auth::save_admin_log(cls_auth::$user->fields['username'], mod_base_type::$get_type[$type].'删除成功ID：'.$id);
                cls_msgbox::show('系统提示', "删除成功", $url);
            }
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], mod_base_type::$get_type[$type].'删除失败ID：'.$id);
            cls_msgbox::show('系统提示', "删除失败", $url);
        }
    }

    //拼接列表页面头部页面切换的html代码
    private function set_html($one,$two)
    {
        $this->html = '<div class="widget-title nav-card-wrap"><ul class="nav nav-tabs ">';
        $this->html .= '<li class="'.$one['if'].'"><a href="?ct=base_type_setting&ac='.$one['ac'].'" >'.$one['name'].'</a></li>';
        $this->html .= '<li class="'.$two['if'].'"><a href="?ct=base_type_setting&ac='.$two['ac'].'"  >'.$two['name'].'</a></li></ul></div>';

    }





}
