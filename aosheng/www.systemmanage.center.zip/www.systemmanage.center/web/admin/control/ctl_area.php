<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 地区管理
 *
 * @version $Id$
 */
class ctl_area
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $this->table = '#PB#_area';
        $this->baseUrl = '?ct=area&ac=index';
    }

    //地区列表
    public function index()
    {
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 15);
        $zero = req::item('zero',0);
        $one = req::item('one',0);
        $even = req::item('even', 'add');
        $where = array();
        $where[] = array('delete_user','=','0');
        if (!empty($keyword))
        {
            $where[] = array('short_name','LIKE',"%{$keyword}%");
        }
        if($one > 0)
        {
            $where[] = array('path','LIKE',"%-{$one}%");
        }
        elseif( $zero > 0)
        {
            $where[] = array('path','LIKE',"0-{$zero}%");
        }


        $row = db::select("COUNT(id) AS count")->from($this->table)->where($where)->execute();
        $pages = pub_page::make($row[0]['count'], $page_size,'page_no',2);
        $where_md5 = '';
        foreach ($where as $value)
        {
            $where_md5 .= implode(':',$value);
        }
        $key = md5($where_md5.$page_size.$keyword.$pages['offset'].$pages['page_size'],$row[0]['count']);
        //$list = cache::get($this->table,$key);

        if(empty($list))
        {
            $field = array('parent_id','name','id','short_name','path','level');
            //$list = mod_area::getlist($field,$where,'', $pages['page_size'],$pages['offset']);
            $query = db::select($field)->from($this->table);
            $query->where_open();
            $query->where($where);
            $query->where_close();
            if($one > 0 && empty($keyword))
            {
                $query->or_where_open();
                $query->where('id','=',$one);
                $query->or_where_close();
            }
            elseif( $zero > 0 && empty($keyword))
            {
                $query->or_where_open();
                $query->where('id','=',$zero);
                $query->or_where_close();
            }
            $query->limit($pages['page_size']);
            $query->offset($pages['offset']);
            $list = $query->execute();

            //var_dump($query->compile());exit;
            //关联五级 上级 地址
            foreach ($list as $k => $v)
            {
                $list[$k] = mod_area::get_path_area($v);
            }
            cache::set($this->table,$key,$list,mod_area::$cache_time);
            mod_area::log_cache_key($key);
        }

        if(req::item('type') == 'test')
        {
            echo '<pre>';
            var_dump($list);
            echo '</pre>';
            exit;
        }

        tpl::assign('even', $even);
        tpl::assign('zero',$zero);
        tpl::assign('one',$one);

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);


        if($zero > 0)
        {
            tpl::assign('data_one',mod_area::getlist('short_name,id',array('parent_id','=',$zero)));
        }
        tpl::assign('country',mod_area::getlist('short_name,id',array('level','=','-1')));

        tpl::display('area.index.tpl');
    }

    /**
     * 增加地区
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            if (empty($data['name']) || empty($data['short_name']))
            {
                cls_msgbox::show('系统提示', '区域名称或简称不能为空！','-1');
            }
            $where = array(
                array('name','=',$data['name']),
                array('parent_id','=',$data['parent_id']),
                array('delete_user','=','0')
            );
            $row_name = mod_area::getdump('name',$where);
            $where = array(
                array('short_name','=',$data['short_name']),
                array('parent_id','=',$data['parent_id']),
                array('delete_user','=','0')
            );
            $row_short_name = mod_area::getdump('name',$where);
            if(!empty($row_name) || !empty($row_short_name))
            {
                cls_msgbox::show('系统提示', '您输入的区域已名称或者简称经存在' ,'-1');
            }

            $data['path'] = '0';
            if($data['parent_id'] > 0)
            {
                $parent_d = mod_area::getdump('',array('id','=',$data['parent_id']));
                $data['path'] = $parent_d['path'].'-'.$parent_d['id'];
                $data['level'] =  $parent_d['level'] + ($parent_d['level'] == '-1'?2:1);
            }

            if($data['level'] > 4)
            {
                cls_msgbox::show('系统提示', '您添加区域地址已经超过了五个级别' ,'-1');
            }
            $data['create_time'] = time();
            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            unset($data['parentid']);
            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();//新增地址数据
            //新增上级地址的chil——num数量
            mod_area::set_child_num($data['parent_id']);

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加了区域ID ：{$insert_id}");
            //清楚缓存，更新列表信息
            mod_area::celar_cache();
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "区域添加成功", $gourl);
        }
        else
        {
            $top_area = mod_area::getlist('short_name,id,level',array(
                array('level','=','-1'),
                array('delete_user','=','0')
            ));
            tpl::assign('top_area',$top_area);
            tpl::display('area.add.tpl');
        }

    }


    /**
     * 区域地址迁移，国家级地址不允许迁移
     */
    public function transfer()
    {
        $parent_id = req::item('parent_id','0');
        $parent_id_old = req::item('parent_id_old','0');
        $id = req::item('id',0);

        $path = req::item('path',false);
        if($parent_id > 0 && $parent_id_old > 0 && $path && $id > 0)
        {
            //迁出。下级关联地址处理
            //$begin  = rtrim($path,$parent_id_old);
            db::query("UPDATE `{$this->table}` SET parent_id = '{$parent_id}' WHERE  id = '{$id}'")->execute();

            $sql = "UPDATE `{$this->table}` SET path = REPLACE(path,'{$parent_id_old}','{$parent_id}') WHERE path like '{$path}%'";
            db::query($sql)->execute();
            mod_area::set_child_num($parent_id,'1');

            //var_dump($sql);exit;
            //迁出。上级地址信息处理
            mod_area::set_child_num($parent_id_old,'-1');

            mod_area::celar_cache();
            cls_msgbox::show('系统提示', "区域迁移成功", '?ct=area&ac=index');
        }
        if($id > 0)
        {
            $data = mod_area::getdump('',array('id','=',$id));
            tpl::assign('data',$data);
            //$parent_id = db::get_one("SELECT parent_id FROM `{$this->table}` WHERE  id = '{$data['parent_id']}'");
            $parent_id = mod_area::getdump('parent_id',array('id','=',$data['parent_id']));
            $parent_data = mod_area::getlist('name,short_name,id,parent_id',array('parent_id','=',$parent_id['parent_id']));
            tpl::assign('parent_data',$parent_data);
            tpl::display('area.transfer.tpl');
        }
        return false;
    }

    /**
     * 批量操作页面 下载excel地址列表的demo
     */
    public function excel()
    {
        if(req::item('download','') == 'excel')
        {
            include PATH_LIBRARY.'/phpexcel/PHPExcel.php';

            //下载 excel 地址倒入的模版文件
            $objPHPExcel = new PHPExcel();
            //标题
            $objPHPExcel->getProperties()->setTitle("地址EXCEL倒入DEMO");
            //题目
            $objPHPExcel->getProperties()->setSubject("Excel 地址表");
            //描述
            $objPHPExcel->getProperties()->setDescription("地址等级：-1，国家");

            //文明名称
            $objPHPExcel->getActiveSheet()->setTitle('区域地址Excel导入格式模版');


            $objPHPExcel->getActiveSheet()
                ->setCellValue('A1','地址等级')
                ->setCellValue('B1','国家名称')
                //->setCellValue('C1','国家简称')
                ->setCellValue('C1','州省名称')
                //->setCellValue('E1','州省简称')
                ->setCellValue('D1','市级名称')
                //->setCellValue('G1','市级简称')
                ->setCellValue('E1','区镇名称')
                //->setCellValue('I1','区镇简称')
                ->setCellValue('F1','街道名称');
                //->setCellValue('K1','街道简称');
                //->setCellValue('K1','地址等级');
                //->setCellValue('L1','用户等级');

            $objPHPExcel->getActiveSheet()
                ->setCellValue('A2','-1')
                ->setCellValue('B2','中华人民共和国')
                //->setCellValue('C2','中国')
                ->setCellValue('A3','1')
                ->setCellValue('B3','中华人民共和国')
                //->setCellValue('C3','中国')
                ->setCellValue('C3','湖北省')
                //->setCellValue('E3','湖北')
                ->setCellValue('A4','2')
                ->setCellValue('B4','中华人民共和国')
                //->setCellValue('C4','中国')
                ->setCellValue('C4','湖北省')
                //->setCellValue('E4','湖北')
                ->setCellValue('D4','武汉市')
                //->setCellValue('G4','武汉')
                ->setCellValue('A5','3')
                ->setCellValue('B5','中华人民共和国')
                //->setCellValue('C5','中国')
                ->setCellValue('C5','湖北省')
                //->setCellValue('E5','湖北')
                ->setCellValue('D5','武汉市')
                //->setCellValue('G5','武汉')
                ->setCellValue('E5','武昌区')
                //->setCellValue('I5','武昌')
                ->setCellValue('A6','4')
                ->setCellValue('B6','中华人民共和国')
                //->setCellValue('C6','中国')
                ->setCellValue('C6','湖北省')
                //->setCellValue('E6','湖北')
                ->setCellValue('D6','武汉市')
                //->setCellValue('G6','武汉')
                ->setCellValue('E6','武昌区')
                //->setCellValue('I6','武昌')
                ->setCellValue('F6','东湖风景区街道')
                //->setCellValue('K6','东湖风景区街道')
                ->setCellValue('A11',"地址等级：-1，国家；1，州省；2，市级；3，区镇；4，街道 \n Excel添加地址必须先从国家级地址开始添加，否则导入失败 \n 添加时候请删除此行内容");
            //冻结单元格
            $objPHPExcel->getActiveSheet()->freezePane('A1');

            //合并单元格
            $objPHPExcel->getActiveSheet()->mergeCells('A11:K17');
            //设置填充色
            $objPHPExcel->getActiveSheet()->getStyle('A11')->getFill()->getStartColor()->setARGB('#e26578');

            // Rename worksheet
            ////设置第一个工作表为活动工作表
            $objPHPExcel->setActiveSheetIndex(0);
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="simple.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            // If you're serving to IE over SSL, then the following may be needed
            header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
            header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header ('Pragma: public'); // HTTP/1.0
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');

            exit;
        }

        tpl::display('area.excel.tpl');
    }

    /**
     * excel地址表格文件的上传 并倒入数据库
     */
    public function update_excel()
    {
        $fileinfo = req::item('fileinfo','');
        if(empty($fileinfo))
        {
            cls_msgbox::show('系统提示', "Excel文件上传失败,导入不成功", '-1');
        }

            $filepath = PATH_UPLOADS.'/tmp/'.$fileinfo[0];
            //var_dump($filepath);exit;
            if(!file_exists($filepath)){
                cls_msgbox::show('系统提示', "Excel文件不存在", '-1');
            }
            if(mime_content_type($filepath) != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){
                cls_msgbox::show('系统提示', "Excel文件格式错误，请实用2007或以上版本的office excel", '-1');
            }
            if(filesize($filepath) > 10240*1024){
                cls_msgbox::show('系统提示', "您上传的Excel文件已超过10M", '-1');
            }

            require_once PATH_LIBRARY.'/phpexcel/PHPExcel.php';

            $objReader          = new PHPExcel_Reader_Excel2007();//excel2007 for 2007
            $objPHPExcel        = $objReader->load($filepath);

            $sheet              = $objPHPExcel->getSheet(0);
            $rows         = $sheet->getHighestRow();//取得总行数
            //$columns      = $sheet->getHighestColumn();//取得总列数
            //$columnIndex = PHPExcel_Cell::columnIndexFromString($columns);//索引

            //循环取出所有行的数据 从第二行开始起
            for ($row = 2; $row < $rows; $row++) {
                    //去除第一行数据，判断地址等级，验证数据的重复性，分别插入数据表
                    //$sheet->getCellByColumnAndRow($col, $row)->getValue();

                    $data['level'] = $sheet->getCellByColumnAndRow(0, $row)->getValue();
                    $data['level'] = intval($data['level']);
                    if(!in_array($data['level'],array('-1','1','2','3','4'))){
                        continue;
                    }
                    //根据地址 等级 分别关联上级  并检测从复地址数据。分批导入
                    switch ($data['level']) {
                        case '-1':
                            $data['short_name'] = $sheet->getCellByColumnAndRow(1, $row)->getValue();
                            $data['path'] = '0';
                            $this->excel_get_check($data['short_name'],'',$data['level'],false,$data);
                            break;
                        case '1':
                            $zero = $sheet->getCellByColumnAndRow(1, $row)->getValue();
                            $zero_info = $this->excel_get_check($zero,'','-1');

                            $data['short_name'] = $sheet->getCellByColumnAndRow(2, $row)->getValue();
                            $data['path'] = '0-' . $zero_info['id'];
                            $this->excel_get_check($data['short_name'],$zero_info['id'],$data['level'],false,$data);
                            break;
                        case '2':
                            $zero = $sheet->getCellByColumnAndRow(1, $row)->getValue();
                            $zero_info = $this->excel_get_check($zero,'','-1');

                            $one = $sheet->getCellByColumnAndRow(2, $row)->getValue();
                            $one_info = $this->excel_get_check($one,$zero_info['id'],'1');

                            $data['short_name'] = $sheet->getCellByColumnAndRow(3, $row)->getValue();
                            $data['path'] = '0-' . $zero_info['id'] . '-' . $one_info['id'];
                            $this->excel_get_check($data['short_name'],$one_info['id'],$data['level'],false,$data);
                            break;
                        case '3':
                            $zero = $sheet->getCellByColumnAndRow(1, $row)->getValue();
                            $zero_info = $this->excel_get_check($zero,'','-1');

                            $one = $sheet->getCellByColumnAndRow(2, $row)->getValue();
                            $one_info = $this->excel_get_check($one,$zero_info['id'],'1');

                            $two = $sheet->getCellByColumnAndRow(3, $row)->getValue();
                            $two_info = $this->excel_get_check($two,$one_info['id'],'2');

                            $data['short_name'] = $sheet->getCellByColumnAndRow(4, $row)->getValue();
                            $data['path'] = '0-' . $zero_info['id'] . '-' . $one_info['id'] . '-' . $two_info['id'];
                            $this->excel_get_check($data['short_name'],$two_info['id'],$data['level'],false,$data);
                            break;
                        case '4':
                            $zero = $sheet->getCellByColumnAndRow(1, $row)->getValue();
                            $zero_info = $this->excel_get_check($zero,'','-1');

                            $one = $sheet->getCellByColumnAndRow(2, $row)->getValue();
                            $one_info = $this->excel_get_check($one,$zero_info['id'],'1');

                            $two = $sheet->getCellByColumnAndRow(3, $row)->getValue();
                            $two_info = $this->excel_get_check($two,$one_info['id'],'2');

                            $thr = $sheet->getCellByColumnAndRow(4, $row)->getValue();
                            $thr_info = $this->excel_get_check($thr,$two_info['id'],'3');

                            $data['short_name'] = $sheet->getCellByColumnAndRow(5, $row)->getValue();
                            $data['path'] = '0-' . $zero_info['id'] . '-' . $one_info['id'] . '-' . $two_info['id'] . '-' . $thr_info['id'];
                            $this->excel_get_check($data['short_name'],$thr_info['id'],$data['level'],false,$data);
                            break;
                    }
            }
            mod_area::celar_cache();
            cls_msgbox::show('系统提示', "Excel地址导入成功", '?ct=area&ac=index');
    }

    //统一使用 批量插入
    private function excel_get_check($short_name = '',$parent_id = '0',$level = '-1',$boole = true, $insert = ''){
        if(empty($short_name))
        {
            return false;
        }
        $data = mod_area::getdump('id',array(
            array('short_name','=',$short_name),
            array('parent_id','=',$parent_id),
            array('level','=',$level)
        ));
        if ($data['id'] > 0 && $boole)
        {
            return $data;
        }
        if ($data['id'] > 0 && !$boole)
        {
            cls_msgbox::show('系统提示', "地址导入不成功，".mod_area::$level_intro[$level]."地址 [{$short_name}] 已经存在", '-1');
        }
        if($boole)
        {
            cls_msgbox::show('系统提示', "地址导入不成功,".mod_area::$level_intro[$level]."地址 [{$short_name}] 不存在：", '-1');
        }
        else
        {
            //地址批量保存,数据组装
            $insert['create_time'] = time();
            $insert['create_user'] = cls_auth::$user->fields['admin_id'];
            $insert['update_time'] = time();
            $insert['update_user'] = $insert['create_user'];
            $insert['name'] = $short_name;
            $insert['parent_id'] = $parent_id;
            //数据insert
            list($insert_id, $rows_affected) = db::insert($this->table)->set($insert)->execute();
            //父级的子级数目+1
            mod_area::set_child_num($parent_id);
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], " EXCEL新增地址ID：{$insert_id} ");
            return true;
        }
    }

    /**
     * 编辑地区 数据保存
     **/
    public function save()
    {
        $fou_id = req::item('fou_id',0);
        $thr_id = req::item('thr_id',0);
        $two_id = req::item('two_id',0);
        $one_id = req::item('one_id',0);
        $zero_id = req::item('zero_id',0);
        $data = array();
        if($fou_id > 0)
        {
            $data[0]['id'] = $fou_id;
            $data[0]['short_name'] = req::item('fou','');
        }
        if($thr_id > 0)
        {
            $data[1]['id'] = $thr_id;
            $data[1]['short_name'] = req::item('thr','');
        }
        if($two_id > 0)
        {
            $data[2]['id'] = $two_id;
            $data[2]['short_name'] = req::item('two','');
        }
        if($one_id > 0)
        {
            $data[3]['id'] = $one_id;
            $data[3]['short_name'] = req::item('one','');
        }
        if($zero_id > 0)
        {
            $data[4]['id'] = $zero_id;
            $data[4]['short_name'] = req::item('zero','');
        }

        foreach ($data as $val)
        {
            if(empty($val['short_name']))
            {
                cls_msgbox::show('系统提示', "区域简称不能为空", '-1');
            }
        }

        if(count($data) >= 1 && $data[4]['id'] > 0) //数据修改。国家名称必不能为空
        {
            foreach ($data as $v)
            {
                if(empty($v['short_name']) || empty($v['id']))
                {
                    continue;
                }
                db::update($this->table)->value('short_name',$v['short_name'])->where('id','=',$v['id'])->execute();
                cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改区域简称ID:{$v['id']}");
            }
            mod_area::celar_cache();
            //db::update_batch($this->table,$data,'id');
            cls_msgbox::show('系统提示', "修改成功", '?ct=area&ac=index');
        }
        cls_msgbox::show('系统提示', "修改失败", '-1');
    }

    /**
     * 区域地址编辑
     * @return bool
     */
    public function edit(){
        if(req::item('id',0) > 0){
            $area = mod_area::getdump('',array('id','=',req::item('id')));
            if(empty($area)) return false;
            $area = mod_area::get_path_area($area);
            tpl::assign('data',$area);
            tpl::display('area.edit.tpl');
            exit;
        }
        cls_msgbox::show('系统提示', "页面不村在", '-1');
    }


    /**********************************************************************************************************************
     * 地址添加  地址多级联动 异步数据    其他功能模块有调用，输出数据结构请勿修改
     */
    public function ajax_set_area()
    {
        $parent_id = req::item('parent_id',0);
        if($parent_id <= 0)
        {
            return;
        }
        $level = req::item('level');  //区域等级
        $level_name = '';
        $select_name = '';
        switch ($level)
        {
            case '-1':
                $select_name = 'province';
                $level_name = '国家';
                break;
            case '1':
                $level_name = '省份';
                $select_name = 'city';break;
            case '2':
                $level_name = '城市';
                $select_name = 'town';break;
            case '3':
                $level_name = '区县';
                $select_name = 'street';break;
            case '4':
                $level_name = '街道';
                $select_name = 'way';break;
        }

        $data = mod_area::getlist('short_name,id,parent_id,level',array(
            array('delete_user','=','0'),
            array('parent_id','=',$parent_id)
        ));
        
        $select = '';
        if(!empty($data))
        {
            $select = "<select level='".$data[0]['level']."' id='{$select_name}' name='{$select_name}' class='form-control' onchange=add_select(this); >";
            $select.="<option value='0'>请选择{$level_name}</option>";
            foreach($data as $v)
            {
                $select.="<option value='".$v['id']."'>".$v['short_name']."</option>\n";
            }

            $select.="</select>";
        }
        echo $select;
    }
    /***************************************************************中间代码请勿修改，多处调用***********************************/

    /**
     * ajax_set_area方法功能类似，重写功能只限查询数据输出
     */
    public function ajax_add_area()
    {
        $parent_id = req::item('parent_id',0);
        // $level = req::item('level');  //区域等级
        if($parent_id <= 0)
        {
            return;
        }


        $data = mod_area::getlist('short_name,id,parent_id,level',array(
            array('parent_id','=',$parent_id),
            array('delete_user','=','0')
        ));

        if(empty($data))
        {
            exit('empty');
        }
        echo json_encode($data);
    }

    /**
     * 地址树形页面列表
     */
    public function tree()
    {
        $zero = req::item('zero',0);
        $one = req::item('one',0);

        //搜索条件组织
        $where[] = array('delete_user','=','0');
        if($one > 0)
        {
            $where[] = array('parent_id','=',$one);
            tpl::assign('data_one',mod_area::getlist('short_name,name,id',array(
                array('delete_user','=','0'),
                array('parent_id','=',$zero),
                array('level','=','1')
            )));
        }
        elseif( $zero > 0)
        {
            tpl::assign('data_one',mod_area::getlist('short_name,name,id',array(
                array('delete_user','=','0'),
                array('parent_id','=',$zero),
                array('level','=','1')
            )));
            $where[] = array('parent_id','=',$zero);
        }
        else
        {
            $where[] = array('level','=','-1');
        }

        //数据查询
        $res = mod_area::getlist('short_name,name,id,child_num,level',$where);
        //db::get_all("SELECT short_name,name,id,child_num,`level` FROM `{$this->table}`  {$where}");

        //树型结构 数据组织
        $json_c = array(0 => array(
            'name' => '区域地址',
            'dr' => 6,
            'children' => $res
        ));


        tpl::assign('zero',$zero);
        tpl::assign('one',$one);

        tpl::assign('country_json',json_encode($json_c));

        tpl::assign('country',mod_area::getlist('name,short_name,id,level,parent_id',array(
            array('delete_user','=','0'),
            array('level','=','-1')
        )));

        tpl::display('area.tree.tpl');
    }


    /**
     * 地址树形列表的 ajax异步数据
     */
    public function ajax_get_tree()
    {
        $id = req::item('id',0);
        if($id > 0)
        {
            $res = mod_area::getlist("short_name,id,level,child_num",array('parent_id','=',$id));
            if(empty($res))
            {
                exit(false);
            }
            echo json_encode($res);exit;
        }
        exit(false);
    }

    public function showCache()
    {
        mod_area::celar_cache();exit;
        //var_dump(mod_area::get_level_area());exit;

        //var_dump(mod_base_type::get_bussiness_treatment_list());
        //var_dump($data);
        //$data = db::select(array('id','name'))->from('system_base_type_setting')->execute();
        //var_dump(db::select(array('id','name'))->from('system_base_type_setting')->compile());exit;
        $data = db::query("SELECT * FROM system_base_type_setting")->execute();
        foreach ($data as  $k=>$v)
        {
            //var_dump(db::update('system_base_type_setting')->value('name','你好类型'.($k+1))->where('id','=',$v['id'])->execute());exit;
            if(db::update('system_base_type_setting')->value('name',$v['name'].($k+1))->where('id','=',$v['id'])->execute())
            {
                echo 'success<hr>';
            }
            else
            {
                echo $v['id'].'<hr>';
            }
        }

        //mod_area::celar_cache();exit;

    }



}
