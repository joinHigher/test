<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 保密等级管理
 *
 * @version $Id$
 */
class ctl_security_level
{


    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $this->table = '#PB#_security_level';
        $this->baseUrl = '?ct=security_level&ac=index';
        $this->level = mod_organize_level::get_config_level('security_level');
        $this->where = [
            ['delete_user', '=', '0'],
            ['delete_time', '=', '0']
        ];
        tpl::assign('level', $this->level);
    }

    /**
    * @desc 列表页
     */
    public function index()
    {

        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 20);

        $where = array(
            array('delete_user', '=', '0'),
            array('delete_time', '=', '0')
        );
        if(!empty($keyword))
        {
            $this->where[] = array('level_name', 'like', "%{$keyword}%");
        }
        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();

        $pages = pub_page::make($row['count'], $page_size);
        $list  = db::select("id,level,level_name,level_short_name")->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('id','asc')->execute();

        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('security_level.index.tpl');
    }

    /**
     * @desc 增加级别
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;

            if (empty($data['level'])) cls_msgbox::show('系统提示', '请选择保密等级','-1');
            if (empty($data['level_name'])) cls_msgbox::show('系统提示', '请填写名称','-1');

            $row  = db::select('id')->from($this->table)
                ->where_open()
                ->where($this->where)
                ->where_close()
                ->where_open()
                ->where('level',$data['level'])
                ->or_where('level_name',$data['level_name'])
                ->where_close()
                ->as_row()
                ->execute();
            if (!empty($row))
            {
                cls_msgbox::show('系统提示', '保密等级或等级名称已存在，请修正','-1');
            }

            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['create_time'] = time();
            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加了保密等级ID为{$insert_id}的记录");
            $gourl = req::item('gourl', '?ct=security_level&ac=add');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }else
        {
            tpl::display('security_level.add.tpl');
        }

    }

    /**
     * @desc 编辑级别
     **/
    public function edit()
    {
        $id = req::item("id", 0);
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            $row  = db::select('id')->from($this->table)
                ->where_open()
                ->where($this->where)
                ->and_where('id','!=',$id)
                ->where_close()
                ->where_open()
                ->where('level',$data['level'])
                ->or_where('level_name',$data['level_name'])
                ->where_close()
                ->as_row()
                ->execute();

            if (!empty($row))
            {
                cls_msgbox::show('系统提示', '保密级别或保密名称已经存在,请修正！', '-1');
                exit();
            }

            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();

            db::update($this->table)
                ->set($data)
                ->where('id', '=', $id)
                ->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了保密等级ID为{$id}的数据");
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }else
        {
            $row = db::select('level_name,id,level,level_short_name')->from($this->table)->where('id',$id)->as_row()->execute();
            tpl::assign('row', $row);
            tpl::display('security_level.edit.tpl');

        }
    }
    /**
     * @desc 删除级别
     */
    public function del()
    {
        $id = req::item('id', 0);
        $delete_arr = array
        (
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );
        db::update($this->table)
            ->set($delete_arr)
            ->where('id', '=', $id)
            ->execute();
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "保密级别ID为{$id}被删除");
        $gourl =$this->baseUrl;
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

}
