<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 后台管理控制器
 *
 * @version $Id$
 */
class ctl_index
{
    /**
     * 主入口
     */
    public function index()
    {
        $t1 = microtime(true);
        $lang = util::get_language();
        lang::load("common", $lang);
        lang::load("menu", $lang);
        //print_r(lang::$language);
        // is_ajax 为 true 能去掉调试信息
        //call::$is_ajax = true;
        mod_admin_menu::$menu_key = "admin_menu";
        $menus = mod_admin_menu::parse_menu();
        $menus = lang::tpl_change($menus);
        tpl::assign('user', cls_auth::$user->fields );
        tpl::assign('menus', $menus);
        tpl::assign('URL_WEBSOCKET', URL_WEBSOCKET);
        if ($GLOBALS['config']['frame_ui'] == 1)
        {
            tpl::display('index.tpl');
        }
        else
        {
            tpl::display('index2.tpl');
        }
    }

    /**
     * 用户登录
     */
    public function login()
    {
        $username = req::item('username', '');
        $password = req::item('password', '');
        $validate = req::item('validate', '');
        $gourl = req::item('gourl', '');
        $errmsg = '';

        if ( req::method() == 'POST' )
        {
            try
            {
                if( $username == '' || $password == '' )
                {
                    throw new Exception('请输入用户名密码');
                }

                if ( $GLOBALS['config']['validate']['image_code'] )
                {
                    $valicode = substr($validate, 0, 4);
                    $vdimg = new cls_securimage();
                    if( empty($valicode) || !$vdimg->check($valicode) )
                    {
                        throw new Exception('请输入正确的验证码！');
                    }
                }

                if ( $GLOBALS['config']['validate']['potato_code'] )
                {
                    $valicode = substr($validate, 4);
                    if( !pub_redis::get($username.'-'.$valicode) )
                    {
                        throw new Exception('请输入正确的验证码！');
                    }
                    else
                    {
                        // 删除验证码缓存
                        pub_redis::del($username.'-'.$valicode);
                    }
                }

                $rs = cls_auth::$user->check_user( $username, $password );
                if( $rs == 1 )
                {
                    call::$auth->auth_user( cls_auth::$user->fields );
                    $jumpurl = empty($gourl) ? '?ct=index' : $gourl;
                    cls_msgbox::show('成功登录', '成功登录，正在重定向你访问的页面', $jumpurl);
                    exit();
                }
            }
            catch ( Exception $e )
            {
                $errmsg = $e->getMessage();
            }
        }

        tpl::assign('username', $username );
        tpl::assign('password', $password );
        tpl::assign('gourl', $gourl );
        tpl::assign('errmsg', $errmsg );
        tpl::display('login.tpl');
        exit();
    }

    public function xsvalidation()
    {
        $username = req::item('username');
        $password = req::item('password');
        //if( empty($username)  || empty($password) )
        //{
        //exit(json_encode(array(5822,'用户名或密码错误')));
        //}

        static $v_num = 1;
        $ret =  pub_xsverification::check_data(req::item('point'), $_SESSION['XSVer']);
        $v_num +=  $_SESSION["XSVer_VAL_SUM"];
        if( $v_num > 6 )
        {
            $_SESSION["XSVer_SUM"] = null;
            exit(json_encode(array('state'=>4603,'data'=>'验证码失效')));
        }
        else
        {
            $_SESSION["XSVer_VAL_SUM"] = $v_num;
        }

        // 验证通过
        if( $ret['state'] == 0 )
        {
            // 生成一个token
            $_SESSION["XSVer_VAL_SUM"] = 0x111;
            exit(json_encode(array('state'=>0,'data' => $_SESSION['XSVer'])));
        }
        else
        {
            exit(json_encode(array('state'=>603, 'data'=>'错误'.$v_num)));
        }
    }

    //接收登录数据
    public function get_data()
    {
        // 验证token
        if( $_SESSION["XSVer_VAL_SUM"] !== 0x111 )
        {
            exit(json_encode(array(5821,'图片验证码错误')));
        }
        // 验证通过后要清除一下，不然用户只需要拖动一次然后拿到cookie，就可以不断的提交了
        $_SESSION["XSVer_VAL_SUM"] = null;

        $username = req::item('username');
        $password = req::item('password');
        if( empty($username)  || empty($password) )
        {
            exit(json_encode(array(5822,'用户名或密码错误')));
        }
    }

    /**
     * 生成默认权限系统的数据表
     * 实际使用中创建好表后应该删除此函数
     */
    public function db_infos()
    {
        if (DEBUG_MODE === true)
        {
            $type = req::item('type', '');
            mod_make_db_document::show( $type );
        }
        exit();
    }

    /**
     * 系统消息
     */
    public function adminmsg()
    {
        $addjob = req::item('addjob', '');
        if($addjob=='del')
        {
            db::update('#PB#_admin_log')->set(array(
                'isread' => 1
            ))
                ->where('isalert', '=', 1)
                ->execute();
            exit('ok');
        }
        else
        {
            $row = db::select("count(*) As count")->from('#PB#_admin_log')
                ->where('isalert', '=', 1)
                ->and_where('isread', '=', 0)
                ->as_row()
                ->execute();
            if( is_array($row) && $row['count']>0 )
            {
                exit($row['count']);
            }
            else
            {
                exit('false');
            }
        }
    }


    /**
     * 退出
     */
    public function logout()
    {
        call::$auth->logout();
        cls_msgbox::show('注销登录', '成功退出登录！', './');
        exit();
    }

    /**
     * 验证码图片
     */
    public function validate_image()
    {
        // 如果开启了potato验证码
        if ( $GLOBALS['config']['validate']['potato_code'] )
        {
            $username = req::item('username');
            $password = req::item('password');
            if ( !empty($username) && !empty($password) )
            {
                $info = db::select('potato, password')
                    ->from('#PB#_admin')
                    ->where('username', '=', $username)
                    ->where('status', '=', 1)
                    ->as_row()
                    ->execute();
                if ( !empty($info) )
                {
                    // 得到随机数
                    $valicode = util::random('numeric', 6);
                    // 5分钟到期
                    pub_redis::set($username.'-'.$valicode, time(), 5*60);
                    pub_potato::send($info['potato'], $valicode, 'login');
                }
            }
        }

        //$text_num=4, $im_x = 200, $im_y = 40, $scale = 5, $session_name='securimage_code_value'
        //$vdimg = new cls_securimage(4, 120, 24);
        $vdimg = new cls_securimage(4, 94, 32, 3);
        call::$is_ajax = true;
        $vdimg->show();
    }

    public function language_change()
    {
        $lang = req::item("lang");
        setcookie("language", $lang);
        $gourl = '?ct=index';
        cls_msgbox::show('成功切换语言', '成功切换到语言 '.$lang.'，正在重定向你访问的页面', $gourl);
    }
}
