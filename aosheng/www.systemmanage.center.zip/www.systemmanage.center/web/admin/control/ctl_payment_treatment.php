<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 待遇管理
 *
 * @version $Id$
 */
class ctl_payment_treatment
{
    public $page_size = 10;

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        tpl::assign('treat_types',mod_payment_treatment::outside_treat_types(true));
        tpl::assign('life_types',mod_payment_treatment::outside_life_types());

        //等级初始数据
        $levels = mod_payment_treatment::outside_levels();
        tpl::assign('levels',$levels);
        $levels_dis = mod_payment_treatment::array_levels();
        tpl::assign('xing_level_json',json_encode($levels_dis[0]));
        tpl::assign('zu_level_json',json_encode($levels_dis[1]));


        tpl::assign('creator',mod_payment::get_creator());
        tpl::assign('create_time',time());
    }

    //商旅待遇列表
    public function travel_list()
    {
        $search = req::item('search', '');

        $where = [
            ["delete_user", '=', 0]
        ];
        if (!empty($search))
        {
            $where[] = ["name", 'like', "%{$search}%"];
        }

        $count = db::select('count(*)')->from(mod_table::treatment_travel)->where($where)->as_field()->execute();
        $pages = pub_page::make($count, $this->page_size);
        $fields = 'id,name,type,type_other,create_user,create_time';
        $rows = db::select($fields)->from(mod_table::treatment_travel)->where($where)->order_by('id','asc')->limit($pages['page_size'])->offset($pages['offset'])->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                $row['type_display'] = mod_payment_treatment::display_travel_type($row);

                $row['item_display'] = mod_payment_treatment::display_travel_items($row['id']);
                $row['level_display'] = mod_payment_treatment::display_travel_levels($row['id']);

                $row['creator'] = mod_payment::get_creator($row['create_user']);
            }
        }


        tpl::assign('rows', $rows);
        tpl::assign('pages', $pages['show']);
        tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
    }

    //商旅待遇详情
    public function travel_detail()
    {
        $id = req::get('id',0,'int');
        $fields = 'id,name,type,type_other,create_user,create_time';
        $row = db::select($fields)->from(mod_table::treatment_travel)->where('id','=',$id)->as_row()->execute();
        if(empty($row))
        {
            mod_common::exit_page_404();
        }

        $row['type_display'] = mod_payment_treatment::display_travel_type($row);

        $display_items = mod_payment_treatment::display_travel_items($row['id'],true);
        tpl::assign('display_items',$display_items);

        $travel_levels = mod_payment_treatment::display_travel_levels($id,true);
        $row['display_zu_level'] = implode('、',$travel_levels['zu']);
        $row['display_xing_level'] = implode('、',$travel_levels['xing']);
        $row['creator'] = mod_payment::get_creator($row['create_user']);


        tpl::assign('travel_levels',$travel_levels);
        tpl::assign('row',$row);
        tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
    }

    //删除商旅待遇
    public function travel_delete()
    {
        $id = req::get('id',0,'int');

        db::update(mod_table::treatment_travel)->set([
            'delete_user'=>cls_auth::$user->fields['uid'],
            'delete_time'=>time()
        ])->where("id",'=',$id)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除商旅待遇 ID={$id}");

        $gourl = req::item('gourl', '?ct=payment_treatment&ac=travel_list');
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    //添加商旅待遇
    public function travel_add()
    {
        if (!empty(req::$posts))
        {
            $data = [
                'name' => req::post('name'),
                'type' => req::post('type',0,'int'),
                'type_other' => req::post('other'),
                'create_user' => cls_auth::$user->fields['uid'],
                'create_time' => time()
            ];

            mod_form::validate(mod_payment_treatment::$rule_travel);

            db::begin_tran();

            db::insert(mod_table::treatment_travel)->set($data)->execute();
            $travel_id = db::insert_id();

            //待遇信息
            $items = isset(req::$posts['item']) ? req::$posts['item'] : [];
            $items = mod_array::filter_array($items);
            if($items)
            {
                foreach ($items as $key=>&$item)
                {
                    if(empty($item['type_id']))
                    {
                        unset($items[$key]);
                    }
                    $item['travel_id'] = $travel_id;
                    $item['create_user'] = cls_auth::$user->fields['uid'];
                    $item['create_time'] = time();
                }

                $coloums = array_keys(current($items));
                db::insert(mod_table::treatment_travel_item)->columns($coloums)->values($items)->execute();
            }


            //适用等级
            $levels = isset(req::$posts['levels']) ? req::$posts['levels'] : [];
            if($levels)
            {
                foreach ($levels as &$level)
                {
                    $level['travel_id'] = $travel_id;
                }

                $coloums = array_keys(current($levels));
                db::insert(mod_table::treatment_travel_level)->columns($coloums)->values($levels)->execute();
            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加商旅待遇 ID={$travel_id}");

            db::commit();

            $gourl = req::item('gourl', '?ct=payment_treatment&ac=travel_list');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else
        {

            tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
        }
    }

    //修改商旅待遇
    public function travel_edit()
    {
        if (!empty(req::$posts))
        {
            $id = req::post('id',0,'int');
            if(empty($id))
            {
                mod_common::exit_page_404();
            }

            db::begin_tran();

            $data = [
                'name' => req::post('name'),
                'type' => req::post('type',0,'int'),
                'type_other' => req::post('other'),
                'update_user' => cls_auth::$user->fields['uid'],
                'update_time' => time()
            ];
            db::update(mod_table::treatment_travel)->set($data)->where('id','=',$id)->execute();

            //待遇信息
            $items = isset(req::$posts['item']) ? req::$posts['item'] : [];
            $items = mod_array::filter_array($items);
            if($items)
            {
                foreach ($items as $key=>&$item)
                {
                    if(empty($item['type_id']))
                    {
                        unset($items[$key]);
                    }
                    $item['travel_id'] = $id;
                }

                db::delete(mod_table::treatment_travel_item)->where('travel_id','=',$id)->execute();
                $coloums = array_keys(current($items));
                db::insert(mod_table::treatment_travel_item)->columns($coloums)->values($items)->execute();
            }

            //适用等级
            $levels = isset(req::$posts['levels']) ? req::$posts['levels'] : [];
            if($levels)
            {
                foreach ($levels as &$level)
                {
                    $level['travel_id'] = $id;
                }

                db::delete(mod_table::treatment_travel_level)->where('travel_id','=',$id)->execute();
                $coloums = array_keys(current($levels));
                db::insert(mod_table::treatment_travel_level)->columns($coloums)->values($levels)->execute();
            }

            db::commit();


            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改商旅待遇 ID={$id}");

            $gourl = req::item('gourl', '?ct=payment_treatment&ac=travel_list');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else 
        {
            $id = req::get('id',0,'int');

            $fields = 'id,name,type,type_other,create_user,create_time';
            $row = db::select($fields)->from(mod_table::treatment_travel)->where('id','=',$id)->as_row()->execute();
            if(empty($row))
            {
                mod_common::exit_page_404();
            }

            //待遇信息
            $display_items = mod_payment_treatment::display_travel_items($row['id'],true);
            tpl::assign('display_items',$display_items);
            tpl::assign('item_index',count($display_items));

            //等极信息
            $travel_levels = mod_payment_treatment::display_travel_levels($id,true);
            $row['display_zu_level'] = implode('、',$travel_levels['zu']);
            $row['display_xing_level'] = implode('、',$travel_levels['xing']);
            $row['hidden_xing'] = $travel_levels['xing_vals'];
            $row['hidden_zu'] = $travel_levels['zu_vals'];
            $row['creator'] = mod_payment::get_creator($row['create_user']);
            
            tpl::assign('row',$row);
            tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
        }
    }



    //生活待遇列表
    public function life_list()
    {
        $search = req::item('search', '');

        $where[] = [ "delete_user",'=',0 ];
        if (!empty($search))
        {
            $where[] = ["name", 'like', "%{$search}%"];
        }

        $count = db::select('count(*)')->from(mod_table::treatment_life)->where($where)->as_field()->execute();
        $pages = pub_page::make($count, $this->page_size);
        $fields = 'id,name,type,type_other,create_user,create_time';
        $rows = db::select($fields)->from(mod_table::treatment_life)->where($where)->order_by('id','asc')->limit($pages['page_size'])->offset($pages['offset'])->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                $row['type_display'] = mod_payment_treatment::display_travel_type($row);//isset($travel_types[$row['type']]) ? $travel_types[$row['type']] : '';

                $row['item_display'] = mod_payment_treatment::display_life_items($row['id']);
                $row['level_display'] = mod_payment_treatment::display_life_levels($row['id']);

                $row['creator'] = mod_payment::get_creator($row['create_user']);
            }
        }

        tpl::assign('rows', $rows);
        tpl::assign('pages', $pages['show']);
        tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
    }

    //生活待遇详情
    public function life_detail()
    {
        $id = req::get('id',0,'int');
        $fields = 'id,name,type,type_other,create_user,create_time';
        $row = db::select($fields)->from(mod_table::treatment_life)->where('id','=',$id)->as_row()->execute();
        if(empty($row))
        {
            mod_common::exit_page_404();
        }

        $row['type_display'] = mod_payment_treatment::display_travel_type($row);

        $display_items = mod_payment_treatment::display_life_items($row['id'],true);
        tpl::assign('display_items',$display_items);

        $travel_levels = mod_payment_treatment::display_life_levels($id,true);
        $row['display_zu_level'] = implode('、',$travel_levels['zu']);
        $row['display_xing_level'] = implode('、',$travel_levels['xing']);
        $row['creator'] = mod_payment::get_creator($row['create_user']);


        tpl::assign('travel_levels',$travel_levels);
        tpl::assign('row',$row);
        tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
    }

    //删除生活待遇
    public function life_delete()
    {
        $id = req::get('id',0,'int');

        db::update(mod_table::treatment_life)->set([
            'delete_user'=>cls_auth::$user->fields['uid'],
            'delete_time'=>time()
        ])->where("id",'=',$id)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除生活待遇 ID={$id}");

        $gourl = req::item('gourl', '?ct=payment_treatment&ac=life_list');
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    //添加生活待遇
    public function life_add()
    {
        if (!empty(req::$posts))
        {
            $data = [
                'name' => req::post('name'),
                'type' => req::post('type',0,'int'),
                'type_other' => req::post('other'),
                'create_user' => cls_auth::$user->fields['uid'],
                'create_time' => time()
            ];

            mod_form::validate(mod_payment_treatment::$rule_life);

            db::begin_tran();

            db::insert(mod_table::treatment_life)->set($data)->execute();
            $travel_id = db::insert_id();

            //待遇信息
            $items = isset(req::$posts['item']) ? req::$posts['item'] : [];
            $items = mod_array::filter_array($items);
            if($items)
            {
                foreach ($items as $key=>&$item)
                {
                    if(empty($item['type_id']))
                    {
                        unset($items[$key]);
                    }
                    $item['life_id'] = $travel_id;
                    $item['create_user'] = cls_auth::$user->fields['uid'];
                    $item['create_time'] = time();
                }

                $columns = array_keys(current($items));
                db::insert(mod_table::treatment_life_item)->columns($columns)->values($items)->execute();
            }

            //适用等级
            $levels = isset(req::$posts['levels']) ? req::$posts['levels'] : [];
            if($levels)
            {
                foreach ($levels as &$level)
                {
                    $level['life_id'] = $travel_id;
                }
                $columns = array_keys(current($levels));
                db::insert(mod_table::treatment_life_level)->columns($columns)->values($levels)->execute();
            }


            db::commit();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加生活待遇 ID={$travel_id}");

            $gourl = req::item('gourl', '?ct=payment_treatment&ac=life_list');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else
        {

            tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
        }
    }

    //修改生活待遇
    public function life_edit()
    {
        if (!empty(req::$posts))
        {
            $id = req::post('id',0,'int');
            if(empty($id))
            {
                mod_common::exit_page_404();
            }

            db::begin_tran();

            $data = [
                'name' => req::post('name'),
                'type' => req::post('type',0,'int'),
                'type_other' => req::post('other'),
                'update_user' => cls_auth::$user->fields['uid'],
                'update_time' => time()
            ];
            db::update(mod_table::treatment_life)->set($data)->where("id",'=',$id)->execute();

            //待遇信息
            $items = isset(req::$posts['item']) ? req::$posts['item'] : [];
            $items = mod_array::filter_array($items);
            if($items)
            {
                foreach ($items as $key=>&$item)
                {
                    if(empty($item['type_id']))
                    {
                        unset($items[$key]);
                    }
                    $item['life_id'] = $id;
                }
                db::delete(mod_table::treatment_life_item)->where('life_id','=',$id)->execute();

                $columns = array_keys(current($items));
                db::insert(mod_table::treatment_life_item)->columns($columns)->values($items)->execute();
            }


            //适用等级
            $levels = isset(req::$posts['levels']) ? req::$posts['levels'] : [];
            if($levels)
            {
                foreach ($levels as &$level)
                {
                    $level['life_id'] = $id;
                }
                db::delete(mod_table::treatment_life_level)->where('life_id','=',$id)->execute();

                $columns = array_keys(current($levels));
                db::insert(mod_table::treatment_life_level)->columns($columns)->values($levels)->execute();
            }

            db::commit();


            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改生活待遇 ID={$id}");

            $gourl = req::item('gourl', '?ct=payment_treatment&ac=life_list');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else
        {
            $id = req::get('id',0,'int');

            $fields = 'id,name,type,type_other,create_user,create_time';
            $row = db::select($fields)->from(mod_table::treatment_life)->where('id','=',$id)->as_row()->execute();
            if(empty($row))
            {
                mod_common::exit_page_404();
            }

            //待遇信息
            $display_items = mod_payment_treatment::display_life_items($row['id'],true);
            tpl::assign('display_items',$display_items);
            tpl::assign('item_index',count($display_items));

            //等极信息
            $travel_levels = mod_payment_treatment::display_life_levels($id,true);
            $row['display_zu_level'] = implode('、',$travel_levels['zu']);
            $row['display_xing_level'] = implode('、',$travel_levels['xing']);
            $row['hidden_xing'] = $travel_levels['xing_vals'];
            $row['hidden_zu'] = $travel_levels['zu_vals'];
            $row['creator'] = mod_payment::get_creator($row['create_user']);

            tpl::assign('row',$row);
            tpl::display('payment_treatment.'.__FUNCTION__.'.tpl');
        }
    }

}
