<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构管理.
 *
 * @version $Id$
 */
class ctl_organization
{

    public static $top_name = '权力机构';

    // 机构状态.
    public static $status_options = array(
        '' => '请选择机构状态',
        '1' => '正常',
        '2' => '注销',
        '3' => '暂停',
    );

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        tpl::assign( 'status_options', self::$status_options );
        tpl::assign( 'level', 0 );
        tpl::assign( 'status', 0 );
    }

    /**
     * 机构列表.
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $level = req::item('level', 0);
        $status = req::item('status', 0);
        $page_size = req::item('page_size', 10);

        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = "%".$keyword."%";
        }

        if (!empty($level)) {
            $condition['level_id'] = $level;
        }

        if (!empty($status)) {
            $condition['status'] = $status;
        }

        $count = mod_organization::instance()->count($condition);
        $pages = pub_page::make($count, $page_size);

        $fields = "`id`,`number`, `name`, `level_id`, `superior`,  `status`, `create_time`, `create_user`";
        $list = mod_organization::instance()->get_list_data($condition, $fields, '', "{$pages['offset']}, {$pages['page_size']}", 'id desc');
        if (!empty($list)) {
            $superior_arr = array_column($list, 'superior');
            $user_id_arr = array_column($list, 'create_user');
            $superior_arr = array_unique($superior_arr);
            $organization = mod_organization::instance()->get_list_data(array('id in'=>$superior_arr), '`id`, `name`', 'id');
        }

        // 数据写入作者.
        $admin_options = array();
        if (!empty($user_id_arr)) {
            $user_id_arr = array_unique($user_id_arr);
            $admin_options = mod_admin::instance()->get_admin_option($user_id_arr);
        }

        // 组织等级.
        $level_options = mod_organize_level::instance()->get_level_options();
        // 获取任务领取人名称.
        foreach ($list as $key=>$value) {
            $list[$key]['creator'] = isset($admin_options[$value['create_user']]) ? $admin_options[$value['create_user']] : '';
            $list[$key]['status'] = isset(self::$status_options[$value['status']]) ? self::$status_options[$value['status']] : '';
            $list[$key]['level'] = isset($level_options[$value['level_id']]) ? $level_options[$value['level_id']] : '';
            $list[$key]['superior'] = isset($organization[$value['superior']]) ? $organization[$value['superior']]['name'] : '';
        }


        tpl::assign('list', $list);
        tpl::assign('level_options', $level_options);
        tpl::assign('keyword', $keyword);
        tpl::assign('level', $level);
        tpl::assign('status', $status);
        tpl::assign('pages', $pages['show']);
        tpl::display('organization.index.tpl');
    }

    /**
     * 机构属性列表.
     */
    public function tree()
    {
        $keyword = req::item('keyword', '');
        $level = req::item('level', 0);
        $status = req::item('status', 0);
        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = "%".$keyword."%";
        }

        if (!empty($level)) {
            $condition['level_id'] = $level;
        }

        if (!empty($status)) {
            $condition['status'] = $status;
        }

        // 默认只展示权力机构.
        if (empty($condition)) {
            $condition = array('type' => 1);
        }

        $organizations = mod_organization::instance()->get_list_data($condition, '`id`, `name`, `status`, `delete_user`');
        $top_organization = array();
        foreach ($organizations as $key => $value) {
            $tmp = array();
            $tmp_status = mod_organization::instance()->checkout_org_status($value, '已');
            $tmp['id'] = $value['id'];
            if (!empty($tmp_status)) {
                $tmp['name'] = '【'.$tmp_status.'】'.$value['name'];
            } else {
                $tmp['name'] = $value['name'];
            }
            $tmp['hasChild'] = mod_organization::instance()->checkout_is_all_sub($value['id']);
            $top_organization[] = $tmp;
        }

        $top_organization = json_encode($top_organization);
        // 组织等级.
        $level_options = mod_organize_level::instance()->get_level_options();
        tpl::assign('level_options', $level_options);
        tpl::assign('top_organization', $top_organization);
        tpl::assign('keyword', $keyword);
        tpl::assign('level', $level);
        tpl::assign('status', $status);
        tpl::display('organization.tree.tpl');
    }

    /**
     * 获取下一级机构.
     */
    public function ajax_get_tree()
    {
        $data = array();
        $id = req::item('id', 0, 'int');
        if (!empty($id)) {
            $data = mod_organization::instance()->get_child_by_org_id($id);
        }

        echo json_encode($data);
    }

    /**
     * 下级机构.
     */
    public function lower()
    {
        $keyword = req::item('keyword', '');
        $level = req::item('level', 0);
        $status = req::item('status', 0);
        $power = req::item('power', 0, 'int');
        $page_size = req::item('page_size', 10);
        $organization_id = req::item('organization_id', 0, 'int');

        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = "%".$keyword."%";
        }
        if (!empty($level)) {
            $condition['level_id'] = $level;
        }
        if (!empty($status)) {
            $condition['status'] = $status;
        }
        if (!empty($organization_id)) {
            $condition['superior'] = $organization_id;
        }

        $count = mod_organization::instance()->count($condition);
        $pages = pub_page::make($count, $page_size);
        $fields = "`id`, `number`, `name`, `level_id`, `superior`,  `status`, `create_time`, `create_user`";
        $list = mod_organization::instance()->get_list_data($condition, $fields, '', "{$pages['offset']}, {$pages['page_size']}", 'id desc');
        if (!empty($list)) {
            $superior_arr = array_column($list, 'superior');
            $superior_arr = array_unique($superior_arr);
            $organization = mod_organization::instance()->get_list_data(array('id in'=>$superior_arr), '`id`, `name`', 'id');
            $organization = array_column($organization, null, 'id');
        }

        $level_options = mod_organize_level::instance()->get_level_options();
        $admin_options = mod_admin::instance()->get_list_data(array('1' => '1'), '`admin_id`, `username`', 'admin_id');
        // 获取任务领取人名称.
        foreach ($list as $key=>$value) {
            $list[$key]['creator'] = isset($admin_options[$value['create_user']]) ? $admin_options[$value['create_user']]['username'] : '';
            $list[$key]['status'] = isset(self::$status_options[$value['status']]) ? self::$status_options[$value['status']] : '';
            $list[$key]['level'] = isset($level_options[$value['level_id']]) ? $level_options[$value['level_id']] : '';
            $list[$key]['superior'] = isset($organization[$value['superior']]) ? $organization[$value['superior']]['name'] : '';
        }

        tpl::assign('index', 'org_lower');
        tpl::assign('list', $list);
        tpl::assign('level_options', $level_options);
        tpl::assign('keyword', $keyword);
        tpl::assign('level', $level);
        tpl::assign('power', $power);
        tpl::assign('status', $status);
        tpl::assign('pages', $pages['show']);
        tpl::assign('organization_id', $organization_id);
        tpl::display('organization.lower.tpl');
    }

    /**
     * 下级机构树型展示.
     */
    public function lower_tree()
    {
        $keyword = req::item('keyword', '');
        $level = req::item('level', 0);
        $status = req::item('status', 0);
        $power = req::item('power', 0, 'int');
        $organization_id = req::item('organization_id', 0, 'int');

        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = "%".$keyword."%";
        }
        if (!empty($level)) {
            $condition['level_id'] = $level;
        }
        if (!empty($status)) {
            $condition['status'] = $status;
        }
        if (!empty($organization_id)) {
            $condition['superior'] = $organization_id;
        }

        if (empty($condition)) {
            $condition['id'] = $organization_id;
        }

        $level_options = mod_organize_level::instance()->get_level_options();
        $organizations = mod_organization::instance()->get_list_data($condition, '`id`, `name`, `delete_user`, `status`');
        $top_organization = array();
        foreach ($organizations as $key => $value) {
            $tmp = array();
            $tmp_status = mod_organization::instance()->checkout_org_status($value, '已');
            $tmp['id'] = $value['id'];
            if (!empty($tmp_status)) {
                $tmp['name'] = '【'.$tmp_status.'】'.$value['name'];
            } else {
                $tmp['name'] = $value['name'];
            }

            $tmp['hasChild'] = mod_organization::instance()->checkout_is_all_sub($value['id']);
            $top_organization[] = $tmp;
        }
        $top_organization = json_encode($top_organization);

        tpl::assign('index', 'org_lower');
        tpl::assign('top_organization', $top_organization);
        tpl::assign('power', $power);
        tpl::assign('status', $status);
        tpl::assign('level', $level);
        tpl::assign('organization_id', $organization_id);
        tpl::assign('level_options', $level_options);
        tpl::display('organization.lower_tree.tpl');
    }

    /**
     * 添加机构.
     */
    public function add()
    {
        $superior_organization_id = req::item('superior_organization_id', 0, 'int');
        $type = req::item('type', 0, 'int');
        $power = req::item('power', 0, 'int');
        if (!empty(req::$posts))
        {
            $return = array(
                'status' => 0,
                'message' => '添加成功',
                'data' => '',
            );
            $data = array();
            $time = time();
            $name = req::item('name', '', 'string');
            // 机构重复性检查.
            $count = mod_organization::instance()->count(array('name'=>$name));
            if (!empty($count)) {
                $return['status'] = '1';
                $return['message'] = '机构名已存在';
                echo json_encode($return);
                exit();
            }

            $internal_name = req::item('internal_name', array());
            $external_name = req::item('external_name', array());
            $internal_name = array_filter($internal_name);
            $external_name = array_filter($external_name);
            $data['type'] = req::item('type', 0, 'int');
            $data['level_id'] = req::item('level', 0, 'int');
            $data['superior'] = req::item('superior', 0, 'int');
            $data['secret_degree'] = req::item('secret_degree', 0, 'int');
            $data['name'] = $name;
            $data['short_name'] = req::item('short_name', '', 'string');
            $data['english_short_name'] = req::item('english_short_name', '', 'string');
            $res = $this->number($data['superior'], $data['type']);
            if ($res['status'] > 0) {
                cls_msgbox::show('系统提示', $res['message'], '-1');
                exit();
            } else {
                $number = $res['data'];
            }
            if (!empty($number)) {
                $data['number'] = $number;
                $number_arr = explode('-' , $number);
                $number_id = array_pop($number_arr);
                $number_id = (int) $number_id;
                $data['number_id'] = $number_id;
            }
            $data['status'] = '1';
            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['create_time'] = $time;
            $data['update_time'] = $time;
            // 查看某一个类型机构是否超过该类型设置的最大机构数量.
            if (!empty($data['type'])) {
                $type_org_num = mod_organization::instance()->count(array('type' => $data['type'], 'status in' => array(1,3)));
                $standard_num = mod_mechanism_type::instance()->get_org_max_num($data['type']);
                // standard_num为零不限制数量.
                if (($standard_num > 0)  && ($type_org_num >= $standard_num)) {
                    cls_msgbox::show('系统提示', '该类型下面的机构数量已满, 不能在新增了!', '-1');
                    exit();
                }
            }
            if (!empty($data['level_id'])) {
                $level_data = mod_organize_level::instance()->get_one_data(array('id' => $data['level_id']), '`id`, `level`');
                $data['level'] = $level_data['level'];
            }

            // 机构对内名称.
            if (!empty($internal_name)) {
                $data['internal_name'] = json_encode($internal_name, JSON_UNESCAPED_UNICODE);
            }
            // 机构对外名称.
            if (!empty($external_name)) {
                $data['external_name'] = json_encode($external_name, JSON_UNESCAPED_UNICODE);
            }

            $insert_id = mod_organization::instance()->insert_data($data);
            if (empty($insert_id)) {
                $return['status'] = '2';
                $return['message'] = '添加失败';
                echo json_encode($return);
            }

            // 跳转.
            if (!empty($insert_id)) {
                // 机构详情。
                cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户添加机构 {$insert_id}");

                $url = '?ct=organization&ac=detail&organization_id='.$insert_id;
                if (!empty($type)) {
                    $url = '?ct=organization&ac=add&type=all';
                }

                // 创建下级机构, 创建成功跳转到下级机构列表.
                if (!empty($superior_organization_id)) {
                    $url = '?ct=organization&ac=lower&organization_id='.$superior_organization_id.'&power='.$power;
                }
                cls_msgbox::show('系统提示', "添加成功", $url);
            } else {
                cls_msgbox::show('系统提示', "添加失败", -1);
            }
        }
        else
        {
            // 创建下级机构.
            if (!empty($superior_organization_id)) {
                $superior_organizations = mod_organization::instance()->get_one_data(array('id' => $superior_organization_id), '`id`, `name`, `status`, `delete_user`');
                if ($superior_organizations['status'] != 1 || !empty($superior_organizations['delete_user'])) {
                    cls_msgbox::show('系统提示', '非正常机构下面不能创子机构!', '-1');
                    exit();
                }

                $level_options = array();
                $res = $this->get_organization_level_in_org($superior_organization_id);
                if ($res['status'] == 0) {
                    $level_options = $res['data'];
                } else {
                    cls_msgbox::show('系统提示', $res['message'], '-1');
                    exit();
                }
            } else {
                $level_options = mod_organize_level::instance()->get_level_options();
            }
            // 判断是否权力机构, 第一个机构为权力机构，没有上级机构，后面的机构必须选择上级机构, 有上级机构的机构为普通机构.
            $count = mod_organization::instance()->count(array('id >' => '0'));
            if (empty($count)) {
                // 只展示权力机构类型.
                $type_option = mod_mechanism_type::instance()->get_one_data(array('name like' => self::$top_name), '`id`, `name`, `short_name`');
                if (empty($type_option)) {
                    cls_msgbox::show('系统提示', '没有权力机构类型!', '-1');
                    exit();
                }

                $type_options = array(
                    $type_option['id'] => $type_option['name'].' ('.$type_option['short_name'].')',
                );
            } else {
                $type_data = mod_mechanism_type::instance()->get_one_data(array('name like' => self::$top_name), '`id`, `name`, `short_name`');
                $type_options = mod_mechanism_type::instance()->get_type_options();
                if (!empty($type_data)) {
                    unset($type_options[$type_data['id']]);
                }
            }

            $organizations = mod_organization::instance()->get_level_and_organization();
            $security_level = mod_security_level::instance()->get_security_level_options();

            tpl::assign( 'level_options', $level_options);
            tpl::assign( 'secret_degree_options', $security_level);
            tpl::assign( 'superior_organization_id', $superior_organization_id);
            tpl::assign('organizations', $organizations);
            tpl::assign('count', $count);
            tpl::assign( 'type_options', $type_options);
            tpl::assign( 'superior_organization_id', $superior_organization_id);
            tpl::display('organization.add.tpl');
        }
    }

    /**
     * ajax获取获取组织等级.
     */
    public function get_organization_level_in_org($organization_id = 0)
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'data' => array(),
        );

        $org_id = req::item('id', '', 'string');
        $ajax = req::item('ajax', '', 'string');
        $org_id = empty($org_id) ? $organization_id : $org_id;
        if (empty($org_id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        $level_data = mod_organization::instance()->get_one_data(array('id' => $org_id), '`id`, `level_id`');
        if (empty($level_data)) {
            $result['status'] = 2;
            $result['message'] = '机构数据不存在';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        $organize_level_data = mod_organize_level::instance()->get_one_data(array('id' => $level_data['level_id']), '`level`');
        if (empty($organize_level_data)) {
            $result['status'] = 3;
            $result['message'] = '组织等级数据不存在';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        $res = mod_organize_level::instance()->get_list_data(
            array(
                'level >' => $organize_level_data['level'],
                'delete_user' => 0,
            ),
            '`id`,`level_short_name`',
            '',
            '',
            'level asc'
        );

        if (!empty($res)) {
            $result['data'] = array_column($res, 'level_short_name', 'id');
        }

        if (!empty($ajax)) {
            echo json_encode($result);
        } else {
            return $result;
        }
    }

    /**
     * 获取编码.
     */
    public function number($organization_id = 0, $type_id = 0)
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'data' => '',
        );

        $type = req::item('type', 0, 'int');
        $org_id = req::item('org_id', 0, 'int');
        $ajax = req::item('ajax', 0, 'int');
        // 所属上级.
        $super_org_id = empty($organization_id) ? $org_id : $organization_id;
        $type = empty($type) ? $type_id : $type_id;
        if (empty($type)) {
            $result['status'] = 1;
            $result['message'] = '参数错误!';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        $type_data = mod_mechanism_type::instance()->get_one_data(array('id'=> $type), '`id`, `short_name`');
        if (empty($type_data['short_name'])) {
            $result['status'] = 1;
            $result['message'] = '类型数据错误!';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }
        // 机构编码.
        $numberArr = array();
        $date = date('Ym', time());

        if (!empty($super_org_id)) {
            while (!empty($super_org_id)) {
                $org_data = mod_organization::instance()->get_one_data(array('id' => $super_org_id), 'superior, number');
                $super_org_id = !empty($org_data) ? $org_data['superior'] : 0;
                $numberArr[] = substr(trim($org_data['number']), -3);
            }

            if (!empty($numberArr)) {
                $tm_keys = array_keys($numberArr);
                array_multisort($numberArr, $tm_keys, SORT_DESC);
            }
        }

        array_unshift($numberArr, $type_data['short_name'], $date);
        $data = mod_organization::instance()->get_list_data(array('1'=> '1'), '`id`', '', '1', 'id desc');
        $data1 = mod_organization::instance()->get_list_data(array('1'=> '1'), '`number_id`', '', '1', 'number_id desc');
        if (empty($data)) {
            $id = 1;
        } else {
            $base_num = $data[0]['id'] > $data1[0]['number_id'] ? $data[0]['id'] : $data1[0]['number_id'];
            $id = $base_num + 1;
        }

        $numberArr[] = str_pad($id, 3, "0", STR_PAD_LEFT);
        $result['data'] = implode('-', $numberArr);

        if (!empty($ajax)) {
            echo json_encode($result);
            exit();
        } else {
            return $result;
        }
    }

    /**
     * 权力机构
     */
    public function power()
    {
        // 机构数据.
        $data = mod_organization::instance()->get_list_data(array('superior' => 0), '', '', '1', 'id ASC');
        if (empty($data)) {
            $gourl = '?ct=organization&ac=index';
            cls_msgbox::show('系统提示', '请您先去创建权力机构!', $gourl);
            exit();
        }

        $count = count($data);
        if ($count > 1) {
            cls_msgbox::show('系统提示', '数据错误, 存在多个权力机构！', '-1');
            exit();
        }
        $data = $data[0];

        $data['secret_degree'] = mod_security_level::instance()->get_security_level_name($data['secret_degree']);
        if (!empty($data['type'])) {
            $type_data = mod_mechanism_type::instance()->get_one_data(array('id' => $data['type']), '`id`, `name`, `short_name`');
            $data['type'] = !empty($type_data) ? $type_data['name'].' ('.$type_data['short_name'].')' : '';
        }
        if (!empty($data['internal_name'])) {
            $data['internal_name'] = json_decode($data['internal_name'], true);
        }
        if (!empty($data['external_name'])) {
            $data['external_name'] = json_decode($data['external_name'], true);
        }

        $data['superior'] = '';
        // 组织等级.
        if (!empty($data['level_id'])) {
            $data['level'] = mod_organize_level::instance()->get_level_name($data['level_id']);
        }

        $return_url = '?ct=organization&ac=index';
        tpl::assign('return_url', $return_url);
        tpl::assign('index', 'org');
        tpl::assign('power', '1');
        tpl::assign('data', $data);
        tpl::assign('organization_id', $data['id']);
        tpl::display('organization.detail.tpl');
    }

    /**
     * 机构详情.
     */
    public function detail()
    {
        $id = req::item('organization_id', 0, 'int');
        $return = req::item('return', '', 'string');
        $power = req::item('power', 0, 'int');
        if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }
        
        // 机构数据.
        $data = mod_organization::instance()->get_one_data(array('id' => $id));
        if (empty($data)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        $data['secret_degree'] = mod_security_level::instance()->get_security_level_name($data['secret_degree']);
        if (!empty($data['type'])) {
            $type_data = mod_mechanism_type::instance()->get_one_data(array('id' => $data['type']), '`id`, `name`, `short_name`');
            $data['type'] = !empty($type_data) ? $type_data['name'].' ('.$type_data['short_name'].')' : '';
        }
        if (!empty($data['internal_name'])) {
            $data['internal_name'] = json_decode($data['internal_name'], true);
        }
        if (!empty($data['external_name'])) {
            $data['external_name'] = json_decode($data['external_name'], true);
        }
        if (!empty($data['superior'])) {
            // 上级机构数据.
            $result = mod_organization::instance()->get_one_data(array('id' => $data['superior']), '`id`, `name`');
            $data['superior'] = $result['name'];
        } else {
            $data['superior'] = '';
        }

        // 组织等级.
        if (!empty($data['level_id'])) {
            $result = mod_organize_level::instance()->get_one_data(array('id' =>$data['level_id']), '`id`,`level_short_name`');
            $data['level'] = isset($result['level_short_name']) ? $result['level_short_name'] : '';
        }

        $return_url = '?ct=organization&ac=index';
        if ($return=='back') {
            $return_url = 'javascript:history.back(-1);';
        }

        tpl::assign('index', 'org');
        tpl::assign('return_url', $return_url);
        tpl::assign('power', $power);
        tpl::assign('data', $data);
        tpl::assign('organization_id', $data['id']);
        tpl::display('organization.detail.tpl');
    }

    /*
     * 编辑机构.
     */
    public function edit()
    {
        $id = req::item('organization_id', 0, 'int');
        if (empty($id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 机构数据.
        $old_data = mod_organization::instance()->get_one_data(array('id' => $id));
        if (empty($old_data)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        if (!empty($old_data['internal_name'])) {
            $old_data['internal_name'] = json_decode($old_data['internal_name'], true);
        }
        if (!empty($old_data['external_name'])) {
            $old_data['external_name'] = json_decode($old_data['external_name'], true);
        }

        if (!empty(req::$posts))
        {
            $data = array();
            $time = time();
            $name = req::item('name', '');
            // 机构重复性检查.
            $tmp = mod_organization::instance()->get_one_data(array('name'=>$name), '`id`');
            if (!empty($tmp) && ($tmp['id'] != $id)) {
                cls_msgbox::show('系统提示', '机构名已存在', '-1');
                exit();
            }

            $top_type = mod_mechanism_type::instance()->get_one_data(array('name'=> self::$top_name), '`id`');
            $internal_name = req::item('internal_name', array());
            $external_name = req::item('external_name', array());
            $internal_name = array_filter($internal_name);
            $external_name = array_filter($external_name);
            $data['name'] = $name;
            $data['type'] = req::item('type', 0, 'int');

            // 非权力机构才能改机构类型, 机构类型不能为权力机构类型.
            if (isset($top_type['id']) && !empty($data['type']) && ($data['type'] != $old_data['type']) && ($data['type'] == $top_type['id']) ) {
                cls_msgbox::show('系统提示', '普通机构不能改为权力机构类型!', '-1');
                exit();
            }

            // 不能把机构类型数据改成零.
            if (empty($data['type'])) {
                unset($data['type']);
            }

            $data['level_id'] = req::item('level', 0, 'int');
            $data['superior'] = req::item('superior', 0, 'int');
            $data['secret_degree'] = req::item('secret_degree', 0, 'int');
            $data['short_name'] = req::item('short_name', '', 'string');
            $data['english_short_name'] = req::item('english_short_name', '', 'string');
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = $time;
            // 查看某一个类型机构是否超过该类型设置的最大机构数量.
            if (!empty($data['type'])) {
                $type_org_num = mod_organization::instance()->count(array('type' => $data['type'], 'status in' => array(1,3)));
                $standard_num = mod_mechanism_type::instance()->get_org_max_num($data['type']);
                // standard_num为零不限制数量.
                if (($standard_num > 0)  && ($type_org_num >= $standard_num)) {
                    cls_msgbox::show('系统提示', '该类型下面的机构数量已满, 不能在新增了!', '-1');
                    exit();
                }
            }
            // 组织等级.
            if (!empty($data['level_id'])) {
                $level_data = mod_organize_level::instance()->get_one_data(array('id' => $data['level_id']), '`id`, `level`');
                $data['level'] = $level_data['level'];
            }
            $gourl = '?ct=organization&ac=index';
            // 查找下级是否有该上级机构.
            while (!empty($data['superior'])) {
                $org_data = mod_organization::instance()->get_one_data(array('superior' => $id), '`id`');
                $sub_org_id = !empty($org_data) ? $org_data['id'] : 0;
                if ($sub_org_id == $data['superior']) {
                    cls_msgbox::show('系统提示', '选择的上级机构是当前机构的下级，修改失败!', '-1');
                    exit();
                }
            }

            if (($old_data['type'] != $top_type['id']) && ($data['type'] == $top_type['id'])) {
                cls_msgbox::show('系统提示', '普通的机构不能改为权力机构类型!', '-1');
                exit();
            }
            
            // 非权力机构类型改变或上级机构改变, 机构编号改变.
            if ((isset($data['type']) && ($data['type'] != $old_data['type']))  || ($data['superior'] != $old_data['superior'])) {
                $type_res = mod_mechanism_type::instance()->get_one_data(array('id' => $data['type']), 'id, short_name');
                if (empty($type_res)) {
                    cls_msgbox::show('系统提示', "错误的机构类型数据.", $gourl);
                }

                $res = $this->number($data['superior'], $data['type']);
                if ($res['status'] > 0) {
                    cls_msgbox::show('系统提示', $res['message'], '-1');
                    exit();
                } else {
                    $number = $res['data'];
                }

                $number_arr = explode('-', $number);
                $number_tmp = array_pop($number_arr);
                if (empty($old_data['number_id'])) {
                    $data['number_id'] = (int) $number_tmp;
                } else {
                    $number_arr[] = str_pad($old_data['number_id'], 3, "0", STR_PAD_LEFT);
                    $number = implode('-', $number_arr);
                }

                $data['number'] = $number;
            }

            // 机构对内名称.
            if (!empty($internal_name)) {
                $data['internal_name'] = json_encode($internal_name, JSON_UNESCAPED_UNICODE);
            }
            // 机构对外名称.
            if (!empty($external_name)) {
                $data['external_name'] = json_encode($external_name, JSON_UNESCAPED_UNICODE);
            }

            $result = mod_organization::instance()->update_data($data, array('id' => $id));
            $gourl = req::item('gourl', '?ct=organization&ac=detail&organization_id='.$id);
            if (empty($result)) {
                cls_msgbox::show('系统提示', "修改失败", $gourl);
            }

            // 记录日志, 跳转.
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户修改机构 {$id}");
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else
        {
            $is_top = 0;
            // 上级机构.
            $organizations = mod_organization::instance()->get_level_and_organization();
            unset($organizations[$id]);
            // 机构类型.
            $type_options = mod_mechanism_type::instance()->get_type_options();
            // 查出权力机构id.
            $top_type = mod_mechanism_type::instance()->get_one_data(array('name'=> self::$top_name), '`id`');
            if (empty($top_type)) {
                // cls_msgbox::show('系统提示', '没有权力机构类型!', '-1');
                // exit();
            }
            if (!empty($old_data['superior']) && (isset($top_type['id']) && $old_data['type'] != $top_type['id'])) {
                unset($type_options[$top_type['id']]);
            }

            // 该机构为权力机构.
            if (isset($top_type['id']) && ($old_data['type'] == $top_type['id'])) {
                $is_top = 1;
            }

            // 组织等级.
            $level_options = mod_organize_level::instance()->get_level_options();
            if (!empty($old_data['superior'])){
                $res = $this->get_organization_level_in_org($old_data['superior']);
                if ($res['status'] == 0) {
                    $level_options = $res['data'];
                }
            }
            $security_level = mod_security_level::instance()->get_security_level_options();
            tpl::assign( 'secret_degree_options', $security_level);
            tpl::assign('data', $old_data);
            tpl::assign('level_options', $level_options);
            tpl::assign('is_top', $is_top);
            tpl::assign('organizations', $organizations);
            tpl::assign( 'type_options', $type_options);
            tpl::display('organization.edit.tpl');
        }
    }

    /**
     * 更改机构状态.
     */
    public function edit_organization_status()
    {
        $result = array(
            'status' => 0,
            'message' => '操作成功.',
        );

        $type = req::item('type', '', 'string');
        $id = req::item('id', 0, 'int');
        $data = array();
        switch ($type) {
            case 'stop':
                $data['status'] = '3';
                break;
            case 'cancel':
                $data['status'] = '2';
                break;
            case 'recover':
                $data['status'] = '1';
                break;

            default:
                break;
        }

        if (empty($type) || empty($id) || empty($data)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $org_data = mod_organization::instance()->get_one_data(array('id' => $id), 'id, status');
        if (!empty($org_data) &&  ($org_data['status'] == '2')) {
            $result['status'] = 2;
            $result['message'] = '注销的数据不能更改状态!';
            echo json_encode($result);
            exit();
        }

        $res = mod_organization::instance()->update_data($data, array('id'=> $id));
        if ($res === false) {
            $result['status'] = '3';
            $result['message'] = '更改失败.';
        }

        echo json_encode($result);
    }

}
