<?php
if( !defined('PHPCALL') ) exit('Request Error!');
if( !defined('__CONTROL__') )   define('__CONTROL__','department_room');
/**
 * 科室管理
 *
 * @version $Id$
 */
class ctl_department_room
{
    public $page_size = 10;
    public $people_levels = [
        1,2,3,4,5
    ];
    public $action = '';
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $route_path = mod_department::route_path();
        tpl::assign('route_path', ($route_path ? $route_path.' 委员会管理' : '') );
        tpl::assign('creator',mod_payment::get_creator());
        tpl::assign('create_time',time());
    }

    //列表
    public function make_list($falg=0)
    {
        $search = req::item('search', '');
        $select = isset(req::$gets['select']) ? req::$gets['select'] : [];
        $organ_id = req::get('organization_id',0,'int');
        $depart_id = req::get('department_id',0,'int');
        $type = req::item('type', '', 'string');
        if($select)
        {
            list($organ_id,$depart_id) = $select;
        }else{
            $select = [0,0];
        }

        $where[] = ["delete_user", '=', $falg];
        if (!empty($search))
        {
            $where[] = ["name", 'like', "%{$search}%"];
        }
        !empty($organ_id) && $where[] = ["organ_id",'=',$organ_id];
        !empty($depart_id) && $where[] = ["department_id",'=',$depart_id];

        $count = db::select('count(*)')->from(mod_table::department_room)->where($where)->as_field()->execute();
        $pages = pub_page::make($count, $this->page_size);
        $fields = 'id,code,name,people_count,department_id,array_data,create_user,create_time,delete_user';
        $rows = db::select($fields)->from(mod_table::department_room)->where($where)->limit($pages['page_size'])->offset($pages['offset'])->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                $row['department'] = db::select('name')->from(mod_table::department)->where('id','=',$row['department_id'])->as_field()->execute();

                $row['leader'] = db::select('job_name')->from(mod_table::department_room_people)->where('room_id','=',$row['id'])
                    ->where('is_leader','=',1)->as_field()->execute();
                $row['creator'] = mod_common::field_creator($row['create_user']);
                $row['status'] = $row['delete_user']==0 ? '正常' :'<font color="red">删除</font>';
            }
        }


        tpl::assign('select',$select);

        //部门是否已删除
        $where = [
            ['id','=',$depart_id],
            ['delete_user','>',0]
        ];
        $is_depart_deleted = db::select('count(*)')->from(mod_table::department)->where($where)->as_field()->execute();
        tpl::assign('is_depart_deleted',$is_depart_deleted);

        tpl::assign('index','department_room');
        $this->action = $this->action ? $this->action : __FUNCTION__;
        tpl::assign('action',$this->action);
        tpl::assign('type',$type);
        tpl::assign('rows', $rows);
        tpl::assign('pages', $pages['show']);
        tpl::display(__CONTROL__.'.'.__FUNCTION__.'.tpl');
    }

    //科室详情
    public function detail()
    {
        $id = req::get('id',0,'int');
        //$row = db::get_one("select * from ".mod_table::department_room." where id=$id");
        $fields = 'id,code,name,department_id,people_count,array_data,create_user,create_time';
        $row = db::select($fields)->from(mod_table::department_room)->where('id','=',$id)->as_row()->execute();
        if(empty($row))
        {
            mod_common::exit_page_404();
        }

        //$one = db::get_one("select id,name,short_name from ".mod_table::department." where id={$row['department_id']}");
        $row['department'] = db::select('name')->from(mod_table::department)->where('id','=',$row['department_id'])->as_field()->execute();

        //科室职权
        //$one1 = db::get_one("select id,job_name from ".mod_table::department_room_people." where room_id={$row['id']} and is_leader=1");
        $lea_where = [
            ['room_id','=',$row['id']], ['is_leader','=',1]
        ];
        $row['leader'] = db::select('job_name')->from(mod_table::department_room_people)->where($lea_where)->as_field()->execute();

        $array_data = unserialize($row['array_data']);
        //包含岗位 只列出父岗位名称
        $row['jobs'] = '';
        if($array_data['job_ids'])
        {
            //$job_p_ids = db::get_all("select DISTINCT station_id from ".mod_table::job_child." where station_id>0 and id IN({$array_data['job_ids']})");
            $job_where = [
                ['station_id', '>', 0],
                ['id', 'in', explode(',',$array_data['job_ids'])]
            ];
            $job_p_ids = db::select('station_id')->from(mod_table::job_child)->distinct(true)->where($job_where)->execute();


            if($job_p_ids)
            {
                $job_p_ids = mod_array::one_array($job_p_ids,[0,'station_id']);
                //$jobs = db::get_all("select name from ".mod_table::job." where id IN({$job_p_ids})");
                $jobs = db::select('name')->from(mod_table::job)->where('id','in',$job_p_ids)->execute();
                $row['jobs'] = implode('、', mod_array::one_array($jobs,[0,'name']));
            }
        }


        //员工列表
        //$peoples = db::get_all("select id,people_id,job_id,job_name,create_time from ".mod_table::department_room_people." where room_id={$row['id']}");
        $fields = 'id,people_id,job_id,job_name,create_time';
        $peoples = db::select($fields)->from(mod_table::department_room_people)->where('room_id','=',$row['id'])->execute();
        if($peoples)
        {
            foreach ($peoples as &$people)
            {
                //$people += db::get_one("select sn,realname from ".mod_table::people." where id={$people['people_id']}");
                $people += db::select('sn,realname')->from(mod_table::people)->where('id','=',$people['people_id'])->as_row()->execute();
                //$one2 = db::get_one("select name as job from ".mod_table::job." where id={$people['job_id']}");
                $one2 = db::select('name as job')->from(mod_table::job)->where('id','=',$people['job_id'])->as_row()->execute();
                $people += $one2 ? $one2 : [];
                $people['create_time'] = date('Y-m-d H:i:s',$people['create_time']);
            }
        }

        tpl::assign('row',$row);
        tpl::assign('peoples',$peoples);
        tpl::display(__CONTROL__.'.'.__FUNCTION__.'.tpl');
    }

    //删除科室
    public function delete()
    {
        $id = req::get('id',0,'int');
        if(empty($id)){
            mod_common::exit_page_404();
        }
        $gets = req::$gets;
        $action = 'make_list';
        if(isset($gets['organization_id']) && isset($gets['department_id']))
        {
            $action .= "&organization_id={$gets['organization_id']}&department_id={$gets['department_id']}";
        }

        db::update(mod_table::department_room)->set([
            'delete_user'=>cls_auth::$user->fields['uid'],
            'delete_time'=>time()
        ])->where("id",'=',$id)->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除科室 ID={$id}");

        mod_common::jump_delete($action);
    }

    //添加科室
    public function create()
    {
        if (!empty(req::$posts))
        {
            $job_ids = req::post('job_ids');
            $leader_job_id = req::post('leader_job_id',0,'int');
            $select_jobs = json_decode(req::post('select_jobs'),true);

            $data = [
                'name' => req::post('name'),
                'organ_id' => req::post('organ_id',0,'int'),
                'department_id' => req::post('department_id',0,'int'),
                'array_data' => serialize([
                    'job_ids'=>$job_ids,
                    'leader_job_id'=>$leader_job_id,
                    'select_jobs'=> $select_jobs
                ]),
                'job_count' => req::post('job_count'),
                'people_count' => req::post('people_count'),
                //'leader_job_id' => req::post('leader_job_id',0,'int'),
                'create_user' => cls_auth::$user->fields['uid'],
                'create_time' => time()
            ];

            mod_form::validate(mod_department::$rule_room);

            db::begin_tran();

            db::insert(mod_table::department_room)->set($data)->execute();
            $room_id = db::insert_id();
            db::update(mod_table::department_room)->set(['code'=>mod_department::room_code($room_id)])->where("id",'=',$room_id)->execute();

            if($job_ids)
            {
                //$peoples = db::get_all("select member_id as people_id,station_id as job_id,id from ".mod_table::job_child." where member_id>0 and id IN({$job_ids})");
                $peo_where = [
                    ['member_id','>',0],  ['id','in',explode(',',$job_ids)]
                ];
                $peoples = db::select('member_id as people_id,station_id as job_id,id')->from(mod_table::job_child)->where($peo_where)->execute();
                if($peoples)
                {
                    foreach ($peoples as &$people)
                    {
                        $people['is_leader'] = $people['id']==$leader_job_id ? 1 : 0;
                        $people['room_id'] = $room_id;
                        $people['create_user'] = cls_auth::$user->fields['uid'];
                        $people['create_time'] = time();
                        unset($people['id']);
                    }
                    //db::insert_batch(mod_table::department_room_people,$peoples);
                    $columns = array_keys(current($peoples));
                    db::insert(mod_table::department_room_people)->columns($columns)->values($peoples)->execute();
                }
            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加科室 ID={$room_id}");

            db::commit();

            mod_common::jump_create();
        }
        else
        {
            $show_data = [];
            $department_id = req::get('department_id',0,'int');
            if($department_id)
            {
                //$one = db::get_one("select id,name,organization_id from ".mod_table::department." where id={$department_id}");
                $one = db::select('id,name,organization_id')->from(mod_table::department)->where('id','=',$department_id)->as_row()->execute();
                $show_data['department'] = $one['name'];
                //$one1 = db::get_one("select id,name from ".mod_table::organization." where id={$one['organization_id']}");
                $one1 = db::select('id,name')->from(mod_table::organization)->where('id','=',$one['organization_id'])->as_row()->execute();
                $show_data['organ'] = $one1['name'];
            }

            tpl::assign('show_data',$show_data);
            tpl::assign('from',req::get('from','global'));
            tpl::display(__CONTROL__.'.'.__FUNCTION__.'.tpl');
        }
    }

    //修改科室
    public function edit()
    {
        if (!empty(req::$posts))
        {
            $id = req::post('id',0,'int');
            $job_ids = req::post('job_ids');
            $leader_job_id = req::post('leader_job_id',0,'int');
            $select_jobs = json_decode(req::post('select_jobs'),true);

            $data = [
                'name' => req::post('name'),
                'organ_id' => req::post('organ_id',0,'int'),
                'department_id' => req::post('department_id',0,'int'),
                'array_data' => serialize([
                    'job_ids'=>$job_ids,
                    'leader_job_id'=>$leader_job_id,
                    'select_jobs'=> $select_jobs
                ]),
                'job_count' => req::post('job_count'),
                //'leader_job_id' => req::post('leader_job_id',0,'int'),
                'update_user' => cls_auth::$user->fields['uid'],
                'update_time' => time()
            ];
            $people_count = req::post('people_count');
            $people_count && $data['people_count'] = $people_count;

            db::begin_tran();

            db::update(mod_table::department_room)->set($data)->where("id",'=',$id)->execute();

            if($job_ids)
            {
                //原来的人员
                $ord_people_ids = db::select('people_id')->from(mod_table::department_room_people)->where('room_id','=',$id)->execute();
                $ord_people_ids = mod_array::one_array((array)$ord_people_ids, [0,'people_id']);
                //现在的人员
                $peo_where = [
                    ['member_id', '>', 0],
                    ['id', 'in', explode(',',$job_ids)]
                ];
                $peoples = db::select('member_id as people_id,id')->from(mod_table::job_child)->where($peo_where)->execute();
                empty($peoples) && $peoples = [];
                $people_ids = mod_array::one_array($peoples, [0,'people_id']);

                list($create_ids, $delete_ids) = mod_array::update_array($ord_people_ids,$people_ids);

                //新增人员
                if($create_ids)
                {
                    $fields = 'member_id as people_id,station_id as job_id,id';
                    $peoples = db::select($fields)->from(mod_table::job_child)->where('member_id','in',$create_ids)->execute();
                    if($peoples)
                    {
                        foreach ($peoples as &$people)
                        {
                            $people['is_leader'] = $people['id']==$leader_job_id ? 1 : 0;
                            $people['room_id'] = $id;
                            $people['create_user'] = cls_auth::$user->fields['uid'];
                            $people['create_time'] = time();
                            unset($people['id']);
                        }
                        $columns = array_keys(current($peoples));
                        db::insert(mod_table::department_room_people)->columns($columns)->values($peoples)->execute();
                    }
                }

                //删除人员
                if($delete_ids)
                {
                    db::delete(mod_table::department_room_people)->where('people_id','in',$delete_ids)->execute();
                }

            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "编辑科室 ID={$id}");

            db::commit();

            mod_common::jump_update();
        }
        else
        {
            $id = req::get('id',0,'int');
            $fields = 'id,name,organ_id,department_id,job_count,people_count,array_data,create_user,create_time';
            $row = db::select($fields)->from(mod_table::department_room)->where('id','=',$id)->as_row()->execute();
            if(empty($row))
            {
                mod_common::exit_page_404();
            }

            $array_data = unserialize($row['array_data']);
            $select_jobs = json_encode($array_data['select_jobs']);
            tpl::assign('select_jobs',$select_jobs);

            $one = db::select('id,name')->from(mod_table::organization)->where('id','=',$row['organ_id'])->as_row()->execute();
            $row['organ_obj'] = json_encode($one);

            $one = db::select('id,name')->from(mod_table::department)->where('id','=',$row['department_id'])->as_row()->execute();
            $row['depart_obj'] = json_encode($one);

            //科室职权
            $one1 = db::select('id,job_name')->from(mod_table::department_room_people)->where('room_id','=',$row['id'])
                ->where('is_leader','=',1)->as_row()->execute();
            $row['leader'] = $one1 ? $one1['job_name'] : '';

            $row['display_count'] = "已选择{$row['job_count']}个岗位，{$row['people_count']}个员工";

            tpl::assign('row',$row);
            tpl::assign('array_data',$array_data);
            tpl::display(__CONTROL__.'.'.__FUNCTION__.'.tpl');
        }
    }

    public function people_detail()
    {
        $id = req::get('id',0,'int');
        $depart_id  = req::get('department_id',0,'int');

        //$row = db::get_one("select * from ".mod_table::department_room_people." where id=$id");
        $fields = 'id,people_id,room_id,level,is_leader,job_id,job_name,desc,create_time';
        $row = db::select($fields)->from(mod_table::department_room_people)->where('id','=',$id)->as_row()->execute();
        if(empty($row))
        {
            mod_common::exit_page_404();
        }

        $one3 = db::select('realname,sn')->from(mod_table::people)->where('id','=',$row['people_id'])->as_row()->execute();
        $row += $one3 ? $one3 : ['realname'=>'','sn'=>''];

        //员工岗位
        $one2 = db::select('station_id,code')->from(mod_table::job_child)->where('member_id','=',$row['people_id'])->as_row()->execute();
        $one2 += db::select('name')->from(mod_table::job)->where('id','=',$one2['station_id'])->as_row()->execute();
        $row['job'] = "{$one2['code']} {$one2['name']}";


        $one3 = db::select('name')->from(mod_table::department)->where('id','=',$depart_id)->as_row()->execute();
        $row['department'] = $one3['name'];

        $one4 = db::select('name')->from(mod_table::department_room)->where('id','=',$row['room_id'])->as_row()->execute();
        $row['room'] = $one4['name'];

        $fields = 'id,people_id,level,is_leader,job_id,job_name,desc';
        $one1 = db::select($fields)->from(mod_table::department_room_people)->where('room_id','=',$row['room_id'])
            ->where('is_leader','=',1)->as_row()->execute();
        $row['leader'] = $one1;

        $row['create_time'] = date('Y-m-d H:i:s',$row['create_time']);

        tpl::assign('row',$row);
        tpl::display(__CONTROL__.'.'.__FUNCTION__.'.tpl');
    }

    public function people_delete()
    {
        $id = req::get('id',0,'int');
        $room_id = req::get('room_id',0,'int');
        if(empty($id)){
            mod_common::exit_page_404();
        }

        db::begin_tran();

        //更新表态数据
        $people_id = db::select('people_id')->from(mod_table::department_room_people)->where('id','=',$id)->as_field()->execute();
        $job_child_id = db::select('id')->from(mod_table::job_child)->where('member_id','=',$people_id)->as_field()->execute();
        $array_data = db::select('array_data')->from(mod_table::department_room)->where('id','=',$room_id)->as_field()->execute();

        if( mod_array::array_data_delete($array_data,['select_jobs.id', $job_child_id]) )
        {
            mod_array::dot_data_delete($array_data['job_ids'],$job_child_id);
            db::update(mod_table::department_room)->set(['array_data'=>serialize($array_data)])->where('id','=',$room_id)->execute();
        }

        db::delete(mod_table::department_room_people)->where('id','=',$id)->execute();
        //TODO 计数这里到时问一下kaka
        //db::update(mod_table::department_room)->set(['people_count'=>'people_count-1'])->where('id','=',$room_id)->execute();
        db::query("update ".mod_table::department_room." set people_count=people_count-1 where id=$room_id")->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除科室员工 ID={$id}");

        db::commit();

        $gets = req::$gets;
        $action = "detail&id={$room_id}";
        if(isset($gets['organization_id']) && isset($gets['department_id']))
        {
            $action .= "&organization_id={$gets['organization_id']}&department_id={$gets['department_id']}";
        }

        mod_common::jump_delete($action);
    }

    public function people_edit()
    {
        if(req::$posts)
        {
            $id = req::post('id',0,'int');
            $room_id = req::post('room_id',0,'int');

            $data = [
                'level' => req::post('level'),
                'job_name' => req::post('job_name'),
                'desc' => req::post('desc'),
                'update_user' => cls_auth::$user->fields['uid'],
                'update_time' => time()
            ];
            db::update(mod_table::department_room_people)->set($data)->where("id",'=',$id)->execute();


            mod_common::jump_update("detail&id={$room_id}");
        }else
        {
            $id = req::get('id',0,'int');
            $depart_id  = req::get('department_id',0,'int');

            $fields = 'id,people_id,room_id,level,is_leader,job_id,job_name,desc,create_time';
            $row = db::select($fields)->from(mod_table::department_room_people)->where('id','=',$id)->as_row()->execute();

            $one3 = db::select('realname,sn')->from(mod_table::people)->where('id','=',$row['people_id'])->as_row()->execute();
            $row += $one3;

            //员工岗位
            $one2 = db::select('station_id,code')->from(mod_table::job_child)->where('member_id','=',$row['people_id'])->as_row()->execute();
            $one2 += db::select('name')->from(mod_table::job)->where('id','=',$one2['station_id'])->as_row()->execute();
            $row['job'] = "{$one2['code']} {$one2['name']}";


            $one3 = db::select('name')->from(mod_table::department)->where('id','=',$depart_id)->as_row()->execute();
            $row['department'] = $one3['name'];

            $one = db::select('name')->from(mod_table::department_room)->where('id','=',$row['room_id'])->as_row()->execute();
            $row['room'] = $one['name'];

            $fields = 'id,people_id,level,is_leader,job_id,job_name,desc';
            $one1 = db::select($fields)->from(mod_table::department_room_people)->where('room_id','=',$row['room_id'])
                ->where('is_leader','=',1)->as_row()->execute();
            $row['leader'] = $one1;

            $row['create_time'] = date('Y-m-d H:i:s',$row['create_time']);


            tpl::assign('people_levels',$this->people_levels);
            tpl::assign('row',$row);
            tpl::display(__CONTROL__.'.'.__FUNCTION__.'.tpl');
        }
    }

    //回收站
    public function recycle_bin()
    {
        $this->action = __FUNCTION__;
        $this->make_list(1);
    }

    public function ajax_select_organ()
    {
        $search = req::post('search');
        $where = [];
        empty($where) && $where[] = ['name','like',"%$search%"];

        $rows = db::select('id,name as txt')->from(mod_table::organization)->where($where)->execute();

        mod_common::exit_json($rows);
    }

    public function ajax_select_department()
    {
        $search = req::post('search');
        $organ_id = req::post('organ_id',0,'int');
        if(empty($organ_id)){
            exit("organ_id is empty");
        }

        $rows = db::select('id,name as txt')->from(mod_table::department)->where('organization_id','=',$organ_id)
            ->where('name','like',"%$search%")->execute();

        empty($rows) && $rows = [];
        mod_common::exit_json($rows);
    }

    public function ajax_get_jobs()
    {
        $department_id = req::post('department_id',0,'int');
        if(empty($department_id)){
            exit("department_id is empty");
        }

        $rows = db::select('id,name')->from(mod_table::job)->where('department_id','=',$department_id)->execute();
        if(empty($rows)){
            mod_common::exit_json([]);
        }

        foreach ($rows as $key=>&$row)
        {
            $row['child'] = db::select('id,code,member_id,external_name as outer_name')->from(mod_table::job_child)->where('member_id','>',0)
                ->where('station_id','=',$row['id'])->execute();
            if($row['child'])
            {
                $childs = $row['child'];
                foreach ($childs as $child_key=>&$child)
                {
                    //只列出在职的
                    $one = db::select('id,realname')->from(mod_table::people)->where('id','=',$child['member_id'])
                        ->where('job_sta','=',1)->as_row()->execute();
                    if(empty($one))
                    {
                        unset($childs[$child_key]);
                        mod_common::log_line(__CLASS__,__FUNCTION__,"ID={$child['member_id']} 员工数据被删除");
                    }else{
                        isset($one['realname']) && empty($one['realname']) && $one['realname'] = '未知';
                        $child['name'] = !empty($one) ? $one['realname'] : '未知';
                    }

                }

                sort($childs);
                $row['child'] = $childs;
            }else{
                unset($rows[$key]);
            }

        }

        sort($rows);
        mod_common::exit_json($rows);
    }

}
