<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 配置管理
 *
 * @version $Id$
 */
class ctl_config
{
    public static $options = array(
        1 => '基本配置',
        2 => '附件设置',
        3 => '文档设置',
    );

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        tpl::assign( 'options', self::$options );
        tpl::assign( 'groupid', 1 );
    }

    /**
     * 管理员帐号管理
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $groupid = req::item('groupid', 1);

        $where = array();
        if (!empty($keyword)) 
        {
            $where[] = array( 'name', 'like', '%$keyword%' );
        }
        if (!empty($groupid)) 
        {
            $where[] = array( 'groupid', '=', $groupid );
        }

        $row = db::select('count(*) AS `count`')->from('#PB#_config')->where($where)->as_row()->execute();
        $pages = pub_page::make($row['count'], 10);
        $list = db::select()->from('#PB#_config')->where($where)->order_by('sort', 'asc')->limit($pages['page_size'])->offset($pages['offset'])->execute();

        tpl::assign('groupid', $groupid);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('config.index.tpl');
    }

    public function add()
    {
        if (!empty(req::$posts)) 
        {
            $name = req::item('name');
            $row = db::select('count(*) AS `count`')->from('#PB#_config')->where('name', $name)->as_row()->execute();
            if( $row['count'] )
            {
                cls_msgbox::show('系统提示', '变量名称已经存在！', '-1');
                exit();
            }

            db::insert('#PB#_config')->set(array(
                'name'    => req::item('name'),
                'groupid' => req::item('groupid'),
                'title'   => req::item('title'),
                'info'    => req::item('info'),
                'value'   => req::item('value'),
                'sort'    => req::item('sort'),
            ))
            ->execute();

            config::reload();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "配置添加 {$name}");

            $gourl = req::item('gourl', '?ct=config&ac=index');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else 
        {
            $gourl = '?ct=config&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('config.add.tpl');
        }
    }

    public function edit()
    {
        $name = req::item('name', '');
        if (!empty(req::$posts)) 
        {
            db::update('#PB#_config')->set(array(
                'name'    => req::item('name'),
                'groupid' => req::item('groupid'),
                'title'   => req::item('title'),
                'info'    => req::item('info'),
                'value'   => req::item('value'),
                'sort'    => req::item('sort'),
            ))
            ->where('name', $name)
            ->execute();

            config::reload();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "配置修改 {$name}");

            $gourl = req::item('gourl', '?ct=config&ac=index');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else 
        {
            $v = db::select()->from('#PB#_config')->where('name', $name)->as_row()->execute();
            tpl::assign('v', $v);
            $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=config&ac=index' : $_SERVER['HTTP_REFERER'];
            tpl::assign('gourl', $gourl);
            tpl::display('config.edit.tpl');
        }
    }

    public function del()
    {
        $ids = implode(',', req::item('ids', 0));
        db::delete('#PB#_config')->where('sort', 'in', $ids)->execute();

        config::reload();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "配置删除 {$ids}");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=config&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    public function batch_edit()
    {
        $sorts = req::item('sorts', array());
        $datas = req::item('datas', array());
        foreach ($sorts as $name=>$sort) 
        {
            db::update('#PB#_config')->set(array(
                'sort' => $sort
            ))->where('name', $name);
        }
        foreach ($datas as $name=>$value) 
        {
            db::update('#PB#_config')->set(array(
                'value' => $value
            ))->where('name', $name);
        }

        config::reload();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "配置批量修改");

        $gourl = empty($_SERVER['HTTP_REFERER']) ? '?ct=config&ac=index' : $_SERVER['HTTP_REFERER'];
        cls_msgbox::show('系统提示', "批量修改成功", $gourl);
    }

}
