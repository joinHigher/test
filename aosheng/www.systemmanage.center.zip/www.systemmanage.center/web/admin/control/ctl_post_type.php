<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 岗位类型管理
 *
 * @version $Id$
 */
class ctl_post_type
{
    public function __construct()
    {
        $this->level = mod_organize_level::get_config_level('organize_level');
        unset($this->level['']);
        $this->table = '#PB#_post_type';
        tpl::assign('level', $this->level);
        $this->where = [
            ['delete_user', '=', '0'],
            ['delete_time', '=', '0']
        ];
    }

    /**
     * @desc 列表
     */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 20);

        if(!empty($keyword))
        {
            $this->where[] = array('name', 'like', "%{$keyword}%");
        }
        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();

        $pages = pub_page::make($row['count'], $page_size);
        $list  = db::select("id,name,org_level_region,mec_level_region")->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('id','asc')->execute();

        $list = self::data_operation($list);
        //print_r($list);exit;
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('post_type.index.tpl');
    }


    /**
     * @desc 查看机构等级
     */
    public function show()
    {
        $id = req::item('id');
        if(!$id) cls_msgbox::show('系统提示', '数据有误','-1');
        $post_data = db::select('id,name,org_level_region,mec_level_region')->from($this->table)->where('id',$id)->as_row()->execute();

        if(empty($post_data)) cls_msgbox::show('系统提示', '数据有误','-1');
        $post_data = self::data_show($post_data);
        tpl::assign('post_data', $post_data);
        tpl::display('post_type.show.tpl');
    }


    /**
     * @desc 添加
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;

            $data['name'] = $data['realname'];
            unset($data['realname']);
            if (empty($data['name'])) cls_msgbox::show('系统提示', '请填写岗位类型名称','-1');

            $post_info  = db::select('name')->from($this->table)->where('name',$data['name'])->and_where($this->where)->as_row()->execute();
            if(!empty($post_info))   cls_msgbox::show('系统提示', "岗位类型名称已存在，请重新选择", '-1');
            $data['create_user'] = cls_auth::$user->fields['uid'];
            $data['create_time'] = time();

            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增岗位类型 ID为{$insert_id}的数据");

            $gourl = req::item('gourl', '?ct=post_type&ac=add');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else
        {
            //获取所有组织
            $arr = config::get('organize_level');
            $org_data = [];
            for ($x=1; $x<=$arr; $x++)
            {
                $org_data[$x]['id'] = $x;
                $org_data[$x]['level_name'] = $x . "级";
            }

            //获取所有机构
            $mec_data  = db::select('id,name')->from('#PB#_organization')->where($this->where)->execute();

            $gourl = '?ct=post_level&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::assign('org_data', $org_data);
            tpl::assign('mec_data', $mec_data);
            tpl::display('post_type.add.tpl');
        }
    }


    /**
     * @desc 删除
     */
    public function del()
    {
        $id = req::item('id', 0);
        if (empty($id))
        {
            cls_msgbox::show('系统提示', "删除失败，请选择要删除的内容", '-1');
        }

        $delete_arr = array(
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );
        db::update($this->table)
            ->set($delete_arr)
            ->where('id', '=', $id)
            ->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "删除岗位类型ID为 {$id}的数据");

        $gourl =  '?ct=post_type&ac=index' ;
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

    /**
     * @desc 编辑
     */
    public function edit()
    {
        $id = req::item('id', 0, 'int');
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            $data['name'] = $data['realname'];
            unset($data['realname']);
            if (empty($data['name'])) cls_msgbox::show('系统提示', '请填写岗位类型名称','-1');

            $post_info  = db::select('name')->from($this->table)->where('name',$data['name'])->and_where('id','!=',$id)->and_where($this->where)->as_row()->execute();
            if(!empty($post_info))   cls_msgbox::show('系统提示', "岗位类型名称已存在，请重新选择", '-1');
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();
            db::update($this->table)
                ->set($data)
                ->where('id', '=', $id)
                ->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了岗位资类型ID为{$id}的数据");
            $gourl = req::item('gourl', "?ct=post_type&ac=show&id={$id}");
            cls_msgbox::show('系统提示', "修改成功", $gourl);

        }else{
            $mec_region_data = $org_region_data = [];
            $info  = db::select("id,name,org_level_region,mec_level_region")->from($this->table)->where($this->where)->and_where('id',$id)->as_row()->execute();
            if(empty($info)) cls_msgbox::show('系统提示', "数据有误", '-1');
            //适用范围
            if(!empty($info['mec_level_region']))
            {
                $mec_level_region = explode(',',$info['mec_level_region']);
                $mec_region_data  = db::select('name,id')->from('#PB#_organization')->where('id','in',$mec_level_region)->and_where($this->where)->execute();

                $mec_region_data = array_column($mec_region_data,'name','id');

            }
            $index = config::get('organize_level');
            //组织等级
            if(!empty($info['org_level_region']))
            {
                $org_data_id = json_decode($info['org_level_region'],true);
                $key = array_keys($org_data_id);
                $org_region_data  = db::select('id,level_name')->from('#PB#_organize_level')->where('id','in',$key)->and_where($this->where)->execute();
                foreach ($key as $k => $value)
                {
                    if(isset($org_data_id[$value]))
                    {
                        $org_region_data[$k]['id'] = $value;
                        $org_region_data[$k]['region'] = $org_data_id[$value];
                        $org_region_data[$k]['level_name'] = $value.'级机构';
                        $num = count(explode(',',$org_data_id[$value]));
                        if($index == $num)
                        {
                            $org_region_data[$k]['tips'] = "全部组织";
                        }
                    }
                }
            }

            //获取所有组织

            $org_data = [];
            for ($x=1; $x<=$index; $x++)
            {
                $org_data[$x]['id'] = $x;
                $org_data[$x]['level_name'] = $x . "级";
            }
            //获取所有机构
            $mec_data  = db::select('id,name')->from('#PB#_organization')->where($this->where)->execute();

            //print_r($mec_data);
            $gourl = '?ct=post_level&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::assign('org_data', $org_data);
            tpl::assign('mec_data', $mec_data);
            tpl::assign('info', $info);
            tpl::assign('mec_region_data', $mec_region_data);
            tpl::assign('org_region_data', $org_region_data);
            tpl::display('post_type.edit.tpl');
        }
    }


    private static function data_operation($list)
    {
        if (empty($list)) return [];
        foreach ($list as $key => $value)
        {
            $list[$key]['mec_region'] = $list[$key]['org_region'] = '';
            if(!empty($value['org_level_region']))
            {
                //查询机构名称
                $org_data = json_decode($value['org_level_region']);
                foreach ($org_data as $k => $v)
                {
                    //$org_info  = db::select('level_name')->from('#PB#_organize_level')->where('id',$k)->as_row()->execute();
                    $list[$key]['mec_region'] .= $k.'级机构组织等级：'.$v."<br />";
                }
            }else{
                $list[$key]['mec_region'] = '<span style="color: #881b1b">全部可用</span>';

            }
            if(!empty($value['mec_level_region']))
            {
                //适用机构
                $mec_level_region = explode(',',$value['mec_level_region']);
                $org  = db::select('name')->from('#PB#_organization')->where('id','in',$mec_level_region)->and_where('delete_user','0')->execute();

                $org  = array_column($org,'name');
                $num = count($org);
                if(!empty($org))
                {
                    $list[$key]['org_region'] = $num >= 2 ? $org[0] . '、' . $org[1]."等 ".$num."个机构" : $org[0];
                }
            }else{
                $list[$key]['org_region'] = '<span style="color: #881b1b">全部可用</span>';
            }

        }
        return $list;
    }


    private static function data_show($data)
    {
        if (empty($data)) return [];
        //查询机构名称
        $org_level_region = json_decode($data['org_level_region']);
        $data['org_region'] = $data['mec_region'] = [];
        if(!empty($org_level_region))
        {
            foreach ($org_level_region as $k => $v)
            {
                //$org_info  = db::select('level_name')->from('#PB#_organize_level')->where('id',$k)->as_row()->execute();
                $data['org_region'][$k]['name'] = $k.'级机构';//$org_info['level_name'];
                $data['org_region'][$k]['mec'] = $v;
            }
        }

        if(!empty($data['mec_level_region']))
        {
            $mec_level_region = explode(',',$data['mec_level_region']);
            $org  = db::select('name')->from('#PB#_organization')->where('id','in',$mec_level_region)->execute();
            $org  = array_column($org,'name');
            $data['mec_region'] = is_array($org) ? $org : [];
        }
        //适用机构
        return $data;
    }

}
