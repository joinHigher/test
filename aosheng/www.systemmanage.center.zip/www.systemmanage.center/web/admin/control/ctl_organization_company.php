<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 工商注册信息.
 *
 * @version $Id$
 */
class ctl_organization_company
{

    public static $image_path = PATH_UPLOADS.DIRECTORY_SEPARATOR.'image'.DIRECTORY_SEPARATOR;
    public static $options = array(0 => '请选择管理员');
    public static $department_prefix = 'DP';
    public static $top_name = '权力部门';

    /**
     * 公司类型(1:有限责任公司,2:股份有限公司,3:有限合伙企业,4:外商独资公司,5:个人独资公司,6:国有独资公司,7:其他)
     */
    public static $type_options = array(
        '' => '请选择类型',
        '1' => '有限责任公司',
        '2' => '股份有限公司',
        '3' => '有限合伙企业',
        '4' => '外商独资公司',
        '5' => '个人独资公司',
        '6' => '国有独资公司',
        '7' => '其他',
    );

    /**
     * 岗位类型.
     */
    public static $station_type_options = array(
        '' => '请选择',
        '1' => '员工岗',
        '2' => '委员岗',
        '3' => '兼职岗',
        '4' => '实际岗',
    );

    /**
     * 货币类型.
     */
    public static $currency_options = array(
        '' => '请选择货币类型',
        '1' => '人民币',
        '2' => '美元',
        '3' => '欧元',
        '4' => '柬埔寨币',
        '5' => '日元',
    );

    /**
     * 股东类型.
     */
    public static $shareholder_type_options = array(
        '' => '请选择',
        '1' => '注册股东',
        '2' => '实际股东',
    );

    // 部门状态.
    public static $status_options = array(
        '' => '请选择',
        '1' => '正常',
        '2' => '删除',
    );

    /**
     * 股东身份.
     */
    public static $identity_options = array(
        '' => '请选择',
        '1' => '机构',
        '2' => '部门',
        '3' => '个人',
    );

    /**
     * 实际出资方式.
     */
    public static $contribution_options;

    /**
     * 上级部门类型.
     */
    public static $superior_department_type_options = array(
        '' => '请选择',
        '1' => '由部门领导',
        '2' => '由独立岗位领导',
    );

    /**
     * 部门状态.
     */
    public static $department_status_options = array(
        '1' => '正常',
        '2' => '删除',
    );

    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        self::$contribution_options = $this->get_contribution_options();
        tpl::assign( 'type_options', self::$type_options);
        tpl::assign( 'currency_options', self::$currency_options);
        tpl::assign( 'shareholder_type_options', self::$shareholder_type_options);
        tpl::assign( 'identity_options', self::$identity_options);
        tpl::assign( 'contribution_options', self::$contribution_options);
        tpl::assign( 'superior_department_type_options', self::$superior_department_type_options);
    }

    /**
     * 获取出资方式数据.
     */
    private function get_contribution_options()
    {
        return mod_base_type::get_contri();
    }

    /**
     * 获取联系方式.
     *
     * @return array|bool|mixed|null
     */
    private function get_contact_options()
    {
        return mod_base_type::get_contact();
    }

    /**
     * 获取国家数据.
     */
    private function get_nation_options()
    {
        $data = mod_area::get_level_area();

        return $data;
    }

    /**
     * 获取组织等级.
     */
    private function get_level_options()
    {
        $data = mod_organize_level::instance()->get_level_options();

        return $data;
    }

    /**
     * 获取部门编号.
     */
    private function get_department_number()
    {
        // 岗位编号.
        $data = mod_department::instance()->get_list_data(array('1' => 1), '`id`,`number`', '', 1, 'id desc');
        if (empty($data)) {
            $id = 1;
        } else {
            $data = $data[0];
            $number = substr($data['number'], 2, 5);
            $number = (int) $number;
            $id = $data['id'] + 1;
            if ($number >= $id) {
                $id = $number + 1;
            }
        }

        $number = self::$department_prefix.str_pad($id, 5, "0", STR_PAD_LEFT);

        return $number;
    }

    /**
     * 获取业务属性.
     */
    private function get_tag_options($org_id = 0)
    {
        return mod_operation_tag::instance()->get_tag_options(array(), $org_id);
    }

    /**
     * 获取公司注册信息.
     */
    public function index()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $power = req::item('power', 0, 'int');
        if (empty($organization_id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        $data = mod_organization_company::instance()->get_one_data(array('organization_id' => $organization_id), '', true);
        if (!empty($data['id'])) {
            $data['type'] = isset(self::$type_options[$data['type']]) ? self::$type_options[$data['type']] : '';
            $data['currency'] = isset(self::$currency_options[$data['currency']]) ? self::$currency_options[$data['currency']] : '';
            $data['license'] = json_decode($data['license'], true);
        }
        // 国籍.
        if (!empty($data['country'])) {
            $nation_data = mod_area::get_area_name($data['country']);
            $data['country']  = !empty($nation_data) ? $nation_data : '';
        }

        tpl::assign('index', 'org_company');
        tpl::assign('power', $power);
        tpl::assign('data', $data);
        tpl::assign('organization_id', $organization_id);
        tpl::display('organization_company.index.tpl');
    }

    /**
     * 公司注册营业执照图片.
     */
    public function index_images()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');
        if (empty($organization_id) || empty($id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        $data = mod_organization_company::instance()->get_one_data(array('id' => $id, 'organization_id' => $organization_id), '`id`, `license`');
        if (!empty($data)) {
            $data['license'] = json_decode($data['license'], true);
        }

        tpl::assign('data', $data);
        tpl::display('organization_company.index_images.tpl');
    }

    /**
     * 获取文件.
     */
    public function get_file()
    {
        $key = req::item('key', '', 'string');
        $file_name = req::item('file_name', '', 'string');
        $file = self::$image_path.$file_name;
        if (empty($key) || empty($file_name)) {
            exit('参数错误!');
        }

        if (!file_exists($file)) {
            exit('文件不存在!');
        }

        $content = file_get_contents($file);
        $data = cls_crypt::decode($content, $key);
        ob_clean();
        header('Content-Type: image/png;');
        echo $data;
    }

    /**
     * 获取机构下面的股东信息.
     */
    public function shareholder()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $page_size = req::item('page_size', 10);
        $type = req::item('type', 1, 'int');
        $power = req::item('power', 0, 'int');
        if (empty($organization_id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        $condition = array(
            'organization_id' => $organization_id,
            'type' => $type,
            'delete_user' => 0
        );
        $count = mod_shareholder::instance()->count($condition);
        $pages = pub_page::make($count, $page_size);
        $list = mod_shareholder::instance()->get_list_data($condition, '', '', "{$pages['offset']}, {$pages['page_size']}", 'id desc');

        array_walk(
            $list,
            function(&$value, $key){
                $value['identity'] = isset(self::$identity_options[$value['identity']]) ? self::$identity_options[$value['identity']] : '';
                $value['contribution'] = isset(self::$contribution_options[$value['contribution']]) ? self::$contribution_options[$value['contribution']] : '';
                empty($value['identity']) ? '' : ($value['shares'].='%');
            }
        );

        tpl::assign('index', 'org_shareholder');
        tpl::assign('list', $list);
        tpl::assign('type', $type);
        tpl::assign('power', $power);
        tpl::assign('pages', $pages['show']);
        tpl::assign('organization_id', $organization_id);
        tpl::display('organization_company.shareholder.tpl');
    }

    /**
     * 获取机构下面的部门信息
     */
    public function department()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $power = req::item('power', 0, 'int');
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 10);
        $type = req::item('type', '', 'string');
        $level_id = req::item('level_id', '', 'string');

        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = "%".$keyword."%";
        }

        if (!empty($organization_id)) {
            $condition['organization_id'] = $organization_id;
        }
        if (!empty($level_id)) {
            $condition['level_id'] = $level_id;
        }

        if ($type=='delete') {
            $condition['delete_user >'] = 0;
        } else {
            $condition['delete_user'] = 0;
        }

        $count = mod_department::instance()->count($condition);
        $pages = pub_page::make($count, $page_size);
        $list = mod_department::instance()->get_list_data($condition, '', '', "{$pages['offset']}, {$pages['page_size']}", 'id desc');

        // 组织等级.
        $level_data = array();
        $level_id_arr = array_column($list, 'level_id');
        if (!empty($level_id_arr)) {
            $level_id_arr = array_unique($level_id_arr);
            $level_data = mod_organize_level::instance()->get_level_options($level_id_arr);
        }

        // 部门等级.
        $organization_data = array();
        $organization_id_arr = array_column($list, 'organization_id');
        $user_id_arr = array_column($list, 'create_user');
        if (!empty($organization_id_arr)) {
            $organization_id_arr = array_unique($organization_id_arr);
            $organization_data = mod_organization::instance()->get_list_data(array('id in' => $organization_id_arr), '`id`,`name`', 'id');
        }

        // 上级部门.
        $superior_department_id_arr = array();
        $superior_station_id_arr = array();
        foreach ($list as $key => $value) {
            switch ($value['superior_department_type']) {
                case 1:
                    // 由部门领导.
                    $superior_department_id_arr[] = $value['superior_id'];
                    break;
                case 2:
                    // 由独立岗位领导.
                    $superior_station_id_arr[] = $value['superior_id'];
                    break;
                default:
                    break;
            }
        }

        // 数据写入作者.
        $admin_options = array();
        if (!empty($user_id_arr)) {
            $user_id_arr = array_unique($user_id_arr);
            $admin_options = mod_admin::instance()->get_admin_option($user_id_arr);
        }

        $superior_department = array();
        $superior_station = array();
        if (!empty($superior_department_id_arr)) {
            $superior_department_id_arr = array_unique($superior_department_id_arr);
            $superior_department = mod_department::instance()->get_list_data(array('id in' =>$superior_department_id_arr), '`id`,`name`', 'id');
        }
        if (!empty($superior_station_id_arr)) {
            $superior_station_id_arr = array_unique($superior_station_id_arr);
            $superior_station = mod_station::instance()->get_list_data(array('id in' => $superior_station_id_arr), '`id`,`name`', 'id');
        }

        // 部门类型.
        $department_type = mod_base_type::get_depart();
        $organization_name = '';
        foreach ($list as $key=>$value) {
            $list[$key]['type'] = isset($department_type[$value['type']]) ? $department_type[$value['type']] : '';
            $list[$key]['creator'] = isset($admin_options[$value['create_user']]) ? $admin_options[$value['create_user']] : '';
            $list[$key]['status'] = isset(self::$status_options[$value['status']]) ? self::$status_options[$value['status']] : '';
            $list[$key]['level_id'] = isset($level_data[$value['level_id']]) ? $level_data[$value['level_id']] : '';
            $list[$key]['organization_id'] = isset($organization_data[$value['organization_id']]) ? $organization_data[$value['organization_id']]['name'] : '';
            if (!empty($organization_id) && empty($organization_name)) {
                $organization_name = $list[$key]['organization_id'];
            }
            $list[$key]['superior_id'] = ($value['superior_department_type'] == '1') ? (isset($superior_department[$value['superior_id']]) ? $superior_department[$value['superior_id']]['name'] : '') : (isset($superior_station[$value['superior_id']]) ? $superior_station[$value['superior_id']]['name'] : '');
            $list[$key]['is_delete'] = !empty($value['delete_user']) ? self::$department_status_options['2'] : self::$department_status_options['1'];
        }


        tpl::assign('index', 'org_department');
        tpl::assign('list', $list);
        tpl::assign('type', $type);
        tpl::assign('power', $power);
        tpl::assign('pages', $pages['show']);
        tpl::assign('organization_id', $organization_id);
        // 点击部门岗位管理-部门管理.
        if (!empty($type)) {
            $organization_options = mod_organization::instance()->get_list_data(array('status' => '1'), '`id`,`name`');
            $organization_options = array_column($organization_options, 'name', 'id');
            $level_options = $this->get_level_options();
            tpl::assign('level_options', $level_options);
            tpl::assign('organization_options', $organization_options);
            tpl::assign('level_id', $level_id);
            tpl::display('organization_company.department.all.tpl');
        } else {
            tpl::assign('organization_name', $organization_name);
            tpl::display('organization_company.department.tpl');
        }
    }

    /**
     * 部门管理树形图.
     */
    public function department_tree()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $power = req::item('power', 0, 'int');
        $keyword = req::item('keyword', '');

        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = "%".$keyword."%";
        }

        if (!empty($organization_id)) {
            $condition['organization_id'] = $organization_id;
        }

        $children = array();
        if (empty($keyword)) {
            $condition['belong_id'] = 0;
        }
        $department = mod_department::instance()->get_list_data($condition, '`id`, `name`');
        foreach ($department as $key => $value) {
            $tmp = array();
            $tmp['id'] = $value['id'];
            $tmp['name'] = $value['name'];
            $tmp['hasChild'] = mod_department::instance()->checkout_is_sub_belong_id($value['id']);
            $children[] = $tmp;
        }

        $top_organization = array();
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `name`');
        $organizations['children'] = $children;
        $organizations['hasChild'] = count($children);
        $top_organization[] = $organizations;
        $top_organization = json_encode($top_organization);

        tpl::assign('top_organization', $top_organization);
        tpl::assign('organization_id', $organization_id);
        tpl::assign('index', 'org_department');
        tpl::assign('power', $power);
        tpl::display('organization_company.department_tree.tpl');
    }

    /**
     * 获取下一级部门.
     */
    public function ajax_get_department_tree()
    {
        $data = array();
        $id = req::item('id', 0, 'int');
        if (!empty($id)) {
            $data = mod_department::instance()->get_child_by_belong_id($id);
        }

        echo json_encode($data);
    }

    /**
     * 部门下岗位.
     */
    public function department_station()
    {
        $keyword = req::item('keyword', '');
        $organization_id = req::item('organization_id', 0, 'int');
        $department_id = req::item('id', 0, 'int');
        $page_size = req::item('page_size', 10);
        $type = req::item('type', '', 'string');
        if (empty($organization_id) || empty($department_id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        $condition = array();
        if (!empty($keyword)) {
            $condition['name like'] = "%".$keyword."%";
        }

        if (!empty($organization_id)) {
            $condition['organization_id'] = $organization_id;
        }
        if (!empty($department_id)) {
            $condition['department_id'] = $department_id;
        }

        $condition['delete_user'] = 0;

        $count = mod_station::instance()->count($condition);
        $pages = pub_page::make($count, $page_size);
        $list = mod_station::instance()->get_list_data($condition, '', '', "{$pages['offset']}, {$pages['page_size']}", 'id desc');
        // 机构.
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `name`');
        // 部门.
        $department_data = mod_department::instance()->get_one_data(array('id' => $department_id), '`id`,`name`, `delete_user`');
        // 计算每个岗位有人员在岗的人数.
        $station_ids = array_column($list, 'id');
        $station_ids = array_unique($station_ids);
        $staff_data = array();
        if (!empty($station_ids)) {
            $staff_data = mod_station_list::instance()->get_list_data(
                array(
                    'station_id in' => $station_ids,
                    'member_id >' => 0,
                ),
                'count(*) as num, station_id',
                'station_id',
                '',
                '',
                'station_id'

            );
        }

        $user_id_arr = array_column($list, 'create_user');
        // 数据写入作者.
        $admin_options = array();
        if (!empty($user_id_arr)) {
            $user_id_arr = array_unique($user_id_arr);
            $admin_options = mod_admin::instance()->get_admin_option($user_id_arr);
        }

        // 组织等级.
        $level_data = array();
        $level_id_arr = array_column($list, 'level_id');
        if (!empty($level_id_arr)) {
            $level_id_arr = array_unique($level_id_arr);
            $level_data = mod_organize_level::instance()->get_level_options($level_id_arr);
        }

        // 获取任务领取人名称.
        foreach ($list as $key=>$value)
        {
            $list[$key]['creator'] = isset($admin_options[$value['create_user']]) ? $admin_options[$value['create_user']] : '';
            $list[$key]['status'] = ($value['delete_user'] == 0) ? self::$status_options[1] : self::$status_options[2];
            $list[$key]['type'] = isset(self::$station_type_options[$value['type']]) ? self::$station_type_options[$value['type']] : '';
            $list[$key]['level_id'] = isset($level_data[$value['level_id']]) ? $level_data[$value['level_id']] : '';
            $list[$key]['on_duty_num'] = isset($staff_data[$value['id']]) ? $staff_data[$value['id']]['num'] : 0;
        }

        tpl::assign('index', 'department_station');
        tpl::assign('list', $list);
        tpl::assign('type', $type);
        tpl::assign('is_depart_deleted', $department_data['delete_user']);
        tpl::assign('department_add_type', 1);
        tpl::assign('pages', $pages['show']);
        tpl::assign('organizations', $organizations);
        tpl::assign('department_data', $department_data);
        tpl::assign('organization_id', $organization_id);
        tpl::assign('department_id', $department_id);
        tpl::display('organization_company.department_station.tpl');
    }



    /**
     * 股东详情.
     */
    public function shareholder_detail()
    {
        $id = req::item('id', 0, 'int');
        if (empty($id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 股东数据.
        $data = mod_shareholder::instance()->get_one_data(array('id' => $id));
        if (empty($data)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }
        if (!empty($data['contact'])) {
            $data['contact'] = json_decode($data['contact'], true);
            $contact_data = mod_base_type::get_contact(array_keys($data['contact']));
            $contact_data = array_column($contact_data, null, 'id');
            $new_contact_data = array();
            array_walk(
                $data['contact'],
                function ($value, $key) use($contact_data, &$new_contact_data){
                    $new_contact_data[$contact_data[$key]['name']] = $value;
                }
            );
            $data['contact'] = $new_contact_data;
        }
        if (!empty($data['contribution'])) {
            $contribution_data = mod_base_type::get_contri($data['contribution']);
            !empty($contribution_data) ? ($data['amount'].='万元 ('.$contribution_data['name'].')') : null;
        }

        // 股东证件类型.
        $certificate_type_options = mod_base_type::get_certif();
        $data['type'] = isset(self::$shareholder_type_options[$data['type']]) ? self::$shareholder_type_options[$data['type']] : '';
        $data['identity'] = isset(self::$identity_options[$data['identity']]) ? self::$identity_options[$data['identity']] : '';
        $data['certificate_type'] = isset($certificate_type_options[$data['certificate_type']]) ? $certificate_type_options[$data['certificate_type']] : '';
        empty($data['shares']) ? '' : ($data['shares'].='%');
        $data['certificate_picture'] = json_decode($data['certificate_picture'], true);
        tpl::assign('organization_id', $data['organization_id']);
        tpl::assign('data', $data);
        tpl::assign('delete_user', $data['delete_user']);
        tpl::display('organization_company.shareholder.detail.tpl');
    }

    /**
     * 公司注册营业执照图片.
     */
    public function shareholder_images()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');
        if (empty($organization_id) || empty($id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        $data = mod_shareholder::instance()->get_one_data(array('id' => $id, 'organization_id' => $organization_id), '`id`, `certificate_picture`');
        if (!empty($data)) {
            $data['certificate_picture'] = json_decode($data['certificate_picture'], true);
        }

        tpl::assign('data', $data);
        tpl::display('organization_company.shareholder_images.tpl');
    }

    /**
     * 部门详情.
     */
    public function department_detail()
    {
        $id = req::item('id', 0, 'int');
        $type = req::item('type', '', 'string');
        if (empty($id))
        {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 股东数据.
        $data = mod_department::instance()->get_one_data(array('id' => $id));
        if (empty($data)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        // 机构数据.
        $organization = mod_organization::instance()->get_one_data(array('id' => $data['organization_id']), '`id`, `name`');
        $data['organization_name'] = !empty($organization) ? $organization['name'] : '';
        $data['secret_degree'] = mod_security_level::instance()->get_security_level_name($data['secret_degree']);
        // 组织等级.
        $data['level_id'] = mod_organize_level::instance()->get_level_name($data['level_id']);

        // 上级部门
        if (!empty($data['superior_id'])) {
            switch ($data['superior_department_type']) {
                case 1:
                    // 由部门领导.
                    $res = mod_department::instance()->get_one_data(array('id' => $data['superior_id']), '`id`,`name`');
                    break;
                case 2:
                    // 由独立岗位领导.
                    $res = mod_station::instance()->get_one_data(array('id' => $data['superior_id']), '`id`,`name`');
                    break;
                default:
                    break;
            }
            if (!empty($res)) {
                $data['superior_id'] = $res['name'];
            }
        } else {
            $data['superior_id'] = '';
        }

        $data['superior_department_type'] = isset(self::$superior_department_type_options[$data['superior_department_type']]) ? self::$superior_department_type_options[$data['superior_department_type']] : '';
        // 部门对外名称.
        if (!empty($data['external_name'])) {
            $data['external_name'] = json_decode($data['external_name'], true);
        }
        if (!empty($data['business_leader'])) {
            $data['business_leader'] = json_decode($data['business_leader'], true);
        }
        if (!empty($data['business_link'])) {
            $data['business_link'] = json_decode($data['business_link'], true);
        }

        // 部门类型.
        if (!empty($data['type'])) {
            $department_type_data = mod_base_type::get_depart($data['type']);
            $data['type'] = $department_type_data['name'];
        } else {
            $data['type'] = '';
        }

        // 行政归属.
        if (!empty($data['belong_id'])) {
            switch ($data['belong_type']) {
                case 1:
                    // 由部门领导.
                    $res = mod_department::instance()->get_one_data(array('id' => $data['belong_id']), '`id`,`name`');
                    break;
                case 2:
                    // 由独立岗位领导.
                    $res = mod_station::instance()->get_one_data(array('id' => $data['belong_id']), '`id`,`name`');
                    break;
                default:
                    break;
            }
            if (!empty($res)) {
                $data['belong_id'] = $res['name'];
            }
        } else {
            $data['belong_id'] = '';
        }

        // 业务属性.
        if (!empty($data['business_tag'])) {
            $tag_arr = explode(',', $data['business_tag']);
            $tags = mod_operation_tag::instance()->get_column_data(array('id in' => $tag_arr), 'tag_name');
            $data['business_tag'] = implode(',', $tags);
        }

        $return_url = '';
        if ($type == 'all') {
            $return_url = '?ct=organization_company&ac=department&type=all';
        } elseif ($type == 'delete') {
            // 部门回收站.
            $return_url = '?ct=organization_company&ac=department&type=delete';
        }

        tpl::assign('return_url', $return_url);

        tpl::assign('index', 'department_detail');
        tpl::assign('type', $type);
        tpl::assign('organization_id', $data['organization_id']);
        tpl::assign('department_id', $data['id']);
        tpl::assign('data', $data);
        tpl::assign('is_depart_deleted', $data['delete_user']);
        tpl::display('organization_company.department.detail.tpl');
    }

    /*
     * 添加或编辑工商注册信息.
     */
    public function edit_add_company()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');
        if (empty($organization_id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        if (empty($id)) {
            $result = mod_organization_company::instance()->get_one_data(array('organization_id' => $organization_id));
        } else {
            $result = mod_organization_company::instance()->get_one_data(array('organization_id' => $organization_id, 'id' => $id));
        }
        // 机构数据.
        if (!empty($result)) {
            $result['license'] = json_decode($result['license'], true);
        }

        if (!empty(req::$posts))
        {
            $data = array();
            $time = time();
            $license = req::item('license_data', array());
            $data['type'] = req::item('type', 0, 'int');
            $data['country'] = req::item('country', 0, 'int');
            $data['organization_id'] = $organization_id;
            $data['registered_capital'] = req::item('registered_capital', 0, 'int');
            $data['currency'] = req::item('currency', 0, 'int');
            $data['established_date'] = strtotime(req::item('established_date', 0, 'string'));
            $data['date_from'] = strtotime(req::item('date_from', 0, 'string'));
            $data['date_end'] = strtotime(req::item('date_end', 0, 'string'));
            $data['approval_date'] = strtotime(req::item('approval_date', 0, 'string'));
            $data['social_code'] = req::item('social_code', '', 'string');
            $data['name'] = req::item('name', '', 'string');
            $data['legal_representative'] = req::item('legal_representative', '', 'string');
            $data['registration_authority'] = req::item('registration_authority', '', 'string');
            $data['address'] = req::item('address', '', 'string');
            $data['business_scope'] = req::item('business_scope', '', 'string');
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = $time;

            $gourl = req::item('gourl', '?ct=organization_company&ac=index&organization_id='.$organization_id);
            // 修改的时候, 只需要处理已经新增的数据.
            if (!empty($result)) {
                !empty($result['license']) ? ($old_images = array_column($result['license'], null, 'file_name')) : ($old_images = array());
                $images_arr = array_keys($old_images);
                $need_uploadfile = array_diff($license, $images_arr);
                $delete_arr = array_diff($images_arr, $license);
            } else {
                $need_uploadfile = $license;
            }

            // 处理需要上传的营业执照图片数据.
            if (!empty($need_uploadfile)) {
                $path = date('Y').DIRECTORY_SEPARATOR.date('m').DIRECTORY_SEPARATOR.date('d');
                $upload = mod_image::file_move($need_uploadfile, $path);
                if (!empty($upload['status'])) {
                    cls_msgbox::show('营业执照图片处理失败!', $result['message'], $gourl);
                    exit();
                }
            }

            // 整理图片数据.
            if (empty($result)) {
                $data['license'] = isset($upload) ? $upload['data'] : array();
                $data['license'] = json_encode($data['license']);
            } else {
                $upload = isset($upload) ? array_column($upload['data'], null, 'old_name') : array();
                $tmp_data = array();
                foreach ($license as $key => $value) {
                    if (in_array($value, $images_arr)) {
                        $tmp_data[] = $old_images[$value];
                    } elseif(in_array($value, $need_uploadfile)) {
                        $tmp_data[] = $upload[$value];
                    }
                }

                foreach ($delete_arr as $key => $value) {
                    unlink(self::$image_path.$value);
                }

                $data['license'] = json_encode($tmp_data);
            }

            $gourl = req::item('gourl', '?ct=organization_company&ac=index&organization_id='.$organization_id);
            if (empty($result)) {
                $data['create_user'] = cls_auth::$user->fields['admin_id'];
                $data['create_time'] = $time;
                $insert_id = mod_organization_company::instance()->insert_data($data);
                if (empty($insert_id)) {
                    cls_msgbox::show('系统提示', "添加失败", $gourl);
                    exit();
                }
                cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户添加工商注册信息 {$insert_id}");
                cls_msgbox::show('系统提示', "添加成功", $gourl);
            } else {
                $result = mod_organization_company::instance()->update_data($data, array('organization_id' => $organization_id));
                if ($result !== false) {
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户修改机构 {$organization_id}");
                    cls_msgbox::show('系统提示', "修改成功", $gourl);
                } else {
                    cls_msgbox::show('系统提示', "修改失败", $gourl);
                }
            }
        }
        else
        {
            $nation_data = $this->get_nation_options();
            tpl::assign('data', $result);
            tpl::assign('nation_data', $nation_data);
            tpl::assign('organization_id', $organization_id);
            tpl::display('organization_company.edit.tpl');
        }
    }

    /**
     * 添加或编辑股东信息.
     */
    public function add_edit_shareholder()
    {
        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');
        $do = req::item('do', 0, 'int');

        if (empty($organization_id)) {
            cls_msgbox::show('系统提示', '参数错误！', '-1');
            exit();
        }

        if ($do) {
            if (empty($id)) {
                cls_msgbox::show('系统提示', '参数错误！', '-1');
                exit();
            }
            // 修改操作.
            $result = mod_shareholder::instance()->get_one_data(array('id' => $id, 'organization_id' => $organization_id));
            if (empty($result)) {
                cls_msgbox::show('系统提示', '不存在该数据！', '-1');
            }
            if (!empty($result['contact'])) {
                $result['contact'] = json_decode($result['contact'], true);
            }
            $result['certificate_picture'] = json_decode($result['certificate_picture'], true);
        }
        if (!empty(req::$posts))
        {
            $data = array();
            $time = time();
            $image_data = req::item('image_data', array());
            $data['type'] = req::item('type', 0, 'int');
            $data['organization_id'] = $organization_id;
            $data['identity'] = req::item('identity', 0, 'int');
            $data['shares'] = req::item('shares', 0, 'int');
            $data['contribution'] = req::item('contribution', 0, 'int');
            $data['amount'] = req::item('amount', 0, 'int');
            $data['certificate_type'] = req::item('certificate_type', 0, 'int');
            $data['name'] = req::item('name', '', 'string');
            $data['certificate_number'] = req::item('certificate_number', '', 'string');
            $data['certificate_picture'] = req::item('certificate_picture', '', 'string');
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = $time;
            // 联系方式.
            $contact_type = req::item('contact_type', array());
            $contact = req::item('contact', array());
            $contact_type = array_filter($contact_type);
            $contact = array_filter($contact);
            if (count($contact_type) != count($contact)) {
                cls_msgbox::show('系统提示', '联系方式数据错误!', -1);
                exit();
            }

            $data_contact = array();
            if (!empty($contact_type)) {
                $data_contact = array_combine($contact_type, $contact);
            }
            $data['contact'] = json_encode($data_contact);

            // 修改的时候, 只需要处理已经新增的数据.
            if (!empty($result)) {
                !empty($result['certificate_picture']) ? ($old_images = array_column($result['certificate_picture'], null, 'file_name')) : ($old_images = array());
                $images_arr = array_keys($old_images);
                $need_uploadfile = array_diff($image_data, $images_arr);
                $delete_arr = array_diff($images_arr, $image_data);
            } else {
                $need_uploadfile = $image_data;
            }

            // 处理需要上传的营业执照图片数据.
            if (!empty($need_uploadfile)) {
                $path = date('Y').DIRECTORY_SEPARATOR.date('m').DIRECTORY_SEPARATOR.date('d');
                $upload = mod_image::file_move($need_uploadfile, $path);
                if (!empty($upload['status'])) {
                    cls_msgbox::show('图片处理失败!', '营业执照图片处理失败!');
                    exit();
                }
            }

            // 整理图片数据.
            if (empty($result)) {
                $data['certificate_picture'] = isset($upload) ? $upload['data'] : array();
                $data['certificate_picture'] = json_encode($data['certificate_picture']);
            } else {
                $upload = isset($upload) ? array_column($upload['data'], null, 'old_name') : array();
                $tmp_data = array();
                foreach ($image_data as $key => $value) {
                    if (in_array($value, $images_arr)) {
                        $tmp_data[] = $old_images[$value];
                    } elseif(in_array($value, $need_uploadfile)) {
                        $tmp_data[] = $upload[$value];
                    }
                }

                foreach ($delete_arr as $key => $value) {
                    unlink(self::$image_path.$value);
                }

                $data['certificate_picture'] = json_encode($tmp_data);
            }

            if (empty($result)) {
                $gourl = req::item('gourl', '?ct=organization_company&ac=shareholder&organization_id=' . $organization_id);
                $data['create_user'] = cls_auth::$user->fields['admin_id'];
                $data['create_time'] = $time;
                $insert_id = mod_shareholder::instance()->insert_data($data);
                
                if (empty($insert_id)) {
                    cls_msgbox::show('系统提示', "添加失败", $gourl);
                    exit();
                }
                cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户添股东信息 {$insert_id}");
                cls_msgbox::show('系统提示', "添加成功", $gourl);
            } else {
                $gourl = req::item('gourl', '?ct=organization_company&ac=shareholder_detail&id='.$id);
                $result = mod_shareholder::instance()->update_data($data, array('id' => $id));
                if ($result !== false) {
                    cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户修改股东信息 {$id}");
                    cls_msgbox::show('系统提示', "修改成功", $gourl);
                } else {
                    cls_msgbox::show('系统提示', "修改失败", $gourl);
                }
            }
        }
        else
        {
            // 修改操作.
            if ($do) {
                tpl::assign('data', $result);
            }

            // 股东证件类型.
            $certificate_type_options = mod_base_type::get_certif();
            // 联系方式.
            $contact_data = $this->get_contact_options();
            empty($do) ? ($title = "添加股东") : ($title = "编辑股东");
            tpl::assign('id', $id);
            tpl::assign('do', $do);
            tpl::assign('certificate_type_options', $certificate_type_options);
            tpl::assign('organization_id', $organization_id);
            tpl::assign('contact_data', $contact_data);
            tpl::assign('title', $title);
            tpl::display('organization_company.shareholder.add.tpl');
        }
    }

    /**
     * 删除股东操作.
     */
    public function delete_shareholder()
    {
        $result = array(
            'status' => 0,
            'message' => '更新成功.',
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');

        if (empty($organization_id) || empty($id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $shareholder_data = mod_shareholder::instance()->get_one_data(array('id' => $id, 'organization_id'=> $organization_id, 'delete_user' => 0), '`id`');
        if (empty($shareholder_data)) {
            $result['status'] = '2';
            $result['message'] = '股东数据不存在, 不能操作!';
            echo json_encode($result);
            exit();
        }

        $data['delete_user'] = cls_auth::$user->fields['admin_id'];
        $data['delete_time'] = time();

        $condition = array(
            'id' => $id,
            'organization_id' => $organization_id
        );
        $res = mod_shareholder::instance()->update_data($data, $condition);
        if ($res === false) {
            $result['status'] = '3';
            $result['message'] = '更改失败.';
        }

        echo json_encode($result);
    }

    /**
     * 删除部门操作.
     */
    public function delete_department()
    {
        $result = array(
            'status' => 0,
            'message' => '更新成功.',
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');

        if (empty($organization_id) || empty($id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $department_data = mod_department::instance()->get_one_data(array('id' => $id, 'organization_id' => $organization_id, 'delete_user' => 0), '`id`, `type`');
        if (empty($department_data)) {
            $result['status'] = '2';
            $result['message'] = '部门数据不存在, 不能操作!';
            echo json_encode($result);
            exit();
        }

        if ($department_data['type'] == 1) {
            $result['status'] = '3';
            $result['message'] = '权力部门不能被删除!';
            echo json_encode($result);
            exit();
        }

        // 查看是该部门下否有岗位
        $station = mod_station::instance()->get_one_data(array('department_id' => $id, 'delete_user' => 0), 'id');
        if (!empty($station)) {
            $result['status'] = '4';
            $result['message'] = '部门下面有岗位数据, 不能删除该部门数据';
            echo json_encode($result);
            exit();
        }
        // 查看是否有员工直属该部门.
        $staff = mod_station_list::instance()->get_one_data(array('department_id' => $id, 'member_id >' => 0), 'id');
        if (!empty($staff)) {
            $result['status'] = '5';
            $result['message'] = '有员工直属该部门, 不能删除该部门数据.';
            echo json_encode($result);
            exit();
        }

        // 查看该部门是否是其他部门的直属上级部门.
        $department = mod_department::instance()->get_one_data(array('superior_id' => $id, 'delete_user' => 0), 'id');
        if (!empty($department)) {
            $result['status'] = '6';
            $result['message'] = '该部门为其他部门的直属上级部门, 不能删除该部门数据.';
            echo json_encode($result);
            exit();
        }

        $data['delete_user'] = cls_auth::$user->fields['admin_id'];
        $data['delete_time'] = time();
        $res = mod_department::instance()->update_data($data, array('id' => $id, 'organization_id' => $organization_id));
        if ($res === false) {
            $result['status'] = '7';
            $result['message'] = '更改失败.';
        }

        echo json_encode($result);
    }

    /**
     * 恢复部门.
     */
    public function recover_department()
    {
        $result = array(
            'status' => 0,
            'message' => '恢复成功.',
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');

        if (empty($organization_id) || empty($id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $data['delete_user'] = 0;
        $data['delete_time'] = 0;
        $res = mod_department::instance()->update_data($data, array('id' => $id, 'organization_id' => $organization_id));
        if ($res === false) {
            $result['status'] = '2';
            $result['message'] = '恢复失败.';
        }

        echo json_encode($result);
    }

    /**
     * 添加或编辑部门.
     */
    public function add_edit_department()
    {
        // 选择的所属机构参数.
        $organization_id = req::item('organization_id', 0, 'int');
        // 从添加部门按钮带过来的机构参数.
        $href_organization_id = req::item('href_organization_id', 0, 'int');
        $id = req::item('id', 0, 'int');
        $do = req::item('do', 0, 'int');
        $type = req::item('type', '', 'string');
        $organization_id = empty($organization_id) ? $href_organization_id : $organization_id;

        // 修改.
        if ($do) {
            if (empty($id)) {
                cls_msgbox::show('系统提示', '参数错误！', '-1');
                exit();
            }
            // 修改操作.
            $result = mod_department::instance()->get_one_data(array('id' => $id, 'organization_id' => $organization_id));
            if (empty($result)) {
                cls_msgbox::show('系统提示', '部门数据不存在！', '-1');
                exit();
            }
            if (!empty($result['delete_user'])) {
                cls_msgbox::show('系统提示', '已删除的部门不能被编辑！', '-1');
                exit();
            }

            $result['business_tag']  = explode(',', $result['business_tag']);
            $result['external_name'] = json_decode($result['external_name'], true);
        }
        if (!empty(req::$posts))
        {
            $data = array();
            $time = time();
            $name = req::item('name', '', 'string');
            // 部门名重复性检查.
            $tmp = mod_department::instance()->get_one_data(array('name' => $name), 'id');
            $res = ($do && (isset($tmp['id']) && $tmp['id'] != $id)) ? true : ((!$do && !empty($tmp)) ? true : false);
            if ($res) {
                cls_msgbox::show('系统提示', '部门名已存在', '-1');
                exit();
            }

            $superior_id = req::item('superior_id', '', 'string');
            $department_type = req::item('department_type', 0, 'int');
            $superior_id_arr = explode('_', $superior_id);
            $superior_idd = array_pop($superior_id_arr);
            if (in_array('department', $superior_id_arr)) {
                $data['superior_department_type'] = 1;
                $data['superior_id'] = $superior_idd;
            } elseif(in_array('station', $superior_id_arr)) {
                $data['superior_department_type'] = 2;
                $data['superior_id'] = $superior_idd;
            }
            $department_business_leader = req::item('department_business_leader', '{}', 'string');
            $department_business_link = req::item('department_business_link', '{}', 'string');
            $department_belong_id = req::item('department_belong_id', '');
            $department_business_leader = json_decode($department_business_leader, true);
            $department_business_link = json_decode($department_business_link, true);
            // 添加或编辑部门没有选择所属机构，所属机构为默认点击编辑或添加带过来带机构id.
            $department_business_tag = req::item('department_business_tag', array());
            $department_business_tag = array_unique($department_business_tag);
            $data['organization_id'] = !empty($organization_id) ? $organization_id : (!empty($href_organization_id) ? $href_organization_id : 0);
            $data['level_id'] = req::item('level', 0, 'int');
            $data['highest_station'] = req::item('highest_station', 0, 'int');
            $data['secret_degree'] = req::item('secret_degree', 0, 'int');
            if (!empty($department_type)) {
                $data['type'] = $department_type;
            }
            $data['name'] = $name;
            $data['short_name'] = req::item('short_name', '', 'string');
            $data['number'] = $this->get_department_number();
            $data['code'] = req::item('code', '', 'string');
            $data['business_tag'] = implode(',', $department_business_tag);
            if (empty($department_business_leader)) {
                $department_business_leader = array();
            }
            if (empty($department_business_link)) {
                $department_business_link = array();
            }
            $data['business_leader'] = json_encode($department_business_leader, JSON_UNESCAPED_UNICODE);
            $data['business_link'] = json_encode($department_business_link, JSON_UNESCAPED_UNICODE);

            if (!empty($department_belong_id)) {
                $department_belong_id_arr = explode('_', $department_belong_id);
                $data['belong_id'] = array_pop($department_belong_id_arr);
                if (in_array('department', $department_belong_id_arr)) {
                    $data['belong_type'] = 1;
                } elseif(in_array('station', $department_belong_id_arr)) {
                    $data['belong_type'] = 2;
                }
            }
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = $time;
            // 部门对外名称.
            $external_name = req::item('external_name', array());
            $external_name = array_filter($external_name);
            if (!empty($external_name)) {
                $data['external_name'] = json_encode($external_name, JSON_UNESCAPED_UNICODE);
            }
            // 组织等级.
            if (!empty($data['level_id'])) {
                $level_data = mod_organize_level::instance()->get_one_data(array('id' => $data['level_id']), '`id`, `level`');
                $data['level'] = $level_data['level'];
            }

            // 验证.
            // 是否展示权力部门.
            $count = mod_department::instance()->count(array('organization_id' => $organization_id, 'type' => 1));
            if (!empty($count) && isset($data['type']) && $data['type'] == '1') {
                cls_msgbox::show('系统提示', '该机构已存在权力部门, 不能再创建权力部门!', '-1');
                exit();
            }
            // 权力部门可以没有上级,其他部门必须要.
            if (isset($data['type']) && $data['type'] != '1' && empty($data['superior_id'])) {
                cls_msgbox::show('系统提示', '必须选择级部门或独立岗位!', '-1');
                exit();
            }

            if (empty($result)) {
                // 添加
                $gourl = req::item('gourl', '?ct=organization_company&ac=department&organization_id='.$data['organization_id']);
                $data['create_user'] = cls_auth::$user->fields['admin_id'];
                $data['create_time'] = $time;
                $insert_id = mod_department::instance()->insert_data($data);
                if (empty($insert_id)) {
                    cls_msgbox::show('系统提示', "添加失败", -1);
                    exit();
                }
            } else {
                // 修改.
                $gourl = req::item('gourl', '?ct=organization_company&ac=department_detail&id='.$id.'&type='.$type);
                $result = mod_department::instance()->update_data($data, array('id' => $id));
                if ($result === false) {
                    cls_msgbox::show('系统提示', "修改失败", -1);
                    exit();
                }
            }

            if ($do) {
                cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户修改部门 {$id}");
                cls_msgbox::show('系统提示', "修改成功", $gourl);
            } else {
                // 点击部门岗位管理-创建部门.
                if (!empty($type)) {
                    // 返回到创建操作动作页面.
                    $gourl = '?ct=organization_company&ac=add_edit_department&type=all';
                }
                cls_auth::save_admin_log(cls_auth::$user->fields['username'], "用户部门 {$insert_id}");
                cls_msgbox::show('系统提示', "添加成功", $gourl);
            }
        }
        else
        {
            $is_top = 0;
            $superiors = array();
            $belongs = array();
            $level_options = mod_organize_level::instance()->get_level_options();;
            // 部门类型.
            $department_type = mod_base_type::get_depart();
            if (empty($department_type[1])) {
                cls_msgbox::show('系统提示', '权力部门类型不存在, 请创建权力部门类型!', '-1');
                exit();
            }
            if (!empty($organization_id)) {
                // 机构数据.
                $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`,`superior`,`level`, `name`');
                if (empty($organizations)) {
                    cls_msgbox::show('系统提示', '机构不存在!', '-1');
                    exit();
                }

                // 是否展示权力部门.
                $count = mod_department::instance()->count(array('organization_id' => $organization_id));
                $is_top = 0;
                if (empty($count) || (isset($result) && $result['type'] == 1)) {
                    $is_top = 1;
                }
                // 判断是否权力机构, 第一个机构为权力机构，没有上级机构，后面的机构必须选择上级机构, 有上级机构的机构为普通机构.
                if ($is_top) {
                    $department_type = array(
                        '1' => $department_type[1],
                    );
                }

                // 判断是否权力机构, 第一个机构为权力机构，没有上级机构，后面的机构必须选择上级机构, 有上级机构的机构为普通机构.
                if (empty($is_top)) {
                    unset($department_type[1]);
                }

                // 上级部门或独立岗位.
                $res = $this->get_superior_data($organization_id, $id);
                if ($res['status'] != 0) {
                    cls_msgbox::show('系统提示', $res['message'], -1);
                    exit();
                }
                $superiors = $res['data']['superior'];

                // 行政上级数据.
                $res = $this->get_belong_data($organization_id, $id);
                if ($res['status'] != 0) {
                    cls_msgbox::show('系统提示', $res['message'], -1);
                    exit();
                }

                $level_options = mod_organize_level::instance()->get_top_department_level_by_org($organization_id);
                $belongs  = $res['data'];
                tpl::assign('organizations', $organizations);
            } else {
                // 添加部门的时候.
                $organizations_list = mod_organization::instance()->get_list_data(array('status' => 1, 'delete_user' => 0), '`id`, `name`');
                $organizations_list = array_column($organizations_list, 'name', 'id');
                tpl::assign('organizations_list', $organizations_list);
            }

            // 修改操作.
            if ($do) {
                if ($result['superior_department_type'] == '1') {
                    $result['superior_id'] = 'department_'.$result['superior_id'];

                } elseif($result['superior_department_type'] == '2') {
                    $result['superior_id'] = 'station_'.$result['superior_id'];
                }

                if ($result['belong_type'] == '1') {
                    $result['belong_id'] = 'department_'.$result['belong_id'];

                } elseif($result['belong_type'] == '2') {
                    $result['belong_id'] = 'station_'.$result['belong_id'];
                }

                //组织等级.
                $res = $this->get_organization_level($result['superior_id'], $result['belong_id'], $result['organization_id'], $is_top);
                if ($res['status'] == 0) {
                    $level_options = $res['data'];
                }

                tpl::assign('data', $result);
            } else {
                $number = $this->get_department_number();
                tpl::assign('number', $number);
            }

            if (empty($organization_id)) {
                $tags = $this->get_tag_options();
            } else {
                $tags = mod_operation_tag::instance()->get_tag_option_in_org($organization_id);
            }
            $secret_degree_options = mod_security_level::instance()->get_security_level_options();
            empty($do) ? ($title = "添加部门") : ($title = "编辑部门");

            tpl::assign('id', $id);
            tpl::assign('do', $do);
            tpl::assign('type', $type);
            tpl::assign( 'secret_degree_options', $secret_degree_options);
            tpl::assign('department_type', $department_type);
            tpl::assign('title', $title);
            tpl::assign('level_options', $level_options);
            tpl::assign('organization_id', $organization_id);
            tpl::assign('tags', $tags);
            tpl::assign('is_top', $is_top);
            tpl::assign('superiors', $superiors);
            tpl::assign('belongs', $belongs);
            tpl::display('organization_company.department.add.tpl');
        }

    }

    /**
     * 获取上级数据.
     */
    public function get_superior_data($organization_id = 0, $department_id = 0, $belong_id = 0, $superior_id = 0, $is_top = 0)
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'data' => array(
                'superior' => array(),
                'department_type' => array(),
                'org_level' => array(),
            ),
        );

        $id = req::item('id', 0, 'int');
        $department_belong_id = req::item('department_belong_id', '', 'string');
        $up_id = req::item('up_id', '', 'string');
        $is_top_dep = req::item('is_top_dep', 0, 'int');
        $ajax = req::item('ajax', '', 'string');

        $organization_id = empty($organization_id) ? $id : $organization_id;
        $department_belong_id = empty($department_belong_id) ? $belong_id : $department_belong_id;
        $up_id = empty($up_id) ? $superior_id : $up_id;
        $is_top_dep = empty($is_top_dep) ? $is_top : $is_top_dep;
        if (empty($organization_id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            return $result;
        }

        $organization = mod_organization::instance()->get_one_data(array('id' => $organization_id, 'status' => 1), '`id`, `superior`');
        if (empty($organization)) {
            $result['status'] = 2;
            $result['message'] = '机构数据不存在';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        $org_id_arr = array($organization_id, $organization['superior']);
        // 所属机构的部门数据.
        $department_data = mod_department::instance()->get_list_data(array('organization_id in' => $org_id_arr, 'delete_user' => 0, 'status' => 1), '`id` as department_id,`name`,`level`, `level_id`', '', '', 'level ASC');
        $level_id_arr = array_column($department_data, 'level_id');
        // 所属机构的独立岗位数据.
        $station_data = mod_station::instance()->get_list_data(array('organization_id in' => $org_id_arr, 'department_id' => 0, 'delete_user' => 0, 'status' => '1'), '`id` as station_id, `name`, `level`, `level_id`', '', '', 'level ASC');
        $level_id_arr = array_merge($level_id_arr, array_column($station_data, 'level_id'));

        if (!empty($level_id_arr)) {
            $level_id_arr = array_unique($level_id_arr);
            $level_data = mod_organize_level::instance()->get_list_data(array('id in' => $level_id_arr), '`id`, `level_short_name`', 'id');

            $data = array();
            foreach ($department_data as $key => $value) {
                // 排除本部门为上级部门.
                if (!empty($department_id) && $value['department_id'] == $department_id) {
                    continue;
                }
                $k = 'department_'.$value['department_id'];
                $v = '【部门】'.$level_data[$value['level_id']]['level_short_name'].'  '.$value['name'];
                $data[$k] = $v;
            }

            foreach ($station_data as $key => $value) {
                $k = 'station_'.$value['station_id'];
                $v = '【岗位】'.$level_data[$value['level_id']]['level_short_name'].'  '.$value['name'];
                $data[$k] = $v;
            }

            $result['data']['superior'] = $data;
        }

        // 前端ajax获取.
        if (!empty($ajax)) {
            // 获取部门类型.
            $count = mod_department::instance()->count(array('organization_id' => $organization_id));
            if (empty($count)) {
                $top_level_name = mod_base_type::get_depart(1);
                if (empty($top_level_name)) {
                    $result['status'] = 3;
                    $result['message'] = '权力部门类型不存在!';
                    if (!empty($ajax)) {
                        echo json_encode($result);
                        exit();
                    } else {
                        return $result;
                    }
                }

                $result['data']['department_type'] = array(
                    '1' => $top_level_name['name'],
                );
            } else {
                $level_data = mod_base_type::get_depart();
                // 干掉权力部门类型.
                unset($level_data['1']);
                unset($level_data[""]);
                $result['data']['department_type'] = $level_data;
            }

            // 组织等级.
            $res = $this->get_organization_level($up_id, $department_belong_id, $organization_id, $is_top_dep, 1);
            if ($res['status'] == 0) {
                $result['data']['org_level'] = $res['data'];
            }

            // 业务属性.
            $result['data']['tags'] = mod_operation_tag::instance()->get_tag_option_in_org($organization_id);
        }

        if (!empty($ajax)) {
            echo json_encode($result);
        } else {
            return $result;
        }
    }

    /**
     * 获取部门行政上级数据..
     */
    public function get_belong_data($organization_id = 0, $department_id = 0)
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'data' => array(),
        );

        $id = req::item('id', 0, 'int');
        $ajax = req::item('ajax', '', 'string');
        if (empty($organization_id) && empty($id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            return $result;
        }
        $organization_id = empty($organization_id) ? $id : $organization_id;

        $organization = mod_organization::instance()->get_one_data(array('id' => $organization_id, 'status' => 1), '`id`, `superior`');
        if (empty($organization)) {
            $result['status'] = 2;
            $result['message'] = '机构数据不存在';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        // 所属机构的部门数据.
        $department_data = mod_department::instance()->get_list_data(array('organization_id' => $organization_id, 'delete_user' => 0, 'status' => 1), '`id` as department_id,`name`,`level`, `level_id`', '', '', 'level ASC');
        $level_id_arr = array_column($department_data, 'level_id');
        // 所属机构的独立岗位数据.
        $station_data = mod_station::instance()->get_list_data(array('organization_id' => $organization_id, 'department_id' => 0, 'delete_user' => 0, 'status' => '1'), '`id` as station_id, `name`, `level`, `level_id`', '', '', 'level ASC');
        $level_id_arr = array_merge($level_id_arr, array_column($station_data, 'level_id'));

        if (!empty($level_id_arr)) {
            $level_id_arr = array_unique($level_id_arr);
            $level_data = mod_organize_level::instance()->get_list_data(array('id' => $level_id_arr), '`id`, `level_short_name`', 'id');

            $data = array();
            foreach ($department_data as $key => $value) {
                // 排除本部门.
                if (!empty($department_id) && $value['department_id'] == $department_id) {
                    continue;
                }
                $k = 'department_'.$value['department_id'];
                $v = '【部门】'.$level_data[$value['level_id']]['level_short_name'].'  '.$value['name'];
                $data[$k] = $v;
            }

            foreach ($station_data as $key => $value) {
                $k = 'station_'.$value['station_id'];
                $v = '【岗位】'.$level_data[$value['level_id']]['level_short_name'].'  '.$value['name'];
                $data[$k] = $v;
            }

            $result['data'] = $data;
        }

        if (!empty($ajax)) {
            echo json_encode($result);
        } else {
            return $result;
        }
    }

    /**
     * 获取业务领导数据.
     */
    public function get_business_leader_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'departments' => array(),
            'stations' => array(),
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $except_department_id = req::item('except_department_id', 0, 'int');
        $tags = req::item('tags', array());
        if (empty($organization_id) && empty($tags)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        // 本机构.
        $superiors = array($organization_id);
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `superior`');
        // 直属上级机构.
        $superior_id = $organizations['superior'];
        do {
            $tmp = mod_organization::instance()->get_one_data(array('id' => $superior_id), '`id`, `superior`');
            if (!empty($tmp)) {
                $superior_id = $tmp['superior'];
                $superiors[] = $tmp['id'];
            } else {
                $superior_id = 0;
            }

        } while($superior_id > 0);

        $superiors = array_filter($superiors);
        // 找部门.
        $departments = mod_department::instance()->get_list_data(array('organization_id in' => $superiors), '`id`, `name`, `business_tag`');
        if (!empty($departments)) {
            foreach ($departments as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    // 编辑的时候排除自己.
                    if (!empty($except_department_id) && $value['id'] == $except_department_id) {
                        continue;
                    }
                    $result['stations'][] = array(
                        'id' => $value['id'].'_department',
                        'name' => $value['name'],
                    );
                }
            }
        }

        // 找独立岗位.
        $stations = mod_station::instance()->get_list_data(array('organization_id in' => $superiors, 'department_id' => 0), '`id`, `name`, `business_tag`');
        if (!empty($stations)) {
            foreach ($stations as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    $result['stations'][] = array(
                        'id' => $value['id'].'_station',
                        'name' => $value['name'],
                    );
                }
            }
        }

        echo json_encode($result);
    }

    /**
     * 获取业务对接数据.
     */
    public function get_business_link_data()
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'departments' => array(),
            'stations' => array(),
        );

        $organization_id = req::item('organization_id', 0, 'int');
        $except_department_id = req::item('except_department_id', 0, 'int');
        $tags = req::item('tags', array());
        if (empty($organization_id) && empty($tags)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            echo json_encode($result);
            exit();
        }

        $superiors = array();
        $organizations = mod_organization::instance()->get_one_data(array('id' => $organization_id), '`id`, `superior`');
        // 直属上级机构.
        $superior_id = $organizations['superior'];
        do {
            $tmp = mod_organization::instance()->get_one_data(array('id' => $superior_id), '`id`, `superior`');
            if (!empty($tmp)) {
                $superior_id = $tmp['superior'];
                $superiors[] = $tmp['id'];
            } else {
                $superior_id = 0;
            }

        } while($superior_id > 0);

        // 找部门.
        $superiors  = array_unique($superiors);
        $departments = mod_department::instance()->get_list_data(array('organization_id in' => $superiors), '`id`, `name`, `business_tag`');
        if (!empty($departments)) {
            foreach ($departments as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    // 编辑的时候排除自己.
                    if (!empty($except_department_id) && $value['id'] == $except_department_id) {
                        continue;
                    }
                    $result['stations'][] = array(
                        'id' => $value['id'].'_department',
                        'name' => $value['name'],
                    );
                }
            }
        }

        // 找独立岗位.
        $stations = mod_station::instance()->get_list_data(array('organization_id in' => $superiors, 'department_id' => 0), '`id`, `name`, `business_tag`');
        if (!empty($stations)) {
            foreach ($stations as $key => $value) {
                $business_tag_arr = explode(',', $value['business_tag']);
                $inter = array_intersect($tags, $business_tag_arr);
                if (!empty($inter)) {
                    $result['stations'][] = array(
                        'id' => $value['id'].'_station',
                        'name' => $value['name'],
                    );
                }
            }
        }

        echo json_encode($result);
    }

    /**
     * ajax获取获取组织等级.
     */
    public function get_organization_level($superior_id = 0, $belong_id = 0, $organization_id = 0, $is_top_dep = 0, $is_return = 0)
    {
        $result = array(
            'status' => 0,
            'message' => '',
            'data' => array(),
        );

        $org_id = req::item('org_id', 0, 'int');
        $department_belong_id = req::item('department_belong_id', '', 'string');
        $up_id = req::item('idd', '', 'string');
        $is_top = req::item('is_top_dep', '', 'string');
        $ajax = req::item('ajax', '', 'string');

        $org_id = empty($org_id) ? $organization_id : $org_id;
        $department_belong_id = empty($department_belong_id) ? $belong_id : $department_belong_id;
        $up_id = empty($up_id) ? $superior_id : $up_id;
        $is_top = empty($is_top) ? $is_top_dep : $is_top;
        if (empty($org_id)) {
            $result['status'] = 1;
            $result['message'] = '参数错误';
            if (!empty($ajax)) {
                echo json_encode($result);
                exit();
            } else {
                return $result;
            }
        }

        // 是权力部门.
        if (!empty($is_top)) {
            $data = mod_organize_level::instance()->get_top_department_level_by_org($org_id);
        } else {
            $data = mod_organize_level::instance()->get_level_options();
        }

        // 非权力部门.
        if (empty($is_top) && empty($department_belong_id)) {
            $data = mod_organize_level::instance()->get_department_level_by_org($org_id);
        }

        // 行政归属.
        if (!empty($department_belong_id)) {
            $belong_data = mod_organize_level::instance()->get_department_level_by_belong($department_belong_id);
            $data = array_intersect_key($data, $belong_data);
        }

        // 上级部门或独立岗位.
        if (!empty($up_id)) {
            $superior_data = mod_organize_level::instance()->get_department_level_by_superior($up_id);
            $data = array_intersect_key($data, $superior_data);
        }

        $result['data'] = $data;

        // 内部调用，非ajax调用, 直接返回.
        if ($is_return) {
            return $result;
        }

        if (!empty($ajax)) {
            echo json_encode($result);
            exit();
        } else {
            return $result;
        }
    }

}
