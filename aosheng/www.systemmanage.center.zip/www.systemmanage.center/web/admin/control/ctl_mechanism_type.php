<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 机构类型设置
 *
 * @version $Id$
 */
class ctl_mechanism_type
{
    public function __construct()
    {
        $this->table = '#PB#_mechanism_type';
        $this->where = [
            ['delete_user', '=', '0'],
        ];
    }

    /**
    * @desc 列表页
     */
    public function index()
    {
        $keyword = req::item('keyword', '');

        $page_size = req::item('page_size', 20);
        $where = array(
            array('delete_user', '=', '0'),
            array('delete_time', '=', '0')
        );
        if(!empty($keyword))
        {
            $this->where[] = array('name', 'like', "%{$keyword}%");
        }

        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();

        $pages = pub_page::make($row['count'], $page_size);
        $list  = db::select("id,name,short_name,num,remark")->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('id','asc')->execute();
        if(!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $totel = db::select(' count(id) as org_num')->from("#PB#_organization")->where('type',$value['id'])->as_row()->execute();
                $list[$key]['org_num'] = $totel['org_num'];
            }
        }


        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('mechanism_type.index.tpl');
    }


    /**
     * @desc 添加
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            if (empty($data['name'])) cls_msgbox::show('系统提示', '请填写名称','-1');
            if (empty($data['short_name'])) cls_msgbox::show('系统提示', '请填简称','-1');
            if (!empty($data['num']) && !is_numeric($data['num'])) cls_msgbox::show('系统提示', '机构数量只能为数字','-1');
            $this->where[] = array('name', '=', $data['name']);
            $post_info  = db::select('id')->from($this->table)->where($this->where)->as_row()->execute();
            if(!empty($post_info))   cls_msgbox::show('系统提示', "名称已存在，请重新选择", '-1');

            $data['create_user'] = cls_auth::$user->fields['uid'];
            $data['create_time'] = time();

            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增机构类型 {$insert_id}");

            $gourl = req::item('gourl', '?ct=mechanism_type&ac=add');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else
        {
            $gourl = '?ct=mechanism_type&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('mechanism_type.add.tpl');
        }
    }


    /**
     * @desc 修改
     */
    public function edit()
    {
        $id = req::item('id', 0, 'int');
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            if (empty($data['id'])) cls_msgbox::show('系统提示', '请选择需要修改的数据','-1');
            if (empty($data['name'])) cls_msgbox::show('系统提示', '请填写名称','-1');
            if (empty($data['short_name'])) cls_msgbox::show('系统提示', '请填写简称','-1');
            $this->where[] = ['name', '=', $data['name']];
            $this->where[] = ['id','!=',$id];
            $post_info  = db::select('id')->from($this->table)->where($this->where)->as_row()->execute();
            if (!empty($post_info)) cls_msgbox::show('系统提示', "名称已存在", '-1');

            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();

            db::update($this->table)
                ->set($data)
                ->where('id', '=', $data['id'])
                ->execute();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了机构类型id为{$id}的数据");
            $gourl = req::item('gourl', "?ct=mechanism_type&ac=show&id={$id}");
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }else
        {
            $this->where[] = ['id','=',$id];
            $mec_type = db::select('id,name,short_name,num,remark')->from($this->table)->where($this->where)->as_row()->execute();
            $gourl = '?ct=mechanism_type&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::assign('mec_type', $mec_type);
            tpl::display('mechanism_type.edit.tpl');
        }
    }


    /**
     * @desc 查看机构等级
     */
    public function show()
    {
        $page_size = req::item('page_size',20);
        $id = req::item('id');

        $mechanism_info = db::select('id,name,short_name,num,remark')->from($this->table)->where('id',$id)->as_row()->execute();
        $this->where[] = ['type','=',$id];
        $row = db::select('Count(*) AS count')->from('#PB#_organization')->where($this->where)->as_row()->execute();
        $pages = pub_page::make($row['count'], $page_size);

        $list = db::select('id,name,number,status,superior,create_user,create_time,level_id')
            ->from('#PB#_organization')
            ->where('type','=',$id)
            ->and_where('delete_user','0')->and_where('delete_time','0')
            ->limit($pages['page_size'])
            ->offset($pages['offset'])
            ->execute();
        if(!empty($list))
        {
            foreach ($list as $key => $value)
            {
                $org_level = db::select('level_name')->from('#PB#_organize_level')->where('id',$value['level_id'])->as_row()->execute();
                $org = db::select('name')->from('#PB#_organization')->where('id',$value['superior'])->as_row()->execute();
                $list[$key]['level_name'] = !empty($org_level['level_name']) ? $org_level['level_name'] : null;
                $list[$key]['org_name'] = !empty($org['name']) ? $org['name'] : null;
                $list[$key]['create_user'] = mod_member::get_username($value['create_user']);
                $list[$key]['create_time'] = date('Y-m-d H:i:s',$value['create_time']);
            }
        }
        $arr = ['id','!=',$id];
        tpl::assign('type_all',$this->_type_all($arr));
        tpl::assign('list',$list);
        tpl::assign('num',$row['count']);

        tpl::assign('row',$mechanism_info);
        tpl::assign('pages', $pages['show']);
        tpl::display('mechanism_type.show.tpl');
    }


    /**
     * @desc 删除级别
     */
    public function del()
    {
        $id = req::item('id');
        $org_row = db::select('id')->from('#PB#_organization')->where('type',$id)->as_row()->execute();
        if(!empty($org_row))
        {
            echo "00001";exit;
        }
        $delete_arr = array(
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );
        db::update($this->table)
            ->set($delete_arr)
            ->where('id', '=', $id)
            ->execute();
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "机构类型".$id."被删除");
        cls_msgbox::show('系统提示', "删除成功", '?ct=mechanism_type&ac=index');exit;
        echo "00002";exit;
    }




    /**
     * 批量迁移
     **/

    public function move_more()
    {

        $old_type_id = req::item('old_type_id');  //需要迁移的等级id

        $type_id = req::item('id');  //新的等级id
        $old_type_row = db::select('id,name')->from($this->table)->where('id','=',$old_type_id)->as_row()->execute();
        $type_row = db::select('id,name,num')->from($this->table)->where('id','=',$type_id)->as_row()->execute();
        if(empty($old_type_row) || empty($type_row))
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }
        if($type_row['num'] > 0)
        {
            $this->where[] = ['type','in',[$old_type_id,$type_id]];
            $nums = db::select('type,Count(*) AS count')->from('#PB#_organization')->where($this->where)->group_by('type')->execute();
            if(empty($nums))
            {
                cls_msgbox::show('系统提示', "数据有误", '-1');
            }

            $num1 = $nums[0]['type'] == $old_type_id ? $nums[0]['count'] : (isset($nums[1]) ? $nums[1]['count'] : 0);
            $num2 = $nums[0]['type'] == $type_id ? $nums[0]['count'] : (isset($nums[1]) ? $nums[1]['count'] : 0);
            $num = $num1 + $num2;
            if($num > $type_row['num'])
            {
                cls_msgbox::show('系统提示', "超出最大机构数量，迁移失败", '-1');
            }

        }

        //迁移 数据
        $data['type'] = $type_id;
        db::update('#PB#_organization')
            ->set($data)
            ->where('type', $old_type_id)
            ->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "迁移了机构类型id".$old_type_id."下的机构类型数据");
        $gourl = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : "?ct=mechamism_type&ac=show&id={$old_type_id}";

        cls_msgbox::show('系统提示', "批量迁移成功", $gourl);

    }

    /**
     * 单个迁移
     **/
    public function move()
    {
        $org_id = req::item('org_id');  //需要迁移的id

        $id = req::item('id');  //需要迁移的id

        $type_id = req::item('type_id');  //新的等级id

        $type_row = db::select('id,num')->from($this->table)->where('id',$type_id)->as_row()->execute();

        if(empty($type_row) || !$org_id || !$type_id)
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }
        if($type_row['num'] > 0)
        {
            $this->where[] = ['type','=',$type_id];
            $nums = db::select('Count(*) AS count')->from('#PB#_organization')->where($this->where)->as_row()->execute();

            $num = !empty($nums) ? $nums['count'] : 0;
            $num = $num + 1;
            if($num > $type_row['num'])
            {
                cls_msgbox::show('系统提示', "超出最大机构数量，迁移失败", '-1');
            }
        }


        //迁移 部门数据
        $data['type'] = $type_row['id'];
        db::update('#PB#_organization')
            ->set($data)
            ->where('id', $id)
            ->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改机构id".$org_id."的机构类型");
        $gourl = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : "?ct=mechamism_type&ac=show&id={$id}";

        cls_msgbox::show('系统提示', "机构类型迁移成功", $gourl);
    }



    private function _type_all($arr)
    {
        $data = array();
        $where[] = array('delete_user','=','0');
        if(!empty($arr))
        {
            $where[] = $arr;
        }
        $arr = db::select('id,name')->from($this->table)->where($where)->execute();

        if($arr)
        {
            foreach($arr as $k=>$v)
            {
                $data[$v['id']] = $v['name'];
            }
        }
        return $data;
    }


}
