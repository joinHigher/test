<?php
if (!defined('PHPCALL')) exit('Request Error!');

/**
 * 出资方式配置管理
 *
 * @version $Id$
 */
class ctl_capital
{
    /**
     * 构造函数
     * @return void
     */
    public function __construct()
    {
        $this->even = req::item('even','capital');
        $this->table = '#PB#_capital';
        $this->baseUrl = '?ct=capital&ac=index';
        $this->level = array(0 => '请选择等级', '1' => '1级', '2' => '2级', '3' => '3级');
        tpl::assign('level', $this->level);
    }

    public function index()
    {
        $keyword = req::item('keyword', '');
        $page_size = req::item('page_size', 20);
        $even = req::item('even', 'add');
        $where = array();
        $where[] = "`isdeleted` = '0'";
        if (!empty($keyword)) {
            $where[] = "(`capital` Like '%{$keyword}%')";
        }
        $where = empty($where) ? '' : 'Where ' . implode(' And ', $where);
        $sql = "Select Count(*) AS count From `$this->table` {$where}";
        $row = db::get_one($sql);
        $pages = pub_page::make($row['count'], $page_size);
        $sql = "Select * From `$this->table` {$where} Order By `id` Asc Limit {$pages['offset']}, {$pages['page_size']}";
        $list = db::get_all($sql);
        tpl::assign('even', $this->even);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('capital.index.tpl');
    }

    /**
     * 增加级别
     */
    public function add()
    {

        if (!empty(req::$posts)) {
            $data = req::$posts;
            if (empty($data['capital'])) cls_msgbox::show('系统提示', '请填写出资方式名称');
            $row = db::get_one("select `capital` from `$this->table` where `capital`='{$data['capital']}' and `isdeleted`!='1' ");
            if (!empty($row)) {
                cls_msgbox::show('系统提示', '出资方式名称已存在，请换别的名称');
            }
            $data['create_user'] = cls_auth::$user->fields['admin_id'];
            $data['create_time'] = time();
            db::insert($this->table, $data);
            $insert_id = db::insert_id();
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "添加了出资方式为{$insert_id}的记录");
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }

    }

    /**
     * 编辑级别
     **/
    public function edit()
    {
        $id = req::item('id');
        if (!empty(req::$posts)) {
            $data = req::$posts;
            $capital = req::item('capital');
            $row = db::get_one("Select * From `$this->table` Where `capital`='{$capital}' And `id`!='{$id}'");
            if (!empty($row)) {
                cls_msgbox::show('系统提示', '出资方式名称已存在,请换别的名称！', '-1');
                exit();
            }
            $data['update_user'] = cls_auth::$user->fields['admin_id'];
            $data['update_time'] = time();
            db::update($this->table, $data, "`id`='{$id}'");
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了出资方式id为{$id}的数据");
            $gourl = req::item('gourl', $this->baseUrl);
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }

    }
    /**
     * 删除级别
     */
    public function del()
    {
        $id = req::item('id', 0);
        $delete_arr = array(
            'isdeleted'=>1,
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );
        db::update($this->table, $delete_arr, "`id` = '{$id}' ");
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "行政级别{$id}被删除");
        $gourl =$this->baseUrl;
        cls_msgbox::show('系统提示', "删除成功", $gourl);
    }

}
