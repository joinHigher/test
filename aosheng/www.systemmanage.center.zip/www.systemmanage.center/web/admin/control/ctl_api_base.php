<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * Created by PhpStorm.
 * User: nengliu
 * Date: 2018/3/31
 * Time: 下午7:47
 */
class ctl_api_base
{
}