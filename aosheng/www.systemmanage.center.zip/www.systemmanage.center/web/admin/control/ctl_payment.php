<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 内容管理
 *
 * @version $Id$
 */
class ctl_payment
{
    public $page_size = 10;
    public $tab_job = '#PB#_station',
        $tab_payment_job = '#PB#_payment_job',
        $tab_xing = '#PB#_admin_level',//行政等级;
        $tab_payment_xing = '#PB#_payment_xing',
        $tab_zu = '#PB#_organize_level',//组织等级
        $tab_payment_level = '#PB#_payment_level',
        $tab_payment_zu = '#PB#_payment_org';

    /**
     * 构造函数
     * @return void
     */
    public function __construct(){}

    //岗位薪酬列表
    public function job_list()
    {
        $search = req::item('search', '');

        $where = [
            ['delete_user','=',0]
        ];
        if (!empty($search))
        {
            $where[] = ["name", 'like', "%{$search}%"];
        }

        $count = db::select('count(*)')->from($this->tab_job)->where($where)->as_field()->execute();
        $pages = pub_page::make($count, $this->page_size);
        $fields = 'id,name,level_id,business_tag,create_user,create_time';
        $rows = db::select($fields)->from($this->tab_job)->where($where)->limit($pages['page_size'])->offset($pages['offset'])->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                //组织等级
                $row['level_name'] = db::select('level_short_name')->from($this->tab_zu)->where('id','=',$row['level_id'])->as_field()->execute();
                //创建人
                $row['creator'] = mod_payment::get_creator($row['create_user']);

                //薪酬范围
                $payment_range = mod_payment::count_range($row['business_tag']);
                $row['payment_range'] = !empty($payment_range) ? "{$payment_range[0]}-{$payment_range[1]}" : '基础薪酬未设置';
            }
        }


        tpl::assign('rows', $rows);
        tpl::assign('pages', $pages['show']);
        tpl::display('payment.'.__FUNCTION__.'.tpl');
    }

    //岗位薪酬详情
    public function job_detail()
    {
        $id = req::get('id',0,'int');
        $fields = 'id,name,level_id,organization_id,department_id,superior,business_tag,number,create_user,create_time';
        $row = db::select($fields)->from($this->tab_job)->where('id','=',$id)->as_row()->execute();
        if(empty($row)){
            mod_common::exit_page_404();
        }

        //组织等级
        $row['level_name'] = db::select('level_short_name')->from($this->tab_zu)->where('id','=',$row['level_id'])->as_field()->execute();

        $row['organ_name'] = db::select('name')->from('#PB#_organization')->where('id','=',$row['organization_id'])->as_field()->execute();

        $row['department'] = db::select('name')->from('#PB#_department')->where('id','=',$row['department_id'])->as_field()->execute();

        $row['add_pay'] = db::select('add_pay')->from('#PB#_payment_job')->where('job_id','=',$row['id'])->as_field()->execute();
        !empty($row['add_pay']) && $row['add_pay'] = number_format($row['add_pay'],2);
        //上级岗位
        $row['super'] = db::select('name')->from($this->tab_job)->where('id','=',$row['superior'])->as_field()->execute();

        //业务属性
        $row['yuewu'] = '';
        if($row['business_tag'])
        {
            $business_ids = explode(',',$row['business_tag']);
            $rows_yuewu = db::select('id,tag_name')->from(mod_table::yuewu)->where('id','in',$business_ids)->execute();
            if($rows_yuewu)
            {
                $one_array = mod_array::one_array($rows_yuewu, ['id', 'tag_name']);
                $row['yuewu'] = implode(' ', $one_array);
            }
        }

        $levels = mod_payment::payment_levels($row['business_tag']);
        $post_levels = mod_payment::post_levels();

        tpl::assign('post_levels',$post_levels);
        tpl::assign('levels',$levels);


        $add_type = ( isset($row_payment['add_pay']) && $row_payment['add_pay']<0 ? '减薪' : '加薪' );
        tpl::assign('add_type',$add_type);
        tpl::assign('edit_url',"?ct=payment&ac=job_edit&id=$id");
        tpl::assign('row',$row);
        tpl::display('payment.'.__FUNCTION__.'.tpl');
    }

    //岗位薪酬修改
    public function job_edit()
    {
        if (!empty(req::$posts)) {
            $id = req::post('id', 0, 'int');

            db::begin_tran();

            $row_payment = db::select('id')->from($this->tab_payment_job)->where('job_id','=',$id)->as_row()->execute();
            if (empty($row_payment))//创建
            {
                $data = [
                    'job_id' => $id,
                    'add_pay' => req::post('add_pay') * req::post('add_type'),
                    'create_user' => cls_auth::$user->fields['uid'],
                    'create_time' => time()
                ];

                db::insert($this->tab_payment_job)->set($data)->execute();
            } else//修改
            {
                $data = [
                    'add_pay' => req::post('add_pay') * req::post('add_type'),
                    'update_user' => cls_auth::$user->fields['uid'],
                    'update_time' => time()
                ];

                db::update($this->tab_payment_job)->set($data)->where("job_id",'=',$id)->execute();
            }

            //更新薪酬
            $cell_intos = isset(req::$posts['cell_into']) ? req::$posts['cell_into'] : [];
            $cells = isset(req::$posts['cell']) ? req::$posts['cell'] : [];

            if ($cell_intos)
            {
                $cell_into_data = [];
                foreach ($cell_intos as $cell_into_yuewu_id => $cell_into) {
                    foreach ($cell_into as $cell_into_level => $cell_into_child) {
                        $cell_into_child['yuewu_id'] = $cell_into_yuewu_id;
                        $cell_into_child['level'] = $cell_into_level;
                        $cell_into_child['create_user'] = cls_auth::$user->fields['uid'];
                        $cell_into_child['create_time'] = time();
                        $cell_into_data[] = $cell_into_child;
                    }
                }
                $columns = array_keys(current($cell_into_data));
                db::insert(mod_table::payment_level)->columns($columns)->values($cell_into_data)->execute();
            }

            if($cells)
            {
                foreach ($cells as $cell_id=>&$cell)
                {
                    $cell['id'] = $cell_id;
                    $cell['update_user'] = cls_auth::$user->fields['uid'];
                    $cell['update_time'] = time();
                    db::update(mod_table::payment_level)->set($cell)->where('id','=',$cell_id)->execute();
                }
            }

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改岗位薪酬 ID={$id}");

            db::commit();

            $gourl = req::item('gourl', '?ct=payment&ac=job_list');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else 
        {
            $gourl = '?ct=content&ac=index';
            tpl::assign('go_url', $gourl);
            $id = req::get('id',0,'int');

            $fields = 'id,name,level_id,organization_id,department_id,superior,business_tag,number,create_user,create_time';
            $row = db::select($fields)->from($this->tab_job)->where('id','=',$id)->as_row()->execute();
            if(empty($row))
            {
                mod_common::exit_page_404();
            }

            //组织等级
            $row['level_name'] = db::select('level_short_name')->from($this->tab_zu)->where('id','=',$row['level_id'])->as_field()->execute();
            //$row['level_name'] = ( $row_level ? $row_level['level_name'] : "");

            $row_organ = db::select('name')->from('#PB#_organization')->where('id','=',$row['organization_id'])->as_row()->execute();
            $row['organ_name'] = $row_organ['name'];

            $row_department = db::select('name')->from('#PB#_department')->where('id','=',$row['department_id'])->as_row()->execute();
            $row['department'] = $row_department['name'];

            $row_payment = db::select('add_pay')->from('#PB#_payment_job')->where('job_id','=',$row['id'])->as_row()->execute();
            $row['add_pay'] = $row_payment['add_pay'];

            $add_type = ( !empty($row['add_pay']) && $row['add_pay']<0 ? -1 : 1 );
            $row['add_pay'] = $add_type * $row['add_pay'];

            $levels = mod_payment::payment_levels($row['business_tag']);
            $post_levels = mod_payment::post_levels();

            //上级岗位
            $row_super = db::select('name')->from($this->tab_job)->where('id','=',$row['superior'])->as_row()->execute();
            $row['super'] = $row_super['name'];

            //业务属性
            $row['yuewu'] = '';
            if($row['business_tag'])
            {
                $business_ids = explode(',',$row['business_tag']);
                $rows_yuewu = db::select('id,tag_name')->from(mod_table::yuewu)->where('id','in',$business_ids)->execute();
                if($rows_yuewu)
                {
                    $one_array = mod_array::one_array($rows_yuewu, ['id', 'tag_name']);
                    $row['yuewu'] = implode(' ', $one_array);
                }
            }

            tpl::assign('post_levels',$post_levels);
            tpl::assign('levels',$levels);

            tpl::assign('levels',$levels);
            tpl::assign( 'add_type', $add_type );
            tpl::assign('row',$row);
            tpl::display('payment.'.__FUNCTION__.'.tpl');
        }
    }

    //行政薪酬列表
    public function xing_list()
    {
        $search = req::item('search', '');

        $where = [
            ['delete_user','=',0]
        ];
        if (!empty($search))
        {
            $where[] = ["level_short_name", 'like', "%{$search}%"];
        }

        $count = db::select('count(*)')->from($this->tab_xing)->where($where)->as_field()->execute();
        $pages = pub_page::make($count, $this->page_size);
        $fields = 'id,level,level_name,level_short_name,create_user,create_time';
        $rows = db::select($fields)->from($this->tab_xing)->where($where)->order_by('level','asc')->limit($pages['page_size'])->offset($pages['offset'])->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                //行政等级薪酬
                $row['payment_display'] = "";
                $payment_obj = db::select('id,set_type,payment,percent')->from($this->tab_payment_xing)->where('xing_id','=',$row['id'])->as_row()->execute();
                if($payment_obj)
                {
                    $row['payment_display'] .= "按" . ($payment_obj['set_type']==0 ? '固定值' : '比例') . "设置，";
                    $row['payment_display'] .= "行政薪酬" . ($payment_obj['set_type']==0 ? "：¥{$payment_obj['payment']}" : "=岗位薪酬 * {$payment_obj['percent']}%");
                }
                $row['payment_obj'] = $payment_obj;

                //创建人
                $row['creator'] = mod_payment::get_creator($row['create_user']);
            }
        }


        tpl::assign('rows', $rows);
        tpl::assign('pages', $pages['show']);
        tpl::display('payment.'.__FUNCTION__.'.tpl');
    }

    //行政薪酬修改
    public function xing_edit()
    {
        if (!empty(req::$posts))
        {
            $id = req::post('id',0,'int');

            $row_payment = db::select('id')->from($this->tab_payment_xing)->where('xing_id','=',$id)->as_row()->execute();
            if(empty($row_payment))//创建
            {
                $data = [
                    'xing_id' => $id,
                    'set_type' => req::post('set_type'),
                    'payment' => number_format(req::post('payment'), 2),
                    'percent' => req::post('percent',0,'int'),
                    'create_user' => cls_auth::$user->fields['uid'],
                    'create_time' => time()
                ];
                db::insert($this->tab_payment_xing)->set($data)->execute();

            }else//修改
            {
                $data = [
                    'set_type' => req::post('set_type'),
                    'payment' => number_format(req::post('payment'), 2),
                    'percent' => req::post('percent',0,'int'),
                    'update_user' => cls_auth::$user->fields['uid'],
                    'update_time' => time()
                ];
                db::update($this->tab_payment_xing)->set($data)->where("xing_id",'=',$id)->execute();
            }
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改行政薪酬 ID={$id}");

            $gourl = req::item('gourl', '?ct=payment&ac=xing_list');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }

    }

    //基础薪酬
    public function zu_list()
    {
        $search = req::item('search', '');

        $where = [
            ['delete_user','=',0]
        ];
        if (!empty($search))
        {
            $where[] = ["level_short_name", 'like', "%{$search}%"];
        }


        $count = db::select('count(*)')->from($this->tab_zu)->where($where)->as_field()->execute();
        $pages = pub_page::make($count, $this->page_size);
        $fields = 'id,level,level_name,level_short_name,create_user,create_time';
        $rows = db::select($fields)->from($this->tab_zu)->where($where)->order_by('level','asc')->limit($pages['page_size'])->offset($pages['offset'])->execute();
        if($rows)
        {
            foreach ($rows as &$row)
            {
                //薪酬范围
                $business_ids = db::select('business_tag')->from(mod_table::job)->where('level_id','=',$row['id'])->execute();
                empty($business_ids) && $business_ids = [];
                $business_ids = array_filter( mod_array::one_array($business_ids,[0,'business_tag']) );
                $business_ids = implode(',',$business_ids);
                $payment_range = mod_payment::count_range($business_ids);
                $row['payment_range'] = !empty($payment_range) ? "{$payment_range[0]}-{$payment_range[1]}" : '基础薪酬未设置';

                //创建人
                $row['creator'] = mod_payment::get_creator($row['create_user']);
            }
        }

        tpl::assign('rows', $rows);
        tpl::assign('pages', $pages['show']);
        tpl::display('payment.'.__FUNCTION__.'.tpl');
    }

    public function zu_detail()
    {
        $id = req::get('id',0,'int');

        $fields = 'id,level,level_name,level_short_name,create_user,create_time';
        $row = db::select($fields)->from($this->tab_zu)->where('id','=',$id)->as_row()->execute();
        if(empty($row))
        {
            mod_common::exit_page_404();
        }

        //取得组织下对应的业务属性
        $bus_where = [
            ['level_id','=',$row['id']],
            ['business_tag','>',0]
        ];

        $levels = [];
        $business_ids = db::select('business_tag')->from($this->tab_job)->where($bus_where)->execute();
        if($business_ids)
        {
            $business_ids = mod_array::one_array($business_ids,[0,'business_tag']);
            $business_ids = implode(',',$business_ids);
            $levels = mod_payment::payment_levels($business_ids);
        }

        $post_levels = mod_payment::post_levels();

        tpl::assign('post_levels',$post_levels);
        tpl::assign('levels',$levels);

        tpl::assign('edit_url',"?ct=payment&ac=zu_edit&id=$id");
        tpl::assign('row',$row);
        tpl::display('payment.'.__FUNCTION__.'.tpl');
    }

    //修改基础薪酬
    public function zu_edit()
    {
        if (!empty(req::$posts))
        {
            $id = req::post('id',0,'int');

            db::begin_tran();

            $row_payment = db::select('id')->from($this->tab_payment_zu)->where('org_id','=',$id)->as_row()->execute();
            if(empty($row_payment))//创建
            {
                $data = [
                    'org_id' => $id,
                    'create_user' => cls_auth::$user->fields['uid'],
                    'create_time' => time()
                ];

                db::insert(mod_table::payment_zu)->set($data)->execute();
            }else//修改
            {
                $data = [
                    'update_user' => cls_auth::$user->fields['uid'],
                    'update_time' => time()
                ];
                db::update(mod_table::payment_zu)->set($data)->where("org_id",'=',$id)->execute();
            }
            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改基础薪酬 ID={$id}");


            //更新薪酬
            $cell_intos = isset(req::$posts['cell_into']) ? req::$posts['cell_into'] : [];
            $cells = isset(req::$posts['cell']) ? req::$posts['cell'] : [];

            if ($cell_intos)
            {
                $cell_into_data = [];
                foreach ($cell_intos as $cell_into_yuewu_id => $cell_into) {
                    foreach ($cell_into as $cell_into_level => $cell_into_child) {
                        $cell_into_child['yuewu_id'] = $cell_into_yuewu_id;
                        $cell_into_child['level'] = $cell_into_level;
                        $cell_into_child['create_user'] = cls_auth::$user->fields['uid'];
                        $cell_into_child['create_time'] = time();
                        $cell_into_data[] = $cell_into_child;
                    }
                }

                $columns = array_keys(current($cell_into_data));
                db::insert(mod_table::payment_level)->columns($columns)->values($cell_into_data)->execute();
            }

            if($cells)
            {
                foreach ($cells as $cell_id=>&$cell)
                {
                    $cell['update_user'] = cls_auth::$user->fields['uid'];
                    $cell['update_time'] = time();

                    db::update(mod_table::payment_level)->set($cell)->where('id','=',$cell_id)->execute();
                }
            }

            db::commit();

            $gourl = req::item('gourl', '?ct=payment&ac=zu_list');
            cls_msgbox::show('系统提示', "修改成功", $gourl);
        }
        else
        {
            $id = req::get('id');
            $fields = 'id,level,level_name,level_short_name,create_user,create_time';
            $row = db::select($fields)->from($this->tab_zu)->where('id','=',$id)->as_row()->execute();
            if(empty($row))
            {
                mod_common::exit_page_404();
            }

            //取得组织下对应的业务属性
            $bus_where = [
                ['level_id','=',$row['id']],
                ['business_tag','>',0]
            ];
            $levels = [];
            $business_ids = db::select('business_tag')->from($this->tab_job)->where($bus_where)->execute();
            if($business_ids)
            {
                $business_ids = mod_array::one_array($business_ids,[0,'business_tag']);
                $business_ids = implode(',',$business_ids);
                $levels = mod_payment::payment_levels($business_ids);
            }
            $post_levels = mod_payment::post_levels();

            $gourl = '?ct=content&ac=index';
            tpl::assign('go_url', $gourl);
            tpl::assign('post_levels',$post_levels);
            tpl::assign('levels',$levels);
            tpl::assign('row',$row);
            tpl::display('payment.'.__FUNCTION__.'.tpl');
        }
    }

    //取得区域列表
    public function ajax_get_areas()
    {
        $parent_id = req::post('parent_id',0,'int');

        $areas = mod_area::get_api_name($parent_id);
        exit(json_encode($areas));
    }

    //取得所有机构
    public function ajax_get_organs()
    {
        $parent_id = req::post('parent_id',0,'int');
        $organ_tree = mod_payment::all_organs($parent_id);

        exit(json_encode($organ_tree));
    }
}
