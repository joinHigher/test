<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 *  组织等级管理
 *
 * @version $Id$
 */
class ctl_organize_level
{
    public function __construct()
    {
        $this->level = mod_organize_level::get_config_level('organize_level');
        $this->table = '#PB#_organize_level';
        $this->org_data = mod_organize_level::get_level();
        $this->where = [
            ['delete_user', '=', '0'],
            ['delete_time', '=', '0']
        ];

        tpl::assign('all_org_data',$this->org_data);
        tpl::assign('count_level', count($this->level));
        tpl::assign('level', $this->level);
    }

    /**
     * @desc 列表页
     * */
    public function index()
    {
        $keyword = req::item('keyword', '');
        $level_id = req::item('level_id', 0,'int');

        $page_size = req::item('page_size', 20);

        if(!empty($keyword))
        {
            //$where[] = "`title` Like '%{$title}%'";
            $this->where[] = array('level_name', 'like', "%{$keyword}%");
        }

        if (!empty($level_id))
        {
            $this->where[] = array('level', '=', $level_id);;
        }
        $row = db::select('count(*) AS `count`')->from($this->table)->where($this->where)->as_row()->execute();
        $pages = pub_page::make($row['count'], $page_size);
        $list  = db::select('id,level,level_deputy,level_name,level_short_name,h_org_level,h_post_level,l_post_level,l_org_level,h_mec_level,l_mec_level')->from($this->table)->where($this->where)->limit($pages['page_size'])->offset($pages['offset'])->order_by('id','asc')->execute();

        tpl::assign('level_id', $level_id);
        tpl::assign('list', $list);
        tpl::assign('pages', $pages['show']);
        tpl::display('organize_level.index.tpl');
    }


    /**
     * @desc 添加
     */
    public function add()
    {
        if (!empty(req::$posts))
        {
            $data = req::$posts;
            if (empty($data['level'])) cls_msgbox::show('系统提示', '请选择等级','-1');
            if (empty($data['level_name'])) cls_msgbox::show('系统提示', '请填写等级名称','-1');
            if (empty($data['h_org_level'])) cls_msgbox::show('系统提示', '请选择下级部门最高组织等级','-1');
            if (empty($data['l_org_level'])) cls_msgbox::show('系统提示', '请选择下级部门最低组织等级','-1');
            if (empty($data['h_post_level'])) cls_msgbox::show('系统提示', '请选择下级岗位最高组织等级','-1');
            if (empty($data['l_post_level'])) cls_msgbox::show('系统提示', '请选择下级岗位最低组织等级','-1');

            if($data['h_org_level'] > $data['l_org_level']) cls_msgbox::show('系统提示', '选择下级部门组织等级选择错误','-1');
            if($data['h_post_level'] > $data['l_post_level']) cls_msgbox::show('系统提示', '选择下级岗位等级选择错误','-1');
            $zheng_name = "正".$data['level'];
            if($data['level_name'] == "正".$data['level'])
            {
                $this->where[] = ['level','=',$data['level']];
                $this->where[] = ['level_name','=',$zheng_name];
                $org_info  = db::select('level')->from($this->table)->where($this->where)->as_row()->execute();
                if(!empty($org_info))
                {
                    cls_msgbox::show('系统提示', '添加失败，正级名称已存在，请确认','-1');
                }
            }

            $data['create_user'] = cls_auth::$user->fields['uid'];
            $data['create_time'] = time();
            list($insert_id, $rows_affected) = db::insert($this->table)->set($data)->execute();

            cls_auth::save_admin_log(cls_auth::$user->fields['username'], "新增组织等级 ID为{$insert_id}的数据");

            $gourl = req::item('gourl', '?ct=organize_level&ac=add');
            cls_msgbox::show('系统提示', "添加成功", $gourl);
        }
        else
        {
            $gourl = '?ct=organize_level&ac=index';
            tpl::assign('gourl', $gourl);
            tpl::display('organize_level.add.tpl');
        }
    }

    /**
     * @desc 查看组织等级
     */
    public function show()
    {
        $page_size = req::item('page_size',10);
        $id        = req::item('id');
        $type      =  req::item('type');
        $org_info  = db::select('id,level,level_deputy,level_name,level_short_name,h_org_level,h_post_level,l_post_level,l_org_level,h_mec_level,l_mec_level')->from($this->table)->where('id',$id)->as_row()->execute();

        $org_all   = db::select('id,level_short_name as level_name')->from($this->table)->where('id','!=',$id)->and_where($this->where)->execute();
        if($type == 'sta')
        {
            //等级下所有岗位
           //$where = "where sta.`level_id`='{$id}' and sta.`delete_user` = '0' and sta.`delete_time` = '0'";
            $row = db::select('Count(*) AS count')->from('#PB#_station')->where('level_id',$id)->and_where($this->where)->as_row()->execute();
            $pages = pub_page::make($row['count'], $page_size);


            /*$sql = "Select sta.*,orga.name as orga_name,org.level_name,ad.username,count(sta_l.station_id) as num
From `#PB#_station` as sta  
LEFT JOIN `#PB#_organization` as orga on orga.id=sta.organization_id 
 JOIN `#PB#_station_list`  as sta_l on sta_l.station_id = sta.id  
LEFT JOIN `{$this->table}`  as org on org.id = sta.level_id  
LEFT JOIN `#PB#_admin` as ad on ad.admin_id=sta.create_user  {$where} GROUP BY sta_l.station_id
            Order By sta.`id` Asc Limit {$pages['offset']}, {$pages['page_size']}";*/



            $list = db::select('`#PB#_station`.`name`,`#PB#_station`.`id`,#PB#_organize_level.level_name,`#PB#_station`.`create_time`,`#PB#_station`.`name`,`#PB#_station`.`status`,`#PB#_station`.`id`,`#PB#_station`.amount`,`#PB#_station`.number`,`#PB#_organization`.`name` as `orga_name`,#PB#_admin.username')
                ->from('#PB#_station')
                ->join('#PB#_organization','LEFT')
                ->on('`#PB#_organization`.`id`','=','`#PB#_station`.`organization_id` ')
                ->join('#PB#_organize_level','LEFT')
                ->on('#PB#_organize_level.id','=','#PB#_station.level_id')
                ->join('#PB#_admin','LEFT')
                ->on('#PB#_admin.admin_id','=','#PB#_station.create_user')
                ->where('#PB#_station.level_id','=',$id)
                ->and_where('#PB#_station.delete_user','0')->and_where('#PB#_station.delete_time','0')
                ->limit($pages['page_size'])
                ->offset($pages['offset'])
                ->execute();
           // print_r($list);exit;
            if(!empty($list))
            {
                foreach ($list as $key => $value)
                {
                    $sta_num = db::select('count(*) as num')->from('#PB#_station_list')->where('station_id',$value['id'])->group_by('station_id')->as_row()->execute();
                    $list[$key]['num'] = !empty($sta_num['num']) ? $sta_num['num'] : null;
                }
            }







            //$list = db::query($sql)->execute();
        }else if($type == "dep"){

            //所有部门等级数据
            //$where = "where de.`level_id`='{$id}' and  de.`delete_user` = '0' and de.`delete_time` = '0'";
            $row = db::select('Count(*) AS count')->from('#PB#_department')->where('level_id',$id)->and_where($this->where)->as_row()->execute();
            $pages = pub_page::make($row['count'], $page_size);

           /* $sql = "Select de.*,org.name as org_name,dep.name as dep_name,ad.username,org_l.level_name From `#PB#_department` as de
LEFT JOIN `#PB#_organization` as org on org.id=de.organization_id
LEFT JOIN `{$this->table}`  as org_l on org_l.id = de.level_id 
LEFT JOIN `#PB#_department` as dep on dep.id = de.superior_id 
LEFT JOIN `#PB#_admin` as ad on ad.admin_id=de.create_user 
                 {$where}  Order By  dep.`id` Asc Limit {$pages['offset']}, {$pages['page_size']}";
            $list = db::query($sql)->execute();*/




            $list = db::select("#PB#_department.name,#PB#_department.id,#PB#_organize_level.level_name,#PB#_department.superior_id,#PB#_department.create_time,#PB#_department.number,#PB#_department.status,#PB#_department.type,#PB#_organization.name as org_name,#PB#_admin.username")
                ->from('`#PB#_department`')
                ->join('`#PB#_organization`','LEFT')
                ->on('`#PB#_organization`.`id`','=','`#PB#_department`.`organization_id`')
                ->join('`#PB#_organize_level`','LEFT')
                ->on('`#PB#_organize_level`.id','=','`#PB#_department`.level_id')
               // ->join('`#PB#_department`','LEFT')
               // ->on('`#PB#_department`.id','=','`#PB#_department`.superior_id')
                ->join('`#PB#_admin`','LEFT')
                ->on('`#PB#_admin`.admin_id','=','`#PB#_department`.create_user')
                ->where('`#PB#_department`.level_id','=',$id)
                ->and_where('`#PB#_department`.delete_user','0')->and_where('#PB#_department.delete_time','0')
                ->limit($pages['page_size'])
                ->offset($pages['offset'])
                ->execute();

            if(!empty($list))
            {
                foreach ($list as $key => $value)
                {
                    if($value['superior_id'])
                    {
                        $sta_num = db::select('name')->from('#PB#_department')->where('id',$value['superior_id'])->as_row()->execute();
                        $list[$key]['dep_name'] = !empty($sta_num['name']) ? $sta_num['name'] : null;
                    }

                }
            }


        }else if($type == '' || $type == 'org')
        {
            //等级下所有机构
            //$where = "where org.`level_id`='{$id}' and  org.`delete_user` = '0' and org.`delete_time` = '0'";
            $row = db::select('Count(*) AS count')->from('#PB#_organization')->where('level_id',$id)->and_where($this->where)->as_row()->execute();
            $pages = pub_page::make($row['count'], $page_size);

            /*$sql = "Select org.*,orga.name as orga_name ,org_l.level_name as level_name,ad.username
From `#PB#_organization` as org 
LEFT JOIN `#PB#_organization` as orga on orga.id=org.superior 
LEFT JOIN `{$this->table}`  as org_l on org_l.id = org.level_id  
LEFT JOIN `#PB#_admin` as ad on ad.admin_id=org.create_user  {$where}
            Order By org.`id` Asc Limit {$pages['offset']}, {$pages['page_size']}";
            $list = db::query($sql)->execute();*/


            $list = db::select('#PB#_organization.name,#PB#_organization.id,#PB#_organization.superior,#PB#_organize_level.level_name,#PB#_organization.status,#PB#_organization.create_time,#PB#_organization.number,#PB#_admin.username')
                ->from('#PB#_organization')
                //->join('#PB#_organization','LEFT')
                //->on('orga.id','=','org.superior ')
                ->join('#PB#_organize_level','LEFT')
                ->on('#PB#_organize_level.id','=','#PB#_organization.level_id')
                ->join('`#PB#_admin`','LEFT')
                ->on('`#PB#_admin`.admin_id','=','`#PB#_organization`.create_user')
                ->where('#PB#_organization.level_id','=',$id)
                ->and_where('#PB#_organization.delete_user','0')->and_where('#PB#_organization.delete_time','0')
                ->limit($pages['page_size'])
                ->offset($pages['offset'])
                ->execute();

            if(!empty($list))
            {
                foreach ($list as $key => $value)
                {
                    if($value['superior'])
                    {
                        $sta_num = db::select('name')->from('#PB#_organization')->where('id',$value['superior'])->as_row()->execute();
                        $list[$key]['orga_name'] = !empty($sta_num['name']) ? $sta_num['name'] : null;
                    }

                }
            }


        }
        $level_new = mod_organize_level::get_config_level('organize_level',$org_info['level']);
        unset($level_new['']);
        tpl::assign('level_new',$level_new);
        tpl::assign('org_all',$org_all);
        tpl::assign('count_level_new', count($level_new));
        tpl::assign('list',$list);
        tpl::assign('type',$type);
        tpl::assign('row',$org_info);
        tpl::assign('pages', $pages['show']);
        tpl::display('organize_level.show.tpl');
    }


    /**
    * @desc 修改下级等级组织
     */
    public function edit_hl()
    {
        $data = req::$posts;
        $id = $data['id'];
        if (empty($data['h_org_level'])) cls_msgbox::show('系统提示', '请选择下级部门最高组织等级','-1');
        if (empty($data['h_mec_level'])) cls_msgbox::show('系统提示', '请选择下级机构最高组织等级','-1');
        if (empty($data['l_org_level'])) cls_msgbox::show('系统提示', '请选择下级部门最低组织等级','-1');
        if (empty($data['l_mec_level'])) cls_msgbox::show('系统提示', '请选择下级机构最低组织等级','-1');
        if (empty($data['h_post_level'])) cls_msgbox::show('系统提示', '请选择下级岗位最高组织等级','-1');
        if (empty($data['l_post_level'])) cls_msgbox::show('系统提示', '请选择下级岗位最低组织等级','-1');

        if($data['h_mec_level'] > $data['l_mec_level']) cls_msgbox::show('系统提示', '选择下级机构组织等级选择错误','-1');
        if($data['h_org_level'] > $data['l_org_level']) cls_msgbox::show('系统提示', '选择下级部门组织等级选择错误','-1');
        if($data['h_post_level'] > $data['l_post_level']) cls_msgbox::show('系统提示', '选择下级岗位等级选择错误','-1');
        $data['update_user'] = cls_auth::$user->fields['admin_id'];
        $data['update_time'] = time();
        db::update($this->table)
            ->set($data)
            ->where('id', '=', $data['id'])
            ->execute();
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "修改了组织等级管理id为{$id}的数据");
        $gourl = req::item('gourl', "?ct=organize_level&ac=show&id=".$id);
        cls_msgbox::show('系统提示', "修改成功", $gourl);
    }

    /**
     * @desc 删除级别
     */
    public function del()
    {
        $id = req::item('id');

        $mec_row = db::select('id')->from('#PB#_organization')->where('level_id',$id)->as_row()->execute();
        $org_row = db::select('id')->from('#PB#_department')->where('level_id',$id)->as_row()->execute();
        $sta_row = db::select('id')->from('#PB#_station')->where('level_id',$id)->as_row()->execute();
        if(!empty($org_row) || !empty($sta_row) || !empty($mec_row))
        {
            echo "00001";exit;
        }
        $delete_arr = array(
            'delete_user'=>cls_auth::$user->fields['admin_id'],
            'delete_time'=>time()
        );
        db::update($this->table)
            ->set($delete_arr)
            ->where('id', '=', $id)
            ->execute();
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "组织级别ID为".$id."被删除");
        echo "00002";exit;
    }


    /**
     * @desc 批量迁移
     **/

    public function move_more()
    {
        $old_level_id = req::item('old_level_id');  //需要迁移的等级id
        $level_id = req::item('level_id');  //新的等级id
        $old_level_row = db::select('level,id')->from($this->table)->where('id',$old_level_id)->as_row()->execute();
        $level_row = db::select('level,id')->from($this->table)->where('id',$level_id)->as_row()->execute();

        if(empty($old_level_row) || empty($level_row))
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }
        db::begin_tran();
        //迁移 部门数据
        $data['level_id'] = $level_row['id'];
        $data['level'] = $level_row['level'];
        $res = db::update('#PB#_department')
            ->set($data)
            ->where('level_id', $old_level_row['id'])
            ->execute();

        //迁移岗位数据
        $res_sta = db::update('#PB#_station')
            ->set($data)
            ->where('level_id', $old_level_row['id'])
            ->execute();
        //迁移机构数据
        $res_sta = db::update('#PB#_organization')
            ->set($data)
            ->where('level_id', $old_level_row['id'])
            ->execute();

        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "迁移了组织等级id".$old_level_id."下的组织与机构数据");

        $gourl = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : "?ct=organize_level&ac=show&id={$old_level_id}";
        if(!$res || !$res_sta || !$res_sta)
        {
            db::rollback();
            cls_msgbox::show('系统提示', "迁移失败", $gourl);
        }
        db::commit();
        cls_msgbox::show('系统提示', "迁移成功", $gourl);

    }

    /**
     * @desc 单个迁移
     **/
    public function move()
    {
        $id = req::item('id');  //需要迁移ID
        $level_id = req::item('level_id');  //新的等级id
        $org_id = req::item('org_id');
        $type = req::item('type');
        $level_row = db::select('level,id')->from($this->table)->where('id',$level_id)->as_row()->execute();

        if(empty($level_row))
        {
            cls_msgbox::show('系统提示', "数据有误", '-1');
        }
        $data['level_id'] = $level_row['id'];
        $data['level'] = $level_row['level'];
        if($type == "org")
        {
            $res = db::update('#PB#_organization')
                ->set($data)
                ->where('id', $id)
                ->execute();
        }else if($type == "dep")
        {
            $res = db::update('#PB#_department')
                ->set($data)
                ->where('id', $id)
                ->execute();
        }else
        {
            $res = db::update('#PB#_station')
                ->set($data)
                ->where('id', $id)
                ->execute();
        }
        //迁移
        cls_auth::save_admin_log(cls_auth::$user->fields['username'], "迁移组织等级下的数据 id".$id."");
        if($res)
        {
            $gourl = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : "?ct=organize_level&ac=show&id={$org_id}";
            cls_msgbox::show('系统提示', "迁移成功", $gourl);
        }
    }



}