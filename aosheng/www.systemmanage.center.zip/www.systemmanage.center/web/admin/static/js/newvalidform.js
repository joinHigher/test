$(function(){
    //楠岃瘉------------------------------------------start-------
    var checkoneFn = function(gets,obj,curform,regxp){    //澶氶€変竴鑷畾涔夋柟娉�
        /*鍙傛暟gets鏄幏鍙栧埌鐨勮〃鍗曞厓绱犲€硷紝
          obj涓哄綋鍓嶈〃鍗曞厓绱狅紝
          curform涓哄綋鍓嶉獙璇佺殑琛ㄥ崟锛�
          regxp涓哄唴缃殑涓€浜涙鍒欒〃杈惧紡鐨勫紩鐢ㄣ€�*/
        var flag = 0;
        var len = curform.find(".checkone").length;
        curform.find(".checkone").each(function(){
            if($(this).val().length == 0){
                flag++
            }
        })
        if(flag==len){
            return false;
        }else{
            $(".checkone").siblings("span").remove();
            $(".checkone").parent("div").removeClass("has-error").addClass("has-success");
            $(".checkone").parents(".form-group").find(".control-label").css("color","#1ab394");
            return true;

        }
    }
    //瀵嗙爜蹇呴』鍖呭惈澶у皬鍐欏瓧姣嶏紝鏁板瓧
    var passwordFn = function(gets,obj,curform,regxp){
        var lv = 0;var val = $(obj).val();
        if (val.match(/[A-Z]/g)) {
            lv++;
        }
        if (val.match(/[a-z]/g)) {
            lv++;
        }
        if (val.match(/[0-9]/g)) {
            lv++;
        }
        if (lv < 3) {
            return false;
        } else {
            return true;
        }
    }


    //韬唤璇�
    var IdCard =  function(gets,obj,curform,regxp){
        var reg = /^((\d{18})|([0-9x]{18})|([0-9X]{18}))$/;
        if(reg.test($(obj).val())){
            return true;
        }else {
            return false
        }
    }

    //鎶ょ収
    var passCard = function(gets,obj,curform,regxp){
        var reg = /^1[45][0-9]{7}|([P|p|S|s]\d{7})|([S|s|G|g]\d{8})|([Gg|Tt|Ss|Ll|Qq|Dd|Aa|Ff]\d{8})|([H|h|M|m]\d{8,10})$/;
        if(reg.test($(obj).val())){
            return true;
        }else{
            return false;
        }
    }

    //閾惰鍗″彿
    function luhmCheck(bankno){
        var lastNum=bankno.substr(bankno.length-1,1);//鍙栧嚭鏈€鍚庝竴浣嶏紙涓巐uhm杩涜姣旇緝锛�
        var first15Num=bankno.substr(0,bankno.length-1);//鍓�15鎴�18浣�
        var newArr=new Array();
        for(var i=first15Num.length-1;i>-1;i--){
            //鍓�15鎴�18浣嶅€掑簭瀛樿繘鏁扮粍
            newArr.push(first15Num.substr(i,1));

        }
        var arrJiShu=new Array();  //濂囨暟浣�*2鐨勭Н <9
        var arrJiShu2=new Array(); //濂囨暟浣�*2鐨勭Н >9

        var arrOuShu=new Array();  //鍋舵暟浣嶆暟缁�
        for(var j=0;j<newArr.length;j++){
            if((j+1)%2==1){
                if(parseInt(newArr[j])*2<9)
                    arrJiShu.push(parseInt(newArr[j])*2);
                else
                    arrJiShu2.push(parseInt(newArr[j])*2);
            } else //鍋舵暟浣�
                arrOuShu.push(newArr[j]);
        }
        var jishu_child1=new Array();//濂囨暟浣�*2 >9 鐨勫垎鍓蹭箣鍚庣殑鏁扮粍涓綅鏁�
        var jishu_child2=new Array();//濂囨暟浣�*2 >9 鐨勫垎鍓蹭箣鍚庣殑鏁扮粍鍗佷綅鏁�
        for(var h=0;h<arrJiShu2.length;h++){
            jishu_child1.push(parseInt(arrJiShu2[h])%10);
            jishu_child2.push(parseInt(arrJiShu2[h])/10);

        }
        var sumJiShu=0; //濂囨暟浣�*2 < 9 鐨勬暟缁勪箣鍜�
        var sumOuShu=0; //鍋舵暟浣嶆暟缁勪箣鍜�
        var sumJiShuChild1=0; //濂囨暟浣�*2 >9 鐨勫垎鍓蹭箣鍚庣殑鏁扮粍涓綅鏁颁箣鍜�
        var sumJiShuChild2=0; //濂囨暟浣�*2 >9 鐨勫垎鍓蹭箣鍚庣殑鏁扮粍鍗佷綅鏁颁箣鍜�
        var sumTotal=0;
        for(var m=0;m<arrJiShu.length;m++){

            sumJiShu=sumJiShu+parseInt(arrJiShu[m]);

        }
        for(var n=0;n<arrOuShu.length;n++){

            sumOuShu=sumOuShu+parseInt(arrOuShu[n]);
        }
        for(var p=0;p<jishu_child1.length;p++){
            sumJiShuChild1=sumJiShuChild1+parseInt(jishu_child1[p]);
            sumJiShuChild2=sumJiShuChild2+parseInt(jishu_child2[p]);
        }
        //璁＄畻鎬诲拰
        sumTotal=parseInt(sumJiShu)+parseInt(sumOuShu)+parseInt(sumJiShuChild1)+parseInt(sumJiShuChild2);

        //璁＄畻Luhm鍊�
        var k= parseInt(sumTotal)%10==0?10:parseInt(sumTotal)%10;
        var luhm= 10-k;

        if(lastNum==luhm){
            //$("#banknoInfo").html("Luhm楠岃瘉閫氳繃");
            return true;
        }
        else{
            //$("#banknoInfo").html("閾惰鍗″彿蹇呴』绗﹀悎Luhm鏍￠獙");
            return false;

        }

    }

    var cnbank = function(gets,obj,curform,regxp){
        var msg = "";
        var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
        if(gets!=""){
            if(strBin.indexOf(gets.substring(0, 2)) == -1 ){
                msg="閾惰鍗″彿寮€澶�6浣嶄笉绗﹀悎瑙勮寖";
                $(obj).attr("errmsg",msg);
                return false;
            }else{
                if(gets.length<16 || gets.length>19){
                    msg = "閾惰鍗″彿闀垮害蹇呴』鍦�16鍒�19涔嬮棿";
                    $(obj).attr("errmsg",msg);
                    return false;
                }else{
                    if(luhmCheck($(obj).val())){
                        return true;
                    }else{
                        msg = "璇疯緭鍏ユ纭殑閾惰鍗″彿";
                        $(obj).attr("errmsg",msg);
                        return false
                    }

                }
                return true;
            }
        }else{
            return false;
        }
    }

    //鍗曞浘涓婁紶
    var imgSingleFn = function(gets,obj,curform,regxp){
        var src = $(obj).closest("div").siblings(".add-img-wrap").find("img").attr("src");
        if(src=="static/img/addimage.png"){
            return false;
        }else{
            return true;
        }

    }

    //澶氬浘涓婁紶
    var imgMoreFn = function(gets,obj,curform,regxp){
        var len = $(obj).closest("div").siblings(".pro-wrap").find(".pre-img-wrap").length;
        if(len==0){
            return false;
        }else{
            return true;
        }
    }

    //澶氬浘涓婁紶
    var fileFn = function(gets,obj,curform,regxp){
        var len = $(obj).parents(".form-group").find(".item").length;
        if(len==0){
            return false;
        }else{
            return true;
        }
    }




    $(".form-horizontal").Validform({
        tiptype:function(msg,o,cssctl){
            if(o.type==3){
                var parent = $(o.obj).closest('.validform-wrap');
                parent.length == 0 && (parent = $(o.obj).parent('div'));
                parent.addClass("has-error");
                var str = '<span class="Validform_checktip Validform_wrong"><i class="fa fa-times-circle"></i> '+ msg+'</span>';
                parent.children(".Validform_checktip").remove();
                parent.append(str);
                $(o.obj).parents("div.form-group").find(".control-label").css("color","#ed5565");
            }else{
                $(o.obj).parents("div.form-group").find(".control-label").css("color","#1ab394");
                $(o.obj).closest("div").removeClass("has-error").addClass("has-success");
                if($(o.obj).attr("sucmsg")){
                    $(o.obj).closest("div").children(".Validform_checktip").addClass("Validform_right").html('<i class="fa fa-check-circle-o"></i> '+$(o.obj).attr("sucmsg"));
                }else{
                    $(o.obj).closest("div").children(".Validform_checktip").remove();
                }
            }
        },
        showAllError:true,
        datatype:{    //鑷畾涔夋柟娉�
            "password":passwordFn,
            "id":IdCard,
            "pp":passCard,
            "cnbank":cnbank,
            "checkone":checkoneFn,    //鑷畾涔夎皟鐢�
            "imgSingle":imgSingleFn,   //鍗曞浘涓婁紶
            "imgMore":imgMoreFn,       //澶氬浘涓婁紶
            "file":fileFn              //鏂囦欢涓婁紶
        }
    });
    //tipsmsg 灞炴€�
    $("form").find("[tipsmsg]").each(function(){
        var str = '<span class="Validform_checktip"><i class="fa fa-info-circle"></i> '+ $(this).attr('tipsmsg')+'</span>';
        $(this).closest("div").append(str);
    })

    //楠岃瘉------------------------------------------end-------
})