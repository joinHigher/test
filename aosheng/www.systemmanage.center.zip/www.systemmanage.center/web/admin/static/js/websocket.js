var heartbeat_timer = 0;
var last_health = -1;
// 配置建议
// health_timeout对应 swoole 的 heartbeat_idle_time
// check_interval对应 swoole 的 heartbeat_check_interval
// 建议 health_timeout 为 check_interval 的两倍多一点。
// 这个两倍是为了进行容错，允许丢一个包
// 而多一点是考虑到网络的延时。
// 你可以跟据实际的业务来调整这个容错率（允许丢几个包）。
// 连接最大的空闲时间 （如果最后一个心跳包的时间与当前时间之差超过这个值，则认为该连接失效）
var health_timeout = 30000;
// 定时检测在线列表的时间
var check_interval = 10000;

$(document).ready(function(){ 

    var token = "";
    var userid = $("#userid").val();
    var username = $("#username").val();
    var host = "127.0.0.1";
    var port = "9527";

    //var uuid = "";
    //// 删除cookie
    ////$.cookie('uuid', '', { expires: -1 });
    //uuid = $.cookie('uuid');
    //// 生成用户唯一标识
    //if (uuid == null || uuid == undefined || uuid == '') {
        //uuid = Math.uuid();
        //$.cookie('uuid', uuid);
    //}

    var path = "/json?token="+token+"&userid="+userid+"&username="+username+"&usertype=admin";
    var ws = ws_conn("ws://"+host+":"+port + path);
});

function keepalive( ws ) {
	var time = new Date();
	if ( last_health != -1 && ( time.getTime() - last_health > health_timeout ) ) {
        //此时即可以认为连接断开，可是设置重连或者关闭
        console.log("服务器没有响应.");
        //$("#keeplive_box").html( "服务器没有响应." ).css({"color":"red"});
        //ws.close();
	}
	else{
        console.log("连接正常.");
        //$("#keeplive_box").html( "连接正常" ).css({"color":"green"});
        if( ws.bufferedAmount == 0 ) {
            ws.send( '~H#C~' );
        }
	}
}

// websocket function
function ws_conn( to_url ) {

    to_url = to_url || "";
    if ( to_url == "" ) {
        return false;
    }

    clearInterval( heartbeat_timer );
    console.log("Connecting...");
    //$("#statustxt").html("Connecting...");
    var ws = new WebSocket( to_url );
    ws.onopen = function() {
        strJSON = JSON.stringify({Event:"onopen", Msg: "successful"})
        ws.send(strJSON);
        console.log("Open");


        //strJSON = JSON.stringify({Event:"IncrMessageCount", Msg: "successful"})
        //ws.send(strJSON);

        //$("#statustxt").html("connected.");	
        //$("#send_btn").attr("disabled", false);
        heartbeat_timer = setInterval( function(){keepalive(ws)}, check_interval );
    }

    ws.onerror = function() {
        clearInterval( heartbeat_timer );
        console.log("Error...");
        //$("#statustxt").html("error.");
        //$("#send_btn").attr("disabled", true);
        //$("#keeplive_box").html( "连接出错." ).css({"color":"red"});
    }

    ws.onclose = function() {
        clearInterval( heartbeat_timer );
        console.log("Close...");
        //$("#statustxt").html("closed.");
        //$("#send_btn").attr("disabled", true);
        //$("#keeplive_box").html( "连接已关闭." ).css({"color":"red"});
    }

    ws.onmessage = function(e) {

        // 收到服务端发过来的心跳包
        var time = new Date();
        if ( e.data == ( '~H#S~' ) ) {
            last_health = time.getTime();
            return;
        }

        console.log("Message...");

        obj = JSON.parse(e.data);
        console.log(obj);
        
        if (obj.Event == "SystemMessage") {
            $("body").notifyFn({
                title:obj.Msg,              //标题
                time:obj.Time,              //时间
                index:obj.Index,            //序号
                url:obj.Url,                //链接
                messageTitle:obj.Title,     //导航标题
                reload:true                 //是否要刷新页面
            });

            //$.gritter.add({
                //title: obj.Title,
                //text:  obj.Msg,
                //image: 'static/img/demo/envelope.png',
                //sticky: false
            //});		
        }
        else if (obj.Event == "IncrMessageCount") {
            //var message_count = $(".message_count").html();
            //if ( message_count == '' || isNaN(message_count) ) {
                //message_count = 0;
            //} else {
                //message_count = parseInt($(".message_count").html())
            //}
            //message_count++;
            //$(".message_count").html(""+message_count);
            $(".message_count").html(obj.Msg);
            $(".message_count").show();
            //iframe0.window.gritter_notify('Important Unread messages', 'You have 12 unread messages.');
        }
    }

    return ws;
}

