/**
 * 薪酬
 * @param obj
 * @param tag
 */

function vali_payment(obj,tag)
{
    console.log('vali_payment()')
    decimal(obj);

    var td_obj = $(obj).parent();
    var hidden_id = td_obj.data('hidden_id');
    var hidden_obj = $('input[name=level-'+hidden_id+']');

    var min_obj = hidden_obj.next();
    var normal_obj = hidden_obj.next().next();
    var max_obj = hidden_obj.next().next().next();
    /*var min_obj = td_obj.find('.input_min');
    var normal_obj = td_obj.find('.input_normal');
    var max_obj = td_obj.find('.input_max');*/

    var min_val = td_val(min_obj);
    var max_val = td_val(max_obj);
    var normal_val = td_val(normal_obj);


    if(tag=='normal'){
        if(normal_val<min_val || normal_val>max_val)
        {
            console.log(": "+min_val+' '+normal_val+' '+max_val);
            console.log('normal cancel');
            obj.value = '';

            return false;
        }else{
            return true;
        }
    }else if(tag=='min'){
        if(min_val>normal_val || min_val>max_val)
        {
            console.log(": "+min_val+' '+normal_val+' '+max_val);
            console.log('min cancel');
            obj.value = '';

            return false;
        }
    }else if(tag=='max'){
        if(max_val<normal_val || max_val<min_val)
        {
            console.log(": "+min_val+' '+normal_val+' '+max_val);
            console.log('max cancel');
            obj.value = '';
        }
    }

    return false;
}

function td_val(obj)
{
    var decimal = 0;
    if(obj.find('input').length>0)
    {
        decimal = parseFloat(obj.find('input').val());
    }else{
        decimal = parseFloat(obj.text());
    }

    return decimal;
}

function int(obj)
{
    obj.value = obj.value.replace(/[^\d]/g,'')
}

function decimal(obj)
{
    obj.value = obj.value.replace(/[^\d|^.]/g,'')
}

function log_focus() {
    //console.log($(':focus').val());
    document.focus_obj = $(':focus')[0];
}
