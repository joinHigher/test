$(function(){
    //后台返回返回url，指定返回页面
    function returnFn(){
        if(typeof url!="undefined"){
            $("#return-shareholder").attr("href",url);
        }else{
            $("#return-shareholder").attr("href","javascript:history.back(-1)");
        }
    }
    returnFn();
})
