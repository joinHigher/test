

$(function(){
    var saveArr = [],save=[];
    $("body").on("click",".onLevelWindow",function(){
        layer.open({
            type: 1,
            title: ["选择工作区域"],
            shade: 0.3,
            maxmin: true,
            shadeClose: false,
            area: ['780px','600px'],
            content: $(".call-selector"),
            btn: ['保存', '关闭'],
            btnAlign: 'c',
            yes:function(index, layero){
                saveArr=[];
                var saveStr = "";
                for(var i =0;i<selectArr.length;i++){
                    save = selectArr[i].save.split(",");
                    saveArr.push(save);
                    saveStr += '<span>'+selectArr[i].short_name+'</span>'
                }
                $("#save-area-wrap").html(saveStr);
                $(".area-hid").val(saveArr);
                callback(saveArr);
                layer.close(index);
            },
            success: function () {
                $.ajax({
                    url: '?ct=payment&ac=ajax_get_areas',
                    type: 'post',
                    data: {'parent_id': 0},
                    dataType:"JSON",
                    success:function(data){
                        var countryStr = '';
                        $.each(data,function(i,item){
                            countryStr += '<li >'+
                                '<a href="javascript:;" class="country has-child" data-id="'+item.id+'" data-level="'+item.level+'"><i class="fa fa-plus-square-o"></i>'+item.short_name+'</a>'+
                                '<ul></ul></li>'
                        })
                        $("#area").html(countryStr);
                    }
                }).done(function (rs) {

                }).fail(function (e) {
                    layer.alert('获取数据出错');
                })
            }
        });
    })
    //展开
    $("body").on("click",".has-child",open);
    var selectArr = [];
    function open(){
        var _this = $(this),_parent = _this.closest("li");
        var id = _this.data("id"),allName = _this.text(),level=_this.data("level");
        var cityStr = "",proviceStr="";
        if(_parent.hasClass("open")){
            _parent.removeClass("open")
        }else{
            _parent.siblings("li").removeClass("open");
            _parent.addClass("open");
        }

        $.ajax({
            url: '?ct=payment&ac=ajax_get_areas',
            type: 'post',
            data: {'parent_id': id},
            dataType:"JSON",
            success:function(data){
                if(_this.hasClass("country")){
                    proviceStr = '<li class="checkall"><label ><input type="checkbox" data-id ="'+id+'" value="'+id+'" data-save="'+id+",0" +",0"+'" data-name="'+allName+" "+allName+" 全部城市"+'" data-level="'+level+'">全选</label></li>';
                    $.each(data,function(i,item){
                        proviceStr += '<li class="item">'+
                            '<a href="javascript:;" class="province has-child" data-save="'+id+","+item.id+",0"+'" data-id="'+item.id+'" data-level="'+item.level+'" data-name="'+allName+" "+item.short_name+" 全部城市"+'"><i class="fa fa-plus-square-o"></i>'+item.short_name+'</a>'+
                            '<ul></ul></li>'
                    })
                    _this.siblings("ul").html(proviceStr);
                }else if(_this.hasClass("province")){
                    var ppName = _this.parents("li").find(".country").text();
                    var ppSave = _this.parents("li").find(".country").data("id");
                    var pName = _this.text();
                    var pSave = _this.data("id");
                    if(_parent.siblings(".checkall").find("input").is(':checked')){
                        cityStr = '<li class="checkall"><label ><input type="checkbox" data-id ="'+id+'" value="'+id+'" checked data-name="'+ppName+" "+allName+" 全部城市"+'" data-level="'+level+'" data-save="'+ppSave+","+id+",0"+'">全选</label></li>';
                        $.each(data,function(i,item){
                            cityStr += '<li class="city"><label ><input type="checkbox" data-save="'+ppSave+","+pSave+","+item.id+'" data-id ="'+item.id+'" value="'+item.id+'" checked data-name="'+ppName+" "+pName+" "+item.short_name+'" data-level="'+item.level+'" class="check">'+item.short_name+'</label></li>'
                        })
                    }else{
                        cityStr = '<li class="checkall"><label ><input type="checkbox" data-id ="'+id+'" value="'+id+'" data-name="'+ppName+" "+allName+" 全部城市"+'"  data-level="'+level+'" data-save="'+ppSave+","+id+",0"+'">全选</label></li>';
                        $.each(data,function(i,item){
                            cityStr += '<li class="city"><label ><input type="checkbox" data-save="'+ppSave+","+pSave+","+item.id+'" data-id ="'+item.id+'" value="'+item.id+'" data-name="'+ppName+" "+pName+" "+item.short_name+'" class="check" data-level="'+item.level+'">'+item.short_name+'</label></li>'
                        })
                    }
                    _this.siblings("ul").html(cityStr);

                    _this.siblings("ul").find("li").each(function(){
                        var name = $(this).find("input").data("name");
                        if(JSON.stringify(selectArr).indexOf(name)!=-1){
                            $(this).find("input").prop("checked",true);
                        }
                    })
                    if(_this.siblings("ul").find("li.checkall").find("input").is(":checked")){
                        _this.siblings("ul").find("li").each(function(){
                            $(this).find("input").prop("checked",true);
                        })
                    }

                }
                edit(selectArr);
            }
        }).done(function (rs) {

        }).fail(function (e) {
            layer.alert('获取数据出错');
        })

        //判断是否以加入数组中
        if(JSON.stringify(selectArr).indexOf(allName)!=-1){
            var checkboxs = _this.siblings("ul").find('[type=checkbox]');
            checkboxs.each(function(i){
                if(!this.checked){
                    $(this).prop('checked',true);
                }
            })
        }


    }

    function edit(data){
        var checkboxs = $("#area").find('input[type="checkbox"]');
        checkboxs.each(function(){
            var tip = $(this).data("name");
            if(JSON.stringify(selectArr).indexOf(tip)!=-1){
                $(this).prop('checked',true);
            }
        })
    }

    //全选操作
    $("#area").on('change',".checkall input",function(){
        var _this = $(this),
            _level = $(this).data("level"),
            _id=_this.data("id"),
            _name=_this.data("name"),
            _save = _this.data("save");
        var checkboxs = _this.closest("ul").find('[type=checkbox]');

        if(this.checked){
            checkboxs.each(function(i){
                if(!this.checked){
                    $(this).prop('checked',true);
                }
            })
            if(_level==-1){
                checkboxs.each(function(i){
                    var cid = $(this).data("id");
                    arrRemove(selectArr,cid)
                })
                objToArr(selectArr,_name,_id,_level,_save);

                _this.parents(".checkall").siblings(".item").find(".has-child").each(function(){
                    priid = $(this).data("id");
                    arrRemove(selectArr,priid);
                })

            }else{

                var sib = _this.parents(".checkall").siblings(".city").find("input");
                sib.each(function(){
                    var sibname = $(this).data("name"),
                        sibid = $(this).data("id"),
                        level = $(this).data("level");
                    arrRemove(selectArr,sibid);
                })
                var pckall = _this.parents(".item").siblings(".checkall").children("input");
                objToArr(selectArr,_name,_id,_level,_save);


            }
        }else{
            var pid = $(this).closest("li.open").siblings(".checkall").find("input").val();
            arrRemove(selectArr,_id);
            if($(this).closest("li.open").siblings(".checkall").find("input").is(":checked")){
                arrRemove(selectArr,pid);
            }
            if(_level==1){
                if($(this).closest("li.open").siblings(".checkall").find("input").is(":checked")){
                    $(this).closest("li.open").siblings(".item").find("a.has-child").each(function(){
                        var id = $(this).data("id"),
                            name = $(this).data("name"),
                            level = $(this).data("level"),
                            save = $(this).data("save");
                        objToArr(selectArr,name,id,level,save);
                    })
                }else{

                }
            }
            checkboxs.each(function(){
                var id = $(this).val();pid = $(this).closest("li.open").siblings(".checkall").find("input").val();
                if(this.checked){
                    $(this).prop('checked',false);
                    $(this).closest("li.open").siblings(".checkall").find("input").prop('checked',false);
                }
            })

        }
        leftCreate(this,selectArr);
    });

    //del
    function arrRemove(arr,id){
        var index = -1;
        arr.forEach(function(item,i){
            if(item.id == id) index = i;
        });
        if(index!=-1)
            arr.splice(index, 1)

    }
    //push
    function objToArr(arr,name,id,level,save){
        var obj = {};
        obj.id = id;
        obj.short_name = name;
        obj.level = level;
        obj.save = save;
        if(JSON.stringify(arr).indexOf(name)==-1) arr.push(obj);
    }

    //单选
    $("#area").on("change",".check",function(){

        var _this = $(this),
            id = _this.val(),
            name=_this.data("name"),
            level=_this.data("level"),
            save = _this.data("save");
        var p =_this.closest("ul").find(".checkall").find("input");
        var pp =_this.closest("ul").closest("li").siblings(".checkall").find("input");
        var pid = p.val(),ppid=pp.val();

        if(this.checked){
            objToArr(selectArr,name,id,level,save);
        }else{

            arrRemove(selectArr,id);

            if(p.is(':checked') && !pp.is(":checked")){
                arrRemove(selectArr,pid);

                var check = _this.closest(".city").siblings(".city").find("input");
                check.each(function(){
                    var name = $(this).data("name"),
                        id = $(this).val(),
                        level = $(this).data("level"),
                        save = $(this).data("save");

                    objToArr(selectArr,name,id,level,save);
                })
            }

            if(pp.is(":checked")){

                arrRemove(selectArr,ppid);

                var check = _this.closest(".city").siblings(".city").find("input");
                check.each(function(){
                    var name = $(this).data("name"),
                        id = $(this).val(),
                        level = $(this).data("level"),
                        save = $(this).data("save")
                    objToArr(selectArr,name,id,level,save);
                })

                var pri = _this.closest(".open").siblings(".item").find(".has-child");
                pri.each(function(){
                    var priname = $(this).data("name"),
                        priid = $(this).data("id"),
                        prilevel = $(this).data("level"),
                        prisave = $(this).data("save");
                    objToArr(selectArr,priname,priid,prilevel,prisave);
                })



            }
            p.prop('checked',false);
            pp.prop('checked',false);

        }
        leftCreate(this,selectArr);
    })

    //左侧
    function leftCreate(e,arr){
        var _this = $(e);
        var leftstr = "";
        //var level = _this.data("level");
        $.each(arr,function(i,item){
            if(item.level==-1 || item.level==1){
                leftstr += '<li class="left-item" data-name="'+item.short_name+'" data-id="'+item.id+'"><span >'+item.short_name+'</span> <i class="fa fa-close"></i></li>'
            }else{
                leftstr += '<li class="left-item" data-name="'+item.short_name+'" data-id="'+item.id+'"><span>'+item.short_name+'</span> <i class="fa fa-close"></i></li>'
            }

        })

        $(".area-right ul").html(leftstr);
    }
    //左侧删除
    $(".area-right").on("click",".fa-close",function(){
        var _this = $(this);
        var id = _this.parents("li").data("id");
        _this.parents("li").remove();
        arrRemove(selectArr,id);
        $("#area").find("input[data-id="+id+"]").prop('checked',false).trigger('change');
    })
})
