/*var data = [
    {
        "id":"1",
        "name":"这是十个字这",
        "short_name":"这是十个字",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    },
    {
        "id":"2",
        "name":"机构注册asdf名称3",
        "short_name":"机构简称3这个",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    },
    {
        "id":"3",
        "name":"机构注册asdf名称3",
        "short_name":"机构简称3",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    },
    {
        "id":"4",
        "name":"机构注册名asdf称5.1",
        "short_name":"机构简称5",
        "superior":"0",
        "child_num":2,
        "child":[
            {
                "id":"5",
                "name":"机构名adf称1",
                "short_name":"机构简称",
                "superior":"6",
                "child_num":0,
                "child":[

                ]
            },
            {
                "id":"6",
                "name":"376845678",
                "short_name":"123",
                "superior":"6",
                "child_num":0,
                "child":[

                ]
            }
        ]
    },
    {
        "id":"7",
        "name":"注册34机构名34称5",
        "short_name":"简称",
        "superior":"0",
        "child_num":1,
        "child":[
            {
                "id":"8",
                "name":"机构34注册名称",
                "short_name":"123",
                "superior":"7",
                "child_num":0,
                "child":[

                ]
            }
        ]
    },
    {
        "id":"9",
        "name":"机构注册名34称345",
        "short_name":"132",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    },
    {
        "id":"10",
        "name":"科创有34限公司",
        "short_name":"ertyui",
        "superior":"0",
        "child_num":2,
        "child":[
            {
                "id":"11",
                "name":"dd43d",
                "short_name":"dd",
                "superior":"10",
                "child_num":2,
                "child":[
                    {
                        "id":"12",
                        "name":"ddaa1234sdfd",
                        "short_name":"dd",
                        "superior":"10",
                        "child_num":2,
                        "child":[
                            {
                                "id":"13",
                                "name":"assafadfasdffasfadf",
                                "short_name":"dd",
                                "superior":"10",
                                "child_num":0,
                                "child":[

                                ]
                            },
                            {
                                "id":"14",
                                "name":"3asf33sas4",
                                "short_name":"33",
                                "superior":"10",
                                "child_num":0,
                                "child":[

                                ]
                            }
                        ]
                    },
                    {
                        "id":"15",
                        "name":"3asfd34",
                        "short_name":"33",
                        "superior":"10",
                        "child_num":0,
                        "child":[

                        ]
                    }
                ]
            },
            {
                "id":"16",
                "name":"3asf334",
                "short_name":"33",
                "superior":"10",
                "child_num":0,
                "child":[

                ]
            }
        ]
    },
    {
        "id":"17",
        "name":"ddddadfddd",
        "short_name":"d",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    },
    {
        "id":"18",
        "name":"ad3",
        "short_name":"3",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    },
    {
        "id":"19",
        "name":"21342a453",
        "short_name":"123",
        "superior":"0",
        "child_num":1,
        "child":[
            {
                "id":"20",
                "name":"76q54",
                "short_name":"34",
                "superior":"15",
                "child_num":0,
                "child":[

                ]
            }
        ]
    },
    {
        "id":"21",
        "name":"45sadf63",
        "short_name":"多少",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    },
    {
        "id":"22",
        "name":"金边小伙伴asdfasdf机sadf构",
        "short_name":"小伙伴",
        "superior":"0",
        "child_num":1,
        "child":[
            {
                "id":"23",
                "name":"广州小伙adf伴机构",
                "short_name":"小伙伴",
                "superior":"19",
                "child_num":0,
                "child":[

                ]
            }
        ]
    },
    {
        "id":"24",
        "name":"福州小伙asdfaadfasdf伴机构1",
        "short_name":"小伙伴",
        "superior":"0",
        "child_num":0,
        "child":[

        ]
    }
]*/

$(function(){
    var saveArrDe = []
    $("body").on("click",".department-btn",function(){
        layer.open({
            type: 1,
            title: ["选择工作区域"],
            shade: 0.3,
            maxmin: true,
            shadeClose: false,
            area: ['780px','600px'],
            content: $(".department-select-wrap"),
            btn: ['保存', '关闭'],
            btnAlign: 'c',
            yes:function(index, layero){
                saveArrDe=[];
                var saveStrDe = "";
                for(var i =0;i<selectArrDe.length;i++){
                    saveArrDe.push(selectArrDe[i].id);
                    saveStrDe += '<span>'+selectArrDe[i].name+'</span>'
                }
                $("#save-department-wrap").html(saveStrDe);
                $(".department-hid").val(saveArrDe);
                jg_callback(saveArrDe);
                layer.close(index);
            },
            success: function () {
                $.ajax({
                    url: '?ct=payment&ac=ajax_get_organs',
                    type: 'post',
                    data: {"parent_id":0},
                    dataType:"JSON",
                    success:function(data){
                        getDate(data);
                    }
                }).done(function (rs) {

                }).fail(function (e) {
                    layer.alert('获取数据出错');
                })

            }
        });
    })



    function getDate(data){
        console.log(data)
        var firststr = '<li class="checkall"><label><input type="checkbox" data-name="全部机构" data-id="0" value="0"> 全选</label></li>';
        for(var i = 0;i<data.length;i++){
            if(data[i].child_num==0){
                firststr += '<li class="first-item"><label ><input type="checkbox" data-id ="'+data[i].id+'" value="'+data[i].id+'" data-name="'+data[i].name+'" class="check">'+data[i].name+'</label></li>'
            }else{
                firststr += '<li class="first-item">'+
                    '<label ><input type="checkbox" class="check" value="'+data[i].id+'" data-id ="'+data[i].id+'" data-name="'+data[i].name+'">'+data[i].name+'</label> ' +
                    '<a href="javascript:;" class="has-child2" data-id="'+data[i].id+'" >下级</a>'+
                    '</li>';
            }

        }
        $("#department").html(firststr);

        function getData(index){  //分步循环
                if(data[index].child){
                    var sideStr = "";
                    var arr = data[index].child;
                    function render(arr){
                        var i= 0,len=arr.length;
                        if(arr.child_num!=0){
                            var sideStr='<ul class="checkbox-item"><li class="checkall all"><label><input type="checkbox"  /> 全选</label></li>'
                        }else{
                            var sideStr='<ul class="checkbox-item">'
                        }

                        for(;i<len;i++){
                            if(arr[i].child_num!=0){
                                sideStr+='<li class="th-item">'+
                                    '<label ><input type="checkbox" class="check" data-id="'+arr[i].id+'" data-name="'+arr[i].name+'" value="'+arr[i].id+'">'+arr[i].name+'</label><a href="javascript:;" class="has-child2" data-id="'+arr[i].id+'" >下级</a>'
                                sideStr+=render(arr[i].child);
                            }else{
                                sideStr +='<li class="th-item"><label>'+
                                '<input type="checkbox" value="'+arr[i].id+'" class="check" data-id="'+arr[i].id+'" data-name="'+arr[i].name+'"/> '+arr[i].name+'</label>';
                            }
                            sideStr+='</li>';
                        }

                        sideStr+='</ul>';

                        return sideStr;
                    }
                    $("body").find(".first-item").eq(index).append(render(arr));
                }else{
                    return false
                }
            }
            $("body").find(".first-item").each(function(i) {
                getData(i);
            })
        edit(selectArrDe);
    }
    //展开
    $("body").on("click",".has-child2",open);
    var selectArrDe = [];

    function open(){
        var _this = $(this),_parent = _this.closest("li");
        var id = _this.data("id");

        if(_parent.hasClass("open")){
            _parent.removeClass("open")
        }else{
            _parent.siblings("li").removeClass("open");
            _parent.addClass("open");
        }

        var len =  _this.siblings("ul").find(".th-item").length;
        var flag = 0;
        _this.siblings("ul").find(".th-item").each(function(){
            if($(this).find("input").is(":checked")){
                flag++;
            }
        })
        if(flag==len){
            _this.siblings("ul").find(".checkall").find("input").prop('checked',true);
        }


    }

    function edit(data){
        var checkboxs = $("#department").find('input.check[type="checkbox"]');
        var len = checkboxs.length,flag = 0;
        checkboxs.each(function(){
            var tip = $(this).data("name");
            if(JSON.stringify(selectArrDe).indexOf(tip)!=-1){
                $(this).prop('checked',true);
                flag++;
            }
        })
        if(len==flag){
            $("#department>li.checkall input ").prop('checked',true);
        }
    }

    //全选操作
    $("#department").on('change',".checkall input",function(){
        var _this = $(this),
            _id=_this.data("id"),
            _name=_this.data("name");
        var checkboxs = _this.closest("ul").find('[type=checkbox]');
        var checks = _this.closest("ul").find('.check');  //单选
        if(this.checked){
            checkboxs.each(function(i){
                if(!this.checked){
                    $(this).prop('checked',true);
                }
            })
            checks.each(function(i){
               var name = $(this).data("name");
               var id = $(this).data("id");
                objToArr(selectArrDe,name,id);
            })
        }else{
            checkboxs.each(function(){
                var id = $(this).val();
                if(this.checked){
                    $(this).prop('checked',false);
                }
            })
            $("#department").find(".checkall").find("input").prop('checked',false);
            checks.each(function(i){
                var name = $(this).data("name");
                var id = $(this).data("id");
                arrRemove(selectArrDe,id);
            })
        }
        leftCreate(this,selectArrDe);
    });

    //del
    function arrRemove(arr,id){
        var index = -1;
        arr.forEach(function(item,i){
            if(item.id == id) index = i;
        });
        if(index!=-1)
            arr.splice(index, 1)

    }
    //push
    function objToArr(arr,name,id){
        var flag=false;
        var obj = {};
        obj.id = id;
        obj.name = name;
        for(var key in arr) {
            if(arr[key].id==id){
                flag=true;
                break;
            }
        }
        if(!flag){
            arr.push(obj);
        }
        // obj.name = name;
        // if(JSON.stringify(arr).indexOf(name)==-1) arr.push(obj);
    }

    //单选
    $("#department").on("change",".check",function(){
        var _this = $(this),
            id = _this.val(),
            name=_this.data("name");

        if(this.checked){
            objToArr(selectArrDe,name,id);
        }else{
            arrRemove(selectArrDe,id);
            $("#department").find(".checkall").find("input").prop('checked',false);
        }
        console.log(selectArrDe);
        leftCreate(this,selectArrDe);
    })

    //左侧添加
    function leftCreate(e,arr){
        var _this = $(e);
        var leftstr = "";
        $.each(arr,function(i,item){
            leftstr += '<li class="left-item" data-name="'+item.name+'" data-id="'+item.id+'"><span >'+item.name+'</span> <i class="fa fa-close"></i></li>'
        })

        $(".department-right ul").html(leftstr);
    }

    //左侧删除
    $(".department-right").on("click",".fa-close",function(){
        var _this = $(this);
        var id = _this.parents("li").data("id");
        _this.parents("li").remove();
        arrRemove(selectArrDe,id);
        $("#department").find("input[data-id="+id+"]").prop('checked',false).trigger('change');
    })
})
