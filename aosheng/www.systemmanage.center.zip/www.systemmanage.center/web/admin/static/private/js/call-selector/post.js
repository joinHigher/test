
$(function(){
    var saveArrDe = [];
    $("body").on("click",".department-btn",function(){
        if($("#department_id").val()==null || $("#department_id").val()==""){
            layer.msg("请先选择归属部门");
        }else{
            layer.open({
                type: 1,
                title: ["选择工作区域"],
                shade: 0.3,
                maxmin: true,
                shadeClose: false,
                area: ['780px','600px'],
                content: $(".department-select-wrap"),
                btn: ['保存', '关闭'],
                btnAlign: 'c',
                yes:function(index, layero){
                    saveArrDe=[];
                    for(var i =0;i<selectArrDe.length;i++){
                        saveArrDe.push(selectArrDe[i].id);
                    }
                    $("input[name='job_ids']").val(saveArrDe);
                    $("input[name='job_ids']").addClass("asdf")
                    //统计岗位
                    var len = 0;
                    $("body").find(".first-item").each(function(i,e){
                        $(e).find("input").each(function(i,e){
                            if($(e).is(":checked")){
                                len++;
                                return false;
                            }
                        })
                    })
                    $("input[name='job_count']").val(len);
                    $("input[name='people_count']").val(saveArrDe.length);
                    if(typeof jg_callback != "undefined"){
                        jg_callback(selectArrDe); //权利机构
                    }

                    var str = '已选择'+len+'个岗位，'+saveArrDe.length+'个员工'
                    $(".job-input").val(str);
                    if(saveArrDe.length!=0){
                        $(".job-input").closest("div").removeClass("has-error").addClass("has-success").find("span.help-block").remove();
                    }

                    layer.close(index);
                },

                success: function () {
                    $.ajax({
                        url: '?ct=department_room&ac=ajax_get_jobs',
                        type: 'post',
                        data: {"department_id":$("#department_id").val()},
                        dataType:"JSON",
                        success:function(data){
                            getDate(data);
                        }
                    }).done(function (rs) {

                    }).fail(function (e) {
                        layer.alert('获取数据出错');
                    })

                }
            });
        }

    })



    function getDate(data){
        console.log(data)
        var firststr = '<li class="checkall"><label><input type="checkbox" data-name="全部机构" data-id="0" value="0"> 全选</label></li>';
        for(var i = 0;i<data.length;i++){
            firststr += '<li class="first-item"><label ><i class="fa fa-plus-square-o"></i>'+data[i].name+'</label><a href="javascript:;" class="has-child2" data-id="\'+data[i].id+\'" >下级</a></li>'
        }
        $("#department").html(firststr);
        function getData(index){  //分步循环
                var pname = data[index].name;
                if(data[index].child){
                    var sideStr = "";
                    var arr = data[index].child;
                    function render(arr){
                        console.log(typeof arr)
                        var i= 0,len=arr.length;
                        if(arr.child_num!=0){
                            var sideStr='<ul class="checkbox-item"><li class="checkall all"><label><input type="checkbox"  /> 全选</label></li>'
                        }else{
                            var sideStr='<ul class="checkbox-item">'
                        }
                        var out = "";
                        for(;i<len;i++){
                            sideStr+='<li class="th-item">';
                            if(arr[i].outer_name==null){
                                out = "";
                            }else{
                                out = arr[i].outer_name==null;
                            }
                            if(arr[i].name==""){
                                sideStr+= '<label ><input type="checkbox" class="check" data-id="'+arr[i].id+'" data-name="'+arr[i].code+ " " +out+" 暂无" +'" value="'+arr[i].id+'">'+arr[i].code+ " " +out+' <span style="color:red;">暂无</span>' +'</label>';
                            }else{
                                sideStr+= '<label ><input type="checkbox" class="check" data-id="'+arr[i].id+'" data-name="'+arr[i].code+ " " +out+" " +arr[i].name+'" value="'+arr[i].id+'">'+arr[i].code+ " " +out+" " +arr[i].name+'</label>';
                            }
                            sideStr+='</li>';
                        }

                        sideStr+='</ul>';

                        return sideStr;
                    }
                    $("body").find(".first-item").eq(index).append(render(arr));
                }else{
                    return false
                }
            }
            $("body").find(".first-item").each(function(i) {
                getData(i);
            })
        edit(selectArrDe);
    }
    //展开
    $("body").on("click",".has-child2",open);
    var selectArrDe = [];

    function open(){
        var _this = $(this),_parent = _this.closest("li");
        var id = _this.data("id");

        if(_parent.hasClass("open")){
            _parent.removeClass("open")
        }else{
            _parent.siblings("li").removeClass("open");
            _parent.addClass("open");
        }

        var len =  _this.siblings("ul").find(".th-item").length;
        var flag = 0;
        _this.siblings("ul").find(".th-item").each(function(){
            if($(this).find("input").is(":checked")){
                flag++;
            }
        })
        if(flag==len){
            _this.siblings("ul").find(".checkall").find("input").prop('checked',true);
        }
    }



    function edit(){
        var editArr = $("input[name='job_ids']").val().split(',');
        console.log(editArr)
        var checkboxs = $("#department").find('input.check[type="checkbox"]');
        var len = checkboxs.length,flag = 0;
        checkboxs.each(function(){
            var id = $(this).data("id");
            for(var key in editArr) {
                if(editArr[key]==id){
                    $(this).prop('checked',true).trigger("change");
                    break;
                }
            }
        })
        if(len==flag){
            $("#department>li.checkall input ").prop('checked',true);
        }
    }

    //全选操作
    $("#department").on('change',".checkall input",function(){
        var _this = $(this),
            _id=_this.data("id"),
            _name=_this.data("name");
        var checkboxs = _this.closest("ul").find('[type=checkbox]');
        var checks = _this.closest("ul").find('.check');  //单选
        if(this.checked){
            checkboxs.each(function(i){
                if(!this.checked){
                    $(this).prop('checked',true);
                }
            })
            checks.each(function(i){
               var name = $(this).data("name");
               var id = $(this).data("id");
                objToArr(selectArrDe,name,id);
            })
        }else{
            checkboxs.each(function(){
                var id = $(this).val();
                if(this.checked){
                    $(this).prop('checked',false);
                }
            })
            $("#department").find(".checkall").find("input").prop('checked',false);
            checks.each(function(i){
                var name = $(this).data("name");
                var id = $(this).data("id");
                arrRemove(selectArrDe,id);
            })
        }
        leftCreate(this,selectArrDe);
    });

    //del
    function arrRemove(arr,id){
        var index = -1;
        arr.forEach(function(item,i){
            if(item.id == id) index = i;
        });
        if(index!=-1)
            arr.splice(index, 1)

    }
    //push
    function objToArr(arr,name,id){
        var flag=false;
        var obj = {};
        obj.id = id;
        obj.name = name;
        for(var key in arr) {
            if(arr[key].id==id){
                flag=true;
                break;
            }
        }
        if(!flag){
            arr.push(obj);
        }
        // obj.name = name;
        // if(JSON.stringify(arr).indexOf(name)==-1) arr.push(obj);
    }

    //单选
    $("#department").on("change",".check",function(){
        var _this = $(this),
            id = _this.val(),
            name=_this.data("name");

        if(this.checked){
            objToArr(selectArrDe,name,id);
        }else{
            arrRemove(selectArrDe,id);
            $("#department").find(".checkall").find("input").prop('checked',false);
        }
        console.log(selectArrDe);
        leftCreate(this,selectArrDe);
    })

    //左侧添加
    function leftCreate(e,arr){
        var _this = $(e);
        var leftstr = "";
        $.each(arr,function(i,item){
            leftstr += '<li class="left-item" data-name="'+item.name+'" data-id="'+item.id+'"><span >'+item.name+'</span> <i class="fa fa-close"></i></li>'
        })

        $(".department-right ul").html(leftstr);
    }

    //左侧删除
    $(".department-right").on("click",".fa-close",function(){
        var _this = $(this);
        var id = _this.parents("li").data("id");
        _this.parents("li").remove();
        arrRemove(selectArrDe,id);
        $("#department").find("input[data-id="+id+"]").prop('checked',false).trigger('change');
    })



    $("#department_id,#organ_id").on("change",function(){
        $("[name='job_ids'],[name='job_count'],.job-input,#leader_job_id").val("");
        $("#leader_job_id").html("<option>请选择<option>");
        $(".department-right ul").html("");
        selectArrDe=[];
    });
})
