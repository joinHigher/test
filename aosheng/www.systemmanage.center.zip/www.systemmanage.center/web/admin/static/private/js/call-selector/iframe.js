;(function(){
    function callIframe(target,opt){
        var self = this;
        this.$el = target;
        this.$title = opt.title || 'callSelector';
        if(!opt.url){
            throw new Error('请填写模版地址');
            return false;
        }
        this.$url = opt.url;
        this.$init = opt.init || [];

        this.$done = opt.done || function(){}
    }

    callIframe.prototype = {
        init: function () {
            var self = this;
            layer.open({
                type: 2,
                title: self.$title,
                shade: 0.3,
                maxmin: false,
                shadeClose: false,
                area: ['780px','600px'],
                content: self.$url,
                btn: ['保存', '关闭'],
                btnAlign: 'c',
                yes:function(index, layero){
                    if(self.$iframe){
                        var rs = self.$iframe.contentWindow.getResult();
                        self.$done(rs);
                    }
                    layer.close(index)
                },
                success: function (layero) {
                    self.$layer = layero;
                    self.$iframe = layero.find('iframe')[0];
                    if(self.$init.length){
                        $(self.$iframe).ready(function(){
                            self.$iframe.contentWindow.init(self.$init);
                        })
                    }
                },
            });
            return this.$el;
        }
    }

    $.fn.callIframe = function(opt){
        return new callIframe(this,opt).init();
    }

})();