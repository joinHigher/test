/**
 * 
 * ajax分页插件
 */

if (!Array.prototype.filter)
Array.prototype.filter = function(func, thisArg) {
  'use strict';
  if ( ! ((typeof func === 'Function' || typeof func === 'function') && this) )
      throw new TypeError();
  
  var len = this.length >>> 0,
      res = new Array(len), // preallocate array
      t = this, c = 0, i = -1;
  if (thisArg === undefined)
    while (++i !== len)
      // checks to see if the key was set
      if (i in this)
        if (func(t[i], i, t))
          res[c++] = t[i];
  else
    while (++i !== len)
      // checks to see if the key was set
      if (i in this)
        if (func.call(thisArg, t[i], i, t))
          res[c++] = t[i];
  
  res.length = c; // shrink down array to proper size
  return res;
};

;(function(){
    function Page(target,opt){
        this.el = target;
        this.pageNum = opt.num || 5, //每一页显示的数量，
        this.pageCount;
        this.$data = opt.data || []; //需要分页的数据

        this.show = []; //展示的数据

        this.page = 1 || opt.page;  //配置起始页数

        //页面条状监听
        this.change = opt.change || function(){} //页面跳转是触发
        
        if(toString.call(opt.filter) == '[object Function]'){
            //避免暴露太多参数到外部，此处只提供挂载元素和updte方法到外部
            opt.filter(this.el,this.update.bind(this));
        }

        //是否自定义render方法
        if(toString.call(opt.render) == '[object Function]'){
            this.optRender = opt.render //渲染函数
        }
        
        //是否自定义renderPage方法
        if(toString.call(opt.render) == '[object Function]'){
            this.optRenderPage = opt.renderPage
        }  
        this.init();
    }

    Page.prototype = {
        init:function(){
            this.pageCount = Math.ceil(this.$data.length / this.pageNum);
            this.show = this.getPageData(this.page);
            this.bind();
        },
        bind:function(){
            var foot = $(this.el).find('tfoot');
            var self = this;
            foot.on('click','a,button',function(){
                if($(this).hasClass('disabled') || $(this).hasClass('active')) return false;
                if(this.tagName.toUpperCase() == 'A'){
                    if($(this).hasClass('next')){
                        self.getPageData(parseInt(self.page) + 1);
                    }else if($(this).hasClass('prev')){
                        self.getPageData(parseInt(self.page) -1);
    
                    }else if($(this).hasClass('last')){
                        self.getPageData(self.pageCount);
                    }else {
                        var page = $.trim($(this).text());
                        self.getPageData(page);
                    }
                }else{
                    var page = foot.find('.page_no').val();
                    if(!isNaN(page)){
                        page = parseInt(page);
                        if(self.page == page) return false;
                        self.getPageData(page);
                    }
                }
                
            })
        },
        update:function(data){//目前仅在执行自定义filter的时候触发
            this.page = 1;
            this.$data = data;
            this.init();
        },
        getPageData:function(page){
            if(page < 1 || page > this.pageCount && this.pageCount != 0) return false;
            var clen = page * this.pageNum ,
                len = this.$data.length;
            var start = (page-1) * this.pageNum;
            var end = start + this.pageNum > len ? len : start + this.pageNum;

            this.page = page;
           
            var rs = this.$data.slice(start,end);
           
            this.render(rs);
            this.renderPage();
            this.change(this);
            return rs;
        },
        render:function(data){
            if(this.optRender){
                this.optRender(this,rs);
                return false;
            }

            var body = $(this.el).find('tbody');
            var html = '';
            $.each(data,function(idx,item){
                html += ' <tr>\
                                <td>\
                                    <input type="checkbox" value="'+item.id+'">\
                                </td>\
                                <td>'+item.sn+'</td>\
                                <td>'+item.nickname+'</td>\
                                <td>'+item.organization+'</td>\
                                <td>'+item.department+'</td>\
                                <td>'+item.jon+'</td>\
                            </tr>';
            });
            body.html(html);
        },
        renderPage:function(){
            if(this.optRenderPage){
                this.optRenderPage(this);
                return false;
            }

            var foot = $(this.el).find('tfoot');
            var html = '<tr><td colspan="6"><div class="fr"><div class="ibox-content"  id="pages-wrap">';
                html += '<span>共' + this.$data.length + '条</span> \n\
                <a class="prev '+ (this.page == 1 || this.pageCount == 0 ? 'disabled' : '') + '" href="javascript:void(0);">上一页</a> \n';
                if(this.pageCount>7){
                    if(this.page <= 4){
                        for(var i = 1;i<=5;i++){
                            if(i>0){
                                html += '<a '+ (this.page == i ? 'class="active"' : '') + ' href="javascript:void(0);">'+i+'</a> \n';
                            }
                        }
                        html += '<span>...</span> \n';
                        html += '<a href="javascript:void(0);">'+this.pageCount+'</a> \n';
                        
                        
                    }else if(this.page < this.pageCount-4){
                        html += '<a href="javascript:void(0);">1</a> \n';
                        html += '<span>...</span> \n';
                        html += '<a href="javascript:void(0);">'+(this.page -1)+'</a> \n';
                        html += '<a class="active" href="javascript:void(0);">'+this.page+'</a> \n';
                        html += '<a href="javascript:void(0);">'+(this.page + 1)+'</a> \n';
                        html += '<span>...</span> \n';
                        html += '<a href="javascript:void(0);">'+this.pageCount+'</a> \n';
                    }else{
                        html += '<a href="javascript:void(0);">1</a> \n';
                        html += '<span>...</span> \n';
                        for(var i = this.pageCount-4;i<=this.pageCount;i++){
                            html += '<a '+ (this.page == i ? 'class="active"' : '') + ' href="javascript:void(0);">'+i+'</a> \n';
                        }
                    }
                }else{
                    for(var i =1; i<= this.pageCount; i++){
                        html += '<a '+ (this.page == i ? 'class="active"' : '') + ' href="javascript:void(0);">'+i+'</a> \n';
                    }
                }
                
                
                html += '<a class="next '+ (this.page == this.pageCount || this.pageCount == 0 ? 'disabled' : '') + '" href="javsscript:void(0);">下一页</a>\
                <input type="text" class="page_no" value="'+this.page+'"><button type="button" class="btn">Go</button>\
            </div></div></td></tr>';

            foot.html(html);
        }
    }

    $.fn.callPage = function(option){
        return new Page(this,option);
    }
}())