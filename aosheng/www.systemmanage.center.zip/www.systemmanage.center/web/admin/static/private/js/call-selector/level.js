;(function(){
    function loadCss(path) {
        var head = document.getElementsByTagName('head')[0];
        if (!document.getElementById('css-call-level')) {
            var link = document.createElement('link');
            link.id = 'css-call-level';
            link.href = path;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            head.appendChild(link);
        }
    }

    function CallLevel(target,opt){
        var self = this;

        this.$el = target;

        self.$el.off('call.level.done');

        this.$title = opt.title || '添加';

        this.baseUrl = opt.baseUrl || 'static/private/js/call-selector/';
        

        this.$selectArr = {
            'xing':[],
            'zu':[]
        };

        this.$data = opt.data || {};
        this.$init = opt.init || function(){};

        this.$done = opt.done || function(){};

        //加载css
        loadCss(this.baseUrl + 'index.css');
    }

    CallLevel.prototype = {
        init:function(){
            var self = this;
            $.ajax({
                url: this.baseUrl + 'level.html',
                dataType: 'html',
            }).done(function (data) {
                layer.open({
                    type: 1,
                    title: self.$title,
                    shade: 0.3,
                    maxmin: true,
                    shadeClose: false,
                    area: ['780px','600px'],
                    content: data,
                    btn: ['保存', '关闭'],
                    yes: function (index, layero) {
                        self.$el.triggerHandler('call.level.done',self.$selectArr);
                        self.$done(self.$selectArr);
                        layer.close(index)
                    },
                    success: function (layero) {
                        self.$layer = layero;
                        self.bind();
                        self.renderOrigin(self.$data);

                        self.$init(function(rs){
                            var ca = {};
            
                            Object.keys(rs).forEach(function(key){
                                rs[key].forEach(function(i){
                                    if(!ca[key]) ca[key] = [];
                                    var item = self.getItemById(key,i);
                                    if(item !== null){
                                        ca[key].push(item);
                                        var checkbox = self.$origin.find('dt[data-type="'+key+'"]').siblings('dd').find('input[value=' + i + ']');
                                        checkbox.size() > 0 && !checkbox[0].checked && checkbox.prop('checked', true);
                                    }
                                    
                                })
                            });
                            self.$selectArr = ca 
                        })

                        self.renderSelected(self.$selectArr);
                    },
                });
            }).fail(function(e){
                throw e;
            });
            return this.$el;
        },
        bind:function(){
            var self = this;
            this.$parent = this.$layer.find('.call-selector');
            this.$origin = this.$parent.find('.call-selector-orgin');
            this.$selected = this.$parent.find('.call-selector-selected');
            this.$checkboxs = this.$origin.children('li').children('.checkbox').find('[type=checkbox]');
            //全选
            this.$parent.find('.all').find('[type=checkbox]').on('change',function(){
                if(this.checked){
                    this.$checkboxs.each(function(){
                        if(!this.checked){
                            $(this).prop('checked',true).trigger('change');
                        }
                    })
                }else{
                    this.$checkboxs.each(function(){
                        if(this.checked){
                            $(this).prop('checked',false).trigger('change');
                        }
                    })
                }
            });
        

            //左侧选中事件
            this.$origin.on('change', '[type=checkbox]', function () {
                var type = $(this).data('type');
                if(type == 1){//父节点
                    var checkboxs = $(this).parents('dt').siblings('dd').children('.checkbox').find('[type=checkbox]');
                    if(this.checked){
                        checkboxs.each(function(){
                            if(!this.checked){
                                $(this).prop('checked',true).trigger('change');
                            }
                        })
                    }else{
                        checkboxs.each(function(){
                            if(this.checked){
                                $(this).prop('checked',false).trigger('change');
                            }
                        })
                    }
                }else{
                    var id = $(this).val();
                    var type = $(this).parents('dd').siblings('dt').data('type');
                    if(this.checked){
                        var item = self.getItemById(type,id);
                        var idx = self.getSelectArrIndexById(self.$selectArr[type],item.id);
                            
                        if(idx === -1){
                            self.$selectArr[type].push(item);
                            self.renderSelected();
                        }
                    }else{
                        self.removeItem(id,type);
                    }

                    
                    

                }
                
            });

            //右侧删除
            this.$selected.on('click', '.close', function () {
                var id = $(this).data('id');
                var type = $(this).parents('dd').siblings('dt').data('type');
                self.removeItem(id,type);
            });
        },
        removeItem:function(id,type) {
                        
            var idx = this.getSelectArrIndexById(this.$selectArr[type],id);

            idx !== -1 && this.$selectArr[type].splice(idx, 1);
            this.renderSelected();
            var checkbox = this.$origin.find('dt[data-type="'+type+'"]').siblings('dd').find('input[value=' + id + ']');
            checkbox.size() > 0 && checkbox[0].checked && checkbox.prop('checked', false);
        },
        renderSelected:function(){
            var html = '';
            var self = this;
            Object.keys(this.$selectArr).forEach(function(key,i){
                if(self.$selectArr[key].length==0) return false;
                html += "<li>";
                html += '<dt style="display:none" data-type="' + key + '">' + (key == 'xing' ? '行政等级' : '组织架构') + '</dt>'
                self.$selectArr[key].forEach(function(item){
                    html += '<dd class="clearfix"><span>'+item.name+'</span><a href="javascript:void(0);" data-id="' + item.id + '"class="close"><i class="fa fa-close"></i></a></dd>';
                })
                html += "</li>"
            })
            
            this.$selected.html(html);

            
        },
        getItemById:function(type,id){
            var rs = null;
            this.$data[type] && this.$data[type].forEach(function(item){
                if(item.id == id){
                    rs = item;
                }
            })

            return rs;
        },
        renderOrigin:function(data){
            var html = '';
            var self = this;
            Object.keys(this.$data).forEach(function(key,i){
                html += "<li>";
                html += '<dt style="display:none" data-type="' + key + '">' + (key == 'xing' ? '行政等级' : '组织架构') + '</dt>'
                self.$data[key].forEach(function(item){
                    html += '<dd>';
                    html += '<div class="checkbox">\
                            <label>\
                                <input type="checkbox" value="' + item.id + '"> '+ item.name+'\
                            </label>\
                        </div>';
                    html += '</dd>'
                })
                html += "</li>"
            })
            
            this.$origin.html(html);
        },
        getSelectArrIndexById:function(arr,id){
            var index = -1;
            arr.forEach(function(item,i){
                if(item.id == id) index = i;
            });
            return index;
        }
    }


    $.fn.CallLevel = function(option){
        new CallLevel(this, option).init(); 
    }
})();