/*
 * File Created: 2018/03/10
 * Author:  dayao
 */
/**
 * 
 * config {
 * title //弹窗标题，
 * input //结果保存的input ，初始数据可以保存在这里，实力化插件的时候会读取这里的值
 * data ／／数据源
 * baseUrl 插件的路径，修改插件路径时需要陪着改选项，默认：static/plugin/call-selector/   
 * split //input里多项数据的分隔符 ，默认英文逗号','
 * load //这个为数据获取函数，列表获取数据途径与插件无关，获取数据后只需要通过cb传入给插件即可
 * }
 * 
 * 
 * */
;
(function () {
    function loadCss(path) {
        var head = document.getElementsByTagName('head')[0];
        if (!document.getElementById('css-call-selector')) {
            var link = document.createElement('link');
            link.id = 'css-call-selector';
            link.href = path;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            head.appendChild(link);
        }
    }

    function selectorCall(target, opt) {
        var self = this;
        this.$el = target;

        this.$title = opt.title || 'callSelector';

        this.$subTitle = opt.subTitle || ['未选择','已选择'];
        // this.$url = $.trim(opt.url) || '';
        this.selectArr = [];
        
        //改用$map管理，$data参数目前弃用
        this.$data = opt.data || {};
        this.$split = opt.split || ',';
        this.baseUrl = opt.baseUrl || 'static/private/js/call-selector/';

        this.$showFiled = opt.showFiled;
        this.$returnFiled = opt.returnFiled;

        this.$load = opt.load || function(){};

        this.$map = {};
        this.$uid = 0;
        
        if(!opt.input) {
            throw new Error('请指定保存数据的input');
        }

        this.$input = opt.input;

        //成功回调
        this.$done = opt.done || function(){};

        //加载css
        loadCss(this.baseUrl + 'index.css');
    }

    selectorCall.prototype = {
        getUid :function(){
            return this.$uid++;
        },
        init: function () {
            var self = this;

            $.ajax({
                url: this.baseUrl + 'tpl.html',
                dataType: 'html',
            }).done(function (data) {
                layer.open({
                    type: 1,
                    title: self.$title,
                    shade: 0.3,
                    maxmin: true,
                    shadeClose: false,
                    area: ['780px','600px'],
                    content: data,
                    btn: ['保存', '关闭'],
                    btnAlign: 'c',
                    yes:function(index, layero){
                        var rs = [];
                        var id = '';
                        if(self.selectArr.length>0){
                            id = self.selectArr[0].id
                        }
                        self.$input.val(id);
                        self.$done(self.selectArr);
                        layer.close(index)
                    },
                    success: function (layero) {
                        self.$layer = layero
                        self.bind();
                    },
                });
            }).fail(function (e) {
                throw e;
            });
            return this.$el;
        },
        bind: function () {
            var self = this;
            this.$parent = this.$layer.find('.call-selector');
            this.$nav = this.$parent.find(".call-selector-nav");
            this.$list = this.$parent.find(".call-selector-selected");
            this.$origin = this.$parent.find(".call-selector-orgin");

            this.$parent.find('.origin-box .stitle').text(this.$subTitle[0]);
            this.$parent.find('.selected-box .stitle').text(this.$subTitle[1]);
            // if(this.$url){
            //     this.loadOrigin();
            // }else{

            // }
            //没有全选
            this.$origin.siblings('.all').remove();
            
            //获取初始数据
            this.loadOrigin();
            this.setInitValue();
            
            //展开和收起是修改icon
            function toggleFa(el,show){
                if(show){
                    el.removeClass('fa-plus-square-o').addClass("fa-minus-square-o")
                }else{
                    el.removeClass('fa-minus-square-o').addClass("fa-plus-square-o")
                }
            }

            function chenkData(e){
                var ul = $(this).siblings('ul');
                if(ul.size() >0){
                    toggleFa($(this).find('i'),ul.hasClass('hide'));
                    ul.toggleClass('hide');
                }else{
                    var id = $(this).data('id');
                    if(!isNaN(id)){
                        var param = {id:id,el:this}
                        self.loadOrigin(param);
                        toggleFa($(this).find('i'),true);
                    }
                }
            }

            //左侧部门点击
            this.$origin.on('click','a',chenkData)

            //左侧选中事件
            this.$origin.on('change', '[type=checkbox]', function () {
                var id = $(this).val();
                var uid = $(this).data('uid')
                if(this.checked){

                    //单选
                    self.$origin.find('[type=checkbox]').prop('checked',false);
                    $(this).prop('checked',true);
                    self.setList(self.$map[uid]);
                }else{
                    self.removeItem(id);
                }
            })

            //右侧删除
            this.$list.on('click', '.close', function () {
                var id = $(this).data('id');
                if (!isNaN(id)) {
                    self.removeItem(id);
                }
            });

        },
        removeItem: function (id) {
            var idx = this.getSelectArrIndexById(id);
            idx !== -1 && this.selectArr.splice(idx, 1);
            this.renderList();
            var checkbox = this.$origin.find('input[value=' + id + ']');
            checkbox.size() > 0 && checkbox[0].checked && checkbox.prop('checked', false);
        },
        setList: function (item) {
            this.selectArr = [];
            // if(this.getSelectArrIndexById(item.id) !== -1) return false;
            this.selectArr.push(item);
            this.renderList();
        },
        loadOrigin:function(param){
            var self = this;
            var id = param ? param.id : undefined;
            this.$load(id,function(rs){
                self.renderOrigin(param,rs);
            });
            return false;
        },
        setInitValue:function(){//设置初始数据，需要在拿到$data后才能设置
            var item = $(this.$el).data('cache');
            !!item && this.selectArr.push(item) && this.renderList();  
        },
        refreshOriginCheck:function(){
            var self = this;
            this.renderList();
            this.selectArr.forEach(function (item, i) {
                var checkbox = self.$origin.find('input[value=' + item.id + ']');
                checkbox.size() > 0 && !checkbox[0].checked && checkbox.prop('checked', true);
            });
        },
        renderNav:function(data){
            var len = data.length,
                html = '';

            data.forEach(function(item,i){
                if(i === len -1){
                    html += '<li class="active">' + item.name ;
                }else{
                    html += '<li><a href="javascript:void(0)" data-id="'+ item.id+'">'+item.name+'</a>';
                }
                html += '</li>';
            });

            this.$nav.html(html);
        },
        renderOrigin:function(param,data){
            var self = this;
                html = "";

            var el = param ? $(param.el).parent() : this.$origin;

            // var $data = {};

            data.forEach(function(item,i){
                if(item.chirend_id == "1"){
                    html += '<li>\
                            <a href="javascript:void(0);" data-id="' + item.id + '">\
                                <i class="fa fa-plus-square-o"></i>\
                                <span>' + item.name + '</span>\
                            </a>\
                        </li>';
                }else{
                    var uid = self.getUid();
                    item.uid = uid;
                    self.$map[uid] = item;
                    // $data[item.id] = item;
                    html += '<li>\
                        <div class="checkbox">\
                            <label>\
                                <input type="checkbox"  data-uid="'+uid+'" value="' + item.id + '"> ';
                    html +=   item.code ? '<span>' + item.code + '</span>' : '';
                    
                    html +=   item.name ? '<span>'+item.name+'</span>' : '<span class="text-danger">暂无名字</span>';
                    
                    html += '</label>\
                        </div>\
                    </li>'
                }
            })
           
            if(param){
                html = "<ul>" + html + "</ul>";
            }else{
                // this.$data = $data;
            }
            el.append(html);
            this.refreshOriginCheck();
        },
        renderList: function () {
            var self = this;
            this.$list.html('');
            this.selectArr.forEach(function (item, i) {
                var html = '<li class="clearfix">';
                html +=   item.code ? '<span>' + item.code + '</span>' : '';
                html +=   item.name ? '<span>'+item.name+'</span>' : '<span class="text-danger">暂无名字</span>';
                html += '<a href="javascript:void(0);" data-id="' + item.id + '"class="close"><i class="fa fa-close"></i></a></li>'
                self.$list.append(html);
            })
        },
        getSelectArrIndexById:function(id){
            var index = -1;
            this.selectArr.forEach(function(item,i){
                if(item.id == id) index = i;
            });
            return index;
        }
    }

    $.fn.callSelector = function (option) {
        return new selectorCall(this, option).init();
    }
})();