<?php
if( !defined('PHPCALL') ) exit('Request Error!');
/**
 * 默认缓存类
 *
 * 使用缓存应该比较注意的问题，没特殊原因一般都使用memcache或memcached作为缓存类型，对于很小规模的应用， 可以考虑用 file 作为缓存， 
 * 缓存进行 set/get/deldte 时务必指定 prefix，实际上系统最终得到的 key 是 base64_encode( self::df_prefix.'_'.$prefix.'_'.$key )
 * 为什么要这样做呢？
 * 因为memcache或memcached对应用缓存服务器群通常是很多网站一起使用的，如果没前缀区分，很容易会错把目标网站的同名缓存给clear掉
 *
 * @since 2011-07-20
 * @author seatle<seatle@foxmail.com>
 * @version $Id$
 */
define('CLS_CACHE', true);
class cache
{
    
   //缓存记录内存变量
   private $caches = array();
   
   //文件缓存系统或memcache游标
   private $handle = null;
   
   //缓存类型（file|memcache|memcached|redis）
   public static $cache_type = 'file';
   
   //key默认前缀
   private static $df_prefix = 'mc_df_';
   
   //默认缓存时间 2 小时，单位是秒
   private static $cache_time = 7200;
   
   //当前类实例
   private static $instance = null;
   
   //是否使用内存数组
   public static $need_mem = true;
   
   /**
    * 构造函数
    * @return void
    */
    public function __construct()
    {
        if( !$GLOBALS['config']['cache']['enable'] ) 
        {
            return;
        }
        self::$df_prefix  = $GLOBALS['config']['cache']['prefix'];
        self::$cache_time = $GLOBALS['config']['cache']['cache_time'];
        self::$cache_type = $GLOBALS['config']['cache']['cache_type'];
        if( self::$cache_type == 'file' )
        {
            $this->handle = cls_filecache::factory( $GLOBALS['config']['cache']['cache_name'] );
        }
        else if( self::$cache_type == 'memcached' )
        {
            $this->handle = new Memcached();
            $servers = array();
            foreach ( $GLOBALS['config']['cache']['memcache']['servers'] as $mc )
            {
                $servers[] = array($mc["host"], $mc["port"], $mc["weight"]);            
            }
            // 压缩数据
            //$this->handle->setOption(Memcached::OPT_COMPRESSION, true);
            $this->handle->setOption(Memcached::OPT_CONNECT_TIMEOUT, $GLOBALS['config']['cache']['memcache']['timeout']);
            //$this->handle->setOption(Memcached::OPT_BINARY_PROTOCOL, true); // 支持redis
            //$this->handle->setSaslAuthData('username', 'password');
            $this->handle->addServers( $servers );
        }
        else if( self::$cache_type == 'memcache' )
        {
            $this->handle = new Memcache();
            foreach ( $GLOBALS['config']['cache']['memcache']['servers'] as $mc )
            {
                $this->handle->addServer($mc["host"], $mc["port"], false, $mc["weight"], $GLOBALS['config']['cache']['memcache']['timeout']);            
            }
        }
        else if( self::$cache_type == 'redis' )
        {
            $config = $GLOBALS['config']['redis'];
            $this->handle = new Redis();
            $this->handle->connect( $config['host'], $config['port'], $config['timeout']);
            if ( !empty($config['pass']) )
            {
                if ( !$this->handle->auth($config['pass']) ) 
                {
                    trigger_error("Redis Server authentication failed!!");
                }
            }

        }
    }
    
   /**
    * 为自己创建实例，以方便对主要方法进行静态调用
    */
    protected static function _check_instance()
    {
        if( !$GLOBALS['config']['cache']['enable'] ) 
        {
            return false;
        }
        if( self::$instance == null )
        {
            self::$instance = new cache();
        }
        return self::$instance;
    }
   
   /**
    * 获取key
    */
    protected static function _get_key($prefix, $key)
    {
        //$key = md5(cache::$df_prefix.'_'.$prefix.'_'.$key);
        //return $key;
        $key = base64_encode(cache::$df_prefix.'_'.$prefix.'_'.$key);
        if( strlen($key) > 32 ) $key = md5( $key );
        return $key;
    }

   /**
    * 增加/修改一个缓存
    * @param $prefix     前缀
    * @parem $key        键(key=base64($prefix.'_'.$key))
    * @param $value      值
    * @parem $cachetime  有效时间，单位是秒(0不限, -1使用系统默认)
    * @return void
    */               
    public static function set($prefix, $key, $value, $cachetime=-1)
    {
        if( self::_check_instance()===false ) 
        {
            return false;
        }
        if( $cachetime == -1 ) 
        {
            $cachetime = self::$cache_time;
        }
        $cachekey = self::_get_key($prefix, $key);
        if( self::$need_mem ) 
        {
            self::$instance->handle->caches[ $cachekey ] = $value;
        }

        // redis 扩展无法跟memcached、memcache一样直接传数组，所以需要先转json
        if( self::$cache_type == 'redis' ) 
        {
            $value = is_array($value) ? json_encode($value) : $value;
            return self::$instance->handle->setex($cachekey, $cachetime, $value);
        } 
        // memcached
        elseif( self::$cache_type == 'memcached' ) 
        {
            return self::$instance->handle->set($cachekey, $value, $cachetime);
        }
        // memcache、file
        else 
        {
            return self::$instance->handle->set($cachekey, $value, 0, $cachetime);
        }
    }
    
   /**
    * 删除缓存
    * @param $prefix     前缀
    * @parem $key        键
    * @return void
    */               
    public static function del($prefix, $key)
    {
        if( self::_check_instance()===false ) 
        {
            return false;
        }
        $cachekey = self::_get_key($prefix, $key);
        if( isset(self::$instance->handle->caches[ $cachekey ]) ) 
        {
            self::$instance->handle->caches[ $cachekey ] = false;
            unset(self::$instance->handle->caches[ $cachekey ]);
        }
        return self::$instance->handle->delete( $cachekey );
    }
    
   /**
    * 读取缓存
    * @param $prefix     前缀
    * @parem $key        键
    * @return void
    */               
    public static function get($prefix, $key)
    {
        //全局禁用cache(调试使用的情况)
        if( defined('NO_CACHE') && NO_CACHE ) 
        {
            return false;
        }
        if( self::_check_instance()===false ) 
        {
            return false;
        }
        $cachekey = self::_get_key($prefix, $key);
        if( isset(self::$instance->handle->caches[ $cachekey ]) ) 
        {
            return self::$instance->handle->caches[ $cachekey ];
        }
        if( self::$cache_type == 'redis' ) 
        {
            $value = self::$instance->handle->get( $cachekey );
            return util::is_json($value) ? json_decode($value, true) : $value;
        }
        else 
        {
            return self::$instance->handle->get( $cachekey );
        }
    }
       
    public static function has($prefix, $key)
    {
        return self::get($prefix, $key) ? true : false;
    }

    /**
     * 自增缓存（针对数值缓存）
     * @access public
     * @param  string $name 缓存变量名
     * @param  int    $step 步长
     * @return false|int
     */
    public static function inc($prefix, $key, $step = 1)
    {
        if( self::_check_instance()===false ) 
        {
            return false;
        }
        $cachekey = self::_get_key($prefix, $key);
        if( in_array(self::$cache_type, array('memcached', 'memcache')) ) 
        {
            if (!self::has($prefix, $key)) 
            {
                self::set($prefix, $key, 0);
            }
            return self::$instance->handle->increment( $cachekey, $step );
        }
        elseif( self::$cache_type == 'redis' ) 
        {
            return self::$instance->handle->incrby( $cachekey, $step );
        }
        else 
        {
            $value = (int)self::get($prefix, $key) + $step;
            return self::set($prefix, $key, $value, 0) ? $value : false;
        }
    }

    /**
     * 自减缓存（针对数值缓存）
     * @access public
     * @param  string $name 缓存变量名
     * @param  int    $step 步长
     * @return false|int
     */
    public static function dec($prefix, $key, $step = 1)
    {
        if( self::_check_instance()===false ) 
        {
            return false;
        }
        $cachekey = self::_get_key($prefix, $key);
        if( in_array(self::$cache_type, array('memcached', 'memcache')) ) 
        {
            if (!self::has($prefix, $key)) 
            {
                self::set($prefix, $key, 0);
            }
            return self::$instance->handle->decrement( $cachekey, $step );
        }
        elseif( self::$cache_type == 'redis' ) 
        {
            return self::$instance->handle->decrby( $cachekey, $step );
        }
        else 
        {
            $value = (int)self::get($prefix, $key) - $step;
            return self::set($prefix, $key, $value, 0) ? $value : false;
        }
    }

   /**
    * 清除保存在缓存类的缓存
    * @return void
    */               
    public static function free_mem($flush_memc = false)
    {
        if( isset(self::$instance->handle->caches) ) 
        {
            self::$instance->handle->caches = array();
        }
        
        if ($flush_memc)
        {
            return self::$instance->handle->flush();
        }
        
        return true;
    }
    
   /**
    * 关闭链接
    * @return void
    */               
    public static function free()
    {
        //if( self::_check_instance()===false ) 
        // 前面没有初始化成功，就不要在去初始化了，这里都要关闭连接了还去初始化
        if( self::$instance == null ) 
        {
            return false;
        }
        if( self::$cache_type == 'memcached' ) 
        {
            self::$instance->handle->quit();
        }
        else
        {
            self::$instance->handle->close();
        }
    }
    
   /**
    * 重设cache参数(使用其它缓存文件)
    * @return void
    */               
    public static function reconfig( $config )
    {
        $GLOBALS['config']['cache'] = $config;
        if( self::$instance != null )
        {
            if( self::$cache_type == 'memcached' ) 
            {
                self::$instance->handle->quit();
            }
            else
            {
                self::$instance->handle->close();
            }
            self::$instance = null;
        }
        return self::_check_instance();
    }
}

/* vim: set expandtab: */

