<?php
defined('PHPCALL') or exit('Request Error!');

class cls_aes
{
    private static $_instance;

    private $_key = '';  // 密钥
    private $_iv = '';   // 向量

    // 单例模式
    public static function instance()
    {
        if (!self::$_instance instanceof self) 
        {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function set_key($key)
    {
        $this->_key = $key;
    }

    public function set_iv($iv)
    {
        $this->_iv = $iv;
    }

    /**
     * 加密
     */
    public function encrypt($value)
    {
        // openssl 需要补码
        $value = $this->pkcs5_pad($value);
        $value = openssl_encrypt($value, "aes-128-cbc", $this->_key, OPENSSL_RAW_DATA|OPENSSL_ZERO_PADDING, $this->_iv);
        return $value;
    }

    /**
     * 解密
     */
    public function decrypt($value)
    {
        $value = openssl_decrypt($value, "aes-128-cbc", $this->_key, OPENSSL_RAW_DATA|OPENSSL_ZERO_PADDING, $this->_iv);
        $value = $this->pkcs5_unpad($value);
        return $value;
    }

    /**
     * pkcs7补码，CBC加密方式必须补码
     * @param string $string  明文
     * @return String
     */ 
    public function pkcs5_pad($str)
    {
        $blocksize = openssl_cipher_iv_length("aes-128-cbc");   // 拿到blocksize（字节）
        //$blocksize = 16;
        $len = strlen($str);                                    // 拿到明文的长度
        if ($len % $blocksize != 0)
        {
            $pad = $blocksize - ($len % $blocksize);            // 算出最后一段需要补码的长度
            $str .= str_repeat(chr($pad), $pad);                // 取得ASCII码为补码长度的字符，用该字符把最后一段填满
        }
        return $str;
    }
 
    /**
     * 除去pkcs7补码
     * 
     * @param string 解密后的结果
     * @return string
     */
    public function pkcs5_unpad($str)
    {
        // 获取最后一个字符，其实就是补码那个字符，计算它的ASCII码，其实就是补码的长度
        $pad = ord($str{strlen($str)-1});
        // 补码的长度比字符串长度还长，说明没有补码，直接返回字符串
        if ($pad > strlen($str))                                    
        {
            return $str;
        }
        // 截取补码长度个字符，检查这个字符是否在这个区间出现的次数跟它的数值相等
        if( strspn($str, chr($pad), strlen($str) - $pad) != $pad )
        {
            return $str;
        }
        // 去掉补码，返回数据
        return substr($str, 0, (strlen($str) - $pad));          
    }

}

/* vim: set expandtab: */

/*
注意：
用了OPENSSL_RAW_DATA|OPENSSL_ZERO_PADDING才能和mcrypt匹配得上，但是又需要补码，php得补码和其他语言不同，所有java解不开
不用OPENSSL_RAW_DATA|OPENSSL_ZERO_PADDING和mcrypt匹配不上，java也解不开，所以貌似openssl是没法用了

参考微信做法：
https://github.com/gaoming13/wechat-php-sdk/tree/master/src/WechatPhpSdk/Utils

js加密：
首先引入这几个js文件
下载地址http://pan.baidu.com/s/1sjNpESd
<script type="text/javascript" src="/CryptoJS/aes.js"></script>
<script type="text/javascript" src="/CryptoJS/pad-zeropadding.js"></script>
<script type="text/javascript">
var data="test";//加密字符串
var key  = CryptoJS.enc.Latin1.parse('@12345678912345!');//密钥
var iv   = CryptoJS.enc.Latin1.parse('@12345678912345!');//与密钥保持一致
//加密
var data = JSON.stringify(data);//将数据对象转换为json字符串
var encrypted = CryptoJS.AES.encrypt(data,key,{iv:iv,mode:CryptoJS.mode.CBC,padding:CryptoJS.pad.ZeroPadding});
encrypted=encodeURIComponent(encrypted);
document.write(decrypted);//输出加密后的字符串

//解密
var data="加密的字符串";
//key和iv和加密的时候一致
var decrypted = CryptoJS.AES.decrypt(data,key,{iv:iv,padding:CryptoJS.pad.ZeroPadding});
decrypted=decrypted.toString(CryptoJS.enc.Utf8);
document.write(decrypted);//输出解密后的数据
</script>
在实际用的时候和php传输中，js加密后的字符串里面的+被浏览器解析成了空格  然后php解密的时候出错；这里可以对加密之后的字符串做进一步处理encrypted=encodeURIComponent(encrypted);就没有这个问题了 * */
